#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/camera.h"

extern void fn_1_BD54(void);
extern void fn_1_B870(void);
extern void camera_get_extended_state_storage(__typeof__(lbl_1_bss_F68));
extern void lbl_8006DBAC(void);
extern void fn_8006F038(void *, void *, s16);
extern void lbl_8006DCDC(void);
extern s16 fn_1_6B48(s16 value);
extern void fn_1_6D2C(u32);
extern s32 lbl_1_bss_F78;
extern void fn_1_A2DF4(u32, u32, u32);
extern s8 fn_1_86624(void);
extern s8 fn_1_86634(s32 index);
extern void OSPanic(u8 *file, int line, u8 *message, ...);
extern u8 lbl_1_bss_F74;
extern u8 lbl_1_bss_F75;
extern f32 lbl_1_rodata_188;
extern s32 fn_1_8708(u8 mode, f32 *value0, f32 *value1);
extern void fn_1_8A0C(s16 index);
extern void fn_1_A6FE8(void);
extern void fn_1_8D08(GameCameraEntry *value);
extern f32 lbl_1_bss_1040;
extern f32 lbl_1_bss_1044;
extern void OSReport(const unsigned char *, ...);
extern u8 lbl_1_bss_103C[4];
extern u8 lbl_1_bss_108C[52];
extern u8 lbl_1_bss_1014;

extern s8 fn_1_86624(void);
extern s8 fn_1_86634(s32 index);
extern void OSPanic(u8 *file, int line, u8 *message, ...);
extern void fn_1_8A0C(s16 index);
extern void OSReport(const unsigned char *, ...);

extern f32 lbl_1_rodata_2E0[32];
extern f32 lbl_8006D6FC(f32 *value, void *target);
u32 fn_1_6514(u32);
extern struct fn_1_6400_lbl_801A6410 lbl_801A6410;
extern u32 fn_1_46B4(u32, u32, void *, u32);
extern f64 lbl_1_rodata_478;
extern f32 lbl_1_rodata_49C;
extern f32 lbl_1_bss_10C0[6];

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.30000001192092896f;
    s = 1.100000023841858f;
}
static const u32 fzgx_pool_table2[9] = {0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xBF800000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 55.0f;
    s = 0.0f;
    s = -10.0f;
    d = 0.5;
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table4[18] = {0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x40400000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1500.0f;
    s = 53.0f;
    s = 3.0f;
    s = 0.009999999776482582f;
    d = 0.05;
    s = 3.9999998989515007e-05f;
    s = 80.0f;
    s = 108.0f;
    s = 1.350000023841858f;
    s = 90.0f;
    s = 1.2000000476837158f;
    s = 0.20000000298023224f;
}
static const u32 fzgx_pool_table6[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.01;
    s = 0.05000000074505806f;
    s = 0.10000000149011612f;
    d = 0.15;
    s = 1.0f;
    s = 182.04444885253906f;
    s = 0.4000000059604645f;
}
static const u32 fzgx_pool_table8[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.12;
    s = 5000.0f;
}
static const u32 fzgx_pool_table10[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep10(void) { const u32 *volatile cp; cp = fzgx_pool_table10; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime11(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 1.2;
    d = 1.4;
    d = 1.7;
    d = 0.08;
    d = 0.2;
    d = 0.04;
    s = 0.5f;
}
static const u32 fzgx_pool_table12[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep12(void) { const u32 *volatile cp; cp = fzgx_pool_table12; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime13(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.1;
    s = 1.5f;
    s = 2.299999952316284f;
    s = 0.699999988079071f;
}
static const u32 fzgx_pool_table14[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep14(void) { const u32 *volatile cp; cp = fzgx_pool_table14; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime15(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.3;
    d = 55.0;
    d = 150.0;
    s = 65.0f;
    s = 0.00023668639187235385f;
    s = 60.0f;
    s = 0.00027777778450399637f;
    d = 7.19;
    s = 5.0f;
    s = 2.940000057220459f;
    d = 4503599627370496.0;
    s = -13.0f;
    s = -20.0f;
    s = 13.0f;
}
static const u32 fzgx_pool_table16[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep16(void) { const u32 *volatile cp; cp = fzgx_pool_table16; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime17(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.0;
    d = 3.0;
}
#pragma section code_type ".text"

struct Vec3 {
    f32 x;
    f32 y;
    f32 z;
};

struct Self {
    u8 pad_0[0x2];
    s16 id;
    u8 pad_4[0x6C];
    f32 fov;
};

struct Ent {
    u8 pad_0[0x7C];
    u32 flags;
};

struct Pool {
    f32 a_000;
    u8 pad_004[0x2C];
    f32 a_030;
    u8 pad_034[0xCC];
    f64 b_100;
    u8 pad_108[0x10];
    f64 b_118;
    u8 pad_120[0x70];
    f32 a_190;
    f32 a_194;
    f32 a_198;
    u8 pad_19C[0x4];
    f64 b_1A0;
    f64 b_1A8;
};

struct Big {
    u8 pad_0[0x30];
};

const f32 fzgx_pool_lbl_1_rodata_200 = 0.300000012f;
const u8 fzgx_pool_lbl_1_rodata_204[44] = {0x3F,0x8C,0xCC,0xCD,0x00,0x00,0x00,0x00,0x3F,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xBF,0x80,0x00,0x00,0x42,0x5C,0x00,0x00};
const f32 fzgx_pool_lbl_1_rodata_230 = 0.0f;
const u8 fzgx_pool_lbl_1_rodata_230__fzgx_offset_4[172] = {0xC1,0x20,0x00,0x00,0x3F,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x43,0x30,0x00,0x00,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x40,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x44,0xBB,0x80,0x00,0x42,0x54,0x00,0x00,0x40,0x40,0x00,0x00,0x3C,0x23,0xD7,0x0A,0x3F,0xA9,0x99,0x99,0x99,0x99,0x99,0x9A,0x38,0x27,0xC5,0xAC,0x42,0xA0,0x00,0x00,0x42,0xD8,0x00,0x00,0x3F,0xAC,0xCC,0xCD,0x42,0xB4,0x00,0x00,0x3F,0x99,0x99,0x9A,0x3E,0x4C,0xCC,0xCD,0x00,0x00,0x00,0x00,0x3F,0x84,0x7A,0xE1,0x47,0xAE,0x14,0x7B,0x3D,0x4C,0xCC,0xCD,0x3D,0xCC,0xCC,0xCD,0x3F,0xC3,0x33,0x33,0x33,0x33,0x33,0x33};
const u8 fzgx_pool_lbl_1_rodata_2E0[32] = {0x3F,0x80,0x00,0x00,0x43,0x36,0x0B,0x61,0x3E,0xCC,0xCC,0xCD,0x00,0x00,0x00,0x00,0x3F,0xBE,0xB8,0x51,0xEB,0x85,0x1E,0xB8,0x45,0x9C,0x40,0x00,0x00,0x00,0x00,0x00};
const f64 fzgx_pool_lbl_1_rodata_2E0__fzgx_offset_20 = 1.2;
const u8 fzgx_pool_lbl_1_rodata_2E0__fzgx_offset_28[16] = {0x3F,0xF6,0x66,0x66,0x66,0x66,0x66,0x66,0x3F,0xFB,0x33,0x33,0x33,0x33,0x33,0x33};
const f64 fzgx_pool_lbl_1_rodata_2E0__fzgx_offset_38 = 0.080000000000000002;
const u8 fzgx_pool_lbl_1_rodata_2E0__fzgx_offset_40[64] = {0x3F,0xC9,0x99,0x99,0x99,0x99,0x99,0x9A,0x3F,0xA4,0x7A,0xE1,0x47,0xAE,0x14,0x7B,0x3F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0xB9,0x99,0x99,0x99,0x99,0x99,0x9A,0x3F,0xC0,0x00,0x00,0x40,0x13,0x33,0x33,0x3F,0x33,0x33,0x33,0x00,0x00,0x00,0x00,0x3F,0xD3,0x33,0x33,0x33,0x33,0x33,0x33,0x40,0x4B,0x80,0x00,0x00,0x00,0x00,0x00};
const u8 fzgx_pool_lbl_1_rodata_360[40] = {0x40,0x62,0xC0,0x00,0x00,0x00,0x00,0x00,0x42,0x82,0x00,0x00,0x39,0x78,0x2F,0x05,0x42,0x70,0x00,0x00,0x39,0x91,0xA2,0xB4,0x40,0x1C,0xC2,0x8F,0x5C,0x28,0xF5,0xC3,0x40,0xA0,0x00,0x00,0x40,0x3C,0x28,0xF6};
const u8 fzgx_pool_lbl_1_rodata_388[8] = {0x43,0x30,0x00,0x00,0x00,0x00,0x00,0x00};
const f32 fzgx_pool_lbl_1_rodata_388__fzgx_offset_8 = -13.0f;
const f32 fzgx_pool_lbl_1_rodata_388__fzgx_offset_C = -20.0f;
const f32 fzgx_pool_lbl_1_rodata_388__fzgx_offset_10 = 13.0f;
const u8 fzgx_pool_lbl_1_rodata_388__fzgx_offset_14[4] = {0x00,0x00,0x00,0x00};
const f64 fzgx_pool_lbl_1_rodata_388__fzgx_offset_18 = 0.0;
const f64 fzgx_pool_lbl_1_rodata_388__fzgx_offset_20 = 3.0;
const u8 fzgx_pool_lbl_1_rodata_388__fzgx_offset_28[80] = {0x3F,0x94,0x7A,0xE1,0x47,0xAE,0x14,0x7B,0x42,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x40,0x60,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0xF0,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0xE8,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0xE9,0x99,0x99,0x99,0x99,0x99,0x9A,0x3F,0xE7,0x0A,0x3D,0x70,0xA3,0xD7,0x0A};
extern void lbl_8006DAEC(void *);
extern void *fn_1_8627C(s32);
extern void fn_1_862D4(void *, struct Vec3 *);
extern void fn_1_8636C(s32, void *);
extern void *lbl_8006DC6C(void *);
extern void lbl_8006E1B0(void *, void *);
extern int fn_1_20A5C(void *, void *);
extern u32 fn_1_15578(void *, void *, void *, void *, u32, void *, u32, u32, u32, u32);
extern u32 fn_8006E250(void *, void *);
extern void lbl_8006DB30(void);

static inline void fn_1_A888_setpos(f32 z, f32 y, f32 x) {
    *(f32 *)(0xE0000000 + 0x0C) = x;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
    *(f32 *)(0xE0000000 + 0x1C) = y;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
    *(f32 *)(0xE0000000 + 0x2C) = z;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
}

static inline void fn_1_A888_setpos2(f32 a, f32 b, f32 c) {
    *(f32 *)(0xE0000000 + 0x0C) = a;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
    *(f32 *)(0xE0000000 + 0x1C) = b;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
    *(f32 *)(0xE0000000 + 0x2C) = c;  /* fzgx-allow: A2 locked matrix, retail lis 0xe000 base */
}

#pragma opt_propagation off
f32 fn_1_A888(void *arg0) {
    f32 fzgx_live_;
    f32 *fzgx_value;
    f64 fzgx_live;
    struct Pool *pool;
    struct Self *self = (struct Self *)arg0;
    struct Ent *ent;
    s32 flag;
    u32 w3;
    u32 w2;
    u32 z1;
    struct Vec3 pos;
    u32 z0;
    struct Vec3 v3c;
    struct Vec3 v30;
    struct Vec3 v24;
    struct Vec3 v18;
    struct Big big;
    f32 res;
    f64 t;
    struct { f64 value; } val;
    f32 cur;
    f64 delta;
    f64 scaled;

    lbl_8006DAEC(self);
    ent = fn_1_8627C((s32)self->id);
    if (ent == 0) {
        return (0.0f);
    }
    flag = (s32)(((*(u32 *)((u8 *)ent + 0x7C)) >> 24) & 1);
    fn_1_862D4((void *)(s32)self->id, &pos);
    fn_1_8636C((s32)self->id, &big);
    lbl_8006DC6C(&big);

    fzgx_live = pos.x;
    fzgx_live_ = pos.y;
    fn_1_A888_setpos(pos.z, fzgx_live_, fzgx_live);

    fzgx_value = &(v3c.x);
    *fzgx_value = (0.0f);
    v3c.y = (-13.0f);
    v3c.z = (-20.0f);
    lbl_8006E1B0(&v3c, &v30);

    v3c.y = (13.0f);
    lbl_8006E1B0(&v3c, &v24);

    w3 = (u32)fn_1_20A5C(&v24, &w2);
    fn_1_15578(&v30, &v24, &w2, &v18, 0x80000 + 1, &w3, 1, 0, 0, 0);
    lbl_8006DC6C(&big);

{
    f64 fzgx_live_2;
    fzgx_live_2 = pos.x;
    fzgx_live_ = pos.y;
    fn_1_A888_setpos2(fzgx_live_2, fzgx_live_, pos.z);
}
    fn_8006E250(&v30, &v30);

    t = (1.2) + v30.y;
    if (t < (0.0)) {
        val.value = (0.0);
    } else if (t > (3.0)) {
        val.value = (3.0);
    } else {
        val.value = t;
    }
    res = (f32)val.value / (3.0);
    if (flag) {
        res = (0.300000012f);
    }
    cur = self->fov;
    scaled = (0.080000000000000002) * (res - cur);
    self->fov = (f32)(cur + scaled);
    lbl_8006DB30();
    return res;
}
#pragma opt_propagation reset
