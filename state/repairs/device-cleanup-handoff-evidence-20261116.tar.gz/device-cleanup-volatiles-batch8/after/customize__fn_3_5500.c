#include "types.h"

#include "rel/customize/globals.h"

typedef struct {
    u8 r, g, b, a;
} Color;

/* one port's buttons in lbl_1_bss_9F8 (4 x 0x14); retail rereads +0x10 for each test */
typedef struct {
    u8 pad_0[0x8];
    volatile u16 unk_8;  /* fzgx-allow: S2 volatile keeps the verified access order */
    u8 pad_A[0x6];
    u16 unk_10;
    u16 unk_12;
} Pad_1_bss_9F8;

/* retail reads and writes +0x0 as a word (lwz/stw), where globals.h types it as bytes */
typedef struct {
    u32 unk_0;
    s16 unk_4;
    s16 unk_6;
    s16 unk_8;
    u8 pad_A[0x1A];
    u32 unk_24;
    u8 pad_28[0x8];
} View_3_bss_F0;

extern Pad_1_bss_9F8 lbl_1_bss_9F8[];
extern s16 lbl_1_bss_96A;
extern s32 lbl_801A66B4;
extern u8 lbl_3_bss_6DD74;
extern u32 lbl_3_bss_6DD70;

extern int fn_1_4C10(void);
extern u32 fn_1_435C(u32);
extern void fn_1_426C(u32);
extern void fn_3_5A50(void);
extern void fn_1_53BD8(void *, f32, f32, f32, f32, f32);
extern u32 fn_1_4AEC0(u32);
extern void fn_1_4AEB4(f32);
extern void fn_1_49410(void);
extern void fn_1_4955C(f32, f32);
extern void fn_1_4954C(f32);
extern void fn_1_495C8(u8);
extern void fn_1_496FC(f32, f32);
extern void fn_1_4966C(f32, f32);
extern void fn_1_495B0(u32);
extern void fn_1_49590(f32);
extern void fn_1_4A0D8(const char *);
extern void fn_3_BFC(char *, void *, const char *, const char *);
extern void fn_3_E64(u8 *);
extern void fn_1_A2D84(u32);
extern s16 fn_3_5070(void); /* s16 here: retail keeps the result unextended and extsh-es it at each use */
extern void fn_80008BA8(void *, void *, u32);
extern void fn_1_FDFF4(void);
extern void fn_1_4A00(s32, u8, u32);
extern void fn_1_1280(u32);
extern s32 fn_3_B68(const s16 *);

/* the retail TU's .data objects this function uses, at their retail offsets, so MWCC addresses them off one
 * section base; the fzgx_pool_gap_ objects span the retail objects in between, which this function does not touch */
u16 fzgx_obj_lbl_3_data_0[0x54] = {1};
u8 fzgx_pool_gap_A8[0xC] = {1};
s32 fzgx_obj_lbl_3_data_B4 = 1;
s32 fzgx_obj_lbl_3_data_B8 = 1;
u8 fzgx_pool_gap_BC[0xE80 - 0xBC] = {1};
char *fzgx_obj_lbl_3_data_E80[2][6] = {{0}};
u8 fzgx_pool_gap_EB0[0x1C] = {1};
u8 fzgx_obj_lbl_3_data_ECC[0x34] = {1};
char *lbl_3_data_ECC__fzgx_offset_34[6] = {0};
u8 fzgx_pool_gap_F18[0x15CC - 0xF18] = {1};

/* the retail TU's .bss objects this function uses, likewise */
Obj_3_bss_0 fzgx_obj_lbl_3_bss_0;
u8 fzgx_pool_gap_8[0x10];
s16 fzgx_obj_lbl_3_bss_18;
s16 fzgx_pool_gap_1A;
u8 fzgx_pool_gap_1C;
u8 lbl_3_bss_18__fzgx_offset_5;
u8 fzgx_pool_gap_1E;
u8 fzgx_pool_gap_1F;
u8 fzgx_pool_gap_20[0xD0];
View_3_bss_F0 fzgx_obj_lbl_3_bss_F0;
s32 fzgx_obj_lbl_3_bss_120;
u8 fzgx_pool_gap_124[0x20850 - 0x124];
u32 fzgx_obj_lbl_3_bss_20850;
u8 fzgx_pool_gap_20854[0x24370 - 0x20854];
u32 fzgx_obj_lbl_3_bss_24370;
s32 (*lbl_3_bss_24370__fzgx_offset_4)(const s16 *);
s16 *lbl_3_bss_24370__fzgx_offset_8;
u8 fzgx_obj_lbl_3_bss_2437C[0x2C];
u32 fzgx_obj_lbl_3_bss_243A8;
u8 fzgx_pool_gap_243AC[0x14];
u8 fzgx_obj_lbl_3_bss_243C0[0x81C0];

/* fn_3_131C's body, which retail inlines here (y = 220) */
static inline void fn_3_131C_body(s32 y, char *text) {
    f32 scale;
    char buffer[0x400];

    fn_1_4AEC0(1);
    fn_1_4AEB4(1.5f);
    fn_1_49410();
    scale = 0.75f;
    fn_1_4955C(scale, scale);
    fn_1_4954C(0.09000000357627869f);
    fn_1_495C8(9);
    fn_1_496FC(320.0f, (f32)y);
    fn_1_4966C(-1.0f, 8.0f);
    if (lbl_801A66B4 != 5) {
        fn_1_495B0(0x80000000);
        fn_1_49590(0.5f);
        fn_1_4966C(-1.0f, 4.0f);
    }
    fn_3_BFC(buffer, text, "SLOT", fzgx_obj_lbl_3_data_E80[fzgx_obj_lbl_3_bss_2437C[0]][lbl_801A66B4]);
    fn_3_BFC(buffer, buffer, "SLOT", fzgx_obj_lbl_3_data_E80[fzgx_obj_lbl_3_bss_2437C[0]][lbl_801A66B4]);
    fn_3_BFC(buffer, buffer, "SLOT", fzgx_obj_lbl_3_data_E80[fzgx_obj_lbl_3_bss_2437C[0]][lbl_801A66B4]);
    fn_1_4A0D8(buffer);
    fn_1_4AEC0(0);
    fn_1_4AEB4(0.0f);
}

/* 1 when +0x24 bit 31 is set, +0x24 bit 0 and +0x0 bit 1 are clear, or fn_1_4C10 returns nonzero */
static inline s32 should_skip(void) {
    if ((fzgx_obj_lbl_3_bss_F0.unk_24 & 0x80000000) && !(fzgx_obj_lbl_3_bss_F0.unk_24 & 1) &&
        !(fzgx_obj_lbl_3_bss_F0.unk_0 & 2)) {
        return 1;
    }
    if (fn_1_4C10() != 0) {
        return 1;
    }
    return 0;
}

/* the shared exit of results 1 to 5: next mode, then fn_1_FDFF4 and fn_1_4A00 */
static inline void result_exit(s32 next) {
    fzgx_obj_lbl_3_bss_120 = next;
    fn_1_FDFF4();
    fn_1_4A00(0, 15, fzgx_obj_lbl_3_bss_20850);
    fzgx_obj_lbl_3_bss_243A8 = 0;
}

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_data_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits objects in first-access order */
    s = *(u8 *)&fzgx_obj_lbl_3_data_0;
    s = *(u8 *)&fzgx_pool_gap_A8;
    s = *(u8 *)&fzgx_obj_lbl_3_data_B4;
    s = *(u8 *)&fzgx_obj_lbl_3_data_B8;
    s = *(u8 *)&fzgx_pool_gap_BC;
    s = *(u8 *)&fzgx_obj_lbl_3_data_E80;
    s = *(u8 *)&fzgx_pool_gap_EB0;
    s = *(u8 *)&fzgx_obj_lbl_3_data_ECC;
    s = *(u8 *)&lbl_3_data_ECC__fzgx_offset_34;
    s = *(u8 *)&fzgx_pool_gap_F18;
}
/* the retail .rodata pool up to this function's literal at 0xDC, primed in first-use order */
static const u32 fzgx_pool_table1[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const u32 *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile f32 s;  /* fzgx-allow: S2 pool primer sink */
    s = 320.0f;
    s = 240.0f;
    s = 0.0010000000474974513f;
    s = 0.009999999776482582f;
    s = 0.5f;
    s = 480.0f;
    s = 2.0f;
    s = 176.0f;
}
static const u32 fzgx_pool_table3[7] = {0x00000000, 0x00000000, 0x41200000, 0x41200000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const u32 *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile f32 s;  /* fzgx-allow: S2 pool primer sink */
    s = 0.25f;
    s = 0.0f;
}
/* fn_3_12D4's body, which retail inlines here; defined at this point of the pool so its colour lands at 0x48 */
static inline void fn_3_12D4_body(void) {
    Color color = {255, 255, 255, 255};

    fn_1_53BD8(&color, 320.0f, 240.0f, 500.0f, 300.0f, 0.1f);
}
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) { fn_3_12D4_body(); }  /* fzgx-allow: S2 pool primer */
static const u32 fzgx_pool_table7[1] = {0xFFFFFFFF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const u32 *volatile cp; cp = fzgx_pool_table7; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime8(void) {
    volatile f32 s;  /* fzgx-allow: S2 pool primer sink */
    volatile f64 d;  /* fzgx-allow: S2 pool primer sink */
    s = 1.5f;
    s = -1.0f;
    s = 8.0f;
    s = 4.0f;
    s = 150.0f;
    s = 0.09000000357627869f;
    s = 30.0f;
    s = 0.550000011920929f;
    s = 0.75f;
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table9[21] = {0xA0505000, 0xA0A0A000, 0xFFFFFF00, 0x70707000, 0x00000000, 0x70707000, 0x00000000, 0xFFFFFF00, 0x3F800000, 0x43900000, 0x3DA3D70A, 0x41200000, 0x43B00000, 0xA0505000, 0xA0A0A000, 0xFFFFFF00, 0x70707000, 0x00000000, 0x70707000, 0x00000000, 0xFFFFFF00};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep9(void) { const u32 *volatile cp; cp = fzgx_pool_table9; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_bss_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits objects in first-access order */
    s = *(u8 *)&fzgx_obj_lbl_3_bss_0;
    s = *(u8 *)&fzgx_pool_gap_8;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_18;
    s = *(u8 *)&fzgx_pool_gap_1A;
    s = *(u8 *)&fzgx_pool_gap_1C;
    s = *(u8 *)&lbl_3_bss_18__fzgx_offset_5;
    s = *(u8 *)&fzgx_pool_gap_1E;
    s = *(u8 *)&fzgx_pool_gap_1F;
    s = *(u8 *)&fzgx_pool_gap_20;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_F0;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_120;
    s = *(u8 *)&fzgx_pool_gap_124;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_20850;
    s = *(u8 *)&fzgx_pool_gap_20854;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_24370;
    s = *(u8 *)&lbl_3_bss_24370__fzgx_offset_4;
    s = *(u8 *)&lbl_3_bss_24370__fzgx_offset_8;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_2437C;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_243A8;
    s = *(u8 *)&fzgx_pool_gap_243AC;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_243C0;
}
#pragma section code_type ".text"

void fn_3_5500(void) {
    s16 port;
    s16 result;
    u32 buttons;

    port = fzgx_obj_lbl_3_bss_F0.unk_6;
    if (fzgx_obj_lbl_3_bss_120 == -1) {
        fn_1_4C10();
    }
    if (should_skip()) {
        return;
    }

    if (fzgx_obj_lbl_3_bss_120 != -1) {
        if (!(fzgx_obj_lbl_3_bss_F0.unk_0 & 0x04000000)) {
            if (fzgx_obj_lbl_3_data_B8 != -1) {
                fn_1_435C(fzgx_obj_lbl_3_bss_20850);
                fn_1_426C(fzgx_obj_lbl_3_data_B8);
                fzgx_obj_lbl_3_data_B8 = -1;
            }
            fn_3_5A50();
        }
        lbl_1_bss_96A = fzgx_obj_lbl_3_bss_120;
        fzgx_obj_lbl_3_bss_120 = -1;
        return;
    }

    if (lbl_3_bss_18__fzgx_offset_5 != 0) {
        fn_3_12D4_body();
        fn_3_131C_body(220, lbl_3_data_ECC__fzgx_offset_34[lbl_801A66B4]);
        fn_3_E64(&lbl_3_bss_6DD74);
        if ((lbl_1_bss_9F8[port].unk_10 & 1) || (lbl_1_bss_9F8[port].unk_12 & 1)) {
            lbl_3_bss_6DD74 = 0;
            fn_1_A2D84(0xA9011300);
        }
        if (((lbl_1_bss_9F8[port].unk_10 >> 1) & 1) || ((lbl_1_bss_9F8[port].unk_12 >> 1) & 1)) {
            lbl_3_bss_6DD74 = 1;
            fn_1_A2D84(0xA9011300);
        }
        if ((lbl_1_bss_9F8[port].unk_8 >> 9) & 1) {
            lbl_3_bss_6DD74 = 1;
        }
        buttons = lbl_1_bss_9F8[port].unk_8;
        if (((buttons >> 8) & 1) || ((buttons >> 9) & 1)) {
            lbl_3_bss_18__fzgx_offset_5 = 0;
            if (lbl_3_bss_6DD74 == 0) {
                result = 6;
                fn_1_A2D84(0xA9010100);
            } else {
                fn_1_A2D84(0xA9010200);
                fzgx_obj_lbl_3_bss_120 = 0x5F;
                return;
            }
        } else {
            return;
        }
    } else {
        result = fn_3_5070();
        if (result == 6 && lbl_3_bss_18__fzgx_offset_5 == 0) {
            lbl_3_bss_18__fzgx_offset_5 = 1;
            return;
        }
    }

    if (result == -1) {
        fzgx_obj_lbl_3_bss_120 = 0x5C;
        return;
    }
    if (result != 0) {
        fn_80008BA8(fzgx_obj_lbl_3_bss_243C0, (u8 *)&lbl_3_bss_140 + fzgx_obj_lbl_3_bss_F0.unk_8 * 0x81C0, 0x81C0);
    }
    switch (result) {
    case 1:
        result_exit(0x6B);
        break;
    case 2:
        result_exit(0x60);
        break;
    case 3:
        result_exit(0x6B);
        break;
    case 4:
        result_exit(0x6C);
        break;
    case 5:
        result_exit(0x68);
        break;
    case 6:
        lbl_3_bss_6DD70 |= 1 << fzgx_obj_lbl_3_bss_F0.unk_8;
        fzgx_obj_lbl_3_bss_0.unk_0 = 1;
        fzgx_obj_lbl_3_bss_120 = 0x5D;
        fn_1_1280(1);
        fn_1_FDFF4();
        fzgx_obj_lbl_3_data_B4 = 0x5F;
        fzgx_obj_lbl_3_bss_F0.unk_0 |= 0x04000000;
        lbl_3_bss_24370__fzgx_offset_4 = fn_3_B68;
        lbl_3_bss_24370__fzgx_offset_8 = &fzgx_obj_lbl_3_bss_F0.unk_8;
        break;
    }
}
