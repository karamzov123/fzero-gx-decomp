#include "types.h"
#include "dolphin/hw_regs.h"

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} Fn6FFA0Vec;

typedef struct Fn6FFA0Car {
    u8 pad_00[0x18];
    s16 unk_18;
    u8 pad_1a[0x9e];
    u8 unk_b8[4];
} Fn6FFA0Car;

typedef struct Fn6FFA0Work {
    u8 pad_00[0xc];
    s16 unk_0c;
    u8 pad_0e[2];
    u32 unk_10;
    u8 pad_14[4];
    s16 unk_18;
    u16 unk_1a;
    u8 pad_1c[0xc];
    f32 unk_28;
    f32 unk_2c;
    u8 pad_30[0xc];
    Fn6FFA0Vec unk_3c;
    u8 pad_48[0xc];
    s16 unk_54;
    s16 unk_56;
    u8 pad_58[2];
    s16 unk_5a;
    s16 unk_5c;
    u8 pad_5e[0x8a];
} Fn6FFA0Work;

extern void *memset(void *dest, int value, u32 size);
extern void fn_1_867CC(s16 arg0, void *arg1);
extern u32 fn_1_58C4(void);
extern s16 camera_get_mode(void);
extern u16 fn_1_584AC(void);
extern s32 fn_1_66B8(void *arg0, f32 arg1);
extern void lbl_8006DC6C(void *arg0);
extern void mathutil_mtxA_rotate_y(s16 angle);
extern void mathutil_mtxA_rotate_x(s16 angle);
extern void lbl_8006E1B0(Fn6FFA0Vec *arg0, Fn6FFA0Vec *arg1);
extern s16 fn_1_59078(void *arg0);
extern u32 lbl_801A63C0;
/* Set the translation column of the current matrix (locked cache). */

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.0f;
    s = -1.0f;
    s = 25.0f;
    s = 15.0f;
    s = 8.0f;
    s = 150.0f;
    s = 10.0f;
    s = 0.5f;
    s = 0.125f;
    s = 32767.0f;
    s = 30.0f;
    s = 20.0f;
    s = 1200.0f;
    s = 0.15000000596046448f;
    d = 4503601774854144.0;
    d = 4503599627370496.0;
    s = 255.0f;
    s = 102.0f;
    d = 0.8;
    s = 1.600000023841858f;
    s = 3.0f;
    s = 0.009999999776482582f;
    s = 0.6000000238418579f;
    d = 0.3;
    s = 0.699999988079071f;
    s = 0.20000000298023224f;
    s = 0.4000000059604645f;
    s = 0.10000000149011612f;
    s = 1.5f;
}
static const u32 fzgx_pool_table2[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 2.0;
    s = 0.800000011920929f;
    s = 1.0f;
    s = 85.0f;
    s = 0.25f;
}
static const u32 fzgx_pool_table4[3] = {0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 100.0f;
    s = 3.5f;
    s = 23.0f;
    s = 60.0f;
    s = 4.0f;
}
static const u32 fzgx_pool_table6[1] = {0x34000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 136.0f;
    s = 0.029999999329447746f;
}
static const u32 fzgx_pool_table8[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.5;
    s = 0.30000001192092896f;
    s = 128.0f;
    s = 224.0f;
    s = 500.0f;
    s = 0.9300000071525574f;
    s = 5.0f;
    s = 2.0f;
    s = 0.05000000074505806f;
    s = 0.07999999821186066f;
    s = 0.8999999761581421f;
    d = 0.30000001192092896;
    d = 0.2;
    d = -0.3;
    d = -1.0;
    d = 0.0;
    d = 30.0;
    d = 3.0;
    s = 0.0010000000474974513f;
    s = 0.0020000000949949026f;
    s = 1.899999976158142f;
    s = 10000.0f;
    s = 3000.0f;
    s = 182.04444885253906f;
    s = 0.5647059082984924f;
    s = 0.6901960968971252f;
    s = 3.605555534362793f;
}
static const u32 fzgx_pool_table10[1] = {0x20000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep10(void) { const u32 *volatile cp; cp = fzgx_pool_table10; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime11(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 5.0;
    s = 1.7774999141693115f;
    s = -5.004882768844254e-05f;
    s = 16384.0f;
}
static const u32 fzgx_pool_table12[3] = {0x00000000, 0x3DCCCCCD, 0x3FC00000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep12(void) { const u32 *volatile cp; cp = fzgx_pool_table12; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime13(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 800.0f;
    s = 1000.0f;
    d = 0.05;
    d = 12.0;
    d = -0.16;
    d = 119.0;
    d = 2.5;
    d = 1.0;
    s = 1250.0f;
}
static const u32 fzgx_pool_table14[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep14(void) { const u32 *volatile cp; cp = fzgx_pool_table14; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime15(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.4;
    s = 300.0f;
}
static const u32 fzgx_pool_table16[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep16(void) { const u32 *volatile cp; cp = fzgx_pool_table16; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime17(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.20000000298023224;
    s = 2500.0f;
    s = 5000.0f;
    d = 0.1;
    d = 50.0;
    d = 0.0003;
    d = 0.02;
    s = 1.2000000476837158f;
}
static const u32 fzgx_pool_table18[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep18(void) { const u32 *volatile cp; cp = fzgx_pool_table18; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime19(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.6;
    s = 44.0f;
}
static const u32 fzgx_pool_table20[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep20(void) { const u32 *volatile cp; cp = fzgx_pool_table20; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime21(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 1.3;
    s = 0.0005000000237487257f;
}
static const u32 fzgx_pool_table22[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep22(void) { const u32 *volatile cp; cp = fzgx_pool_table22; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime23(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.003;
    s = 20000.0f;
}
static const u32 fzgx_pool_table24[3] = {0x00000000, 0x3F800000, 0x3F000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep24(void) { const u32 *volatile cp; cp = fzgx_pool_table24; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime25(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 34.0f;
}
static const u32 fzgx_pool_table26[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep26(void) { const u32 *volatile cp; cp = fzgx_pool_table26; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime27(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 10.0;
}
static const u32 fzgx_pool_table28[2] = {0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep28(void) { const u32 *volatile cp; cp = fzgx_pool_table28; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime29(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -2.0f;
    s = 768.0f;
}
static const u32 fzgx_pool_table30[3] = {0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep30(void) { const u32 *volatile cp; cp = fzgx_pool_table30; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime31(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 16.0f;
    s = 4096.0f;
    s = 6.0f;
    s = 1820.4444580078125f;
    s = 119.0f;
    s = 51.0f;
}
static const u32 fzgx_pool_table32[3] = {0x00000000, 0x3DCCCCCD, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep32(void) { const u32 *volatile cp; cp = fzgx_pool_table32; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime33(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 2.5f;
    s = 400.0f;
    s = 2000.0f;
    s = 176.0f;
}
static const u32 fzgx_pool_table34[6] = {0x00000000, 0x3DCCCCCD, 0x40000000, 0x00000000, 0x3F800000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep34(void) { const u32 *volatile cp; cp = fzgx_pool_table34; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime35(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.7999999523162842f;
}
static const u32 fzgx_pool_table36[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep36(void) { const u32 *volatile cp; cp = fzgx_pool_table36; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime37(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.3333333432674408;
    d = 0.800000011920929;
}
static const u32 fzgx_pool_table38[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep38(void) { const u32 *volatile cp; cp = fzgx_pool_table38; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime39(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -0.5f;
    s = 1.2999999523162842f;
    s = -1.2000000476837158f;
    s = 1500.0f;
}
static const u32 fzgx_pool_table40[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep40(void) { const u32 *volatile cp; cp = fzgx_pool_table40; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime41(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.4000000059604645;
}
static const u32 fzgx_pool_table42[4] = {0x00000000, 0x3DCCCCCD, 0x3FC00000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep42(void) { const u32 *volatile cp; cp = fzgx_pool_table42; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime43(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 40.0;
    s = -2.5f;
    s = 1280.0f;
}
static const u32 fzgx_pool_table44[14] = {0, 0x3ECCCCCD, 0x3F800000, 0x402CCCCD, 0x42480000, 0, 0, 0, 0x42900000, 0x40B66666, 0x3FB99999, 0xA0000000, 0x3FF66666, 0x60000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep44(void) { const u32 *volatile cp; cp = fzgx_pool_table44; }  /* fzgx-allow: S2 pool primer sink */
#pragma section code_type ".text"

/* Inline LCG used by the effect code: next 15-bit random value. */
#define FN6FFA0_RAND() \
    (lbl_801A63C0 = lbl_801A63C0 * 0x676A4B6B + 0x33CB, (s32)((lbl_801A63C0 >> 16) & 0x7FFF))

#pragma opt_propagation off
void fn_1_6FFA0(Fn6FFA0Car *car, u32 arg1, u32 arg2) {
    Fn6FFA0Vec pos;
    Fn6FFA0Vec dir;
    Fn6FFA0Work work;
    Fn6FFA0Vec tmp;
    register f32 *matrix;
    Fn6FFA0Vec *velocity;
    u16 n;
    u32 random;

    fn_1_867CC(car->unk_18, &pos);
    memset(&work, 0, sizeof(work));
    work.unk_18 = car->unk_18;
    work.unk_0c = 0x21;
    work.unk_1a = 0xffff;
    work.unk_10 = arg2;
    if (fn_1_58C4() >= 2 || car->unk_18 != camera_get_mode()) {
        n = 2;
    } else {
        n = 3;
    }
    goto setup; /* fzgx-allow: S1 shared loop-entry setup is laid out after the loop in retail */
loop:
    for (; n != 0; n--) {
        work.unk_28 = 0.2f;
        random = lbl_801A63C0 * 0x676A4B6B + 0x33CB;
        lbl_801A63C0 = random;
        work.unk_2c = 1.2f * (0.5f + (f32)(0.5f * ((f32)(s32)((random >> 16) & 0x7fff) / 32767.0f)));
        work.unk_54 = fn_1_584AC();
        work.unk_56 = fn_1_584AC();
        work.unk_5a = 256.0f + (f32)(1024.0f * ((f32)fn_1_584AC() / 32767.0f));
        work.unk_5c = 256.0f + (f32)(1024.0f * ((f32)fn_1_584AC() / 32767.0f));
        if (fn_1_66B8(&pos, 4.0f) == 0) {
            return;
        }
        lbl_8006DC6C(car->unk_b8);
        {
            {
                f32 fzgx_lc0_z;
                f32 fzgx_lc0_y;
                f32 fzgx_lc0_x;
                fzgx_lc0_x = (pos.x);
                fzgx_lc0_y = (pos.y);
                fzgx_lc0_z = (pos.z);
                matrix = (f32 *)0xE0000000; /* fzgx-allow: A2 locked-cache current matrix address */
                matrix[3] = fzgx_lc0_x;
                matrix[7] = fzgx_lc0_y;
                matrix[11] = fzgx_lc0_z;
            }
        }
        mathutil_mtxA_rotate_y(work.unk_56);
        mathutil_mtxA_rotate_x(work.unk_54);
        {
            Fn6FFA0Vec tmp = {0.0f, 0.0f, 0.0f};

            tmp.z = 3.0f * -((f32)FN6FFA0_RAND() / 32767.0f);
            dir = tmp;
        }
        lbl_8006E1B0(&dir, velocity);
        fn_1_59078(&work);
    }
    return;
setup:
    velocity = &work.unk_3c;
    goto loop; /* fzgx-allow: S1 return from shared loop-entry setup */
}
