#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/car.h"
#include "psvec.h"

/* the locked-cache matrix at 0xE0000000 (car_test.c spells it the same way) */
#define HW_F32(off) (*(f32 *)(0xE0000000 + (off)))

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} Vec8B9B8;

/* progress record (racer +0x49C) */
typedef struct {
    u8 pad_0[0x30];
    f32 unk_30;
    f32 unk_34;
    u8 pad_38[0x4];
    f32 unk_3C;
    f32 unk_40;
    u8 pad_44[0x24];
    f32 unk_68;
    f32 unk_6C;
    u8 pad_70[0xC];
    u32 unk_7C;
    u8 pad_80[0x4];
    f32 unk_84;
    u8 pad_88[0x70];
    f32 unk_F8;
    f32 unk_FC;
    f32 unk_100;
    s16 unk_104;
    u8 pad_106[0x2];
    f32 unk_108;
    u8 pad_10C[0x9];
    u8 unk_115;
    u8 pad_116[0xC2];
    u32 unk_1D8;
    f32 unk_1DC;
} Progress8B9B8;

/* racer record (0x620 bytes) */
typedef struct {
    u32 unk_0;
    u8 pad_4[0x78];
    f32 unk_7C;
    f32 unk_80;
    f32 unk_84;
    u8 pad_88[0x64];
    u8 unk_EC[0x3B0];
    Progress8B9B8 *unk_49C;
    u8 pad_4A0[0x180];
} Racer8B9B8;

typedef struct {
    u32 unk_0;
    u8 pad_4[0x6];
    u8 unk_A;
    u8 unk_B;
    u8 pad_C[0x2];
    u8 unk_E[0x1E];
    Progress8B9B8 *unk_2C[30];
} Race8B9B8;

extern u8 *lbl_801A6D00;
extern void lbl_8006DC6C(void *);
extern void lbl_8006DB74(void *);
extern void lbl_8006DBAC(void *);
extern void lbl_8006DF44(void);
extern void lbl_8006DFC4(void *);
extern s16 fn_8006F394(void);
extern void lbl_8006D6FC(void *, void *);
extern s16 lbl_8006D46C(void);
extern f64 __fabs(f64);

/* the retail TU's .bss objects this function uses, at their retail offsets, so MWCC addresses them off one
 * section base; the fzgx_pool_gap_ objects span the retail objects in between */
u32 fzgx_obj_lbl_1_bss_6D820;
u8 fzgx_pool_gap_6D824[0x14];
Racer8B9B8 *fzgx_obj_lbl_1_bss_6D838;
u8 fzgx_pool_gap_6D83C[0xE];
s8 fzgx_obj_lbl_1_bss_6D84A;
u8 lbl_1_bss_6D84A__fzgx_offset_1;
u8 lbl_1_bss_6D84A__fzgx_offset_2;
u8 fzgx_pool_gap_6D84D;
u8 fzgx_pool_gap_6D84E;
u8 fzgx_pool_gap_6D84F;
u8 fzgx_pool_gap_6D850[0x150];
u8 fzgx_obj_lbl_1_bss_6D9A0[0x9C];
u8 lbl_1_bss_6D9A0__fzgx_offset_9C[0x20];
s8 fzgx_obj_lbl_1_bss_6DA5C[0x1E];
u8 fzgx_obj_lbl_1_bss_6DA7A;
u8 fzgx_obj_lbl_1_bss_6DA7B;
u8 lbl_1_bss_6DA7B__fzgx_offset_1;
u8 lbl_1_bss_6DA7B__fzgx_offset_2;
u8 fzgx_pool_gap_6DA7E;
u8 fzgx_pool_gap_6DA7F;
f32 fzgx_obj_lbl_1_bss_6DA80[0x1B8];
f32 fzgx_obj_lbl_1_bss_6E160[0x1B3];

#pragma section code_type ".fzgxpool"
static const u32 fzgx_pool_table1[4] = {0x40400000, 0x40000000, 0x40000000, 0x3FC00000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const u32 *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.0f;
}
static const u32 fzgx_pool_table2[5] = {0x00000000, 0x3E800000, 0x00000000, 0x3FB99999, 0x9999999A};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.0f;
}
static const u32 fzgx_pool_table3[17] = {0x00000000, 0x3FC33333, 0x34CCCCCD, 0x3D4CCCCD, 0x41F00000, 0x3B800000, 0x43360B61, 0x43340000, 0x42300000, 0x42B20000, 0x43B40000, 0x42700000, 0x00000000, 0x3FC0A3D7, 0x08CCCCCD, 0x3CF5C28F, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const u32 *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 4503599627370496.0;
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table4[310] = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00330000, 0x00010001, 0x00020002, 0x00030003, 0x0004002F, 0x00050004, 0x00060005, 0x00070006, 0x00080007, 0x00090008, 0x000A002A, 0x000B0009, 0x000C002B, 0x000D000A, 0x000E002C, 0x000F000B, 0x0010002D, 0x0011000C, 0x0012002E, 0x0013000D, 0x0014000E, 0x003D000F, 0x003E0010, 0x003F0011, 0x00400012, 0x00410013, 0x00420014, 0x00430015, 0x00440016, 0x00450017, 0x00460018, 0x00470019, 0x0048001A, 0x0049001B, 0x004A001C, 0x004B001D, 0x004C0034, 0x004D0035, 0x004E0036, 0x004F0037, 0x001F001E, 0x0020001F, 0x00210020, 0x00220021, 0x00230022, 0x00240023, 0x00250024, 0x00260025, 0x00270026, 0x00280027, 0x00290028, 0x002A0029, 0x00500038, 0x00510030, 0x00520031, 0x00530032, 0x00540033, 0xFFFF0000, 0x42C80000, 0x0032001E, 0x00140004, 0xFFFFFFFF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.5;
}
static const u32 fzgx_pool_table5[14] = {0x3FC99999, 0xA0000000, 0x3DCCCCCD, 0x3DF5C28F, 0xBDCCCCCD, 0xBF800000, 0x3F666666, 0x3EFAE148, 0x3FE99999, 0xA0000000, 0x3ECCCCCD, 0x00000000, 0x3F000000, 0x3F000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const u32 *volatile cp; cp = fzgx_pool_table5; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 2.0f;
}
static const u32 fzgx_pool_table6[3] = {0xB4000000, 0x43700000, 0x3F400000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.5f;
}
static const u32 fzgx_pool_table7[49] = {0x447A0000, 0xFFFFFFFF, 0xFFFFFFFF, 0x3F800000, 0x3F800000, 0x3F800000, 0x3F800000, 0x3F800000, 0x00000000, 0x00000000, 0x3F800000, 0x00000000, 0x3F800000, 0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0x3F800000, 0x3F800000, 0x00000000, 0x3F800000, 0x3F800000, 0x3F800000, 0x00000000, 0x00000000, 0x00000000, 0x3F800000, 0x00000000, 0x00000000, 0xBF800000, 0x3F4CCCCD, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const u32 *volatile cp; cp = fzgx_pool_table7; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 1.0;
}
static const u32 fzgx_pool_table8[92] = {0x41700000, 0x3C23D70A, 0x437F0000, 0x43000000, 0x41980000, 0x41700000, 0x41980000, 0x41980000, 0x41980000, 0x414E6666, 0x41500000, 0x41500000, 0x41500000, 0x41500000, 0x06010406, 0x02000000, 0x3F000000, 0x3F000000, 0x3F000000, 0x3F000000, 0x3E4CCCCD, 0x3F800000, 0x3F800000, 0xBF800000, 0xBF800000, 0x3F800000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x41880000, 0x40133333, 0x416B3333, 0x3E99999A, 0x41200000, 0x40F66666, 0x43200000, 0x41C80000, 0x3FC99999, 0x9999999A, 0x3E800000, 0x46000000, 0xC1F00000, 0x43480000, 0x471C4000, 0x467FA400, 0x467FA400, 0x46822A00, 0x46822A00, 0x46848200, 0x46848200, 0x4686DA00, 0x4686DA00, 0x45C9D800, 0x45CB0000, 0x45E2D800, 0x45E40000, 0x45FBD800, 0x45FD0000, 0x46517C00, 0x4651C400, 0x46537800, 0x4653C000, 0x46557400, 0x4655BC00, 0x465CE400, 0x465D2000, 0x46847400, 0x46849400, 0x02010003, 0x02030103, 0x00020302, 0x03010001, 0x01000200, 0x40A00000, 0x41A00000, 0x42200000, 0xC47A0000, 0xC20C0000, 0x420C0000, 0x44BB8000, 0x00000000, 0x40490000, 0x00000000, 0x42480000, 0xC00000FF, 0x0000C0FF, 0x00000000, 0x40840000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime8(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = -1.0;
    d = 0.05;
    d = 1.5707963705062866;
    s = -0.5f;
}
static const u32 fzgx_pool_table9[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep9(void) { const u32 *volatile cp; cp = fzgx_pool_table9; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 32768.0;
    s = 65536.0f;
    s = 2.1415927410125732f;
    s = 32768.0f;
}
__declspec(section ".fzgxpool") static void fzgx_bss_prime(void) {
    volatile u32 s;  /* fzgx-allow: S2 primer sink */
    s = fzgx_obj_lbl_1_bss_6D820;
    s = fzgx_pool_gap_6D824[0];
    s = *(u32 *)&fzgx_obj_lbl_1_bss_6D838;
    s = fzgx_pool_gap_6D83C[0];
    s = fzgx_obj_lbl_1_bss_6D84A;
    s = lbl_1_bss_6D84A__fzgx_offset_1;
    s = lbl_1_bss_6D84A__fzgx_offset_2;
    s = fzgx_pool_gap_6D84D;
    s = fzgx_pool_gap_6D84E;
    s = fzgx_pool_gap_6D84F;
    s = fzgx_pool_gap_6D850[0];
    s = fzgx_obj_lbl_1_bss_6D9A0[0];
    s = lbl_1_bss_6D9A0__fzgx_offset_9C[0];
    s = fzgx_obj_lbl_1_bss_6DA5C[0];
    s = fzgx_obj_lbl_1_bss_6DA7A;
    s = fzgx_obj_lbl_1_bss_6DA7B;
    s = lbl_1_bss_6DA7B__fzgx_offset_1;
    s = lbl_1_bss_6DA7B__fzgx_offset_2;
    s = fzgx_pool_gap_6DA7E;
    s = fzgx_pool_gap_6DA7F;
    s = *(u32 *)fzgx_obj_lbl_1_bss_6DA80;
    s = *(u32 *)fzgx_obj_lbl_1_bss_6E160;
}
#pragma section code_type ".text"
/* retail has no fused multiply-adds here */
#pragma fp_contract off

static inline void fn_1_8B9B8_translate(Racer8B9B8 *r, f32 *mtx) {
    f32 x;
    f32 y;
    f32 z;

    x = (r->unk_7C);
    y = r->unk_80;
    z = r->unk_84;
    mtx[3] = x;
    mtx[7] = y;
    mtx[11] = z;
}

static inline Progress8B9B8 *fn_1_8B9B8_progress(s32 seat) {
    return (fzgx_obj_lbl_1_bss_6D838 != NULL) ? fzgx_obj_lbl_1_bss_6D838[seat].unk_49C : NULL;
}

static inline void fn_1_8B9B8_ports(Racer8B9B8 *racers) {
    s32 i;
    s8 seat;
    u8 rank;
    s8 *port;

    port = (s8 *)&lbl_1_data_20664;
    for (i = 0; i < 4; port++, i++) {
        seat = *port;
        if (seat != -1) {
            rank = racers[seat].unk_49C->unk_115;
            if (rank < fzgx_obj_lbl_1_bss_6DA7A) {
                fzgx_obj_lbl_1_bss_6DA7A = rank;
                lbl_1_bss_6DA7B__fzgx_offset_1 = seat;
            }
            if (rank > fzgx_obj_lbl_1_bss_6DA7B) {
                fzgx_obj_lbl_1_bss_6DA7B = rank;
                lbl_1_bss_6DA7B__fzgx_offset_2 = *port;
            }
        }
    }
}

/* retail keeps the locked-cache matrix address in a saved register across the machine loop as a reused
 * local (not a folded constant), as fn_1_92554 does: opt_dead_assignments off */
#pragma opt_dead_assignments off
void fn_1_8B9B8(Race8B9B8 *race) {
    s8 start[4];
    s8 end[4];
    s16 seats[30];
    s32 group[30];
    f32 keys[30];
    Racer8B9B8 *racers;
    Progress8B9B8 *p;
    s32 i;
    s32 g;
    s8 best;
    s32 j;
    s8 k;
    f32 ratio;
    Progress8B9B8 *q;
    s32 m;

    /* retail tests the course word signed (cmpwi), though globals.h types it u32 */
    if (lbl_1_bss_3BE0 != NULL && (s32)lbl_1_bss_3BE0->unk_8 != 0) {
        lbl_1_bss_6D84A__fzgx_offset_1 = 0;
        lbl_1_bss_6D84A__fzgx_offset_2 = 0;
        for (i = 0; i < fzgx_obj_lbl_1_bss_6D84A; i++) {
            u32 flags = fzgx_obj_lbl_1_bss_6D838[fzgx_obj_lbl_1_bss_6DA5C[i]].unk_0;
            if (flags & 0x20000000) {
                group[i] = 3;
            } else if (flags & 0x10000) {
                group[i] = 0;
                lbl_1_bss_6D84A__fzgx_offset_1++;
                lbl_1_bss_6D84A__fzgx_offset_2++;
            } else if ((race != NULL && (race->unk_0 & 0x8000)) || !(flags & 0x08000000)) {
                group[i] = 1;
                lbl_1_bss_6D84A__fzgx_offset_1++;
            } else {
                group[i] = 2;
            }
        }
        if (race != NULL) {
            race->unk_A = lbl_1_bss_6D84A__fzgx_offset_1;
            race->unk_B = lbl_1_bss_6D84A__fzgx_offset_2;
        }

        k = 0;
        for (g = 0; g < 4; g++) {
            start[g] = k;
            for (i = 0; i < fzgx_obj_lbl_1_bss_6D84A; i++) {
                if (group[i] == g) {
                    s8 seat = fzgx_obj_lbl_1_bss_6DA5C[i];
                    p = fzgx_obj_lbl_1_bss_6D838[seat].unk_49C;
                    if (g == 0) {
                        keys[k] = (f32)p->unk_1D8 + p->unk_1DC;
                    } else {
                        keys[k] = p->unk_F8;
                    }
                    seats[k++] = seat;
                }
            }
            end[g] = k;
        }

        for (g = 0; g < 4; g++) {
            for (i = start[g]; i < end[g]; i++) {
                f32 bestKey = keys[i];
                best = i;
                for (j = i + 1; j < end[g]; j++) {
                    if (g == 0) {
                        if (bestKey > keys[j]) {
                            bestKey = keys[j];
                            best = j;
                        }
                    } else if (bestKey < keys[j]) {
                        best = j;
                        bestKey = keys[j];
                    }
                }
                if (best != i) {
                    s16 seat = seats[i];
                    f32 key;
                    seats[i] = seats[best];
                    seats[best] = seat;
                    key = keys[i];
                    keys[i] = keys[best];
                    keys[best] = key;
                }
                fzgx_obj_lbl_1_bss_6DA5C[i] = seats[i];
            }
        }

        for (i = 0; i < fzgx_obj_lbl_1_bss_6D84A; i++) {
            s8 seat = fzgx_obj_lbl_1_bss_6DA5C[i];
            racers = &fzgx_obj_lbl_1_bss_6D838[seat];
            p = racers->unk_49C;
            p->unk_115 = i;
            lbl_1_bss_6D9A0__fzgx_offset_9C[seat] = i;
            if (race != NULL) {
                race->unk_E[i] = seat;
                race->unk_2C[i] = p;
            }
        }

        fzgx_obj_lbl_1_bss_6DA7A = 0xFF;
        fzgx_obj_lbl_1_bss_6DA7B = 0;
        racers = fzgx_obj_lbl_1_bss_6D838;
        fn_1_8B9B8_ports(racers);
        if (fzgx_obj_lbl_1_bss_6DA7A == 0xFF) {
            lbl_1_bss_6DA7B__fzgx_offset_1 = 0;
            lbl_1_bss_6DA7B__fzgx_offset_2 = 0;
            fzgx_obj_lbl_1_bss_6DA7A = 1;
            fzgx_obj_lbl_1_bss_6DA7B = 1;
            if (racers != NULL && racers->unk_49C != NULL) {
                fzgx_obj_lbl_1_bss_6DA7A = racers->unk_49C->unk_115;
                fzgx_obj_lbl_1_bss_6DA7B = racers->unk_49C->unk_115;
            }
        }

        /* p is reused for the locked-cache matrix address */
        for (m = 0, p = (Progress8B9B8 *)0xE0000000; /* fzgx-allow: A2 locked-cache current matrix address */
             m < fzgx_obj_lbl_1_bss_6D84A; m++, racers++) {
            q = racers->unk_49C;
            lbl_8006DC6C(racers->unk_EC);
            fn_1_8B9B8_translate(racers, (f32 *)p);
            lbl_8006DB74(lbl_801A6D00 + 0x60);
            lbl_8006DBAC(q);
            lbl_8006DF44();
            if (q->unk_7C & 0x02200000) {
                ratio = 1.0f;
            } else {
                ratio = q->unk_34 / q->unk_30;
                if (ratio < 0.05) {
                    ratio = 0.0f;
                }
            }
            lbl_8006DFC4(lbl_801A6D00 + 0x60);
            q->unk_104 = fn_8006F394();
            if ((q->unk_7C & 0x02200000) || ratio == 0.0f) {
                q->unk_84 = q->unk_68;
                q->unk_108 = *(f32 *)(lbl_801A6D00 + 0xC);
            } else if (q->unk_7C & 0x01800000) {
                Vec8B9B8 b;
                Vec8B9B8 a;
                f32 ang;

                q->unk_84 = 1.5707963705062866 * (q->unk_6C * (q->unk_30 + q->unk_34));
                {
                    f32 y = -0.5f * q->unk_34;
                    a.x = 0.0f;
                    a.z = 0.0f;
                    a.y = y;
                }
                psvec_set(&b, HW_F32(0x2C), HW_F32(0x1C), HW_F32(0xC));
                {
                    f64 sign = (b.x < 0.0f) ? -1.0 : 1.0;
                    lbl_8006D6FC(&a, &b);
                    ang = sign * lbl_8006D46C();
                    if (q->unk_7C & 1) {
                        ang = ((ang < 0.0f) ? -1.0 : 1.0) * (32768.0 - __fabs(ang));
                    }
                }
                q->unk_108 = q->unk_84 * (ang / (65536.0f * q->unk_6C));
            } else {
                Vec8B9B8 b;
                Vec8B9B8 a;
                f32 half;
                f32 dist;
                f32 ang;

                q->unk_84 = (1.0f + 2.1415927410125732f * ratio) * (q->unk_68 - q->unk_3C);
                {
                    f32 y = -0.5f * q->unk_40;
                    a.x = 0.0f;
                    a.z = 0.0f;
                    a.y = y;
                }
                psvec_set(&b, HW_F32(0x2C), HW_F32(0x1C), HW_F32(0xC));
                dist = __fabs(b.x);
                half = 0.5f * q->unk_3C;
                if (dist <= half) {
                    q->unk_84 = q->unk_84 + 2.0f * q->unk_3C;
                    if ((b.y >= 0.0f) ^ (q->unk_7C & 1)) {
                        dist = 0.5f * q->unk_84 - dist;
                    }
                    if (b.x < 0.0f) {
                        dist = -dist;
                    }
                    q->unk_108 = dist;
                } else {
                    b.x = (b.x < 0.0f) ? b.x + half : b.x - half;
                    {
                        f64 sign = (b.x < 0.0f) ? -1.0 : 1.0;
                        lbl_8006D6FC(&a, &b);
                        ang = sign * lbl_8006D46C();
                        if (q->unk_7C & 1) {
                            ang = ((ang < 0.0f) ? -1.0 : 1.0) * (32768.0 - __fabs(ang));
                        }
                    }
                    q->unk_108 = 0.5 * ((ang / 32768.0f) * q->unk_84);
                    if (q->unk_108 < 0.0f) {
                        q->unk_108 -= half;
                    } else {
                        q->unk_108 += half;
                    }
                    q->unk_84 = q->unk_84 + 2.0f * q->unk_3C;
                }
            }
        }

        {
            f32 lap;
            f32 wrap;
            u32 j;
            u32 pair;

            lap = fn_1_8B9B8_progress(0)->unk_FC;
            wrap = 0.5 * lap;
            for (i = 0; i < fzgx_obj_lbl_1_bss_6D84A; i++) {
                Progress8B9B8 *a = fn_1_8B9B8_progress(i);
                f32 dist0;
                f32 lat0;
                dist0 = a->unk_100;
                lat0 = a->unk_108;
                pair = i * 29U - (i * (i + 1U)) / 2 - 1;
                j = i + 1;
                pair += j;
                for (; j < fzgx_obj_lbl_1_bss_6D84A; j++, pair++) {
                    Progress8B9B8 *b = fn_1_8B9B8_progress(j);
                    f32 d = b->unk_100 - dist0;
                    if (d > wrap) {
                        d -= lap;
                    } else if (d < -wrap) {
                        d += lap;
                    }
                    fzgx_obj_lbl_1_bss_6DA80[pair] = d;
                    fzgx_obj_lbl_1_bss_6E160[pair] = b->unk_108 - lat0;
                }
            }
        }
    }
}
#pragma opt_dead_assignments reset
#pragma fp_contract reset
