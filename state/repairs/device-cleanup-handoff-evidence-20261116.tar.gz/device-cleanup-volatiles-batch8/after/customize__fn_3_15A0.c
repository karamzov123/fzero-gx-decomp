#include "types.h"
#include "rel/customize/globals.h"
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAD0;
extern u8 lbl_1_bss_7F0C0[0x5360];
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_970;
extern u8 lbl_1_bss_9F8[];
extern s32 lbl_3_bss_120;
extern s16 lbl_3_bss_20[104];
extern u8 lbl_3_bss_20854[0xc];
extern u8 lbl_3_bss_20860[0x1100];
extern u8 lbl_3_bss_21960[10368];
extern u8 lbl_3_bss_2437C[44];
extern u32 lbl_3_bss_243A8;
extern u32 lbl_3_bss_243C0;
extern u32 lbl_3_bss_2C7C0[66624];
extern s16 lbl_3_bss_6D8C0[600];
extern u32 lbl_3_bss_6DE20;
extern u8 lbl_3_bss_7DB60[0x520];
extern u8 lbl_3_bss_7E080[0x4];
extern s32 lbl_3_bss_8;
extern s32 lbl_3_data_11D4;
extern s32 lbl_3_data_11D8;
extern char lbl_3_data_15CC[5];
extern s32 lbl_3_data_B8;
extern const char * lbl_3_data_E80[12];
extern u8 lbl_3_rodata_1A4[0xa4];
extern u8 lbl_3_rodata_F8[0xa4];
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern void fn_3_8F8(void);
extern void fn_3_BA0(void);
extern void fn_3_1308C(u32, u32, u32);
extern void fn_3_11F60(u32, u32);
extern void fn_1_A0680(void);
extern void fn_1_3CF0(u32, u32);
extern void fn_1_5124(u32, u32);
extern void fn_80074CF4(f32, f32, f32);
extern void OSReport(const char *format, ...);
extern void *memset(void *, int, u32);
extern u16 fn_1_A5DB0(void);
extern u16 fn_1_A5D88(void);
extern void fn_1_411A4(u32);
extern u32 fn_1_7BA08(u16, u16, u16);
extern void fn_1_7BA48(u32);
extern s32 fn_1_465D0(const char *, s32);
extern void fn_1_545B8(void);
extern void fn_1_7BAF8(void);
extern u32 lbl_801A66C8[];
extern void fn_3_11FA0(void);
extern void fn_3_130A8(void);
extern void fn_1_3C78(void);
extern void fn_1_41A8(void);
extern void fn_1_6400(void);
extern void fn_1_8D168(void *);
extern void fn_1_412A0(u32);
extern void fn_1_56298(f32, f32, f32, f32);
extern void fn_1_A0AA4(void);
extern s32 fn_1_46DC4(s32);
extern void fn_1_53C9C(void *color, char *text, f32 x, f32 y, f32 scale, f32 spacing, f32 alpha);
extern void fn_3_968C();
extern void fn_3_60C8(void);
extern u8 fn_1_F8C50(s32);
extern void fn_3_7A30(void);
extern void fzgx_pool_f32(f32);
extern void fzgx_pool_f64(f64);
extern void fzgx_pool_addr(void *);
extern void fn_3_2BFB4(void);
extern char lbl_3_data_15D8[];
extern void fn_3_3438(void);
extern u32 fn_1_B7F08(void);
extern s32 fn_1_F7954(void);
extern void fn_3_23524(void);
extern void fn_3_78C8(s32);
extern void fn_3_BA74(void);
extern s16 fn_1_F7B80(void);

#include "rel/customize/globals.h"

typedef struct {
    u8 pad_0[6];
    s16 controller;
} CustomizeController;

typedef struct { u8 r, g, b, a; } CustomizeColor;

typedef struct {
    u8 pad_0[8];
    u16 pressed;
    u8 pad_A[6];
    u16 repeat;
    u16 held;
} fn_3_15A0_CustomizeInput;




extern s32 lbl_801A66B4;

extern u8 fn_1_B7C00(void);
extern void fn_1_54278(u32, u32);
extern void fn_1_5428C(f32);
extern void fn_80008BEC(void *, int, u32);
extern int fn_1_B7EC4(int);
extern void fn_1_A2D84(u32);
extern void fn_1_53BD8(void *, f32, f32, f32, f32, f32);
extern u32 fn_1_4AEC0(u32);
extern void fn_1_4AEB4(f32);
extern void fn_1_49410(void);
extern void fn_1_4955C(f32, f32);
extern void fn_1_4954C(f32);
extern void fn_1_495C8(u8);
extern void fn_1_496FC(f32, f32);
extern void fn_1_4966C(f32, f32);
extern void fn_1_495B0(u32);
extern void fn_1_49590(f32);
extern void fn_1_4A0D8(const char *);
extern int fn_1_B800C(int);
extern void fn_1_B80F0(int);
extern s32 fn_1_B7C6C(u32);
extern void fn_1_B8338(u32);
extern void fn_1_B8E84(u32, void *, void *, void *);
extern void fn_1_131084(void *, u32);
extern u32 fn_1_B7C5C(void);
extern int fn_1_B7E98(int);
extern int sprintf(char *, const char *, ...);
extern void fn_1_131050(void *, u32);
extern void fn_3_BFC(char *, void *, const char *, const char *);
extern void fn_3_CB4(const char *);
extern void fn_3_10A4(u8 *);
extern void fn_3_E64(u8 *);

#define save_slot           fzgx_obj_lbl_3_bss_2437C
#define save_state          lbl_3_bss_2437C__fzgx_offset_1
#define save_previous_state lbl_3_bss_2437C__fzgx_offset_2
#define save_frame          lbl_3_bss_2437C__fzgx_offset_4
#define save_attempts       lbl_3_bss_2437C__fzgx_offset_8
#define save_error          lbl_3_bss_2437C__fzgx_offset_C
#define save_free_blocks    lbl_3_bss_2437C__fzgx_offset_10
#define save_free_files     lbl_3_bss_2437C__fzgx_offset_14
#define save_result         lbl_3_bss_2437C__fzgx_offset_18
#define save_choice         lbl_3_bss_2437C__fzgx_offset_1C
#define save_timer          lbl_3_bss_2437C__fzgx_offset_20




#define customize_save_move(c, choice) (input_offset = customize_save_move_impl(c, choice))

/* customize .data 0x0-0x15F0: the message tables (English, four empty
   languages, Japanese), the pattern tables and the scene table. In the
   retail .data they come directly before the switch table of this function. */
typedef struct {
    u8 *tables[10];
    s32 table_count;
    u8 **table_list;
    char vehicle_archive[28];
    char parts_archive[32];
    char stage_tpl_format[20];
    char stage_dir[8];
    char stage_gma_format[20];
    u32 at_9C;
} Data_lbl_3_data_1134;

typedef struct {
    char name[32];
    void (*func[3])(void);
} CustomizeScene;

extern void fn_1_12B4(void);
extern void fn_1_12FC(void);
extern void fn_1_1300(void);
extern void fn_3_11FF0(void);
extern void fn_3_12910(void);
extern void fn_3_12B14(void);
extern void fn_3_1304C(void);
extern void fn_3_13050(void);
extern void fn_3_13054(void);
extern void fn_3_13058(void);
extern void fn_3_1305C(void);
extern void fn_3_13060(void);
extern void fn_3_13064(void);
extern void fn_3_13068(void);
extern void fn_3_1306C(void);
extern void fn_3_13070(void);
extern void fn_3_13074(void);
extern void fn_3_13078(void);
extern void fn_3_130C8(void);
extern void fn_3_1338C(void);
extern void fn_3_1349C(void);
extern void fn_3_14E4(void);
extern void fn_3_15A0(void);
extern void fn_3_33A0(void);
extern void fn_3_368C(void);
extern void fn_3_381C(void);
extern void fn_3_39F0(void);
extern void fn_3_3E58(void);
extern void fn_3_3F20(void);
extern void fn_3_41B0(void);
extern void fn_3_4380(void);
extern void fn_3_48E0(void);
extern void fn_3_4BEC(void);
extern void fn_3_4F08(void);
extern void fn_3_5500(void);
extern void fn_3_5B9C(void);
extern void fn_3_5C4C(void);
extern void fn_3_5C8C(void);
extern void fn_3_5CBC(void);
extern void fn_3_61B8(void);
extern void fn_3_6270(void);
extern void fn_3_6540(void);
extern void fn_3_680C(void);
extern void fn_3_6D2C(void);
extern void fn_3_6E14(void);
extern void fn_3_7038(void);
extern void fn_3_7594(void);
extern void fn_3_7688(void);
extern void fn_3_7770(void);
extern void fn_3_77B0(void);
extern void fn_3_7864(void);
extern void fn_3_7868(void);
extern void fn_3_786C(void);
extern void fn_3_7870(void);
extern void fn_3_7E5C(void);
extern void fn_3_8A90(void);
extern void fn_3_9710(void);
extern void fn_3_990C(void);
extern void fn_3_A12C(void);
extern void fn_3_ACF4(void);
extern void fn_3_AE74(void);
extern void fn_3_B5FC(void);
extern void fn_3_B6E4(void);

Obj_3_data_0 lbl_3_data_0 = {
    0x0001U,
    {0x00U, 0x00U, 0x00U, 0x03U, 0x00U, 0x07U},
    0x0008U,
    {0x00U, 0x09U, 0x00U, 0x0AU, 0x00U, 0x0BU},
    0x000CU,
    0x000DU,
    {0x00U, 0x0EU, 0x00U, 0x0FU, 0x00U, 0x10U, 0x00U, 0x11U, 0x00U, 0x12U, 0x00U, 0x13U, 0x00U, 0x14U, 0x00U, 0x15U, 0x00U, 0x16U, 0x00U, 0x17U, 0x00U, 0x18U, 0x00U, 0x19U, 0x00U, 0x1AU, 0x00U, 0x1BU, 0x00U, 0x1CU, 0x00U, 0x1DU, 0x00U, 0x1EU, 0x00U, 0x1FU, 0x00U, 0x20U, 0x00U, 0x21U, 0x00U, 0x22U, 0x00U, 0x23U, 0x00U, 0x24U, 0x00U, 0x25U, 0x00U, 0x26U, 0x00U, 0x27U, 0x00U, 0x28U, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0x00U, 0x06U, 0x00U, 0x02U, 0x00U, 0x05U, 0x00U, 0x04U, 0x00U, 0x01U, 0x00U, 0x00U, 0x00U, 0x03U, 0x00U, 0x07U, 0x00U, 0x08U, 0x00U, 0x09U, 0x00U, 0x0AU, 0x00U, 0x0BU, 0x00U, 0x0CU, 0x00U, 0x0DU, 0x00U, 0x0EU, 0x00U, 0x0FU, 0x00U, 0x10U, 0x00U, 0x11U, 0x00U, 0x12U, 0x00U, 0x13U, 0x00U, 0x14U, 0x00U, 0x15U, 0x00U, 0x16U, 0x00U, 0x17U, 0x00U, 0x18U, 0x00U, 0x19U, 0x00U, 0x1AU, 0x00U, 0x1BU, 0x00U, 0x1CU, 0x00U, 0x1DU, 0x00U, 0x1EU, 0x00U, 0x1FU, 0x00U, 0x20U, 0x00U, 0x21U, 0x00U, 0x22U, 0x00U, 0x23U, 0x00U, 0x24U, 0x00U, 0x25U, 0x00U, 0x26U, 0x00U, 0x27U, 0x00U, 0x28U, 0xFFU, 0xFFU}
};

s16 lbl_3_data_A8[6] = {
    -1, 0, -1, -1, -1, -1
};

u32 lbl_3_data_B4 = 0xFFFFFFFFU;

s32 lbl_3_data_B8 = -1;

u32 lbl_3_data_BC[2] = {
    0xFFFFFFFFU, 0xFFFFFFFFU
};

s16 lbl_3_data_C4 = -1;

char *lbl_3_data_160[6] = {
    "Return to previous screen\nwithout saving changes. OK?", "", "", "", "", "\214\273[\202\260\202\361]\215\335[\202\264\202\242]\202\314\225\317[\202\326\202\361]\215X[\202\261\202\244]\202\360\203Z\201[\203u\202\271\202\270\202\311\n\221O\202\314\211\346\226\312\202\311\226\337[\202\340\202\307]\202\350\202\334\202\267\201B\202\346\202\353\202\265\202\242\202\305\202\267\202\251?\n",
};

char *lbl_3_data_228[6] = {
    "Selected parts and pilot.\nSave and return to\nthe previous screen. OK?", "", "", "", "", "\214\273[\202\260\202\361]\215\335[\202\264\202\242]\202\314\203p\201[\203c\201A\203p\203C\203\215\203b\203g\202\311\214\210\222\350\202\265\202\334\202\267\201B\n\203Z\201[\203u\202\265\202\304\221O\202\314\211\346\226\312\202\311\226\337[\202\340\202\307]\202\350\202\334\202\267\201B\202\346\202\353\202\265\202\242\202\305\202\267\202\251?\n",
};

char *lbl_3_data_2E4[6] = {
    "Select the current color.\nSave and return to\nthe previous screen. OK?", "", "", "", "", "\214\273[\202\260\202\361]\215\335[\202\264\202\242]\202\314\203J\203\211\201[\202\311\214\210\222\350\202\265\202\334\202\267\201B\n\203Z\201[\203u\202\265\202\304\221O\202\314\211\346\226\312\202\311\226\337[\202\340\202\307]\202\350\202\334\202\267\201B\202\346\202\353\202\265\202\242\202\305\202\267\202\251?\n",
};

char *lbl_3_data_35C[6] = {
    "Save current changes. OK?", "", "", "", "", "\214\273[\202\260\202\361]\215\335[\202\264\202\242]\202\314\225\317[\202\326\202\361]\215X[\202\261\202\244]\202\360\203Z\201[\203u\202\265\202\334\202\267\201B\n\202\346\202\353\202\265\202\242\202\305\202\267\202\251?",
};

char *lbl_3_data_3EC[6] = {
    "There are %d free blocks of space\non the Memory Card in SLOT.", "", "", "", "", "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\n%d\203u\203\215\203b\203N\202\314\213\363[\202\240]\202\253\202\252\202\240\202\350\202\334\202\267",
};

char *lbl_3_data_448[6] = {
    "Garage Data was not saved.", "", "", "", "", "\203K\203\214\201[\203W\203f\201[\203^\202\315\203Z\201[\203u\202\263\202\352\202\334\202\271\202\361\202\305\202\265\202\275",
};

char *lbl_3_data_630[6] = {
    "There is not enough free space on the Memory Card in SLOT.\nTo save F-ZERO GX Garage Data, you need at least 1 free file and\n18 free blocks. (To manage files on the Memory Card, please go to\nthe Nintendo GameCube Memory Card management screen.)", "", "", "", "", "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\213\363\202\253\227e\227\312\202\252\202\310\202\242\202\251\201A\203t\203@\203C\203\213\220\224\202\314\220\247\214\300\202\360\n\211z\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\203Z\201[\203u\202\267\202\351\202\311\202\315\217\255\202\310\202\255\202\306\202\340\203t\203@\203C\203\2131\202\302\202\306\n18\203u\203\215\203b\203N\225K\227v\202\305\202\267\201B(\203\201\203\202\203\212\201[\203J\201[\203h\202\314\223\340\227e\202\360\220\256\227\235\202\267\202\351\202\311\202\315\201A\n\226{\221\314\202\314\203\201\203\202\203\212\201[\203J\201[\203h\211\346\226\312\202\305\215s\202\310\202\301\202\304\202\255\202\276\202\263\202\242)",
};

char *lbl_3_data_6A0[6] = {
    "The Memory Card in SLOT\nis corrupted and cannot be used.", "", "", "", "", "\203G\203\223\203R\201[\203h\202\252\202\250\202\251\202\265\202\242\202\305\202\267\202\346",
};

char *lbl_3_data_73C[6] = {
    "The Memory Card in SLOT\nis damaged and cannot be used.", "", "", "", "", "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\201A\203f\201[\203^\202\252\n\202\261\202\355\202\352\202\304\202\242\202\351\202\314\202\305\216g[\202\265]\227p[\202\346\202\244]\202\305\202\253\202\334\202\271\202\361\201B",
};

char *lbl_3_data_7BC[6] = {
    "Please insert a functional Memory Card in SLOT.", "", "", "", "", "SLOT\202\311\216g[\202\265]\227p[\202\346\202\244]\202\267\202\351\203\201\203\202\203\212\201[\203J\201[\203h\202\360\202\263\202\265\202\304\202\255\202\276\202\263\202\242",
};

char *lbl_3_data_858[6] = {
    "The device in SLOT is not supported.\nPlease insert a Memory Card.", "", "", "", "", "SLOT\202\311\202\315\203\201\203\202\203\212\201[\203J\201[\203h\210\310[\202\242]\212O[\202\252\202\242]\202\314\202\340\202\314\202\252\n\202\263\202\263\202\301\202\304\202\242\202\334\202\267\201B",
};

char *lbl_3_data_8E0[6] = {
    "Please select the Memory Card Slot to be used.", "", "", "", "", "\216g[\202\265]\227p[\202\346\202\244]\202\267\202\351\203\201\203\202\203\212\201[\203J\201[\203h\203X\203\215\203b\203g\202\360\n\221I[\202\246\202\347]\202\361\202\305\202\255\202\276\202\263\202\242",
};

char *lbl_3_data_924[6] = {
    "\203\237\201cContinue without saving\n\203\262\201cTry again", "", "", "", "", "",
};

char *lbl_3_data_9B8[6] = {
    "Garage Data cannot be saved.\nContinue without saving?", "", "", "", "", "\202\261\202\314\202\334\202\334\202\305\202\315\201A\203K\203\214\201[\203W\203f\201[\203^\202\360\n\203Z\201[\203u\202\305\202\253\202\334\202\271\202\361\202\252\202\346\202\353\202\265\202\242\202\305\202\267\202\251?",
};

char *lbl_3_data_A60[6] = {
    "No Memory Card was detected.\nGarage Data could not be loaded.", "", "", "", "", "\203\201\203\202\203\212\201[\203J\201[\203h\202\252\214\251[\202\335]\202\302\202\251\202\350\202\334\202\271\202\361\201B\n\203K\203\214\201[\203W\203f\201[\203^\202\360\203\215\201[\203h\202\305\202\253\202\334\202\271\202\361\202\305\202\265\202\275\201B",
};

char *lbl_3_data_AC0[6] = {
    "Garage Data was not loaded.", "", "", "", "", "\203K\203\214\201[\203W\203f\201[\203^\202\315\203\215\201[\203h\202\263\202\352\202\334\202\271\202\361\202\305\202\265\202\275\201B",
};

char *lbl_3_data_B2C[6] = {
    "Garage Data was not created.", "", "", "", "", "\203K\203\214\201[\203W\203f\201[\203^\202\315\215\354[\202\263\202\255]\220\254[\202\271\202\242]\202\263\202\352\202\334\202\271\202\361\202\305\202\265\202\275\201B",
};

char *lbl_3_data_C8C[6] = {
    "There is no Garage Data on the Memory\nCard in SLOT. Would you like to create\nGarage Data on the Memory Card in SLOT?\n(1 free file and 18 free blocks are required.)", "", "", "", "", "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\203K\203\214\201[\203W\203f\201[\203^\202\252\n\202\240\202\350\202\334\202\271\202\361\201BSLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\n\203K\203\214\201[\203W\203f\201[\203^\202\360\215\354[\202\263\202\255]\220\254[\202\271\202\242]\202\265\202\304\202\340\202\346\202\353\202\265\202\242\202\305\202\267\202\251?\n(18\203u\203\215\203b\203N\216g[\202\265]\227p[\202\346\202\244]\202\265\202\334\202\267)",
};

char *lbl_3_data_D38[6] = {
    "Once you're ready, press the \203\237 Button.\nPress the \203\240 Button to cancel.", "", "", "", "", "\217\200[\202\266\202\343]\224\365[\202\361\202\321]\202\252\202\305\202\253\202\275\202\347\203\237\202\360\211\237[\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B\n\203\240\202\305\203L\203\203\203\223\203Z\203\213\202\265\202\334\202\267\201B",
};

char *lbl_3_data_DA8[6] = {
    "Cancel Memory Card operations.", "", "", "", "", "\203\201\203\202\203\212\201[\203J\201[\203h\202\314\215\354[\202\263\202\254]\213\306[\202\345\202\244]\202\360\203L\203\203\203\223\203Z\203\213\202\265\202\334\202\265\202\275\201B",
};

char *lbl_3_data_DF8[6] = {
    "Please Press the \203\237 Button.", "", "", "", "", "\203\237\202\360\211\237[\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B",
};

char *lbl_3_data_E1C[6] = {
    "YES", "", "", "", "", "\202\315\202\242",
};

char *lbl_3_data_E40[6] = {
    "NO", "", "", "", "", "\202\242\202\242\202\246",
};

const char *lbl_3_data_E80[12] = {
    "Slot A", "", "", "", "", "\203X\203\215\203b\203gA",
    "Slot B", "", "", "", "", "\203X\203\215\203b\203gB",
};

char *lbl_3_data_F00[6] = {
    "Clearing registration. OK?", "", "", "", "", "\223o[\202\306\202\244]\230^[\202\353\202\255]\202\360\203N\203\212\203A\202\265\202\334\202\267\201B\n\202\346\202\353\202\265\202\242\202\305\202\267\202\251?",
};

u8 lbl_3_data_F18[72] = {
    0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x01U, 0x01U, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_F60[68] = {
    0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x41U, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_FA4[80] = {
    0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x41U, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_FF4[36] = {
    0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x4FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x4FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_1018[36] = {
    0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x4FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_103C[36] = {
    0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_1060[36] = {
    0x01U, 0x00U, 0x00U, 0x4FU, 0x01U, 0x00U, 0x00U, 0x4FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x00U, 0x4FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_1084[36] = {
    0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x00U, 0x8FU, 0x01U, 0x00U, 0x01U, 0x0FU, 0x01U, 0x00U, 0x00U, 0x1FU, 0x01U, 0x00U, 0x00U, 0x2FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_10A8[72] = {
    0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x11U, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

u8 lbl_3_data_10F0[68] = {
    0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x21U, 0x01U, 0x00U, 0x00U, 0x41U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x11U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0x01U, 0x00U, 0x00U, 0x81U, 0x01U, 0x00U, 0x01U, 0x01U, 0xFFU, 0xFFU, 0xFFU, 0xFFU
};

Data_lbl_3_data_1134 lbl_3_data_1134 = {
    {lbl_3_data_F18, lbl_3_data_F60, lbl_3_data_FA4, lbl_3_data_FF4, lbl_3_data_1018, lbl_3_data_103C, lbl_3_data_1060, lbl_3_data_1084, lbl_3_data_10A8, lbl_3_data_10F0},
    10,
    lbl_3_data_1134.tables,
    "vehicle/vehicle_sel.arc.lz",
    "vehicle_parts/parts_all.arc.lz",
    "%s/selst%02d.tpl.lz",
    "stage",
    "%s/selst%02d.gma.lz",
    0x00010000,
};

s32 lbl_3_data_11D4 = -1;

s32 lbl_3_data_11D8 = -1;

u8 lbl_3_data_11DC[0x54] = {
    0x63U, 0x75U, 0x73U, 0x74U, 0x6FU, 0x6DU, 0x69U, 0x7AU, 0x65U, 0x2EU, 0x63U, 0x00U, 0x44U, 0x72U, 0x61U, 0x77U, 0x4FU, 0x72U, 0x64U, 0x53U, 0x79U, 0x73U, 0x00U, 0x00U, 0x53U, 0x74U, 0x61U, 0x72U, 0x74U, 0x20U, 0x43U, 0x75U, 0x73U, 0x74U, 0x6FU, 0x6DU, 0x69U, 0x7AU, 0x65U, 0x20U, 0x3AU, 0x20U, 0x25U, 0x64U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x4CU, 0x69U, 0x67U, 0x68U, 0x74U, 0x4DU, 0x61U, 0x69U, 0x6EU, 0x00U, 0x00U, 0x00U, 0x45U, 0x6EU, 0x64U, 0x20U, 0x20U, 0x20U, 0x43U, 0x75U, 0x73U, 0x74U, 0x6FU, 0x6DU, 0x69U, 0x7AU, 0x65U, 0x20U, 0x3AU, 0x20U, 0x25U, 0x64U, 0x0AU, 0x00U, 0x00U, 0x00U
};

CustomizeScene lbl_3_data_1230[21] = {
    {"SMD_CUST_TOP", {fn_1_12B4, fn_1_12FC, fn_1_1300}},
    {"SMD_CUST_MENU", {fn_3_3E58, fn_3_3F20, fn_3_41B0}},
    {"SMD_CUST_MEMCARD_SAVE", {fn_3_368C, fn_3_381C, fn_3_39F0}},
    {"SMD_CUST_MEMCARD_LOAD", {fn_3_14E4, fn_3_15A0, fn_3_33A0}},
    {"SMD_CUST_GARAGE", {fn_3_4F08, fn_3_5500, fn_3_5B9C}},
    {"SMD_CUST_FZCAR_SEL", {fn_3_4380, fn_3_48E0, fn_3_4BEC}},
    {"SMD_CUST_GARAGE_MENU", {fn_3_5C4C, fn_3_5C8C, fn_3_5CBC}},
    {"SMD_CUST_EMB_TOPMENU", {fn_3_1304C, fn_3_13050, fn_3_13054}},
    {"SMD_CUST_EMB_MENU", {fn_3_13058, fn_3_1305C, fn_3_13060}},
    {"SMD_CUST_EMB_MAKER", {fn_3_130C8, fn_3_1349C, fn_3_1338C}},
    {"SMD_CUST_EMB_PRO", {fn_3_13064, fn_3_13068, fn_3_1306C}},
    {"SMD_CUST_EMB_MEM", {fn_3_13070, fn_3_13074, fn_3_13078}},
    {"SMD_CUST_SHOP_MENU", {fn_3_7038, fn_3_7594, fn_3_7688}},
    {"SMD_CUST_PASTE", {fn_3_11FF0, fn_3_12910, fn_3_12B14}},
    {"SMD_CUST_MACHINE_NAME", {fn_3_7770, fn_3_77B0, fn_3_7864}},
    {"SMD_CUST_PILOT_SEL", {fn_3_7868, fn_3_786C, fn_3_7870}},
    {"SMD_CUST_PARTS_CUST", {fn_3_7E5C, fn_3_8A90, fn_3_9710}},
    {"SMD_CUST_COLCH_MENU", {fn_3_990C, fn_3_A12C, fn_3_ACF4}},
    {"SMD_CUST_CAR_SHOP_MENU", {fn_3_AE74, fn_3_B5FC, fn_3_B6E4}},
    {"SMD_CUST_SHOP_TOP", {fn_3_61B8, fn_3_6270, fn_3_6540}},
    {"SMD_CUST_ITEM_SHOP", {fn_3_680C, fn_3_6D2C, fn_3_6E14}},
};

char lbl_3_data_15CC[5] = "SLOT";

char lbl_3_data_15D4[] = "%s";

char lbl_3_data_15D8[] = "CustomizeMemcardDisp";

#pragma section code_type ".fzgxpool"
static void fzgx_data_layout_lbl_3_data_0(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: addresses the .data section base before the .rodata primers address theirs, as in retail, where this function is the first of its TU */
    s = *(u8 *)lbl_3_data_3EC;
    s = *(u8 *)lbl_3_data_630;
    s = *(u8 *)lbl_3_data_6A0;
}
#pragma section code_type ".text"


/* The retail TU's literal pool (lbl_3_rodata_0), reproduced in retail order. MWCC folds a `static const`
 * scalar into its value, so the fzgx_rodata_ f32 scalars below become pool literals in first-use order
 * (deduplicated TU-wide); the primers use them in retail order. Words that are not float literals in the
 * retail pool (zeros, repeats, the colour constants and the 0x88/0xBC tables) are static const aggregates,
 * which MWCC emits into .rodata at their definition, so each is defined right before the primer whose
 * literals follow it. The two 8-byte int-to-float conversion constants (+0x20 for (f32)u32, +0x80 for
 * (f32)s32) are produced by conversions in the primers; the function's own conversion dedupes onto +0x80. */
static const u32 fzgx_rodata_0[1] = { 0 };
static const f32 fzgx_rodata_4 = 320.0f;
static const f32 fzgx_rodata_8 = 240.0f;
static const f32 fzgx_rodata_C = 0.001f;
static const f32 fzgx_rodata_10 = 0.01f;
static const f32 fzgx_rodata_14 = 0.5f;
static const f32 fzgx_rodata_18 = 480.0f;
static const f32 fzgx_rodata_1C = 2.0f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_a(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    volatile u32 u;  /* fzgx-allow: S2 layout primer source for the (f32)u32 conversion constant */
    s = *(const f32 *)&fzgx_rodata_0[0];
    s = fzgx_rodata_4;
    s = fzgx_rodata_8;
    s = fzgx_rodata_C;
    s = fzgx_rodata_10;
    s = fzgx_rodata_14;
    s = fzgx_rodata_18;
    s = fzgx_rodata_1C;
    s = (f32)u;
}
#pragma section code_type ".text"

static const u32 fzgx_rodata_28[6] = { 0, 0x41200000, 0x41200000, 0, 0, 0 };
  /* fzgx-allow: A1 retail rodata bytes */
static const f32 fzgx_rodata_40 = 0.25f;
static const f32 fzgx_rodata_44 = 0.0f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_b(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    s = *(const f32 *)&fzgx_rodata_28[0];
    s = fzgx_rodata_40;
    s = fzgx_rodata_44;
}
#pragma section code_type ".text"

static const CustomizeColor fzgx_rodata_48 = { 255, 255, 255, 255 };
static const f32 fzgx_rodata_4C = 500.0f;
static const f32 fzgx_rodata_50 = 300.0f;
static const f32 fzgx_rodata_54 = 0.1f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_c(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    s = *(const f32 *)&fzgx_rodata_48;
    s = fzgx_rodata_4C;
    s = fzgx_rodata_50;
    s = fzgx_rodata_54;
}
#pragma section code_type ".text"

static const u32 fzgx_rodata_58[1] = { 0xFFFFFFFF };
static const f32 fzgx_rodata_5C = 1.5f;
static const f32 fzgx_rodata_60 = -1.0f;
static const f32 fzgx_rodata_64 = 8.0f;
static const f32 fzgx_rodata_68 = 4.0f;
static const f32 fzgx_rodata_6C = 150.0f;
static const f32 fzgx_rodata_70 = 0.09f;
static const f32 fzgx_rodata_74 = 30.0f;
static const f32 fzgx_rodata_78 = 0.55f;
static const f32 fzgx_rodata_7C = 0.75f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_d(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    volatile s32 i;  /* fzgx-allow: S2 layout primer source for the (f32)s32 conversion constant */
    s = *(const f32 *)&fzgx_rodata_58[0];
    s = fzgx_rodata_5C;
    s = fzgx_rodata_60;
    s = fzgx_rodata_64;
    s = fzgx_rodata_68;
    s = fzgx_rodata_6C;
    s = fzgx_rodata_70;
    s = fzgx_rodata_74;
    s = fzgx_rodata_78;
    s = fzgx_rodata_7C;
    s = (f32)i;
}
#pragma section code_type ".text"

static const u32 fzgx_rodata_88[8] = { 0xA0505000, 0xA0A0A000, 0xFFFFFF00, 0x70707000, 0x00000000, 0x70707000, 0x00000000, 0xFFFFFF00 };
  /* fzgx-allow: A1 retail rodata bytes */
static const f32 fzgx_rodata_A8 = 1.0f;
static const f32 fzgx_rodata_AC = 288.0f;
static const f32 fzgx_rodata_B0 = 0.08f;
static const f32 fzgx_rodata_B4 = 10.0f;
static const f32 fzgx_rodata_B8 = 352.0f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_e(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    s = *(const f32 *)&fzgx_rodata_88[0];
    s = fzgx_rodata_A8;
    s = fzgx_rodata_AC;
    s = fzgx_rodata_B0;
    s = fzgx_rodata_B4;
    s = fzgx_rodata_B8;
}
#pragma section code_type ".text"

static const u32 fzgx_rodata_BC[8] = { 0xA0505000, 0xA0A0A000, 0xFFFFFF00, 0x70707000, 0x00000000, 0x70707000, 0x00000000, 0xFFFFFF00 };
  /* fzgx-allow: A1 retail rodata bytes */
static const f32 fzgx_rodata_DC = 220.0f;
static const f32 fzgx_rodata_E0 = 280.0f;
static const f32 fzgx_rodata_E4 = 260.0f;
static const f32 fzgx_rodata_E8 = 210.0f;

#pragma section code_type ".fzgxpool"
static void fzgx_rodata_layout_f(void) {
    volatile f32 s;  /* fzgx-allow: S2 layout primer sink: keeps the retail pool words in retail order */
    s = *(const f32 *)&fzgx_rodata_BC[0];
    s = fzgx_rodata_DC;
    s = fzgx_rodata_E0;
    s = fzgx_rodata_E4;
    s = fzgx_rodata_E8;
}
#pragma section code_type ".text"

/* the retail TU's .bss objects this function uses, at their retail offsets, so MWCC addresses them off one
 * section base (the save state at +0x2437C becomes `addis r31, base, 2`); the fzgx_pool_gap_ objects span
 * the retail objects in between, which this function does not touch (lbl_3_bss_140 is addressed by name) */
u32 fzgx_obj_lbl_3_bss_0[2];
u8 fzgx_pool_gap_8[0xE8];
CustomizeController fzgx_obj_lbl_3_bss_F0;
u8 fzgx_pool_gap_F8[0x24284];
u8 fzgx_obj_lbl_3_bss_2437C;
u8 lbl_3_bss_2437C__fzgx_offset_1;
u8 lbl_3_bss_2437C__fzgx_offset_2;
u8 fzgx_pool_gap_2437F;
s32 lbl_3_bss_2437C__fzgx_offset_4;
s32 lbl_3_bss_2437C__fzgx_offset_8;
u8 lbl_3_bss_2437C__fzgx_offset_C;
u8 fzgx_pool_gap_24389;
u8 fzgx_pool_gap_2438A;
u8 fzgx_pool_gap_2438B;
s32 lbl_3_bss_2437C__fzgx_offset_10;
s32 lbl_3_bss_2437C__fzgx_offset_14;
s32 lbl_3_bss_2437C__fzgx_offset_18;
u8 lbl_3_bss_2437C__fzgx_offset_1C;
u8 fzgx_pool_gap_24399;
u8 fzgx_pool_gap_2439A;
u8 fzgx_pool_gap_2439B;
s32 lbl_3_bss_2437C__fzgx_offset_20;

#pragma section code_type ".fzgxpool"
static void fzgx_bss_layout(void) {
    volatile u8 s; /* fzgx-allow: S2 layout primer sink: keeps the retail .bss objects in retail order */
    s = *(u8 *)fzgx_obj_lbl_3_bss_0;
    s = *fzgx_pool_gap_8;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_F0;
    s = *fzgx_pool_gap_F8;
    s = fzgx_obj_lbl_3_bss_2437C;
    s = lbl_3_bss_2437C__fzgx_offset_1;
    s = lbl_3_bss_2437C__fzgx_offset_2;
    s = fzgx_pool_gap_2437F;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_4;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_8;
    s = lbl_3_bss_2437C__fzgx_offset_C;
    s = fzgx_pool_gap_24389;
    s = fzgx_pool_gap_2438A;
    s = fzgx_pool_gap_2438B;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_10;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_14;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_18;
    s = lbl_3_bss_2437C__fzgx_offset_1C;
    s = fzgx_pool_gap_24399;
    s = fzgx_pool_gap_2439A;
    s = fzgx_pool_gap_2439B;
    s = *(u8 *)&lbl_3_bss_2437C__fzgx_offset_20;
}
#pragma section code_type ".text"

static inline void customize_save_panel(void) {
    CustomizeColor color = fzgx_rodata_48;
    fn_1_53BD8(&color, fzgx_rodata_4, fzgx_rodata_8, fzgx_rodata_4C, fzgx_rodata_50, fzgx_rodata_54);
}
static inline void customize_save_text(const char *text, f32 y) {
    char buffer[1024];
    fn_1_4AEC0(1);
    fn_1_4AEB4(fzgx_rodata_5C);
    fn_1_49410();
    fn_1_4955C(fzgx_rodata_7C, fzgx_rodata_7C);
    fn_1_4954C(fzgx_rodata_70);
    fn_1_495C8(9);
    fn_1_496FC(fzgx_rodata_4, y);
    fn_1_4966C(fzgx_rodata_60, fzgx_rodata_64);
    if (lbl_801A66B4 != 5) {
        fn_1_495B0(0x80000000);
        fn_1_49590(fzgx_rodata_14);
        fn_1_4966C(fzgx_rodata_60, fzgx_rodata_68);
    }
    fn_3_BFC(buffer, (void *)text, lbl_3_data_15CC, (&lbl_3_data_E80[save_slot * 6])[lbl_801A66B4]);
    fn_3_BFC(buffer, buffer, lbl_3_data_15CC, (&lbl_3_data_E80[save_slot * 6])[lbl_801A66B4]);
    fn_3_BFC(buffer, buffer, lbl_3_data_15CC, (&lbl_3_data_E80[save_slot * 6])[lbl_801A66B4]);
    fn_1_4A0D8(buffer);
    fn_1_4AEC0(0);
    fn_1_4AEB4(fzgx_rodata_44);
}
static inline s32 customize_save_move_impl(s32 controller, u8 *choice) {
    s32 offset = controller * sizeof(fn_3_15A0_CustomizeInput);
    u16 *repeat = (u16 *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + offset);
    if (((*(repeat += 8) >> 0) & 1) ||
        (((((fn_3_15A0_CustomizeInput *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + offset))->held >> 0) & 1))) {
        *choice = 0;
        fn_1_A2D84(0xA9000000 | (0x11300));
    }
    if (((*repeat >> 1) & 1) ||
        (((((fn_3_15A0_CustomizeInput *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + offset))->held >> 1) & 1))) {
        *choice = 1;
        fn_1_A2D84(0xA9000000 | (0x11300));
    }
    return offset;
}
static inline void customize_save_result(int allow_missing) {
    if (save_result == -6 || save_result == -13) {
        if (save_attempts > 1) save_state = 26;
        else save_state = 8;
    } else if (save_result == 0 || (allow_missing && save_result == -3)) {
        save_state = 2;
    } else if (save_result == -2) {
        save_state = 28;
    } else {
        save_state = 26;
    }
}
#pragma opt_common_subs off
void fn_3_15A0(void) {
    f32 progress, remaining, size;
    s32 controller = fzgx_obj_lbl_3_bss_F0.controller;
    s32 input_offset;
    u16 *pressed;
    char message[1024];

    if (fn_1_B7C00()) return;
    {
        s32 frame = save_frame + 1;
        u8 state = save_state;
        save_frame = frame;
        if (state != save_previous_state) {
            save_previous_state = state;
            save_frame = 0;
        }
    }
    if (save_frame < 10) {
        progress = (f32)save_frame / fzgx_rodata_B4;
        remaining = fzgx_rodata_A8 - progress;
        size = fzgx_rodata_4 * remaining;
        size *= remaining;
        fn_1_54278((s32)size, 0);
        fn_1_5428C(progress * progress);
    } else {
        fn_1_54278(0, 0);
        fn_1_5428C(fzgx_rodata_A8);
    }
    switch (save_state) {
    case 0:
        save_error = 0;
        save_free_blocks = 0;
        save_free_files = 0;
        save_slot = 0;
        save_state = 1;
        fn_80008BEC(&lbl_3_bss_140, 0, 0x20700);
        save_attempts++;
        break;
    case 1:
        if (fn_1_B7EC4(0) && fn_1_B7EC4(1)) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            customize_save_text(lbl_3_data_8E0[lbl_801A66B4], fzgx_rodata_DC);
            fn_3_10A4(&save_slot);
            customize_save_move(controller, &save_slot);
            pressed = (u16 *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + input_offset);
            if (((*(pressed += 4) >> 8) & 1)) {
                fn_1_A2D84(0xA9000000 | (0x11100));
                save_result = fn_1_B800C(save_slot);
                fn_1_B80F0(save_slot);
                customize_save_result(1);
            } else if (((*pressed >> 9) & 1)) {
                lbl_1_bss_96A = 0x5C;
            }
        } else if (fn_1_B7EC4(0)) {
            save_slot = 0;
            save_result = fn_1_B800C(0);
            fn_1_B80F0(save_slot);
            customize_save_result(0);
        } else if (fn_1_B7EC4(1)) {
            save_slot = 1;
            save_result = fn_1_B800C(1);
            fn_1_B80F0(save_slot);
            customize_save_result(0);
        } else {
            save_state = 6;
        }
        break;
    case 2:
        save_state = 3;
        break;
    case 3:
        if (!fn_1_B7EC4(save_slot)) {
            save_state = 6;
        } else if (!fn_1_B7C6C(save_slot)) {
            fn_1_B8338(save_slot);
            fn_1_B8E84(3, &save_error, &save_free_blocks, &save_free_files);
            if (save_error) save_state = 8;
            else if (save_free_blocks >= 18 && save_free_files > 0) save_state = 13;
            else save_state = 15;
        } else {
            save_state = 6;
        }
        break;
    case 26:
        if (!fn_1_B7C00()) {
            save_attempts = 0;
            save_choice = 1;
            save_state = 27;
        }
        break;
    case 27:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            if (save_result == -13 || save_result == -6)
                fn_3_CB4(lbl_3_data_6A0[lbl_801A66B4]);
            else
                fn_3_CB4(lbl_3_data_73C[lbl_801A66B4]);
            customize_save_text(lbl_3_data_9B8[lbl_801A66B4], fzgx_rodata_8);
            fn_3_E64(&save_choice);
            customize_save_move(controller, &save_choice);
            pressed = (u16 *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + input_offset);
            if (((*(pressed += 4) >> 8) & 1)) {
                if (save_choice == 0) {
                    fn_1_A2D84(0xA9000000 | (0x11100));
                    save_timer = 120;
                    save_state = 17;
                } else {
                    fn_1_A2D84(0xA9000000 | (0x11000));
                    save_state = 22;
                }
            }
        }
        break;
    case 28:
        if (!fn_1_B7C00()) {
            save_choice = 1;
            save_state = 29;
        }
        break;
    case 29:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            fn_3_CB4(lbl_3_data_858[lbl_801A66B4]);
            customize_save_text(lbl_3_data_924[lbl_801A66B4], fzgx_rodata_E0);
            if ((((*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8)[0].pressed >> 8) & 1)) {
                fn_1_A2D84(0xA9000000 | (0x11100));
                save_timer = 120;
                save_state = 17;
            } else if ((((*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8)[0].pressed >> 11) & 1)) {
                fn_1_A2D84(0xA9000000 | (0x11000));
                save_state = 22;
            }
        }
        break;
    case 6:
        if (!fn_1_B7C00()) {
            save_timer = 120;
            save_state = 7;
        }
        break;
    case 7:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            customize_save_text(lbl_3_data_A60[lbl_801A66B4], fzgx_rodata_8);
            if (save_timer-- < 0) {
                save_slot = 2;
                lbl_1_bss_96A = 0x5F;
            }
        }
        break;
    case 4:
        if (!fn_1_B7C00()) save_state = 5;
        break;
    case 5:
        if (!fn_1_B7C00()) {
            if (save_error) save_state = 8;
            else save_state = 11;
        }
        break;
    case 8:
        if (!fn_1_B7C00()) {
            fn_1_131084(&lbl_3_bss_140, save_slot);
            save_state = 9;
        }
        break;
    case 9:
        if (!fn_1_B7C00()) {
            save_result = fn_1_B7C5C();
            if (save_result != 0) {
                fn_80008BEC(&lbl_3_bss_140, 0, 0x20700);
                save_state = 0;
            } else {
                save_state = 10;
            }
        }
        break;
    case 10:
        lbl_1_bss_96A = 0x5F;
        break;
    case 11:
        if (!fn_1_B7C00()) save_state = 12;
        break;
    case 12:
        if (!fn_1_B7C00()) {
            if (save_free_blocks >= 18 && save_free_files > 0) save_state = 13;
            else save_state = 15;
        }
        break;
    case 13:
        if (!fn_1_B7C00()) {
            save_choice = 0;
            save_state = 14;
        }
        break;
    case 14:
        if (!fn_1_B7C00()) {
            if (!fn_1_B7E98(save_slot)) {
                save_state = 22;
                break;
            }
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            sprintf(message, lbl_3_data_3EC[lbl_801A66B4], save_free_blocks);
            fn_3_CB4(message);
            customize_save_text(lbl_3_data_C8C[lbl_801A66B4], fzgx_rodata_8);
            fn_3_E64(&save_choice);
            customize_save_move(controller, &save_choice);
            pressed = (u16 *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + input_offset);
            if (((*(pressed += 4) >> 8) & 1)) {
                if (save_choice == 0) {
                    fn_1_A2D84(0xA9000000 | (0x11100));
                    save_timer = 120;
                    save_state = 18;
                } else {
                    fn_1_A2D84(0xA9000000 | (0x11000));
                    save_state = 20;
                }
            }
        }
        break;
    case 18:
        if (!fn_1_B7C00()) {
            fn_1_131050(&lbl_3_bss_140, save_slot);
            save_state = 19;
        }
        break;
    case 19:
        if (!fn_1_B7C00()) {
            if ((s32)fn_1_B7C5C() == 0) lbl_1_bss_96A = 0x5F;
            else save_state = 0;
        }
        break;
    case 20:
        if (!fn_1_B7C00()) {
            save_timer = 120;
            save_state = 21;
        }
        break;
    case 21:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            customize_save_text(lbl_3_data_B2C[lbl_801A66B4], fzgx_rodata_8);
            if (save_timer-- < 0) lbl_1_bss_96A = 0x5F;
        }
        break;
    case 15:
        if (!fn_1_B7C00()) {
            save_choice = 1;
            save_state = 16;
        }
        break;
    case 16:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            fn_3_CB4(lbl_3_data_630[lbl_801A66B4]);
            customize_save_text(lbl_3_data_9B8[lbl_801A66B4], fzgx_rodata_8);
            fn_3_E64(&save_choice);
            customize_save_move(controller, &save_choice);
            pressed = (u16 *)((u8 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8) + input_offset);
            if (((*(pressed += 4) >> 8) & 1)) {
                if (save_choice == 0) {
                    fn_1_A2D84(0xA9000000 | (0x11100));
                    save_timer = 120;
                    save_state = 17;
                } else {
                    fn_1_A2D84(0xA9000000 | (0x11000));
                    save_state = 22;
                }
            }
        }
        break;
    case 17:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            customize_save_text(lbl_3_data_B2C[lbl_801A66B4], fzgx_rodata_8);
            if (save_timer-- < 0) {
                save_slot = 2;
                lbl_1_bss_96A = 0x5F;
            }
        }
        break;
    case 22:
        if (!fn_1_B7C00()) save_state = 23;
        break;
    case 23:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            fn_3_CB4(lbl_3_data_7BC[lbl_801A66B4]);
            customize_save_text(lbl_3_data_D38[lbl_801A66B4], fzgx_rodata_E4);
            pressed = (u16 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8);
            pressed += controller * (sizeof(fn_3_15A0_CustomizeInput) / sizeof(u16));
            if (((*(pressed += 4) >> 8) & 1)) {
                fn_1_A2D84(0xA9000000 | (0x11100));
                save_state = 0;
            } else if (((*pressed >> 9) & 1)) {
                save_timer = 120;
                fn_1_A2D84(0xA9000000 | (0x11000));
                save_state = 24;
            }
        }
        break;
    case 24:
        if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
        customize_save_panel();
        customize_save_text(lbl_3_data_DA8[lbl_801A66B4], fzgx_rodata_8);
        if (save_timer-- < 0) save_state = 25;
        break;
    case 25:
        if (!fn_1_B7C00()) {
            if (save_frame == 0) fn_1_A2D84(0xA9000000 | (0x10600));
            customize_save_panel();
            customize_save_text(lbl_3_data_AC0[lbl_801A66B4], fzgx_rodata_E8);
            customize_save_text(lbl_3_data_DF8[lbl_801A66B4], fzgx_rodata_4);
            pressed = (u16 *)(*(fn_3_15A0_CustomizeInput (*)[])&lbl_1_bss_9F8);
            pressed += controller * (sizeof(fn_3_15A0_CustomizeInput) / sizeof(u16));
            if (((*(pressed += 4) >> 8) & 1)) {
                fn_1_A2D84(0xA9000000 | (0x11100));
                save_slot = 2;
                lbl_1_bss_96A = 0x5F;
            }
        }
        break;
    }
    fn_1_54278(0, 0);
    fn_1_5428C(fzgx_rodata_A8);
}
#pragma opt_common_subs reset
