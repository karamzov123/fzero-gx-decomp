#include "types.h"
#include "dolphin/dvd.h"
#include "rel/main_rel/data/lbl_1_data_35B14.h"
#include "rel/main_rel/data/lbl_1_data_35B5C.h"
#include "rel/main_rel/data/lbl_1_data_35B9C.h"
#include "rel/main_rel/data/lbl_1_data_35BDC.h"
#include "rel/main_rel/data/lbl_1_data_3B74C.h"
#include "rel/main_rel/data/lbl_1_data_3C264.h"
#include "rel/main_rel/data/lbl_1_data_3C58C.h"

typedef struct Sig_DVDOpen_DVDFileInfo Sig_DVDOpen_DVDFileInfo;
typedef void (*Sig_DVDOpen_DVDCallback)(s32 result, Sig_DVDOpen_DVDFileInfo *fileInfo);
struct Sig_DVDOpen_DVDFileInfo {
    DVDCommandBlock cb;
    u32 startAddr;
    u32 length;
    Sig_DVDOpen_DVDCallback callback;
};

typedef struct Sig_fn_800174D0_Fn800174D0Object {
    u8 pad30[0x30];
    u32 field30;
    u32 field34;
    void *field38;
} Sig_fn_800174D0_Fn800174D0Object;

typedef struct CardSlotInfo {
    u16 unk_0;
    u16 unk_2;
    u8 pad_4[4];
    u16 unk_8;
    u16 unk_A;
    u8 pad_C[4];
} CardSlotInfo;

typedef struct CardTask CardTask;
typedef struct CardMgr CardMgr;
typedef struct GhostFileNode GhostFileNode;

struct GhostFileNode {
    u8 pad_00[0x20];
    char unk_20[0x1E];
    u8 unk_3E;
};

struct CardMgr {
    u8 unk_00;
    u8 unk_01;
    u8 pad_02[2];
    s32 unk_04;
    u32 unk_08;
    u32 unk_0C;
    u32 unk_10;
    s32 unk_14;
    u64 unk_18;
    u8 pad_20[0x1E];
    u8 unk_3E;
    u8 pad_3F[0xF];
    u8 unk_4E;
    u8 pad_4F;
    u32 unk_50;
    u16 unk_54;
    u16 unk_56;
    u32 unk_58;
    u8 pad_5C[0x2C];
    u32 unk_88;
    GhostFileNode *unk_8C;
    u8 pad_90[4];
    u8 *unk_94;
    u8 unk_98[0x24];
    u8 unk_BC[0x20];
};

struct CardTask {
    u8 unk_00;
    u8 unk_01;
    u8 unk_02;
    u8 unk_03;
    u8 unk_04;
    u8 unk_05;
    u8 unk_06;
    u8 unk_07;
    s16 unk_08;
    s16 unk_0A;
    void *unk_0C;
    u8 pad_10[0x14];
    CardMgr *unk_24;
    s8 unk_28;
    u8 pad_29;
    u8 unk_2A;
    u8 pad_2B[5];
    u32 unk_30;
    f32 unk_34;
    f32 unk_38;
    u8 pad_3C[0xC];
    u64 unk_48;
    s32 unk_50;
    u8 pad_54[0x4C];
};

typedef struct GhostRegs {
    u16 unk_0;
    u8 pad_2[4];
    u16 unk_6;
    u8 pad_8[0x198];
    u16 unk_1A0;
    u8 pad_1A2[0x537E];
    u16 unk_5520;
    u8 pad_5522[0x4C6];
} GhostRegs;

/* memcard.c file-scope objects, in retail order: MWCC addresses them off one section base. */
u32 lbl_1_bss_716C0[2];
CardTask lbl_1_bss_716C8[2];
u32 lbl_1_bss_71808;
u32 lbl_1_bss_7180C;
u8 lbl_1_bss_71810[0xA1];
u8 lbl_1_bss_718B1;
u32 lbl_1_bss_718B4;
u8 lbl_1_bss_718B8;
u8 lbl_1_bss_718B8__fzgx_offset_1;
u32 lbl_1_bss_718C0[8] __attribute__((aligned(8)));
GhostRegs lbl_1_bss_718E0;
u8 lbl_1_bss_772C8;
u8 lbl_1_bss_772C8__fzgx_offset_1;
u16 lbl_1_bss_772C8__fzgx_offset_2;
u32 lbl_1_bss_772C8__fzgx_offset_4[15];
u8 lbl_1_bss_772C8__fzgx_offset_40;
u8 lbl_1_bss_772C8__fzgx_offset_41;
u8 lbl_1_bss_7730A;

#pragma section code_type ".fzgxpool"
static void fzgx_bss_layout(void) {
    volatile u32 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits .bss objects in first-access order */
    s = lbl_1_bss_716C0[0];
    s = lbl_1_bss_716C8[0].unk_00;
    s = lbl_1_bss_71808;
    s = lbl_1_bss_7180C;
    s = lbl_1_bss_71810[0];
    s = lbl_1_bss_718B1;
    s = lbl_1_bss_718B4;
    s = lbl_1_bss_718B8;
    s = lbl_1_bss_718B8__fzgx_offset_1;
    s = lbl_1_bss_718C0[0];
    s = lbl_1_bss_718E0.unk_0;
    s = lbl_1_bss_772C8;
    s = lbl_1_bss_772C8__fzgx_offset_1;
    s = lbl_1_bss_772C8__fzgx_offset_2;
    s = lbl_1_bss_772C8__fzgx_offset_4[0];
    s = lbl_1_bss_772C8__fzgx_offset_40;
    s = lbl_1_bss_772C8__fzgx_offset_41;
    s = lbl_1_bss_7730A;
}
#pragma section code_type ".text"

typedef struct MgrRoot {
    u32 unk_0;
} MgrRoot;

extern MgrRoot lbl_801A6410;
extern CardSlotInfo lbl_1_bss_9F8;
/* memcard.c .data in retail order, before its string literals */
#pragma explicit_zero_data on
__declspec(section ".data") u32 lbl_1_data_35AC8 __attribute__((aligned(8))) = 0x04040000U;
#pragma explicit_zero_data reset
#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35ACC[9] __attribute__((aligned(4))) = "OVERTAKE";
#pragma explicit_zero_data reset
extern char lbl_1_data_35AD8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35AD8[5] __attribute__((aligned(8))) = "JUMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_35AE0[];
extern char lbl_1_data_35AEC[];
extern char lbl_1_data_35AF4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35AE0[9] __attribute__((aligned(8))) = "ENEMYHIT";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35AEC[8] __attribute__((aligned(4))) = "WALLHIT";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35AF4[11] __attribute__((aligned(4))) = "SIDEBYSIDE";
#pragma explicit_zero_data reset
extern char lbl_1_data_35B00[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B00[6] __attribute__((aligned(8))) = "START";
#pragma explicit_zero_data reset
extern char lbl_1_data_35B08[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B08[5] __attribute__((aligned(8))) = "GOAL";
#pragma explicit_zero_data reset
extern char lbl_1_data_35B10[];
extern char lbl_1_data_35B34[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B10[4] __attribute__((aligned(8))) = "LAP";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_35B14 lbl_1_data_35B14 __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_35ACC,
    (u8 *)&lbl_1_data_35AD8,
    (u8 *)&lbl_1_data_35AE0,
    (u8 *)&lbl_1_data_35AEC,
    (u8 *)&lbl_1_data_35AF4,
    (u8 *)&lbl_1_data_35B00,
    (u8 *)&lbl_1_data_35B08,
    (u8 *)&lbl_1_data_35B10
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B34[20] __attribute__((aligned(4))) = "./memcard/emb_e.bin";
#pragma explicit_zero_data reset
extern char lbl_1_data_35B48[];
extern char lbl_1_data_35B74[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B48[18] __attribute__((aligned(8))) = "./memcard/emb.bin";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_35B5C lbl_1_data_35B5C __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_35B34,
    (u8 *)&lbl_1_data_35B34,
    (u8 *)&lbl_1_data_35B34,
    (u8 *)&lbl_1_data_35B34,
    (u8 *)&lbl_1_data_35B34,
    (u8 *)&lbl_1_data_35B48
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B74[20] __attribute__((aligned(4))) = "./memcard/gho_e.bin";
#pragma explicit_zero_data reset
extern char lbl_1_data_35B88[];
extern char lbl_1_data_35BB4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35B88[18] __attribute__((aligned(8))) = "./memcard/gho.bin";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_35B9C lbl_1_data_35B9C __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_35B74,
    (u8 *)&lbl_1_data_35B74,
    (u8 *)&lbl_1_data_35B74,
    (u8 *)&lbl_1_data_35B74,
    (u8 *)&lbl_1_data_35B74,
    (u8 *)&lbl_1_data_35B88
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35BB4[20] __attribute__((aligned(4))) = "./memcard/rep_e.bin";
#pragma explicit_zero_data reset
extern char lbl_1_data_35BC8[];
extern char lbl_1_data_35BF4[];
extern char lbl_1_data_35C44[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35BC8[18] __attribute__((aligned(8))) = "./memcard/rep.bin";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_35BDC lbl_1_data_35BDC __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_35BB4,
    (u8 *)&lbl_1_data_35BB4,
    (u8 *)&lbl_1_data_35BB4,
    (u8 *)&lbl_1_data_35BB4,
    (u8 *)&lbl_1_data_35BB4,
    (u8 *)&lbl_1_data_35BC8
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35BF4[77] __attribute__((aligned(4))) = "A Memory Card is not inserted in SLOT.\nPlease properly insert a Memory Card.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35C44[11] __attribute__((aligned(4))) = "NOCARD GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_35C50[];
extern char lbl_1_data_35C5C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35C50[11] __attribute__((aligned(8))) = "NOCARD FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35C5C[11] __attribute__((aligned(4))) = "NOCARD SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_35C68[];
extern char lbl_1_data_35C74[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35C68[11] __attribute__((aligned(8))) = "NOCARD ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35C74[108] __attribute__((aligned(4))) = "SLOT\202\311\203\201\203\202\203\212\201[\203J\201[\203h\202\252\214\251[\202\335]\202\302\202"
    "\251\202\350\202\334\202\271\202\361\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\314"
    "\220\332[\202\271\202\302]\221\261[\202\274\202\255]\202\360\212m[\202\251\202\255]\224F[\202"
    "\311\202\361]\202\265\202\304\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_35CE0[];
extern char lbl_1_data_35D24[];
extern char lbl_1_data_35D34[];
extern char lbl_1_data_35D44[];
extern char lbl_1_data_35D54[];
extern char lbl_1_data_35D64[];
extern char lbl_1_data_35DC4[];
extern char lbl_1_data_35E34[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35CE0[66] __attribute__((aligned(8))) = "The device in SLOT is not supported.\nPlease insert a Memory Card.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35D24[16] __attribute__((aligned(4))) = "WRONGDEVICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35D34[16] __attribute__((aligned(4))) = "WRONGDEVICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35D44[16] __attribute__((aligned(4))) = "WRONGDEVICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35D54[16] __attribute__((aligned(4))) = "WRONGDEVICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35D64[96] __attribute__((aligned(4))) = "SLOT\202\311\202\315\n\203\201\203\202\203\212\201[\203J\201[\203h\210\310[\202\242]\212O[\202"
    "\252\202\242]\202\314\202\340\202\314\202\252\202\263\202\263\202\301\202\304\202\242\202\334"
    "\202\267\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\360\202\263\202\265\202\304\202"
    "\255\202\276\202\263\202\242\201B\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35DC4[111] __attribute__((aligned(4))) = "A fatal error has occured.\nTurn the power off and refer to the Nintendo GameCube\nhardware manu"
    "al for details. ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35E34[10] __attribute__((aligned(4))) = "FATAL GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_35E40[];
extern char lbl_1_data_35E4C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35E40[10] __attribute__((aligned(8))) = "FATAL FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35E4C[10] __attribute__((aligned(4))) = "FATAL SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_35E58[];
extern char lbl_1_data_35E64[];
extern char lbl_1_data_35F4C[];
extern char lbl_1_data_35FA4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35E58[10] __attribute__((aligned(8))) = "FATAL ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35E64[232] __attribute__((aligned(4))) = "\222v[\202\277]\226\275[\202\337\202\242]\223I[\202\304\202\253]\202\310\203G\203\211\201[\202"
    "\252\213N[\202\250]\202\261\202\350\202\334\202\265\202\275\201B\n\n\226{[\202\331\202\361]\221"
    "\314[\202\275\202\242]\202\314\203p\203\217\201[\203{\203^\203\223\202\360\211\237[\202\250]\202"
    "\265\202\304\n\223d[\202\305\202\361]\214\271[\202\260\202\361]\202\360\202n\202e\202e\202\311"
    "\202\265\201A\n\226{[\202\331\202\361]\221\314[\202\275\202\242]\202\314\216\346[\202\306]\202"
    "\350\210\265[\202\240\202\302\202\251]\202\242\220\340[\202\271\202\302]\226\276[\202\337\202"
    "\242]\217\221[\202\265\202\345]\202\314\n\216w[\202\265]\216\246[\202\266]\202\311\217][\202\265"
    "\202\275\202\252]\202\301\202\304\202\255\202\276\202\263\202\242\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35F4C[88] __attribute__((aligned(4))) = "This data version is incorrect.\nSave game data again in the Game Data menu in Options. ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35FA4[12] __attribute__((aligned(4))) = "VERSION GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_35FB0[];
extern char lbl_1_data_35FBC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35FB0[12] __attribute__((aligned(8))) = "VERSION FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35FBC[12] __attribute__((aligned(4))) = "VERSION SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_35FC8[];
extern char lbl_1_data_35FD4[];
extern char lbl_1_data_3603C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35FC8[12] __attribute__((aligned(8))) = "VERSION ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_35FD4[104] __attribute__((aligned(4))) = "\203f\201[\203^\202\314\203o\201[\203W\203\207\203\223\202\252\210\341[\202\277\202\252]\202\242"
    "\202\334\202\267\201B\n\203I\203v\203V\203\207\203\223\202\314\203Q\201[\203\200\203f\201[\203^"
    "\202\305\n\203f\201[\203^\202\360\203Z\201[\203u\202\265\222\274[\202\310\202\250]\202\265\202"
    "\304\202\255\202\276\202\263\202\242\201B\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3603C[52] __attribute__((aligned(4))) = "\203\237 \201c Continue without loading\n  \203\262 \201c Try again \000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36070[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36070[23] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36088[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36088[23] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_360A0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_360A0[23] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_360B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_360B8[23] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_360D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_360D0[40] __attribute__((aligned(8))) = "\203\237\201c\203\215\201[\203h\202\271\202\270\202\311\217I[\202\250]\202\355\202\351 \203\262"
    "\201c\203\212\203g\203\211\203C";
#pragma explicit_zero_data reset
extern char lbl_1_data_360F8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_360F8[48] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again \000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36128[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36128[23] __attribute__((aligned(8))) = "CAPTION_SAVE_RETRY GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36140[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36140[23] __attribute__((aligned(8))) = "CAPTION_SAVE_RETRY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36158[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36158[23] __attribute__((aligned(8))) = "CAPTION_SAVE_RETRY SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36170[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36170[23] __attribute__((aligned(8))) = "CAPTION_SAVE_RETRY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36188[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36188[40] __attribute__((aligned(8))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\217I[\202\250]\202\355\202\351 \203\262\201"
    "c\203\212\203g\203\211\203C";
#pragma explicit_zero_data reset
extern char lbl_1_data_361B0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_361B0[48] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_361E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_361E0[23] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_361F8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_361F8[23] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36210[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36210[23] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36228[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36228[23] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36240[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36240[48] __attribute__((aligned(8))) = "\203\237\201c\203\212\203X\203g\202\360\216\346[\202\306]\202\347\202\270\202\311\217I[\202\250]"
    "\202\355\202\351 \203\262\201c\203\212\203g\203\211\203C";
#pragma explicit_zero_data reset
extern char lbl_1_data_36270[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36270[48] __attribute__((aligned(8))) = "\203\237 \201c Continue without erasing\n\203\262 \201c Try again ";
#pragma explicit_zero_data reset
extern char lbl_1_data_362A0[];
extern char lbl_1_data_362BC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_362A0[25] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_362BC[25] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_362D8[];
extern char lbl_1_data_362F4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_362D8[25] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_362F4[25] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36310[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36310[40] __attribute__((aligned(8))) = "\203\237\201c\217\301[\202\257]\202\263\202\270\202\311\217I[\202\250]\202\355\202\351 \203\262"
    "\201c\203\212\203g\203\211\203C";
#pragma explicit_zero_data reset
extern char lbl_1_data_36338[];
extern char lbl_1_data_3636C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36338[52] __attribute__((aligned(8))) = "\203\237 \201c Continue without checking\n\203\262 \201c Try again \000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3636C[25] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36388[];
extern char lbl_1_data_363A4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36388[25] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_363A4[25] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_363C0[];
extern char lbl_1_data_363DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_363C0[25] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_363DC[44] __attribute__((aligned(4))) = "\203\237\201c\203`\203F\203b\203N\202\271\202\270\202\311\217I[\202\250]\202\355\202\351 \203"
    "\262\201c\203\212\203g\203\211\203C\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36408[];
extern char lbl_1_data_3644C[];
extern char lbl_1_data_3646C[];
extern char lbl_1_data_3648C[];
extern char lbl_1_data_364AC[];
extern char lbl_1_data_364CC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36408[68] __attribute__((aligned(8))) = "\203\237 \201c Continue without loading\n\203\262 \201c Try again\n\203\264 \201c Choose Slot "
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3644C[30] __attribute__((aligned(4))) = "CAPTION_LOAD_RETRY_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3646C[30] __attribute__((aligned(4))) = "CAPTION_LOAD_RETRY_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3648C[30] __attribute__((aligned(4))) = "CAPTION_LOAD_RETRY_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_364AC[30] __attribute__((aligned(4))) = "CAPTION_LOAD_RETRY_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_364CC[68] __attribute__((aligned(4))) = "\203\237\201c\203\215\201[\203h\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262"
    "\201c\203\212\203g\203\211\203C \203\264\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202"
    "\347]\202\324\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36510[];
extern char lbl_1_data_36554[];
extern char lbl_1_data_36574[];
extern char lbl_1_data_36594[];
extern char lbl_1_data_365B4[];
extern char lbl_1_data_365D4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36510[68] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again\n\203\264 \201c Choose Slot "
    "\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36554[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36574[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36594[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_365B4[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_365D4[68] __attribute__((aligned(4))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262"
    "\201c\203\212\203g\203\211\203C \203\264\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202"
    "\347]\202\324\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36618[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36618[48] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again \000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36648[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36648[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_CHOICE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36668[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36668[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_CHOICE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36688[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36688[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_CHOICE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_366A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_366A8[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_CHOICE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_366C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_366C8[48] __attribute__((aligned(8))) = "\203\237\201c\203\212\203X\203g\202\360\216\346[\202\306]\202\347\202\270\202\311\217I[\202\250]"
    "\202\355\202\351\n\203\262\201c\203\212\203g\203\211\203C";
#pragma explicit_zero_data reset
extern char lbl_1_data_366F8[];
extern char lbl_1_data_3673C[];
extern char lbl_1_data_3675C[];
extern char lbl_1_data_3677C[];
extern char lbl_1_data_3679C[];
extern char lbl_1_data_367BC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_366F8[68] __attribute__((aligned(8))) = "\203\237 \201c Continue without erasing\n\203\262 \201c Try again\n\203\264 \201c Choose Slot "
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3673C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3675C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3677C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3679C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_367BC[68] __attribute__((aligned(4))) = "\203\237\201c\217\301[\202\257]\202\263\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262"
    "\201c\203\212\203g\203\211\203C \203\264\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202"
    "\347]\202\324\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36800[];
extern char lbl_1_data_36844[];
extern char lbl_1_data_36864[];
extern char lbl_1_data_36884[];
extern char lbl_1_data_368A4[];
extern char lbl_1_data_368C4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36800[68] __attribute__((aligned(8))) = "\203\237 \201c Continue without checking\n\203\262 \201c Try again\n\203\264 \201c Choose Slot "
    "\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36844[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36864[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36884[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_368A4[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_368C4[68] __attribute__((aligned(4))) = "\203\237\201c\203`\203F\203b\203N\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203"
    "\262\201c\203\212\203g\203\211\203C \203\264\201c\203X\203\215\203b\203g\202\360\221I[\202\246"
    "\202\347]\202\324\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36908[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36908[32] __attribute__((aligned(8))) = "Please press the \203\237 Button. \000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36928[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36928[14] __attribute__((aligned(8))) = "CAPTION_A GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36938[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36938[14] __attribute__((aligned(8))) = "CAPTION_A FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36948[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36948[14] __attribute__((aligned(8))) = "CAPTION_A SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36958[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36958[14] __attribute__((aligned(8))) = "CAPTION_A ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36968[];
extern char lbl_1_data_36984[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36968[28] __attribute__((aligned(8))) = "\203\237\202\360\211\237[\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B\000\000"
    "\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36984[20] __attribute__((aligned(4))) = "\203\237 \201c Delete file\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36998[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36998[14] __attribute__((aligned(8))) = "CAPTION_A GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_369A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_369A8[14] __attribute__((aligned(8))) = "CAPTION_A FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_369B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_369B8[14] __attribute__((aligned(8))) = "CAPTION_A SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_369C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_369C8[14] __attribute__((aligned(8))) = "CAPTION_A ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_369D8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_369D8[16] __attribute__((aligned(8))) = "\203\237\201c\217\301[\202\257]\202\267\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_369E8[];
extern char lbl_1_data_36A1C[];
extern char lbl_1_data_36A34[];
extern char lbl_1_data_36A4C[];
extern char lbl_1_data_36A64[];
extern char lbl_1_data_36A7C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_369E8[52] __attribute__((aligned(8))) = "\203\237 \201c Continue without loading\n\203\264 \201c Choose a Slot ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36A1C[24] __attribute__((aligned(4))) = "CAPTION_LOAD_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36A34[24] __attribute__((aligned(4))) = "CAPTION_LOAD_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36A4C[24] __attribute__((aligned(4))) = "CAPTION_LOAD_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36A64[24] __attribute__((aligned(4))) = "CAPTION_LOAD_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36A7C[52] __attribute__((aligned(4))) = "\203\237\201c\203\215\201[\203h\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\264"
    "\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202\347]\202\324";
#pragma explicit_zero_data reset
extern char lbl_1_data_36AB0[];
extern char lbl_1_data_36AE4[];
extern char lbl_1_data_36AFC[];
extern char lbl_1_data_36B14[];
extern char lbl_1_data_36B2C[];
extern char lbl_1_data_36B44[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36AB0[52] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\264 \201c Choose a Slot \000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36AE4[24] __attribute__((aligned(4))) = "CAPTION_SAVE_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36AFC[24] __attribute__((aligned(4))) = "CAPTION_SAVE_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36B14[24] __attribute__((aligned(4))) = "CAPTION_SAVE_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36B2C[24] __attribute__((aligned(4))) = "CAPTION_SAVE_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36B44[52] __attribute__((aligned(4))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\264"
    "\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202\347]\202\324";
#pragma explicit_zero_data reset
extern char lbl_1_data_36B78[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36B78[32] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36B98[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36B98[24] __attribute__((aligned(8))) = "CAPTION_LIST_CHOICE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36BB0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36BB0[24] __attribute__((aligned(8))) = "CAPTION_LIST_CHOICE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36BC8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36BC8[24] __attribute__((aligned(8))) = "CAPTION_LIST_CHOICE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36BE0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36BE0[24] __attribute__((aligned(8))) = "CAPTION_LIST_CHOICE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36BF8[];
extern char lbl_1_data_36C1C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36BF8[36] __attribute__((aligned(8))) = "\203\237\201c\203\212\203X\203g\202\360\216\346[\202\306]\202\347\202\270\202\311\217I[\202\250]"
    "\202\355\202\351\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36C1C[52] __attribute__((aligned(4))) = "\203\237 \201c Continue without erasing\n\203\264 \201c Choose a Slot ";
#pragma explicit_zero_data reset
extern char lbl_1_data_36C50[];
extern char lbl_1_data_36C6C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36C50[26] __attribute__((aligned(8))) = "CAPTION_DELETE_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36C6C[26] __attribute__((aligned(4))) = "CAPTION_DELETE_CHOICE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36C88[];
extern char lbl_1_data_36CA4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36C88[26] __attribute__((aligned(8))) = "CAPTION_DELETE_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36CA4[26] __attribute__((aligned(4))) = "CAPTION_DELETE_CHOICE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36CC0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36CC0[48] __attribute__((aligned(8))) = "\203\237\201c\202\257\202\263\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\264\201c\203X"
    "\203\215\203b\203g\202\360\221I[\202\246\202\347]\202\324";
#pragma explicit_zero_data reset
extern char lbl_1_data_36CF0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36CF0[56] __attribute__((aligned(8))) = "\203\237 \201c Continue without checking\n\203\264 \201c Choose a Slot \000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36D28[];
extern char lbl_1_data_36D44[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36D28[26] __attribute__((aligned(8))) = "CAPTION_DELETE_CHOICE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36D44[26] __attribute__((aligned(4))) = "CAPTION_DELETE_CHOICE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36D60[];
extern char lbl_1_data_36D7C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36D60[26] __attribute__((aligned(8))) = "CAPTION_DELETE_CHOICE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36D7C[26] __attribute__((aligned(4))) = "CAPTION_DELETE_CHOICE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36D98[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36D98[56] __attribute__((aligned(8))) = "\203\237\201c\203`\203F\203b\203N\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203"
    "\264\201c\203X\203\215\203b\203g\202\360\221I[\202\246\202\347]\202\324\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36DD0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36DD0[64] __attribute__((aligned(8))) = "\203\237 \201c Continue without loading\n\203\262 \201c Try again\n\203\264 \201c Format \000"
    "\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36E10[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36E10[30] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY_FORMAT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_36E30[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36E30[30] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY_FORMAT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36E50[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36E50[30] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY_FORMAT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36E70[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36E70[30] __attribute__((aligned(8))) = "CAPTION_LOAD_RETRY_FORMAT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_36E90[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36E90[64] __attribute__((aligned(8))) = "\203\237\201c\203\215\201[\203h\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262"
    "\201c\203\212\203g\203\211\203C \203\264\201c\203t\203H\201[\203}\203b\203g\202\267\202\351\000"
    "\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_36ED0[];
extern char lbl_1_data_36F0C[];
extern char lbl_1_data_36F2C[];
extern char lbl_1_data_36F4C[];
extern char lbl_1_data_36F6C[];
extern char lbl_1_data_36F8C[];
extern char lbl_1_data_36FCC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36ED0[60] __attribute__((aligned(8))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again\n\203\264 \201c Format ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36F0C[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_FORMAT GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36F2C[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_FORMAT FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36F4C[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_FORMAT SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36F6C[30] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY_FORMAT ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36F8C[64] __attribute__((aligned(4))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262"
    "\201c\203\212\203g\203\211\203C \203\264\201c\203t\203H\201[\203}\203b\203g\202\267\202\351\000"
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_36FCC[60] __attribute__((aligned(4))) = "\203\237 \201c Continue without saving\n\203\262 \201c Try again\n\203\264 \201c Format ";
#pragma explicit_zero_data reset
extern char lbl_1_data_37008[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37008[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_FORMAT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37028[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37028[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_FORMAT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37048[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37048[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_FORMAT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37068[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37068[30] __attribute__((aligned(8))) = "CAPTION_LIST_RETRY_FORMAT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37088[];
extern char lbl_1_data_370CC[];
extern char lbl_1_data_3710C[];
extern char lbl_1_data_3712C[];
extern char lbl_1_data_3714C[];
extern char lbl_1_data_3716C[];
extern char lbl_1_data_3718C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37088[68] __attribute__((aligned(8))) = "\203\237\201c\203\212\203X\203g\202\360\202\306\202\347\202\270\202\311\217I[\202\250]\202\355"
    "\202\351\n\203\262\201c\203\212\203g\203\211\203C \203\264\201c\203t\203H\201[\203}\203b\203g"
    "\202\267\202\351\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_370CC[64] __attribute__((aligned(4))) = "\203\237 \201c Continue without erasing\n\203\262 \201c Try again\n\203\264 \201c Format \000"
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3710C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_FORMAT GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3712C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_FORMAT FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3714C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_FORMAT SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3716C[32] __attribute__((aligned(4))) = "CAPTION_DELETE_RETRY_FORMAT ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3718C[60] __attribute__((aligned(4))) = "\203\237\201c\202\257\202\263\202\270\202\311\217I[\202\250]\202\355\202\351\n\203\262\201c\203"
    "\212\203g\203\211\203C \203\264\201c\203t\203H\201[\203}\203b\203g\202\267\202\351\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_371C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_371C8[64] __attribute__((aligned(8))) = "\203\237 \201c Continue without checking\n\203\262 \201c Try again\n\203\264 \201c Format \000"
    "\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_37208[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37208[32] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY_FORMAT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37228[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37228[32] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY_FORMAT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37248[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37248[32] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY_FORMAT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37268[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37268[32] __attribute__((aligned(8))) = "CAPTION_DELETE_RETRY_FORMAT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37288[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37288[64] __attribute__((aligned(8))) = "\203\237\201c\203`\203F\203b\203N\202\271\202\270\202\311\217I[\202\250]\202\355\202\351\n\203"
    "\262\201c\203\212\203g\203\211\203C \203\264\201c\203t\203H\201[\203}\203b\203g\202\267\202\351"
    "\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_372C8[];
extern char lbl_1_data_372F4[];
extern char lbl_1_data_3730C[];
extern char lbl_1_data_37324[];
extern char lbl_1_data_3733C[];
extern char lbl_1_data_37354[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_372C8[44] __attribute__((aligned(8))) = "\203\237 \201c Begin without saveing\n\203\262 \201c Try again";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_372F4[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3730C[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37324[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3733C[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37354[44] __attribute__((aligned(4))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\216n[\202\315\202\266]\202\337\202\351 \203"
    "\262\201c\203\212\203g\203\211\203C\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_37380[];
extern char lbl_1_data_373DC[];
extern char lbl_1_data_373F4[];
extern char lbl_1_data_3740C[];
extern char lbl_1_data_37424[];
extern char lbl_1_data_3743C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37380[92] __attribute__((aligned(8))) = "\203\237 \201c Begin without saving\n\203\262 \201c Try again\n\203\264 \201c Reset and access s"
    "ystem Memory Card screen";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_373DC[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_373F4[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3740C[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37424[23] __attribute__((aligned(4))) = "CAPTION_SAVE_RETRY ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3743C[108] __attribute__((aligned(4))) = "\203\237\201c\203Z\201[\203u\202\271\202\270\202\311\216n[\202\315\202\266]\202\337\202\351 \203"
    "\262\201c\203\212\203g\203\211\203C\n\203\264\201c\203\212\203Z\203b\203g\202\265\202\304\226{["
    "\202\331\202\361]\221\314[\202\275\202\242]\203\201\203\202\203\212\201[\203J\201[\203h\211\346["
    "\202\252]\226\312[\202\337\202\361]\202\326\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_374A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_374A8[48] __attribute__((aligned(8))) = "Choose the Slot with the Memory Card inserted. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_374D8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_374D8[16] __attribute__((aligned(8))) = "CHOICE_SLOT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_374E8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_374E8[16] __attribute__((aligned(8))) = "CHOICE_SLOT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_374F8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_374F8[16] __attribute__((aligned(8))) = "CHOICE_SLOT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37508[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37508[16] __attribute__((aligned(8))) = "CHOICE_SLOT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37518[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37518[56] __attribute__((aligned(8))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\360\202\263\202\265\202\275\203X\203\215\203b"
    "\203g\202\360\n\221I[\202\246\202\347]\202\361\202\305\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_37550[];
extern char lbl_1_data_375A4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37550[84] __attribute__((aligned(8))) = "Use  \203\255 or \203\265to select.\nPress the \203\237 Button to confirm and the \203\240 Butto"
    "n cancel. \000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_375A4[19] __attribute__((aligned(4))) = "CAPTION_CHOICE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_375B8[];
extern char lbl_1_data_375CC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_375B8[19] __attribute__((aligned(8))) = "CAPTION_CHOICE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_375CC[19] __attribute__((aligned(4))) = "CAPTION_CHOICE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_375E0[];
extern char lbl_1_data_375F4[];
extern char lbl_1_data_3763C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_375E0[19] __attribute__((aligned(8))) = "CAPTION_CHOICE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_375F4[72] __attribute__((aligned(4))) = "\203\255\202\251\203\265\202\305\221I[\202\246\202\347]\202\361\202\305\201A\203\237\202\305\214"
    "\210[\202\253]\202\337\202\304\202\255\202\276\202\263\202\242\201B\n\203\240\202\305\203L\203"
    "\203\203\223\203Z\203\213\202\265\202\334\202\267\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3763C[66] __attribute__((aligned(4))) = "The FILE Data save to the Memory Card\nin SLOT has been cancelled.";
#pragma explicit_zero_data reset
extern char lbl_1_data_37680[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37680[16] __attribute__((aligned(8))) = "NOSAVE_EXIT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37690[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37690[16] __attribute__((aligned(8))) = "NOSAVE_EXIT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_376A0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_376A0[16] __attribute__((aligned(8))) = "NOSAVE_EXIT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_376B0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_376B0[16] __attribute__((aligned(8))) = "NOSAVE_EXIT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_376C0[];
extern char lbl_1_data_37704[];
extern char lbl_1_data_3773C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_376C0[68] __attribute__((aligned(8))) = "FILE\203f\201[\203^\202\314\n\203\201\203\202\203\212\201[\203J\201[\203h\202\326\202\314\203Z"
    "\201[\203u\202\360\222\206[\202\277\202\343\202\244]\216~[\202\265]\202\265\202\334\202\265\202"
    "\275\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37704[55] __attribute__((aligned(4))) = "The Memory Card in SLOT\nis damaged and cannot be used.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3773C[17] __attribute__((aligned(4))) = "WRONG_SECTOR GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37750[];
extern char lbl_1_data_37764[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37750[17] __attribute__((aligned(8))) = "WRONG_SECTOR FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37764[17] __attribute__((aligned(4))) = "WRONG_SECTOR SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37778[];
extern char lbl_1_data_3778C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37778[17] __attribute__((aligned(8))) = "WRONG_SECTOR ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3778C[68] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\n\202\261\202\355\202\352\202"
    "\304\202\242\202\351\202\314\202\305\216g[\202\265]\227p[\202\346\202\244]\202\305\202\253\202"
    "\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_377D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_377D0[55] __attribute__((aligned(8))) = "The Memory Card in SLOT\nis damaged and cannot be used.";
#pragma explicit_zero_data reset
extern char lbl_1_data_37808[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37808[15] __attribute__((aligned(8))) = "WRONG_CARD GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37818[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37818[15] __attribute__((aligned(8))) = "WRONG_CARD FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37828[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37828[15] __attribute__((aligned(8))) = "WRONG_CARD SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37838[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37838[15] __attribute__((aligned(8))) = "WRONG_CARD ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37848[];
extern char lbl_1_data_3788C[];
extern char lbl_1_data_378EC[];
extern char lbl_1_data_378FC[];
extern char lbl_1_data_3790C[];
extern char lbl_1_data_3791C[];
extern char lbl_1_data_3792C[];
extern char lbl_1_data_37984[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37848[68] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\n\202\261\202\355\202\352\202"
    "\304\202\242\202\351\202\314\202\305\216g[\202\265]\227p[\202\346\202\244]\202\305\202\253\202"
    "\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3788C[94] __attribute__((aligned(4))) = "The Memory Card in SLOT\nis corrupted and must be formatted.\nOK to format the Memory Card now"
    "\077";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_378EC[13] __attribute__((aligned(4))) = "ENCODING GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_378FC[13] __attribute__((aligned(4))) = "ENCODING FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3790C[13] __attribute__((aligned(4))) = "ENCODING SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3791C[13] __attribute__((aligned(4))) = "ENCODING ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3792C[88] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\216g[\202\302\202\251]\202\246"
    "\202\334\202\271\202\361\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\360\223\374[\202"
    "\242]\202\352\222\274[\202\310\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37984[60] __attribute__((aligned(4))) = "The Memory Card in SLOT\nis corrupted and must be formatted.";
#pragma explicit_zero_data reset
extern char lbl_1_data_379C0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_379C0[13] __attribute__((aligned(8))) = "ENCODING GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_379D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_379D0[13] __attribute__((aligned(8))) = "ENCODING FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_379E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_379E0[13] __attribute__((aligned(8))) = "ENCODING SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_379F0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_379F0[13] __attribute__((aligned(8))) = "ENCODING ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37A00[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37A00[88] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\216g[\202\302\202\251]\202\246"
    "\202\334\202\271\202\361\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\360\223\374[\202"
    "\242]\202\352\222\274[\202\310\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_37A58[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37A58[94] __attribute__((aligned(8))) = "The Memory Card in SLOT\nis corrupted and must be formatted.\nOK to format the Memory Card now"
    "\077";
#pragma explicit_zero_data reset
extern char lbl_1_data_37AB8[];
extern char lbl_1_data_37ACC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37AB8[17] __attribute__((aligned(8))) = "FORMAT_QUERY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37ACC[17] __attribute__((aligned(4))) = "FORMAT_QUERY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37AE0[];
extern char lbl_1_data_37AF4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37AE0[17] __attribute__((aligned(8))) = "FORMAT_QUERY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37AF4[17] __attribute__((aligned(4))) = "FORMAT_QUERY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37B08[];
extern char lbl_1_data_37B74[];
extern char lbl_1_data_37B9C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37B08[108] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\203f\201[\203^\202\252\n\202"
    "\261\202\355\202\352\202\304\202\242\202\351\202\314\202\305\203t\203H\201[\203}\203b\203g\202"
    "\252\225K\227v\202\305\202\267\201B\n\203t\203H\201[\203}\203b\203g\202\265\202\304\202\340\202"
    "\346\202\353\202\265\202\242\202\305\202\267\202\251\201H\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37B74[38] __attribute__((aligned(4))) = "OK to format the\nMemory Card in SLOT\077";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37B9C[18] __attribute__((aligned(4))) = "FORMAT_QUERY2 GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37BB0[];
extern char lbl_1_data_37BC4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37BB0[18] __attribute__((aligned(8))) = "FORMAT_QUERY2 FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37BC4[18] __attribute__((aligned(4))) = "FORMAT_QUERY2 SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37BD8[];
extern char lbl_1_data_37BEC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37BD8[18] __attribute__((aligned(8))) = "FORMAT_QUERY2 ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37BEC[60] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\360\n\203t\203H\201[\203}\203b\203g"
    "\202\265\202\304\202\340\202\346\202\353\202\265\202\242\202\305\202\267\202\251\201H\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C28[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C28[7] __attribute__((aligned(8))) = "Slot A";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C30[];
extern char lbl_1_data_37C3C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C30[11] __attribute__((aligned(8))) = "SLOT_A GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C3C[11] __attribute__((aligned(4))) = "SLOT_A FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C48[];
extern char lbl_1_data_37C54[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C48[11] __attribute__((aligned(8))) = "SLOT_A SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C54[11] __attribute__((aligned(4))) = "SLOT_A ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C60[];
extern char lbl_1_data_37C6C[];
extern char lbl_1_data_37C74[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C60[12] __attribute__((aligned(8))) = "\203X\203\215\203b\203g\202`\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C6C[7] __attribute__((aligned(4))) = "Slot B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C74[11] __attribute__((aligned(4))) = "SLOT_B GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C80[];
extern char lbl_1_data_37C8C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C80[11] __attribute__((aligned(8))) = "SLOT_B FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C8C[11] __attribute__((aligned(4))) = "SLOT_B SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37C98[];
extern char lbl_1_data_37CA4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37C98[11] __attribute__((aligned(8))) = "SLOT_B ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CA4[12] __attribute__((aligned(4))) = "\203X\203\215\203b\203g\202a\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_37CB0[];
extern char lbl_1_data_37CB4[];
extern char lbl_1_data_37CBC[];
extern char lbl_1_data_37CC4[];
extern char lbl_1_data_37CCC[];
extern char lbl_1_data_37CD4[];
extern char lbl_1_data_37CDC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CB0[4] __attribute__((aligned(8))) = "YES";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CB4[8] __attribute__((aligned(4))) = "HAI GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CBC[8] __attribute__((aligned(4))) = "HAI FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CC4[8] __attribute__((aligned(4))) = "HAI SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CCC[8] __attribute__((aligned(4))) = "HAI ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CD4[8] __attribute__((aligned(4))) = "\202\315\202\242\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CDC[3] __attribute__((aligned(4))) = "NO";
#pragma explicit_zero_data reset
extern char lbl_1_data_37CE0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CE0[8] __attribute__((aligned(8))) = "IIE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37CE8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CE8[8] __attribute__((aligned(8))) = "IIE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37CF0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CF0[8] __attribute__((aligned(8))) = "IIE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37CF8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37CF8[8] __attribute__((aligned(8))) = "IIE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37D00[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D00[8] __attribute__((aligned(8))) = "\202\242\202\242\202\246\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_37D08[];
extern char lbl_1_data_37D44[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D08[58] __attribute__((aligned(8))) = "Formatting of the Memory Card in SLOT\nhas been cancelled.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D44[18] __attribute__((aligned(4))) = "FORMAT_CANCEL GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37D58[];
extern char lbl_1_data_37D6C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D58[18] __attribute__((aligned(8))) = "FORMAT_CANCEL FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D6C[18] __attribute__((aligned(4))) = "FORMAT_CANCEL SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37D80[];
extern char lbl_1_data_37D94[];
extern char lbl_1_data_37DD4[];
extern char lbl_1_data_37F64[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D80[18] __attribute__((aligned(8))) = "FORMAT_CANCEL ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37D94[64] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\314\n\203t\203H\201[\203}\203b\203g"
    "\202\360\222\206[\202\277\202\343]\216~[\202\244\202\265]\202\265\202\334\202\265\202\275\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37DD4[400] __attribute__((aligned(4))) = "The Memory Card in SLOT does not have\nenough free space. F-ZERO GX requires the\nfollowing to s"
    "ave its different types of data:\n(To manage files on the Memory Card,\nplease go to the Nintend"
    "o GameCube\nMemory Card management screen.)\nGame Data: 1 File and 4 Blocks\nGarage Data: 1 File"
    " and 18 Blocks\nGhost Data: 1 File and 3 Blocks\nEmblem Data: 1 File and 3 Blocks\nReplay Data: "
    "1 File and 3\201`13 Blocks\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37F64[10] __attribute__((aligned(4))) = "NOENT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_37F70[];
extern char lbl_1_data_37F7C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37F70[10] __attribute__((aligned(8))) = "NOENT FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37F7C[10] __attribute__((aligned(4))) = "NOENT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_37F88[];
extern char lbl_1_data_37F94[];
extern char lbl_1_data_381E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37F88[10] __attribute__((aligned(8))) = "NOENT ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_37F94[592] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\213\363[\202\240]\202\253\227e["
    "\202\346\202\244 ]\227\312[\202\350\202\345\202\244]\202\252\202\310\202\242\202\251\201A\n\203t"
    "\203@\203C\203\213\220\224[\202\267\202\244]\202\314\220\247[\202\271\202\242]\214\300[\202\260"
    "\202\361]\202\360\211z[\202\261]\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\nF"
    "-ZERO GX\202\314\212e[\202\251\202\255]\203t\203@\203C\203\213\202\360\203Z\201[\203u\202\267"
    "\202\351\202\311\202\315\n\217\255[\202\267\202\255]\202\310\202\255\202\306\202\340\210\310["
    "\202\242]\211\272[\202\251]\202\314\213\363[\202\240]\202\253\227e[\202\346\202\244 ]\227\312["
    "\202\350\202\345\202\244]\202\252\225K[\202\320\202\302]\227v[\202\346\202\244]\202\305\202\267"
    "\201B\n(\203\201\203\202\203\212\201[\203J\201[\203h\202\314\223\340[\202\310\202\242]\227e[\202"
    "\346\202\244]\202\360\220\256[\202\271\202\242]\227\235[\202\350]\202\267\202\351\202\311\202"
    "\315\201A\n\226{[\202\331\202\361]\221\314[\202\275\202\242]\202\314\203\201\203\202\203\212\201"
    "[\203J\201[\203h\211\346[\202\252]\226\312[\202\337\202\361]\202\305\215s[\202\250\202\261]\202"
    "\310\202\301\202\304\202\255\202\276\202\263\202\242)\n  \203Q\201[\203\200\203f\201[\203^:\203t"
    "\203@\203C\203\213\202P\202\302\202\306\202S\203u\203\215\203b\203N\n \203K\203\214\201[\203W"
    "\203f\201[\203^:\203t\203@\203C\203\213\202P\202\302\202\306\202P\202W\203u\203\215\203b\203N\n "
    "\203S\201[\203X\203g\203f\201[\203^:\203t\203@\203C\203\213\202P\202\302\202\306\202R\203u\203"
    "\215\203b\203N\n\203G\203\223\203u\203\214\203\200\203f\201[\203^:\203t\203@\203C\203\213\202P"
    "\202\302\202\306\202R\203u\203\215\203b\203N\n  \203\212\203v\203\214\203C\203f\201[\203^:\203t"
    "\203@\203C\203\213\202P\202\302\202\306\202R\201`\202P\202R\203u\203\215\203b\203N\n";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_381E4[228] __attribute__((aligned(4))) = "There is not enough free space on the\nMemory Card in SLOT. To save FILE Data,\nyou need at leas"
    "t 1 file and REQUIRED blocks.\n(To manage files on the Memory Card,\nplease go to the Nintendo G"
    "ameCube\nMemory Card management screen.)";
#pragma explicit_zero_data reset
extern char lbl_1_data_382C8[];
extern char lbl_1_data_382D4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_382C8[10] __attribute__((aligned(8))) = "NOENT GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_382D4[10] __attribute__((aligned(4))) = "NOENT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_382E0[];
extern char lbl_1_data_382EC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_382E0[10] __attribute__((aligned(8))) = "NOENT SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_382EC[10] __attribute__((aligned(4))) = "NOENT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_382F8[];
extern char lbl_1_data_38454[];
extern char lbl_1_data_385E4[];
extern char lbl_1_data_385F4[];
extern char lbl_1_data_38604[];
extern char lbl_1_data_38614[];
extern char lbl_1_data_38624[];
extern char lbl_1_data_38874[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_382F8[348] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\213\363[\202\240]\202\253\227e["
    "\202\346\202\244 ]\227\312[\202\350\202\345\202\244]\202\252\202\310\202\242\202\251\201A\n\203t"
    "\203@\203C\203\213\220\224[\202\267\202\244]\202\314\220\247[\202\271\202\242]\214\300[\202\260"
    "\202\361]\202\360\211z[\202\261]\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\nF"
    "ILE\203f\201[\203^\202\360\203Z\201[\203u\202\267\202\351\202\311\202\315\n\217\255[\202\267\202"
    "\255]\202\310\202\255\202\306\202\340\203t\203@\203C\203\2131\202\302\202\306REQUIRED\203u\203"
    "\215\203b\203N\225K[\202\320\202\302]\227v[\202\346\202\244]\202\305\202\267\201B\n(\203\201\203"
    "\202\203\212\201[\203J\201[\203h\202\314\223\340[\202\310\202\242]\227e[\202\346\202\244]\202"
    "\360\220\256[\202\271\202\242]\227\235[\202\350]\202\267\202\351\202\311\202\315\201A\n\226{["
    "\202\331\202\361]\221\314[\202\275\202\242]\202\314\203\201\203\202\203\212\201[\203J\201[\203h"
    "\211\346[\202\252]\226\312[\202\337\202\361]\202\305\215s[\202\250\202\261]\202\310\202\301\202"
    "\304\202\255\202\276\202\263\202\242)\n\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38454[400] __attribute__((aligned(4))) = "The Memory Card in SLOT does not have\nenough free space. F-ZERO GX requires the\nfollowing to s"
    "ave its different types of data:\n(To manage files on the Memory Card,\nplease go to the Nintend"
    "o GameCube\nMemory Card management screen.)\nGame Data: 1 File and 4 Blocks\nGarage Data: 1 File"
    " and 18 Blocks\nGhost Data: 1 File and 3 Blocks\nEmblem Data: 1 File and 3 Blocks\nReplay Data: "
    "1 File and 3\201`13 Blocks\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_385E4[13] __attribute__((aligned(4))) = "INSSPACE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_385F4[13] __attribute__((aligned(4))) = "INSSPACE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38604[13] __attribute__((aligned(4))) = "INSSPACE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38614[13] __attribute__((aligned(4))) = "INSSPACE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38624[592] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\213\363[\202\240]\202\253\227e["
    "\202\346\202\244 ]\227\312[\202\350\202\345\202\244]\202\252\202\310\202\242\202\251\201A\n\203t"
    "\203@\203C\203\213\220\224[\202\267\202\244]\202\314\220\247[\202\271\202\242]\214\300[\202\260"
    "\202\361]\202\360\211z[\202\261]\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\nF"
    "-ZERO GX\202\314\212e[\202\251\202\255]\203t\203@\203C\203\213\202\360\203Z\201[\203u\202\267"
    "\202\351\202\311\202\315\n\217\255[\202\267\202\255]\202\310\202\255\202\306\202\340\210\310["
    "\202\242]\211\272[\202\251]\202\314\213\363[\202\240]\202\253\227e[\202\346\202\244 ]\227\312["
    "\202\350\202\345\202\244]\202\252\225K[\202\320\202\302]\227v[\202\346\202\244]\202\305\202\267"
    "\201B\n(\203\201\203\202\203\212\201[\203J\201[\203h\202\314\223\340[\202\310\202\242]\227e[\202"
    "\346\202\244]\202\360\220\256[\202\271\202\242]\227\235[\202\350]\202\267\202\351\202\311\202"
    "\315\201A\n\226{[\202\331\202\361]\221\314[\202\275\202\242]\202\314\203\201\203\202\203\212\201"
    "[\203J\201[\203h\211\346[\202\252]\226\312[\202\337\202\361]\202\305\215s[\202\250\202\261]\202"
    "\310\202\301\202\304\202\255\202\276\202\263\202\242)\n  \203Q\201[\203\200\203f\201[\203^:\203t"
    "\203@\203C\203\213\202P\202\302\202\306\202S\203u\203\215\203b\203N\n \203K\203\214\201[\203W"
    "\203f\201[\203^:\203t\203@\203C\203\213\202P\202\302\202\306\202P\202W\203u\203\215\203b\203N\n "
    "\203S\201[\203X\203g\203f\201[\203^:\203t\203@\203C\203\213\202P\202\302\202\306\202R\203u\203"
    "\215\203b\203N\n\203G\203\223\203u\203\214\203\200\203f\201[\203^:\203t\203@\203C\203\213\202P"
    "\202\302\202\306\202R\203u\203\215\203b\203N\n  \203\212\203v\203\214\203C\203f\201[\203^:\203t"
    "\203@\203C\203\213\202P\202\302\202\306\202R\201`\202P\202R\203u\203\215\203b\203N\n";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38874[227] __attribute__((aligned(4))) = "The Memory Card in SLOT does not\nhave enough free space. At least 1 file\nand REQUIRED blocks a"
    "re needed to save\nFILE Data. (To manage files on the Memory\nCard, please go to the Nintendo Ga"
    "meCube\nMemory Card management screen.)";
#pragma explicit_zero_data reset
extern char lbl_1_data_38958[];
extern char lbl_1_data_3896C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38958[20] __attribute__((aligned(8))) = "INSSPACE_REPLAY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3896C[20] __attribute__((aligned(4))) = "INSSPACE_REPLAY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38980[];
extern char lbl_1_data_38994[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38980[20] __attribute__((aligned(8))) = "INSSPACE_REPLAY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38994[20] __attribute__((aligned(4))) = "INSSPACE_REPLAY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_389A8[];
extern char lbl_1_data_38B04[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_389A8[348] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\213\363[\202\240]\202\253\227e["
    "\202\346\202\244 ]\227\312[\202\350\202\345\202\244]\202\252\202\310\202\242\202\251\201A\n\203t"
    "\203@\203C\203\213\220\224[\202\267\202\244]\202\314\220\247[\202\271\202\242]\214\300[\202\260"
    "\202\361]\202\360\211z[\202\261]\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\nF"
    "ILE\203f\201[\203^\202\360\203Z\201[\203u\202\267\202\351\202\311\202\315\n\217\255[\202\267\202"
    "\255]\202\310\202\255\202\306\202\340\203t\203@\203C\203\2131\202\302\202\306REQUIRED\203u\203"
    "\215\203b\203N\225K[\202\320\202\302]\227v[\202\346\202\244]\202\305\202\267\201B\n(\203\201\203"
    "\202\203\212\201[\203J\201[\203h\202\314\223\340[\202\310\202\242]\227e[\202\346\202\244]\202"
    "\360\220\256[\202\271\202\242]\227\235[\202\350]\202\267\202\351\202\311\202\315\201A\n\226{["
    "\202\331\202\361]\221\314[\202\275\202\242]\202\314\203\201\203\202\203\212\201[\203J\201[\203h"
    "\211\346[\202\252]\226\312[\202\337\202\361]\202\305\215s[\202\250\202\261]\202\310\202\301\202"
    "\304\202\255\202\276\202\263\202\242)\n\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38B04[82] __attribute__((aligned(4))) = "There is already FILE Data\non the Memory Card in SLOT.\nOK to save over this data\077";
#pragma explicit_zero_data reset
extern char lbl_1_data_38B58[];
extern char lbl_1_data_38B6C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38B58[20] __attribute__((aligned(8))) = "OVERWRITE_QUERY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38B6C[20] __attribute__((aligned(4))) = "OVERWRITE_QUERY FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38B80[];
extern char lbl_1_data_38B94[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38B80[20] __attribute__((aligned(8))) = "OVERWRITE_QUERY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38B94[20] __attribute__((aligned(4))) = "OVERWRITE_QUERY ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38BA8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38BA8[96] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\n\202\267\202\305\202"
    "\311FILE\203f\201[\203^\202\252\202\240\202\350\202\334\202\267\201B\n\217\343[\202\244\202\355]"
    "\217\221[\202\252]\202\253\202\265\202\304\202\340\202\346\202\353\202\265\202\242\202\305\202"
    "\267\202\251\201H\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C08[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C08[38] __attribute__((aligned(8))) = "The FILE Data overwrite\nwas canceled.";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C30[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C30[21] __attribute__((aligned(8))) = "OVERWRITE_CANCEL GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C48[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C48[21] __attribute__((aligned(8))) = "OVERWRITE_CANCEL FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C60[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C60[21] __attribute__((aligned(8))) = "OVERWRITE_CANCEL SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C78[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C78[21] __attribute__((aligned(8))) = "OVERWRITE_CANCEL ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38C90[];
extern char lbl_1_data_38CCC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38C90[60] __attribute__((aligned(8))) = "FILE\203f\201[\203^\202\314\n\217\343[\202\244\202\355]\217\221[\202\252]\202\253\202\360\222"
    "\206[\202\277\202\343]\216~[\202\244\202\265]\202\265\202\334\202\265\202\275\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38CCC[49] __attribute__((aligned(4))) = "FILE Data was saved to\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D00[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D00[13] __attribute__((aligned(8))) = "SAVE_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D10[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D10[13] __attribute__((aligned(8))) = "SAVE_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D20[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D20[13] __attribute__((aligned(8))) = "SAVE_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D30[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D30[13] __attribute__((aligned(8))) = "SAVE_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D40[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D40[64] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\326\nFILE\203f\201[\203^\202\314"
    "\203Z\201[\203u\202\252\217I[\202\250]\202\355\202\350\202\334\202\265\202\275\201B\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D80[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D80[21] __attribute__((aligned(8))) = "Free blocks in SLOT:";
#pragma explicit_zero_data reset
extern char lbl_1_data_38D98[];
extern char lbl_1_data_38DAC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38D98[18] __attribute__((aligned(8))) = "REMAIN_BLOCKS GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38DAC[18] __attribute__((aligned(4))) = "REMAIN_BLOCKS FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38DC0[];
extern char lbl_1_data_38DD4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38DC0[18] __attribute__((aligned(8))) = "REMAIN_BLOCKS SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38DD4[18] __attribute__((aligned(4))) = "REMAIN_BLOCKS ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38DE8[];
extern char lbl_1_data_38E04[];
extern char lbl_1_data_38E0C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38DE8[28] __attribute__((aligned(8))) = "SLOT\202\314\213\363[\202\240]\202\253\203u\203\215\203b\203N\201F\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E04[8] __attribute__((aligned(4))) = "Blocks:";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E0C[11] __attribute__((aligned(4))) = "BLOCKS GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38E18[];
extern char lbl_1_data_38E24[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E18[11] __attribute__((aligned(8))) = "BLOCKS FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E24[11] __attribute__((aligned(4))) = "BLOCKS SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38E30[];
extern char lbl_1_data_38E3C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E30[11] __attribute__((aligned(8))) = "BLOCKS ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E3C[12] __attribute__((aligned(4))) = "\203u\203\215\203b\203N\201F\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_38E48[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E48[55] __attribute__((aligned(8))) = "Loading FILE Data from\nthe Memory Card was cancelled. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_38E80[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E80[16] __attribute__((aligned(8))) = "NOLOAD_EXIT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38E90[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38E90[16] __attribute__((aligned(8))) = "NOLOAD_EXIT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38EA0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38EA0[16] __attribute__((aligned(8))) = "NOLOAD_EXIT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38EB0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38EB0[16] __attribute__((aligned(8))) = "NOLOAD_EXIT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38EC0[];
extern char lbl_1_data_38F04[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38EC0[68] __attribute__((aligned(8))) = "FILE\203f\201[\203^\202\314\n\203\201\203\202\203\212\201[\203J\201[\203h\202\251\202\347\202"
    "\314\203\215\201[\203h\202\360\222\206[\202\277\202\343\202\244]\216~[\202\265]\202\265\202\334"
    "\202\265\202\275\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F04[44] __attribute__((aligned(4))) = "The Memory Card in SLOT has been formatted.";
#pragma explicit_zero_data reset
extern char lbl_1_data_38F30[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F30[15] __attribute__((aligned(8))) = "FORMAT_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38F40[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F40[15] __attribute__((aligned(8))) = "FORMAT_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38F50[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F50[15] __attribute__((aligned(8))) = "FORMAT_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38F60[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F60[15] __attribute__((aligned(8))) = "FORMAT_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_38F70[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38F70[56] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\314\n\203t\203H\201[\203}\203b\203g"
    "\202\252\217I[\202\250]\202\355\202\350\202\334\202\265\202\275\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_38FA8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38FA8[61] __attribute__((aligned(8))) = "The FILE Data has been loaded\nfrom the Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_38FE8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38FE8[13] __attribute__((aligned(8))) = "LOAD_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_38FF8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_38FF8[13] __attribute__((aligned(8))) = "LOAD_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39008[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39008[13] __attribute__((aligned(8))) = "LOAD_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39018[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39018[13] __attribute__((aligned(8))) = "LOAD_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39028[];
extern char lbl_1_data_3906C[];
extern char lbl_1_data_390C4[];
extern char lbl_1_data_390D4[];
extern char lbl_1_data_390E4[];
extern char lbl_1_data_390F4[];
extern char lbl_1_data_39104[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39028[68] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\251\202\347\202\314\nFILE\203f\201["
    "\203^\202\314\203\215\201[\203h\202\252\217I[\202\250]\202\355\202\350\202\334\202\265\202\275"
    "\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3906C[85] __attribute__((aligned(4))) = "The F-ZERO GX FILE Data on\nthe Memory Card in SLOT\nis corrupted and must be deleted.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_390C4[16] __attribute__((aligned(4))) = "DATA_BROKEN GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_390D4[16] __attribute__((aligned(4))) = "DATA_BROKEN FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_390E4[16] __attribute__((aligned(4))) = "DATA_BROKEN SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_390F4[16] __attribute__((aligned(4))) = "DATA_BROKEN ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39104[68] __attribute__((aligned(4))) = "FILE\203f\201[\203^\202\252\202\261\202\355\202\352\202\304\202\242\202\334\202\267\201B\n\203t"
    "\203@\203C\203\213\202\360\217\301[\202\265\202\345\202\244]\213\216[ \202\253\202\345]\202\265"
    "\202\334\202\267\201B\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39148[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39148[70] __attribute__((aligned(8))) = "The Memory Card in SLOT was removed.\nMemory Card access was stopped. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_39190[];
extern char lbl_1_data_3919C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39190[11] __attribute__((aligned(8))) = "DETACH GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3919C[11] __attribute__((aligned(4))) = "DETACH FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_391A8[];
extern char lbl_1_data_391B4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_391A8[11] __attribute__((aligned(8))) = "DETACH SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_391B4[11] __attribute__((aligned(4))) = "DETACH ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_391C0[];
extern char lbl_1_data_39214[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_391C0[84] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\252\224\262[\202\312]\202\251\202"
    "\352\202\334\202\265\202\275\201B\n\215\354[\202\263\202\254]\213\306[\202\345\202\244]\202\360"
    "\222\206[\202\277\202\343]\216~[\202\244\202\265]\202\265\202\334\202\267\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39214[51] __attribute__((aligned(4))) = "There is no FILE Data on\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_39248[];
extern char lbl_1_data_39254[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39248[11] __attribute__((aligned(8))) = "NOFILE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39254[11] __attribute__((aligned(4))) = "NOFILE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39260[];
extern char lbl_1_data_3926C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39260[11] __attribute__((aligned(8))) = "NOFILE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3926C[11] __attribute__((aligned(4))) = "NOFILE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39278[];
extern char lbl_1_data_392AC[];
extern char lbl_1_data_392E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39278[52] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\nFILE\203f\201[\203^"
    "\202\252\202\240\202\350\202\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_392AC[53] __attribute__((aligned(4))) = "There is no Replay Data on\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_392E4[11] __attribute__((aligned(4))) = "NOFILE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_392F0[];
extern char lbl_1_data_392FC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_392F0[11] __attribute__((aligned(8))) = "NOFILE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_392FC[11] __attribute__((aligned(4))) = "NOFILE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39308[];
extern char lbl_1_data_39314[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39308[11] __attribute__((aligned(8))) = "NOFILE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39314[52] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\nFILE\203f\201[\203^"
    "\202\252\202\240\202\350\202\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39348[];
extern char lbl_1_data_3937C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39348[52] __attribute__((aligned(8))) = "There is no Ghost Data on\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3937C[11] __attribute__((aligned(4))) = "NOFILE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39388[];
extern char lbl_1_data_39394[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39388[11] __attribute__((aligned(8))) = "NOFILE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39394[11] __attribute__((aligned(4))) = "NOFILE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_393A0[];
extern char lbl_1_data_393AC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_393A0[11] __attribute__((aligned(8))) = "NOFILE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_393AC[52] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\nFILE\203f\201[\203^"
    "\202\252\202\240\202\350\202\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_393E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_393E0[53] __attribute__((aligned(8))) = "There is no Emblem Data on\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_39418[];
extern char lbl_1_data_39424[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39418[11] __attribute__((aligned(8))) = "NOFILE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39424[11] __attribute__((aligned(4))) = "NOFILE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39430[];
extern char lbl_1_data_3943C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39430[11] __attribute__((aligned(8))) = "NOFILE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3943C[11] __attribute__((aligned(4))) = "NOFILE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39448[];
extern char lbl_1_data_3947C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39448[52] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\nFILE\203f\201[\203^"
    "\202\252\202\240\202\350\202\334\202\271\202\361\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3947C[57] __attribute__((aligned(4))) = "Unable to get the data list\non the Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_394B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_394B8[16] __attribute__((aligned(8))) = "NOLIST_EXIT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_394C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_394C8[16] __attribute__((aligned(8))) = "NOLIST_EXIT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_394D8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_394D8[16] __attribute__((aligned(8))) = "NOLIST_EXIT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_394E8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_394E8[16] __attribute__((aligned(8))) = "NOLIST_EXIT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_394F8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_394F8[40] __attribute__((aligned(8))) = "SLOT\202\314\203f\201[\203^\203\212\203X\203g\202\252\n\202\306\202\352\202\334\202\271\202\361"
    "\202\305\202\265\202\275\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_39520[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39520[46] __attribute__((aligned(8))) = "There is no data on\nthe Memory Card in SLOT. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_39550[];
extern char lbl_1_data_39564[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39550[18] __attribute__((aligned(8))) = "LIST_NO_EXIST GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39564[18] __attribute__((aligned(4))) = "LIST_NO_EXIST FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39578[];
extern char lbl_1_data_3958C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39578[18] __attribute__((aligned(8))) = "LIST_NO_EXIST SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3958C[18] __attribute__((aligned(4))) = "LIST_NO_EXIST ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_395A0[];
extern char lbl_1_data_395DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_395A0[60] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\n\203f\201[\203^\202"
    "\2521\202\302\202\340\202\240\202\350\202\334\202\271\202\361\202\305\202\265\202\275\201B\000"
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_395DC[58] __attribute__((aligned(4))) = "The data list on the Memory Card\nin SLOT has been loaded.";
#pragma explicit_zero_data reset
extern char lbl_1_data_39618[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39618[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39628[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39628[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39638[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39638[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39648[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39648[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39658[];
extern char lbl_1_data_39694[];
extern char lbl_1_data_396BC[];
extern char lbl_1_data_396CC[];
extern char lbl_1_data_396DC[];
extern char lbl_1_data_396EC[];
extern char lbl_1_data_396FC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39658[60] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\314\n\203f\201[\203^\203\212\203X"
    "\203g\202\360\223\307[\202\346]\202\335\202\261\202\335\202\334\202\265\202\275\201B\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39694[39] __attribute__((aligned(4))) = "Done checking the Memory Card in SLOT.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_396BC[14] __attribute__((aligned(4))) = "CHECK_END GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_396CC[14] __attribute__((aligned(4))) = "CHECK_END FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_396DC[14] __attribute__((aligned(4))) = "CHECK_END SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_396EC[14] __attribute__((aligned(4))) = "CHECK_END ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_396FC[68] __attribute__((aligned(4))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\314\n\203`\203F\203b\203N\202\252["
    "\202\265]\217I[\202\343\202\244]\227\271[\202\350\202\345]\202\265[\202\244]\202\334\202\265\202"
    "\275\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_39740[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39740[61] __attribute__((aligned(8))) = "FILE Data deletion on the Memory Card\nin SLOT was cancelled.";
#pragma explicit_zero_data reset
extern char lbl_1_data_39780[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39780[15] __attribute__((aligned(8))) = "NODEL_EXIT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39790[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39790[15] __attribute__((aligned(8))) = "NODEL_EXIT FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_397A0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_397A0[15] __attribute__((aligned(8))) = "NODEL_EXIT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_397B0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_397B0[15] __attribute__((aligned(8))) = "NODEL_EXIT ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_397C0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_397C0[64] __attribute__((aligned(8))) = "SLOT\202\314FILE\203f\201[\203^\202\314\215\355[\202\263\202\255]\217\234[\202\266\202\345]\202"
    "\360\222\206[\202\277\202\343\202\244]\216~[\202\265]\202\265\202\334\202\265\202\275\201B\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39800[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39800[53] __attribute__((aligned(8))) = "1 FILE Data was erased from the Memory Card in SLOT.";
#pragma explicit_zero_data reset
extern char lbl_1_data_39838[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39838[15] __attribute__((aligned(8))) = "DELETE_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39848[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39848[15] __attribute__((aligned(8))) = "DELETE_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39858[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39858[15] __attribute__((aligned(8))) = "DELETE_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39868[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39868[15] __attribute__((aligned(8))) = "DELETE_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39878[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39878[40] __attribute__((aligned(8))) = "SLOT\202\314FILE\203f\201[\203^\202\360\202P\202\302\217\301[\202\257]\202\265\202\334\202\265"
    "\202\275\201B\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_398A0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398A0[15] __attribute__((aligned(8))) = "NOW FORMATTING";
#pragma explicit_zero_data reset
extern char lbl_1_data_398B0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398B0[15] __attribute__((aligned(8))) = "FORMAT_NOW GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_398C0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398C0[15] __attribute__((aligned(8))) = "FORMAT_NOW FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_398D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398D0[15] __attribute__((aligned(8))) = "FORMAT_NOW SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_398E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398E0[15] __attribute__((aligned(8))) = "FORMAT_NOW ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_398F0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_398F0[15] __attribute__((aligned(8))) = "NOW FORMATTING";
#pragma explicit_zero_data reset
extern char lbl_1_data_39900[];
extern char lbl_1_data_3990C[];
extern char lbl_1_data_3991C[];
extern char lbl_1_data_3992C[];
extern char lbl_1_data_3993C[];
extern char lbl_1_data_3994C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39900[11] __attribute__((aligned(8))) = "NOW SAVING";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3990C[13] __attribute__((aligned(4))) = "SAVE_NOW GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3991C[13] __attribute__((aligned(4))) = "SAVE_NOW FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3992C[13] __attribute__((aligned(4))) = "SAVE_NOW SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3993C[13] __attribute__((aligned(4))) = "SAVE_NOW ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3994C[11] __attribute__((aligned(4))) = "NOW SAVING";
#pragma explicit_zero_data reset
extern char lbl_1_data_39958[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39958[16] __attribute__((aligned(8))) = "NOW MAKING LIST";
#pragma explicit_zero_data reset
extern char lbl_1_data_39968[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39968[13] __attribute__((aligned(8))) = "LIST_NOW GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39978[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39978[13] __attribute__((aligned(8))) = "LIST_NOW FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39988[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39988[13] __attribute__((aligned(8))) = "LIST_NOW SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39998[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39998[13] __attribute__((aligned(8))) = "LIST_NOW ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_399A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399A8[16] __attribute__((aligned(8))) = "NOW MAKING LIST";
#pragma explicit_zero_data reset
extern char lbl_1_data_399B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399B8[13] __attribute__((aligned(8))) = "NOW CHECKING";
#pragma explicit_zero_data reset
extern char lbl_1_data_399C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399C8[13] __attribute__((aligned(8))) = "LIST_NOW GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_399D8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399D8[13] __attribute__((aligned(8))) = "LIST_NOW FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_399E8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399E8[13] __attribute__((aligned(8))) = "LIST_NOW SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_399F8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_399F8[13] __attribute__((aligned(8))) = "LIST_NOW ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39A08[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A08[13] __attribute__((aligned(8))) = "NOW CHECKING";
#pragma explicit_zero_data reset
extern char lbl_1_data_39A18[];
extern char lbl_1_data_39A6C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A18[81] __attribute__((aligned(8))) = "Accessing the Memory Card in SLOT.\nDo not touch the Memory Card or POWER Button.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A6C[11] __attribute__((aligned(4))) = "ACCESS GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39A78[];
extern char lbl_1_data_39A84[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A78[11] __attribute__((aligned(8))) = "ACCESS FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A84[11] __attribute__((aligned(4))) = "ACCESS SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39A90[];
extern char lbl_1_data_39A9C[];
extern char lbl_1_data_39B04[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A90[11] __attribute__((aligned(8))) = "ACCESS ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39A9C[104] __attribute__((aligned(4))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\311\203A\203N\203Z\203X\222\206[\202\277\202"
    "\343\202\244]\202\305\202\267\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\342\223d["
    "\202\305\202\361]\214\271[\202\260\202\361]\202\311\220G[\202\263\202\355]\202\347\202\310\202"
    "\242\202\305\202\255\202\276\202\263\202\242\201B\n\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B04[81] __attribute__((aligned(4))) = "Accessing the Memory Card in SLOT.\nDo not touch the Memory Card or POWER Button.";
#pragma explicit_zero_data reset
extern char lbl_1_data_39B58[];
extern char lbl_1_data_39B64[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B58[11] __attribute__((aligned(8))) = "ACCESS GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B64[11] __attribute__((aligned(4))) = "ACCESS FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39B70[];
extern char lbl_1_data_39B7C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B70[11] __attribute__((aligned(8))) = "ACCESS SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B7C[11] __attribute__((aligned(4))) = "ACCESS ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39B88[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39B88[104] __attribute__((aligned(8))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\311\203A\203N\203Z\203X\222\206[\202\277\202"
    "\343\202\244]\202\305\202\267\201B\n\203\201\203\202\203\212\201[\203J\201[\203h\202\342\223d["
    "\202\305\202\361]\214\271[\202\260\202\361]\202\311\220G[\202\263\202\355]\202\347\202\310\202"
    "\242\202\305\202\255\202\276\202\263\202\242\201B\n\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39BF0[];
extern char lbl_1_data_39C1C[];
extern char lbl_1_data_39C2C[];
extern char lbl_1_data_39C3C[];
extern char lbl_1_data_39C4C[];
extern char lbl_1_data_39C5C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39BF0[44] __attribute__((aligned(8))) = "OK to save FILE to the Memory Card in SLOT\077";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C1C[15] __attribute__((aligned(4))) = "SAVE_QUERY GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C2C[15] __attribute__((aligned(4))) = "SAVE_QUERY FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C3C[15] __attribute__((aligned(4))) = "SAVE_QUERY SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C4C[15] __attribute__((aligned(4))) = "SAVE_QUERY ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C5C[44] __attribute__((aligned(4))) = "SLOT\202\311FILE\202\360\203Z\201[\203u\202\265\202\304\202\340\n\202\346\202\353\202\265\202"
    "\242\202\305\202\267\202\251\201H\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39C88[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39C88[48] __attribute__((aligned(8))) = "If you start now,\nyou will not be able to save.";
#pragma explicit_zero_data reset
extern char lbl_1_data_39CB8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39CB8[16] __attribute__((aligned(8))) = "CANNOT_SAVE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_39CC8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39CC8[16] __attribute__((aligned(8))) = "CANNOT_SAVE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39CD8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39CD8[16] __attribute__((aligned(8))) = "CANNOT_SAVE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39CE8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39CE8[16] __attribute__((aligned(8))) = "CANNOT_SAVE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_39CF8[];
extern char lbl_1_data_39D2C[];
extern char lbl_1_data_39DC4[];
extern char lbl_1_data_39DDC[];
extern char lbl_1_data_39DF4[];
extern char lbl_1_data_39E0C[];
extern char lbl_1_data_39E24[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39CF8[52] __attribute__((aligned(8))) = "\202\261\202\314\202\334\202\334\216n[\202\315\202\266]\202\337\202\275\217\352[\202\316]\215"
    "\207[\202\240\202\242]\n\203Z\201[\203u\202\305\202\253\202\334\202\271\202\361";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39D2C[152] __attribute__((aligned(4))) = "There are no Memory Cards inserted properly.\nPlease check connections or insert a Memory Card."
    "\nIf you start now, you will not be able to save the game.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39DC4[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39DDC[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39DF4[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39E0C[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39E24[140] __attribute__((aligned(4))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\252\214\251[\202\335]\202\302\202\251\202\350"
    "\202\334\202\271\202\361\201B\n\220\332[\202\271\202\302]\221\261[\202\274\202\255]\202\360\212m"
    "[\202\251\202\255]\224F[\202\311\202\361]\202\265\202\304\202\255\202\276\202\263\202\242\201B\n"
    "\202\261\202\314\202\334\202\334\216n[\202\315\202\266]\202\337\202\275\217\352[\202\316]\215"
    "\207[\202\240\202\242]\n\203Z\201[\203u\202\305\202\253\202\334\202\271\202\361\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_39EB0[];
extern char lbl_1_data_39EF4[];
extern char lbl_1_data_39F0C[];
extern char lbl_1_data_39F24[];
extern char lbl_1_data_39F3C[];
extern char lbl_1_data_39F54[];
extern char lbl_1_data_39FA4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39EB0[66] __attribute__((aligned(8))) = "The device in SLOT is not supported.\nPlease insert a Memory Card.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39EF4[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39F0C[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39F24[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39F3C[23] __attribute__((aligned(4))) = "CANNOT_SAVE_NOCARD ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39F54[80] __attribute__((aligned(4))) = "\203\201\203\202\203\212\201[\203J\201[\203h\210\310\212O\202\314\202\340\202\314\202\252\214"
    "\251[\202\335]\202\302\202\251\202\350\202\334\202\265\202\275\201B\n\203\201\203\202\203\212"
    "\201[\203J\201[\203h\202\360\202\263\202\265\202\304\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_39FA4[116] __attribute__((aligned(4))) = "Either Game Data was not loaded\nor the original Memory Card,\nfrom which the Game data was load"
    "ed,\nhas been removed.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A018[];
extern char lbl_1_data_3A01C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A018[4] __attribute__((aligned(8))) = "GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A01C[4] __attribute__((aligned(4))) = "FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A020[];
extern char lbl_1_data_3A024[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A020[4] __attribute__((aligned(8))) = "SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A024[4] __attribute__((aligned(4))) = "ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A028[];
extern char lbl_1_data_3A0E4[];
extern char lbl_1_data_3A15C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A028[188] __attribute__((aligned(8))) = "\203Q\201[\203\200\203f\201[\203^\202\252\203\215\201[\203h\202\263\202\352\202\304\202\242\202"
    "\310\202\242\202\251\n\203Q\201[\203\200\203f\201[\203^\202\360\203\215\201[\203h\202\265\202"
    "\275\203\201\203\202\203\212\201[\203J\201[\203h\n\202\305\202\315\202\240\202\350\202\334\202"
    "\271\202\361\201B(\203Q\201[\203\200\203f\201[\203^\202\314\203Z\201[\203u\201A\n\203\215\201["
    "\203h\202\315\201A\203I\203v\203V\203\207\203\223\202\314\203\201\203\202\203\212\201[\203J\201["
    "\203h\n\203\201\203j\203\205\201[\202\251\202\347\211\302[\202\251]\224\\[\202\314\202\244]\202"
    "\305\202\267\201B)\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A0E4[117] __attribute__((aligned(4))) = "Either Game Data was not loaded\nor the original Memory Card,\nfrom which the Game data was load"
    "ed,\n has been removed.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A15C[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A160[];
extern char lbl_1_data_3A164[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A160[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A164[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A168[];
extern char lbl_1_data_3A16C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A168[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A16C[92] __attribute__((aligned(4))) = "\203Q\201[\203\200\203f\201[\203^\202\252\203\215\201[\203h\202\263\202\352\202\304\202\242\202"
    "\310\202\242\202\251\n\203Q\201[\203\200\203f\201[\203^\202\360\203\215\201[\203h\202\265\202"
    "\275\203\201\203\202\203\212\201[\203J\201[\203h\n\202\305\202\315\202\240\202\350\202\334\202"
    "\271\202\361\201B\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A1C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A1C8[5] __attribute__((aligned(8))) = "Data";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A1D0[];
extern char lbl_1_data_3A1DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A1D0[9] __attribute__((aligned(8))) = "File GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A1DC[9] __attribute__((aligned(4))) = "File FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A1E8[];
extern char lbl_1_data_3A1F4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A1E8[9] __attribute__((aligned(8))) = "File SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A1F4[9] __attribute__((aligned(4))) = "File ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A200[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A200[8] __attribute__((aligned(8))) = "\203f\201[\203^\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A208[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A208[5] __attribute__((aligned(8))) = "Game";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A210[];
extern char lbl_1_data_3A21C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A210[11] __attribute__((aligned(8))) = "System GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A21C[11] __attribute__((aligned(4))) = "System FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A228[];
extern char lbl_1_data_3A234[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A228[11] __attribute__((aligned(8))) = "System SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A234[11] __attribute__((aligned(4))) = "System ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A240[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A240[8] __attribute__((aligned(8))) = "\203Q\201[\203\200\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A248[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A248[6] __attribute__((aligned(8))) = "Debug";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A250[];
extern char lbl_1_data_3A25C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A250[10] __attribute__((aligned(8))) = "Debug GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A25C[10] __attribute__((aligned(4))) = "Debug FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A268[];
extern char lbl_1_data_3A274[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A268[10] __attribute__((aligned(8))) = "Debug SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A274[10] __attribute__((aligned(4))) = "Debug ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A280[];
extern char lbl_1_data_3A28C[];
extern char lbl_1_data_3A294[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A280[12] __attribute__((aligned(8))) = "\203f\203o\203b\203O\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A28C[7] __attribute__((aligned(4))) = "Replay";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A294[11] __attribute__((aligned(4))) = "Replay GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A2A0[];
extern char lbl_1_data_3A2AC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2A0[11] __attribute__((aligned(8))) = "Replay FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2AC[11] __attribute__((aligned(4))) = "Replay SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A2B8[];
extern char lbl_1_data_3A2C4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2B8[11] __attribute__((aligned(8))) = "Replay ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2C4[12] __attribute__((aligned(4))) = "\203\212\203v\203\214\203C\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A2D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2D0[7] __attribute__((aligned(8))) = "Emblem";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A2D8[];
extern char lbl_1_data_3A2E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2D8[11] __attribute__((aligned(8))) = "Emblem GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2E4[11] __attribute__((aligned(4))) = "Emblem FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A2F0[];
extern char lbl_1_data_3A2FC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2F0[11] __attribute__((aligned(8))) = "Emblem SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A2FC[11] __attribute__((aligned(4))) = "Emblem ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A308[];
extern char lbl_1_data_3A314[];
extern char lbl_1_data_3A31C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A308[12] __attribute__((aligned(8))) = "\203G\203\223\203u\203\214\203\200\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A314[6] __attribute__((aligned(4))) = "Ghost";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A31C[10] __attribute__((aligned(4))) = "Ghost GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A328[];
extern char lbl_1_data_3A334[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A328[10] __attribute__((aligned(8))) = "Ghost FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A334[10] __attribute__((aligned(4))) = "Ghost SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A340[];
extern char lbl_1_data_3A34C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A340[10] __attribute__((aligned(8))) = "Ghost ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A34C[12] __attribute__((aligned(4))) = "\203S\201[\203X\203g\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A358[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A358[7] __attribute__((aligned(8))) = "Garage";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A360[];
extern char lbl_1_data_3A36C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A360[11] __attribute__((aligned(8))) = "Custom GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A36C[11] __attribute__((aligned(4))) = "Custom FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A378[];
extern char lbl_1_data_3A384[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A378[11] __attribute__((aligned(8))) = "Custom SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A384[11] __attribute__((aligned(4))) = "Custom ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A390[];
extern char lbl_1_data_3A39C[];
extern char lbl_1_data_3A3A4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A390[12] __attribute__((aligned(8))) = "\203K\203\214\201[\203W\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A39C[5] __attribute__((aligned(4))) = "Game";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3A4[9] __attribute__((aligned(4))) = "Game GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A3B0[];
extern char lbl_1_data_3A3BC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3B0[9] __attribute__((aligned(8))) = "Game FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3BC[9] __attribute__((aligned(4))) = "Game SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A3C8[];
extern char lbl_1_data_3A3D4[];
extern char lbl_1_data_3A3DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3C8[9] __attribute__((aligned(8))) = "Game ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3D4[8] __attribute__((aligned(4))) = "\203Q\201[\203\200\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A3DC[323] __attribute__((aligned(4))) = "There is not enough free space on the Memory Card\nin %s to save all types of new files.\nExisti"
    "ng F-ZERO GX files may be erased or overwritten.\n(To manage files on the Memory Card, please go"
    " to\nthe Memory Card management screen.) In order to save\na new file, the following number of f"
    "ree files\nand blocks must be available:";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A520[];
extern char lbl_1_data_3A524[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A520[4] __attribute__((aligned(8))) = "GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A524[4] __attribute__((aligned(4))) = "FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A528[];
extern char lbl_1_data_3A52C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A528[4] __attribute__((aligned(8))) = "SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A52C[4] __attribute__((aligned(4))) = "ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A530[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A530[368] __attribute__((aligned(8))) = "\202\242\202\255\202\302\202\251\202\314\203f\201[\203^\202\315\203Z\201[\203u\202\305\202\253"
    "\202\334\202\271\202\361\201B\n%s\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311"
    "\213\363[\202\240]\202\253\227e\227\312\202\252\202\310\202\242\202\251\201A\n\203t\203@\203C"
    "\203\213\220\224[\202\267\202\244]\202\314\220\247[\202\271\202\242]\214\300[\202\260\202\361]"
    "\202\360\211z[\202\261]\202\246\202\304\202\265\202\334\202\242\202\334\202\267\201B\n\203Z\201["
    "\203u\202\267\202\351\202\311\202\315\217\255[\202\267\202\255]\202\310\202\255\202\306\202\340"
    "\210\310[\202\242]\211\272[\202\251]\202\314\213\363[\202\240]\202\253\227e[\202\346\202\244 ]"
    "\227\312[\202\350\202\345\202\244]\202\252\225K[\202\320\202\302]\227v[\202\346\202\244]\202\305"
    "\202\267\201B\n(\203\201\203\202\203\212\201[\203J\201[\203h\202\314\223\340[\202\310\202\242]"
    "\227e[\202\346\202\244]\202\360\220\256[\202\271\202\242]\227\235[\202\350]\202\267\202\351\202"
    "\311\202\315\201A\n\226{[\202\331\202\361]\221\314[\202\275\202\242]\202\314\203\201\203\202\203"
    "\212\201[\203J\201[\203h\211\346[\202\252]\226\312[\202\337\202\361]\202\305\215s[\202\250\202"
    "\261]\202\310\202\301\202\304\202\255\202\276\202\263\202\242)\n";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A6A0[];
extern char lbl_1_data_3A6E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6A0[67] __attribute__((aligned(8))) = "/bcffa0a0/1/bcffffff/ File and /bcffa0a0/        /bcffffff/ Blocks";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6E4[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A6E8[];
extern char lbl_1_data_3A6EC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6E8[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6EC[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A6F0[];
extern char lbl_1_data_3A6F4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6F0[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A6F4[68] __attribute__((aligned(4))) = "\203t\203@\203C\203\213/bcffa0a0/1/bcffffff/\202\302 \202\306/bcffa0a0/%4d/bcffffff/\203u\203"
    "\215\203b\203N\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A738[];
extern char lbl_1_data_3A77C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A738[68] __attribute__((aligned(8))) = "/bcffa0a0/1/bcffffff/ File and /bcffa0a0/\202R\201`%2d/bcffffff/ Blocks\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A77C[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A780[];
extern char lbl_1_data_3A784[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A780[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A784[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A788[];
extern char lbl_1_data_3A78C[];
extern char lbl_1_data_3A7D4[];
extern char lbl_1_data_3A80C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A788[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A78C[72] __attribute__((aligned(4))) = "\203t\203@\203C\203\213/bcffa0a0/1/bcffffff/\202\302 \202\306/bcffa0a0/\202R\201`%2d/bcffffff/"
    "\203u\203\215\203b\203N\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A7D4[53] __attribute__((aligned(4))) = "No Memory Card in SLOT.\nPlease insert a Memory Card.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A80C[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A810[];
extern char lbl_1_data_3A814[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A810[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A814[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A818[];
extern char lbl_1_data_3A81C[];
extern char lbl_1_data_3A874[];
extern char lbl_1_data_3A87C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A818[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A81C[88] __attribute__((aligned(4))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\252\214\251[\202\335]\202\302\202\251\202\350"
    "\202\334\202\271\202\361\201B\n\220\332[\202\271\202\302]\221\261[\202\274\202\255]\202\360\212m"
    "[\202\251\202\255]\224F[\202\311\202\361]\202\265\202\304\202\255\202\276\202\263\202\242\201B"
    "\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A874[5] __attribute__((aligned(4))) = "SAVE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A87C[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A880[];
extern char lbl_1_data_3A884[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A880[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A884[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A888[];
extern char lbl_1_data_3A88C[];
extern char lbl_1_data_3A894[];
extern char lbl_1_data_3A89C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A888[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A88C[8] __attribute__((aligned(4))) = "\203Z\201[\203u\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A894[5] __attribute__((aligned(4))) = "LOAD";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A89C[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8A0[];
extern char lbl_1_data_3A8A4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8A0[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8A4[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8A8[];
extern char lbl_1_data_3A8AC[];
extern char lbl_1_data_3A8B4[];
extern char lbl_1_data_3A8BC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8A8[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8AC[8] __attribute__((aligned(4))) = "\203\215\201[\203h\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8B4[5] __attribute__((aligned(4))) = "COPY";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8BC[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8C0[];
extern char lbl_1_data_3A8C4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8C0[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8C4[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8C8[];
extern char lbl_1_data_3A8CC[];
extern char lbl_1_data_3A8D4[];
extern char lbl_1_data_3A8DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8C8[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8CC[8] __attribute__((aligned(4))) = "\203R\203s\201[\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8D4[6] __attribute__((aligned(4))) = "ERASE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8DC[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8E0[];
extern char lbl_1_data_3A8E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8E0[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8E4[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A8E8[];
extern char lbl_1_data_3A8EC[];
extern char lbl_1_data_3A8F4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8E8[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8EC[8] __attribute__((aligned(4))) = "\202\257 \202\267\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A8F4[52] __attribute__((aligned(4))) = "This Memory Card cannot be used.\nPlease remove it. ";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A928[];
extern char lbl_1_data_3A92C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A928[4] __attribute__((aligned(8))) = "GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A92C[4] __attribute__((aligned(4))) = "FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A930[];
extern char lbl_1_data_3A934[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A930[4] __attribute__((aligned(8))) = "SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A934[4] __attribute__((aligned(4))) = "ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A938[];
extern char lbl_1_data_3A98C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A938[84] __attribute__((aligned(8))) = "\202\261\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\315\216g[\202\265]\227p[\202"
    "\346\202\244]\202\305\202\253\202\334\202\271\202\361\201B\n\203\201\203\202\203\212\201[\203J"
    "\201[\203h\202\360\224\262[\202\312]\202\242\202\304\202\255\202\276\202\263\202\242\201B";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A98C[83] __attribute__((aligned(4))) = "Accessing the Memory Card in Slot A. Do not touch the Memory Card or POWER Button.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A9E0[];
extern char lbl_1_data_3A9E4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A9E0[4] __attribute__((aligned(8))) = "GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A9E4[4] __attribute__((aligned(4))) = "FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A9E8[];
extern char lbl_1_data_3A9EC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A9E8[4] __attribute__((aligned(8))) = "SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A9EC[4] __attribute__((aligned(4))) = "ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3A9F0[];
extern char lbl_1_data_3AA3C[];
extern char lbl_1_data_3AA44[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3A9F0[76] __attribute__((aligned(8))) = "\203\201\203\202\203\212\201[\203J\201[\203h\202\311\203A\203N\203Z\203X\222\206\202\305\202\267"
    "\201B\203\201\203\202\203\212\201[\203J\201[\203h\202\342\223d\214\271\202\311\220G\202\347\202"
    "\310\202\242\202\305\202\255\202\276\202\263\202\242\201B\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA3C[7] __attribute__((aligned(4))) = "Saving";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA44[4] __attribute__((aligned(4))) = "GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AA48[];
extern char lbl_1_data_3AA4C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA48[4] __attribute__((aligned(8))) = "FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA4C[4] __attribute__((aligned(4))) = "SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AA50[];
extern char lbl_1_data_3AA54[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA50[4] __attribute__((aligned(8))) = "ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA54[12] __attribute__((aligned(4))) = "\203Z\201[\203u\222\206\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AA60[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AA60[64] __attribute__((aligned(8))) = "Some F-ZERO GX files on\nthe Memory Card in SLOT are corrupted.\n";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AAA0[];
extern char lbl_1_data_3AAB4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AAA0[18] __attribute__((aligned(8))) = "LIST_NO_EXIST GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AAB4[18] __attribute__((aligned(4))) = "LIST_NO_EXIST FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AAC8[];
extern char lbl_1_data_3AADC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AAC8[18] __attribute__((aligned(8))) = "LIST_NO_EXIST SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AADC[18] __attribute__((aligned(4))) = "LIST_NO_EXIST ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AAF0[];
extern char lbl_1_data_3ABCC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AAF0[220] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\311\202\315\n\203f\201[\203^\202"
    "\2521\202\302\202\340\202\240\202\350\202\334\202\271\202\361\202\305\202\265\202\275\201B\n("
    "\202\261\202\355\202\352\202\275\203f\201[\203^\202\252\221\266[\202\273\202\361]\215\335[\202"
    "\264\202\242]\202\265\202\304\202\242\202\334\202\267\201B\n\203\201\203\202\203\212\201[\203J"
    "\201[\203h\202\314\223\340[\202\310\202\242]\227e[\202\346\202\244]\202\360\220\256[\202\271\202"
    "\242]\227\235[\202\350]\202\267\202\351\202\311\202\315\201A\n\226{[\202\331\202\361]\221\314["
    "\202\275\202\242]\202\314\203\201\203\202\203\212\201[\203J\201[\203h\211\346\226\312\202\305"
    "\202\250\202\261\202\310\202\301\202\304\202\255\202\276\202\263\202\242)";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3ABCC[121] __attribute__((aligned(4))) = "The data list on the Memory Card in SLOT\nhas been read. (Some F-ZERO GX files on\nthe Memory Ca"
    "rd in SLOT are corrupted.)";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AC48[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AC48[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AC58[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AC58[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AC68[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AC68[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AC78[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AC78[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AC88[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AC88[224] __attribute__((aligned(8))) = "SLOT\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\314\n\203f\201[\203^\203\212\203X"
    "\203g\202\360\223\307[\202\346]\202\335\202\261\202\335\202\334\202\265\202\275\201B\n(\202\261"
    "\202\355\202\352\202\275\203f\201[\203^\202\252\221\266[\202\273\202\361]\215\335[\202\264\202"
    "\242]\202\265\202\304\202\242\202\334\202\267\201B\n\203\201\203\202\203\212\201[\203J\201[\203h"
    "\202\314\223\340[\202\310\202\242]\227e[\202\346\202\244]\202\360\220\256[\202\271\202\242]\227"
    "\235[\202\350]\202\267\202\351\202\311\202\315\201A\n\226{[\202\331\202\361]\221\314[\202\275"
    "\202\242]\202\314\203\201\203\202\203\212\201[\203J\201[\203h\211\346\226\312\202\305\202\250"
    "\202\261\202\310\202\301\202\304\202\255\202\276\202\263\202\242)\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AD68[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AD68[111] __attribute__((aligned(8))) = "Some F-ZERO GX files on\nthe Memory Card in SLOT are corrupted.\nPlease go to Options to manage "
    "the Memory Card.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3ADD8[];
extern char lbl_1_data_3ADEC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3ADD8[18] __attribute__((aligned(8))) = "LIST_NO_EXIST GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3ADEC[18] __attribute__((aligned(4))) = "LIST_NO_EXIST FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AE00[];
extern char lbl_1_data_3AE14[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AE00[18] __attribute__((aligned(8))) = "LIST_NO_EXIST SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AE14[18] __attribute__((aligned(4))) = "LIST_NO_EXIST ITA";
#pragma explicit_zero_data reset
extern u8 lbl_1_data_3AE28[];
extern char lbl_1_data_3AE2C[];
extern char lbl_1_data_3AED4[];
extern char lbl_1_data_3AEE4[];
extern char lbl_1_data_3AEF4[];
extern char lbl_1_data_3AF04[];
extern u8 lbl_1_data_3AF14[];

#pragma explicit_zero_data on
__declspec(section ".data") u8 lbl_1_data_3AE28[4] __attribute__((aligned(8))) = {
    0x00U, 0x00U, 0x00U, 0x00U
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AE2C[166] __attribute__((aligned(4))) = "The data list on the Memory Card in SLOT\nhas been read. (Some F-ZERO GX files on\nthe Memory Ca"
    "rd in SLOT are corrupted.\nPlease go to Options manage the Memory Card.)";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AED4[13] __attribute__((aligned(4))) = "LIST_END GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AEE4[13] __attribute__((aligned(4))) = "LIST_END FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AEF4[13] __attribute__((aligned(4))) = "LIST_END SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AF04[13] __attribute__((aligned(4))) = "LIST_END ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") u8 lbl_1_data_3AF14[4] __attribute__((aligned(4))) = {
    0x00U, 0x00U, 0x00U, 0x00U
};
#pragma explicit_zero_data reset
extern char lbl_1_data_3AF18[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AF18[168] __attribute__((aligned(8))) = "No Memory Card found in Slot A. Please re-insert the\noriginal Memory Card from which the Game d"
    "ata was loaded.\n\203\237 Button \201c Retry\n\203\240 Button \201c Continue without saving\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AFC0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AFC0[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AFD0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AFD0[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AFE0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AFE0[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3AFF0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3AFF0[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B000[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B000[184] __attribute__((aligned(8))) = "\203X\203\215\203b\203g\202`\202\314\203\201\203\202\203\212\201[\203J\201[\203h\202\252\224\262"
    "[\202\312]\202\251\202\352\202\304\202\242\202\334\202\267\201B\n\203Q\201[\203\200\203f\201["
    "\203^\202\360\203\215\201[\203h\202\265\202\275\203\201\203\202\203\212\201[\203J\201[\203h\202"
    "\360\n\203X\203\215\203b\203g\202`\202\311\202\263\202\265\202\304\203\237\203{\203^\203\223\202"
    "\360\211\237[\202\250]\202\265\202\304\202\255\202\276\202\263\202\242\201B\n\203L\203\203\203"
    "\223\203Z\203\213\202\267\202\351\202\311\202\315\203\240\202\360\211\237[\202\250]\202\265\202"
    "\304\202\255\202\276\202\263\202\242\201B\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B0B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B0B8[38] __attribute__((aligned(8))) = "Are you sure you\nwant to delete this\077";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B0E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B0E0[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B0F0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B0F0[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B100[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B100[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B110[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B110[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B120[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B120[48] __attribute__((aligned(8))) = "\226{[\202\331\202\361]\223\226[\202\306\202\244]\202\311\217\301[\202\257]\202\265\202\304\202"
    "\340\n\202\346\202\353\202\265\202\242\202\305\202\267\202\251\077\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B150[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B150[70] __attribute__((aligned(8))) = "The device in SLOT is not a Memory Card.\nPlease insert a Memory Card.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B198[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B198[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B1A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B1A8[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B1B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B1B8[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B1C8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B1C8[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B1D8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B1D8[104] __attribute__((aligned(8))) = "\203\201\203\202\203\212\201[\203J\201[\203h\210\310\212O\202\314\202\340\202\314\202\252\214"
    "\251[\202\335]\202\302\202\251\202\350\202\334\202\265\202\275\201B\n\202\261\202\314\202\334"
    "\202\334\202\305\202\315\215\354[\202\263\202\254]\213\306[\202\345\202\244]\202\252\225\333["
    "\202\331]\221\266[\202\274\202\361]\202\305\202\253\202\334\202\271\202\361\201B";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B240[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B240[53] __attribute__((aligned(8))) = "Created Emblems cannot be\nsaved to this Memory Card.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B278[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B278[13] __attribute__((aligned(8))) = "LIST_END GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B288[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B288[13] __attribute__((aligned(8))) = "LIST_END FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B298[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B298[13] __attribute__((aligned(8))) = "LIST_END SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B2A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B2A8[13] __attribute__((aligned(8))) = "LIST_END ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B2B8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B2B8[72] __attribute__((aligned(8))) = "\202\261\202\314\202\334\202\334\202\305\202\315\203G\203\223\203u\203\214\203\200\202\314\215"
    "\354[\202\263\202\254]\213\306[\202\345\202\244]\202\252\225\333[\202\331]\221\266[\202\274\202"
    "\361]\202\305\202\253\202\334\202\271\202\361\201B\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B300[];
extern char lbl_1_data_3B32C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B300[42] __attribute__((aligned(8))) = "The FILE Data exists in SLOT. \nOverwrite\077";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B32C[20] __attribute__((aligned(4))) = "OVERWRITE_QUERY GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B340[];
extern char lbl_1_data_3B354[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B340[20] __attribute__((aligned(8))) = "OVERWRITE_QUERY FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B354[20] __attribute__((aligned(4))) = "OVERWRITE_QUERY SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B368[];
extern char lbl_1_data_3B37C[];
extern char lbl_1_data_3B3AC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B368[20] __attribute__((aligned(8))) = "OVERWRITE_QUERY ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B37C[48] __attribute__((aligned(4))) = "    \217\343[\202\244\202\355]\217\221[\202\252]\202\253\202\265\202\304\202\340\202\346\202\353"
    "\202\265\202\242\202\305\202\267\202\251\201H    \000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B3AC[18] __attribute__((aligned(4))) = "Create a New File";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B3C0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B3C0[15] __attribute__((aligned(8))) = "NEW_CREATE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B3D0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B3D0[15] __attribute__((aligned(8))) = "NEW_CREATE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B3E0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B3E0[15] __attribute__((aligned(8))) = "NEW_CREATE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B3F0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B3F0[15] __attribute__((aligned(8))) = "NEW_CREATE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B400[];
extern char lbl_1_data_3B40C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B400[12] __attribute__((aligned(8))) = "\220V\213K\215\354\220\254\000\000\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B40C[19] __attribute__((aligned(4))) = "Create a new file.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B420[];
extern char lbl_1_data_3B434[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B420[18] __attribute__((aligned(8))) = "NEW_CREATE_DO GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B434[18] __attribute__((aligned(4))) = "NEW_CREATE_DO FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B448[];
extern char lbl_1_data_3B45C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B448[18] __attribute__((aligned(8))) = "NEW_CREATE_DO SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B45C[18] __attribute__((aligned(4))) = "NEW_CREATE_DO ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B470[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B470[32] __attribute__((aligned(8))) = "\220V\213K\202\311\203t\203@\203C\203\213\202\360\215\354\220\254\202\265\202\334\202\267\201B"
    "\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B490[];
extern char lbl_1_data_3B4AC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B490[26] __attribute__((aligned(8))) = "Cannot create a new file.";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B4AC[20] __attribute__((aligned(4))) = "NEW_CREATE_DONT GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B4C0[];
extern char lbl_1_data_3B4D4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B4C0[20] __attribute__((aligned(8))) = "NEW_CREATE_DONT FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B4D4[20] __attribute__((aligned(4))) = "NEW_CREATE_DONT SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B4E8[];
extern char lbl_1_data_3B4FC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B4E8[20] __attribute__((aligned(8))) = "NEW_CREATE_DONT ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B4FC[36] __attribute__((aligned(4))) = "\220V\213K\202\311\203t\203@\203C\203\213\202\360\215\354\220\254\202\305\202\253\202\334\202"
    "\271\202\361\201B\000\000\000";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B520[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B520[32] __attribute__((aligned(8))) = "%d block(s) of space available.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B540[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B540[15] __attribute__((aligned(8))) = "FREE_SPACE GER";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B550[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B550[15] __attribute__((aligned(8))) = "FREE_SPACE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B560[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B560[15] __attribute__((aligned(8))) = "FREE_SPACE SPA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B570[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B570[15] __attribute__((aligned(8))) = "FREE_SPACE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B580[];
extern char lbl_1_data_3B594[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B580[20] __attribute__((aligned(8))) = "\213\363\202\253\227e\227\312 %d\203u\203\215\203b\203N";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B594[49] __attribute__((aligned(4))) = "%d block(s) needed. (%d free block(s) available)";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B5C8[];
extern char lbl_1_data_3B5DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B5C8[20] __attribute__((aligned(8))) = "FREE_NEED_SPACE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B5DC[20] __attribute__((aligned(4))) = "FREE_NEED_SPACE FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B5F0[];
extern char lbl_1_data_3B604[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B5F0[20] __attribute__((aligned(8))) = "FREE_NEED_SPACE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B604[20] __attribute__((aligned(4))) = "FREE_NEED_SPACE ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B618[];
extern char lbl_1_data_3B63C[];
extern char lbl_1_data_3B64C[];
extern char lbl_1_data_3B65C[];
extern char lbl_1_data_3B66C[];
extern char lbl_1_data_3B67C[];
extern char lbl_1_data_3B68C[];
extern char lbl_1_data_3B69C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B618[36] __attribute__((aligned(8))) = "%d\203u\203\215\203b\203N\225K\227v(\213\363\202\253\227e\227\312 %d\203u\203\215\203b\203N)";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B63C[13] __attribute__((aligned(4))) = "Corrupt File";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B64C[16] __attribute__((aligned(4))) = "BROKEN_FILE GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B65C[16] __attribute__((aligned(4))) = "BROKEN_FILE FRA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B66C[16] __attribute__((aligned(4))) = "BROKEN_FILE SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B67C[16] __attribute__((aligned(4))) = "BROKEN_FILE ITA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B68C[16] __attribute__((aligned(4))) = "\211\363\202\352\202\275\203t\203@\203C\203\213\000";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B69C[44] __attribute__((aligned(4))) = "This file is corrupted and must be deleted.";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B6C8[];
extern char lbl_1_data_3B6DC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B6C8[20] __attribute__((aligned(8))) = "BROKEN_FILE_DEL GER";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B6DC[20] __attribute__((aligned(4))) = "BROKEN_FILE_DEL FRA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B6F0[];
extern char lbl_1_data_3B704[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B6F0[20] __attribute__((aligned(8))) = "BROKEN_FILE_DEL SPA";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B704[20] __attribute__((aligned(4))) = "BROKEN_FILE_DEL ITA";
#pragma explicit_zero_data reset
extern char lbl_1_data_3B718[];
extern u32 lbl_1_data_3C1E4;

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3B718[52] __attribute__((aligned(8))) = "\202\261\202\314\203t\203@\203C\203\213\202\315\211\363\202\352\202\304\202\242\202\351\202\314"
    "\202\305\217\301\202\267\225K\227v\202\252\202\240\202\350\202\334\202\267\201B\000\000\000";
#pragma explicit_zero_data reset

/* Obj_1_data_3B74C (header) does not place every retail pointer; fields follow the relocations. */
#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_3B74C lbl_1_data_3B74C __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_35BF4,
    (u8 *)&lbl_1_data_35C44,
    (u8 *)&lbl_1_data_35C50,
    (u8 *)&lbl_1_data_35C5C,
    (u8 *)&lbl_1_data_35C68,
    (u8 *)&lbl_1_data_35C74,
    (u8 *)&lbl_1_data_35CE0,
    (u8 *)&lbl_1_data_35D24,
    (u8 *)&lbl_1_data_35D34,
    (u8 *)&lbl_1_data_35D44,
    (u8 *)&lbl_1_data_35D54,
    (u8 *)&lbl_1_data_35D64,
    (u8 *)&lbl_1_data_35DC4,
    (u8 *)&lbl_1_data_35E34,
    (u8 *)&lbl_1_data_35E40,
    (u8 *)&lbl_1_data_35E4C,
    (u8 *)&lbl_1_data_35E58,
    (u8 *)&lbl_1_data_35E64,
    (u8 *)&lbl_1_data_35F4C,
    (u8 *)&lbl_1_data_35FA4,
    (u8 *)&lbl_1_data_35FB0,
    (u8 *)&lbl_1_data_35FBC,
    (u8 *)&lbl_1_data_35FC8,
    (u8 *)&lbl_1_data_35FD4,
    (u8 *)&lbl_1_data_3603C,
    (u8 *)&lbl_1_data_36070,
    (u8 *)&lbl_1_data_36088,
    (u8 *)&lbl_1_data_360A0,
    (u8 *)&lbl_1_data_360B8,
    (u8 *)&lbl_1_data_360D0,
    (u8 *)&lbl_1_data_360F8,
    (u8 *)&lbl_1_data_36128,
    (u8 *)&lbl_1_data_36140,
    (u8 *)&lbl_1_data_36158,
    (u8 *)&lbl_1_data_36170,
    (u8 *)&lbl_1_data_36188,
    (u8 *)&lbl_1_data_361B0,
    (u8 *)&lbl_1_data_361E0,
    (u8 *)&lbl_1_data_361F8,
    (u8 *)&lbl_1_data_36210,
    (u8 *)&lbl_1_data_36228,
    (u8 *)&lbl_1_data_36240,
    (u8 *)&lbl_1_data_36270,
    (u8 *)&lbl_1_data_362A0,
    (u8 *)&lbl_1_data_362BC,
    (u8 *)&lbl_1_data_362D8,
    (u8 *)&lbl_1_data_362F4,
    (u8 *)&lbl_1_data_36310,
    (u8 *)&lbl_1_data_36338,
    (u8 *)&lbl_1_data_3636C,
    (u8 *)&lbl_1_data_36388,
    (u8 *)&lbl_1_data_363A4,
    (u8 *)&lbl_1_data_363C0,
    (u8 *)&lbl_1_data_363DC,
    (u8 *)&lbl_1_data_36408,
    (u8 *)&lbl_1_data_3644C,
    (u8 *)&lbl_1_data_3646C,
    (u8 *)&lbl_1_data_3648C,
    (u8 *)&lbl_1_data_364AC,
    (u8 *)&lbl_1_data_364CC,
    (u8 *)&lbl_1_data_36510,
    (u8 *)&lbl_1_data_36554,
    (u8 *)&lbl_1_data_36574,
    (u8 *)&lbl_1_data_36594,
    (u8 *)&lbl_1_data_365B4,
    (u8 *)&lbl_1_data_365D4,
    (u8 *)&lbl_1_data_36618,
    (u8 *)&lbl_1_data_36648,
    (u8 *)&lbl_1_data_36668,
    (u8 *)&lbl_1_data_36688,
    (u8 *)&lbl_1_data_366A8,
    (u8 *)&lbl_1_data_366C8,
    (u8 *)&lbl_1_data_366F8,
    (u8 *)&lbl_1_data_3673C,
    (u8 *)&lbl_1_data_3675C,
    (u8 *)&lbl_1_data_3677C,
    (u8 *)&lbl_1_data_3679C,
    (u8 *)&lbl_1_data_367BC,
    (u8 *)&lbl_1_data_36800,
    (u8 *)&lbl_1_data_36844,
    (u8 *)&lbl_1_data_36864,
    (u8 *)&lbl_1_data_36884,
    (u8 *)&lbl_1_data_368A4,
    (u8 *)&lbl_1_data_368C4,
    (u8 *)&lbl_1_data_36908,
    (u8 *)&lbl_1_data_36928,
    (u8 *)&lbl_1_data_36938,
    (u8 *)&lbl_1_data_36948,
    (u8 *)&lbl_1_data_36958,
    (u8 *)&lbl_1_data_36968,
    (u8 *)&lbl_1_data_36984,
    (u8 *)&lbl_1_data_36998,
    (u8 *)&lbl_1_data_369A8,
    (u8 *)&lbl_1_data_369B8,
    (u8 *)&lbl_1_data_369C8,
    (u8 *)&lbl_1_data_369D8,
    (u8 *)&lbl_1_data_369E8,
    (u8 *)&lbl_1_data_36A1C,
    (u8 *)&lbl_1_data_36A34,
    (u8 *)&lbl_1_data_36A4C,
    (u8 *)&lbl_1_data_36A64,
    (u8 *)&lbl_1_data_36A7C,
    (u8 *)&lbl_1_data_36AB0,
    (u8 *)&lbl_1_data_36AE4,
    (u8 *)&lbl_1_data_36AFC,
    (u8 *)&lbl_1_data_36B14,
    (u8 *)&lbl_1_data_36B2C,
    (u8 *)&lbl_1_data_36B44,
    (u8 *)&lbl_1_data_36B78,
    (u8 *)&lbl_1_data_36B98,
    (u8 *)&lbl_1_data_36BB0,
    (u8 *)&lbl_1_data_36BC8,
    (u8 *)&lbl_1_data_36BE0,
    (u8 *)&lbl_1_data_36BF8,
    (u8 *)&lbl_1_data_36C1C,
    (u8 *)&lbl_1_data_36C50,
    (u8 *)&lbl_1_data_36C6C,
    (u8 *)&lbl_1_data_36C88,
    (u8 *)&lbl_1_data_36CA4,
    (u8 *)&lbl_1_data_36CC0,
    (u8 *)&lbl_1_data_36CF0,
    (u8 *)&lbl_1_data_36D28,
    (u8 *)&lbl_1_data_36D44,
    (u8 *)&lbl_1_data_36D60,
    (u8 *)&lbl_1_data_36D7C,
    (u8 *)&lbl_1_data_36D98,
    (u8 *)&lbl_1_data_36DD0,
    (u8 *)&lbl_1_data_36E10,
    (u8 *)&lbl_1_data_36E30,
    (u8 *)&lbl_1_data_36E50,
    (u8 *)&lbl_1_data_36E70,
    (u8 *)&lbl_1_data_36E90,
    (u8 *)&lbl_1_data_36ED0,
    (u8 *)&lbl_1_data_36F0C,
    (u8 *)&lbl_1_data_36F2C,
    (u8 *)&lbl_1_data_36F4C,
    (u8 *)&lbl_1_data_36F6C,
    (u8 *)&lbl_1_data_36F8C,
    (u8 *)&lbl_1_data_36FCC,
    (u8 *)&lbl_1_data_37008,
    (u8 *)&lbl_1_data_37028,
    (u8 *)&lbl_1_data_37048,
    (u8 *)&lbl_1_data_37068,
    (u8 *)&lbl_1_data_37088,
    (u8 *)&lbl_1_data_370CC,
    (u8 *)&lbl_1_data_3710C,
    (u8 *)&lbl_1_data_3712C,
    (u8 *)&lbl_1_data_3714C,
    (u8 *)&lbl_1_data_3716C,
    (u8 *)&lbl_1_data_3718C,
    (u8 *)&lbl_1_data_371C8,
    (u8 *)&lbl_1_data_37208,
    (u8 *)&lbl_1_data_37228,
    (u8 *)&lbl_1_data_37248,
    (u8 *)&lbl_1_data_37268,
    (u8 *)&lbl_1_data_37288,
    (u8 *)&lbl_1_data_372C8,
    (u8 *)&lbl_1_data_372F4,
    (u8 *)&lbl_1_data_3730C,
    (u8 *)&lbl_1_data_37324,
    (u8 *)&lbl_1_data_3733C,
    (u8 *)&lbl_1_data_37354,
    (u8 *)&lbl_1_data_37380,
    (u8 *)&lbl_1_data_373DC,
    (u8 *)&lbl_1_data_373F4,
    (u8 *)&lbl_1_data_3740C,
    (u8 *)&lbl_1_data_37424,
    (u8 *)&lbl_1_data_3743C,
    (u8 *)&lbl_1_data_374A8,
    (u8 *)&lbl_1_data_374D8,
    (u8 *)&lbl_1_data_374E8,
    (u8 *)&lbl_1_data_374F8,
    (u8 *)&lbl_1_data_37508,
    (u8 *)&lbl_1_data_37518,
    (u8 *)&lbl_1_data_37550,
    (u8 *)&lbl_1_data_375A4,
    (u8 *)&lbl_1_data_375B8,
    (u8 *)&lbl_1_data_375CC,
    (u8 *)&lbl_1_data_375E0,
    (u8 *)&lbl_1_data_375F4,
    (u8 *)&lbl_1_data_3763C,
    (u8 *)&lbl_1_data_37680,
    (u8 *)&lbl_1_data_37690,
    (u8 *)&lbl_1_data_376A0,
    (u8 *)&lbl_1_data_376B0,
    (u8 *)&lbl_1_data_376C0,
    (u8 *)&lbl_1_data_37704,
    (u8 *)&lbl_1_data_3773C,
    (u8 *)&lbl_1_data_37750,
    (u8 *)&lbl_1_data_37764,
    (u8 *)&lbl_1_data_37778,
    (u8 *)&lbl_1_data_3778C,
    (u8 *)&lbl_1_data_377D0,
    (u8 *)&lbl_1_data_37808,
    (u8 *)&lbl_1_data_37818,
    (u8 *)&lbl_1_data_37828,
    (u8 *)&lbl_1_data_37838,
    (u8 *)&lbl_1_data_37848,
    (u8 *)&lbl_1_data_3788C,
    (u8 *)&lbl_1_data_378EC,
    (u8 *)&lbl_1_data_378FC,
    (u8 *)&lbl_1_data_3790C,
    (u8 *)&lbl_1_data_3791C,
    (u8 *)&lbl_1_data_3792C,
    (u8 *)&lbl_1_data_37984,
    (u8 *)&lbl_1_data_379C0,
    (u8 *)&lbl_1_data_379D0,
    (u8 *)&lbl_1_data_379E0,
    (u8 *)&lbl_1_data_379F0,
    (u8 *)&lbl_1_data_37A00,
    (u8 *)&lbl_1_data_37A58,
    (u8 *)&lbl_1_data_37AB8,
    (u8 *)&lbl_1_data_37ACC,
    (u8 *)&lbl_1_data_37AE0,
    (u8 *)&lbl_1_data_37AF4,
    (u8 *)&lbl_1_data_37B08,
    (u8 *)&lbl_1_data_37B74,
    (u8 *)&lbl_1_data_37B9C,
    (u8 *)&lbl_1_data_37BB0,
    (u8 *)&lbl_1_data_37BC4,
    (u8 *)&lbl_1_data_37BD8,
    (u8 *)&lbl_1_data_37BEC,
    (u8 *)&lbl_1_data_37C28,
    (u8 *)&lbl_1_data_37C30,
    (u8 *)&lbl_1_data_37C3C,
    (u8 *)&lbl_1_data_37C48,
    (u8 *)&lbl_1_data_37C54,
    (u8 *)&lbl_1_data_37C60,
    (u8 *)&lbl_1_data_37C6C,
    (u8 *)&lbl_1_data_37C74,
    (u8 *)&lbl_1_data_37C80,
    (u8 *)&lbl_1_data_37C8C,
    (u8 *)&lbl_1_data_37C98,
    (u8 *)&lbl_1_data_37CA4,
    (u8 *)&lbl_1_data_37CB0,
    (u8 *)&lbl_1_data_37CB4,
    (u8 *)&lbl_1_data_37CBC,
    (u8 *)&lbl_1_data_37CC4,
    (u8 *)&lbl_1_data_37CCC,
    (u8 *)&lbl_1_data_37CD4,
    (u8 *)&lbl_1_data_37CDC,
    (u8 *)&lbl_1_data_37CE0,
    (u8 *)&lbl_1_data_37CE8,
    (u8 *)&lbl_1_data_37CF0,
    (u8 *)&lbl_1_data_37CF8,
    (u8 *)&lbl_1_data_37D00,
    (u8 *)&lbl_1_data_37D08,
    (u8 *)&lbl_1_data_37D44,
    (u8 *)&lbl_1_data_37D58,
    (u8 *)&lbl_1_data_37D6C,
    (u8 *)&lbl_1_data_37D80,
    (u8 *)&lbl_1_data_37D94,
    (u8 *)&lbl_1_data_37DD4,
    (u8 *)&lbl_1_data_37F64,
    (u8 *)&lbl_1_data_37F70,
    (u8 *)&lbl_1_data_37F7C,
    (u8 *)&lbl_1_data_37F88,
    (u8 *)&lbl_1_data_37F94,
    (u8 *)&lbl_1_data_381E4,
    (u8 *)&lbl_1_data_382C8,
    (u8 *)&lbl_1_data_382D4,
    (u8 *)&lbl_1_data_382E0,
    (u8 *)&lbl_1_data_382EC,
    (u8 *)&lbl_1_data_382F8,
    (u8 *)&lbl_1_data_38454,
    (u8 *)&lbl_1_data_385E4,
    (u8 *)&lbl_1_data_385F4,
    (u8 *)&lbl_1_data_38604,
    (u8 *)&lbl_1_data_38614,
    (u8 *)&lbl_1_data_38624,
    (u8 *)&lbl_1_data_38874,
    (u8 *)&lbl_1_data_38958,
    (u8 *)&lbl_1_data_3896C,
    (u8 *)&lbl_1_data_38980,
    (u8 *)&lbl_1_data_38994,
    (u8 *)&lbl_1_data_389A8,
    (u8 *)&lbl_1_data_38B04,
    (u8 *)&lbl_1_data_38B58,
    (u8 *)&lbl_1_data_38B6C,
    (u8 *)&lbl_1_data_38B80,
    (u8 *)&lbl_1_data_38B94,
    (u8 *)&lbl_1_data_38BA8,
    (u8 *)&lbl_1_data_38C08,
    (u8 *)&lbl_1_data_38C30,
    (u8 *)&lbl_1_data_38C48,
    (u8 *)&lbl_1_data_38C60,
    (u8 *)&lbl_1_data_38C78,
    (u8 *)&lbl_1_data_38C90,
    (u8 *)&lbl_1_data_38CCC,
    (u8 *)&lbl_1_data_38D00,
    (u8 *)&lbl_1_data_38D10,
    (u8 *)&lbl_1_data_38D20,
    (u8 *)&lbl_1_data_38D30,
    (u8 *)&lbl_1_data_38D40,
    (u8 *)&lbl_1_data_38D80,
    (u8 *)&lbl_1_data_38D98,
    (u8 *)&lbl_1_data_38DAC,
    (u8 *)&lbl_1_data_38DC0,
    (u8 *)&lbl_1_data_38DD4,
    (u8 *)&lbl_1_data_38DE8,
    (u8 *)&lbl_1_data_38E04,
    (u8 *)&lbl_1_data_38E0C,
    (u8 *)&lbl_1_data_38E18,
    (u8 *)&lbl_1_data_38E24,
    (u8 *)&lbl_1_data_38E30,
    (u8 *)&lbl_1_data_38E3C,
    (u8 *)&lbl_1_data_38E48,
    (u8 *)&lbl_1_data_38E80,
    (u8 *)&lbl_1_data_38E90,
    (u8 *)&lbl_1_data_38EA0,
    (u8 *)&lbl_1_data_38EB0,
    (u8 *)&lbl_1_data_38EC0,
    (u8 *)&lbl_1_data_38F04,
    (u8 *)&lbl_1_data_38F30,
    (u8 *)&lbl_1_data_38F40,
    (u8 *)&lbl_1_data_38F50,
    (u8 *)&lbl_1_data_38F60,
    (u8 *)&lbl_1_data_38F70,
    (u8 *)&lbl_1_data_38FA8,
    (u8 *)&lbl_1_data_38FE8,
    (u8 *)&lbl_1_data_38FF8,
    (u8 *)&lbl_1_data_39008,
    (u8 *)&lbl_1_data_39018,
    (u8 *)&lbl_1_data_39028,
    (u8 *)&lbl_1_data_3906C,
    (u8 *)&lbl_1_data_390C4,
    (u8 *)&lbl_1_data_390D4,
    (u8 *)&lbl_1_data_390E4,
    (u8 *)&lbl_1_data_390F4,
    (u8 *)&lbl_1_data_39104,
    (u8 *)&lbl_1_data_39148,
    (u8 *)&lbl_1_data_39190,
    (u8 *)&lbl_1_data_3919C,
    (u8 *)&lbl_1_data_391A8,
    (u8 *)&lbl_1_data_391B4,
    (u8 *)&lbl_1_data_391C0,
    (u8 *)&lbl_1_data_39214,
    (u8 *)&lbl_1_data_39248,
    (u8 *)&lbl_1_data_39254,
    (u8 *)&lbl_1_data_39260,
    (u8 *)&lbl_1_data_3926C,
    (u8 *)&lbl_1_data_39278,
    (u8 *)&lbl_1_data_392AC,
    (u8 *)&lbl_1_data_392E4,
    (u8 *)&lbl_1_data_392F0,
    (u8 *)&lbl_1_data_392FC,
    (u8 *)&lbl_1_data_39308,
    (u8 *)&lbl_1_data_39314,
    (u8 *)&lbl_1_data_39348,
    (u8 *)&lbl_1_data_3937C,
    (u8 *)&lbl_1_data_39388,
    (u8 *)&lbl_1_data_39394,
    (u8 *)&lbl_1_data_393A0,
    (u8 *)&lbl_1_data_393AC,
    (u8 *)&lbl_1_data_393E0,
    (u8 *)&lbl_1_data_39418,
    (u8 *)&lbl_1_data_39424,
    (u8 *)&lbl_1_data_39430,
    (u8 *)&lbl_1_data_3943C,
    (u8 *)&lbl_1_data_39448,
    (u8 *)&lbl_1_data_3947C,
    (u8 *)&lbl_1_data_394B8,
    (u8 *)&lbl_1_data_394C8,
    (u8 *)&lbl_1_data_394D8,
    (u8 *)&lbl_1_data_394E8,
    (u8 *)&lbl_1_data_394F8,
    (u8 *)&lbl_1_data_39520,
    (u8 *)&lbl_1_data_39550,
    (u8 *)&lbl_1_data_39564,
    (u8 *)&lbl_1_data_39578,
    (u8 *)&lbl_1_data_3958C,
    (u8 *)&lbl_1_data_395A0,
    (u8 *)&lbl_1_data_395DC,
    (u8 *)&lbl_1_data_39618,
    (u8 *)&lbl_1_data_39628,
    (u8 *)&lbl_1_data_39638,
    (u8 *)&lbl_1_data_39648,
    (u8 *)&lbl_1_data_39658,
    (u8 *)&lbl_1_data_39694,
    (u8 *)&lbl_1_data_396BC,
    (u8 *)&lbl_1_data_396CC,
    (u8 *)&lbl_1_data_396DC,
    (u8 *)&lbl_1_data_396EC,
    (u8 *)&lbl_1_data_396FC,
    (u8 *)&lbl_1_data_39740,
    (u8 *)&lbl_1_data_39780,
    (u8 *)&lbl_1_data_39790,
    (u8 *)&lbl_1_data_397A0,
    (u8 *)&lbl_1_data_397B0,
    (u8 *)&lbl_1_data_397C0,
    (u8 *)&lbl_1_data_39800,
    (u8 *)&lbl_1_data_39838,
    (u8 *)&lbl_1_data_39848,
    (u8 *)&lbl_1_data_39858,
    (u8 *)&lbl_1_data_39868,
    (u8 *)&lbl_1_data_39878,
    (u8 *)&lbl_1_data_398A0,
    (u8 *)&lbl_1_data_398B0,
    (u8 *)&lbl_1_data_398C0,
    (u8 *)&lbl_1_data_398D0,
    (u8 *)&lbl_1_data_398E0,
    (u8 *)&lbl_1_data_398F0,
    (u8 *)&lbl_1_data_39900,
    (u8 *)&lbl_1_data_3990C,
    (u8 *)&lbl_1_data_3991C,
    (u8 *)&lbl_1_data_3992C,
    (u8 *)&lbl_1_data_3993C,
    (u8 *)&lbl_1_data_3994C,
    (u8 *)&lbl_1_data_39958,
    (u8 *)&lbl_1_data_39968,
    (u8 *)&lbl_1_data_39978,
    (u8 *)&lbl_1_data_39988,
    (u8 *)&lbl_1_data_39998,
    (u8 *)&lbl_1_data_399A8,
    (u8 *)&lbl_1_data_399B8,
    (u8 *)&lbl_1_data_399C8,
    (u8 *)&lbl_1_data_399D8,
    (u8 *)&lbl_1_data_399E8,
    (u8 *)&lbl_1_data_399F8,
    (u8 *)&lbl_1_data_39A08,
    (u8 *)&lbl_1_data_39A18,
    (u8 *)&lbl_1_data_39A6C,
    (u8 *)&lbl_1_data_39A78,
    (u8 *)&lbl_1_data_39A84,
    (u8 *)&lbl_1_data_39A90,
    (u8 *)&lbl_1_data_39A9C,
    (u8 *)&lbl_1_data_39B04,
    (u8 *)&lbl_1_data_39B58,
    (u8 *)&lbl_1_data_39B64,
    (u8 *)&lbl_1_data_39B70,
    (u8 *)&lbl_1_data_39B7C,
    (u8 *)&lbl_1_data_39B88,
    (u8 *)&lbl_1_data_39BF0,
    (u8 *)&lbl_1_data_39C1C,
    (u8 *)&lbl_1_data_39C2C,
    (u8 *)&lbl_1_data_39C3C,
    (u8 *)&lbl_1_data_39C4C,
    (u8 *)&lbl_1_data_39C5C,
    (u8 *)&lbl_1_data_39C88,
    (u8 *)&lbl_1_data_39CB8,
    (u8 *)&lbl_1_data_39CC8,
    (u8 *)&lbl_1_data_39CD8,
    (u8 *)&lbl_1_data_39CE8,
    (u8 *)&lbl_1_data_39CF8,
    (u8 *)&lbl_1_data_39D2C,
    (u8 *)&lbl_1_data_39DC4,
    (u8 *)&lbl_1_data_39DDC,
    (u8 *)&lbl_1_data_39DF4,
    (u8 *)&lbl_1_data_39E0C,
    (u8 *)&lbl_1_data_39E24,
    (u8 *)&lbl_1_data_39EB0,
    (u8 *)&lbl_1_data_39EF4,
    (u8 *)&lbl_1_data_39F0C,
    (u8 *)&lbl_1_data_39F24,
    (u8 *)&lbl_1_data_39F3C,
    (u8 *)&lbl_1_data_39F54,
    (u8 *)&lbl_1_data_39FA4,
    (u8 *)&lbl_1_data_3A018,
    (u8 *)&lbl_1_data_3A01C,
    (u8 *)&lbl_1_data_3A020,
    (u8 *)&lbl_1_data_3A024,
    (u8 *)&lbl_1_data_3A028,
    (u8 *)&lbl_1_data_3A0E4,
    (u8 *)&lbl_1_data_3A15C,
    (u8 *)&lbl_1_data_3A160,
    (u8 *)&lbl_1_data_3A164,
    (u8 *)&lbl_1_data_3A168,
    (u8 *)&lbl_1_data_3A16C,
    (u8 *)&lbl_1_data_3A1C8,
    (u8 *)&lbl_1_data_3A1D0,
    (u8 *)&lbl_1_data_3A1DC,
    (u8 *)&lbl_1_data_3A1E8,
    (u8 *)&lbl_1_data_3A1F4,
    (u8 *)&lbl_1_data_3A200,
    (u8 *)&lbl_1_data_3A208,
    (u8 *)&lbl_1_data_3A210,
    (u8 *)&lbl_1_data_3A21C,
    (u8 *)&lbl_1_data_3A228,
    (u8 *)&lbl_1_data_3A234,
    (u8 *)&lbl_1_data_3A240,
    (u8 *)&lbl_1_data_3A248,
    (u8 *)&lbl_1_data_3A250,
    (u8 *)&lbl_1_data_3A25C,
    (u8 *)&lbl_1_data_3A268,
    (u8 *)&lbl_1_data_3A274,
    (u8 *)&lbl_1_data_3A280,
    (u8 *)&lbl_1_data_3A28C,
    (u8 *)&lbl_1_data_3A294,
    (u8 *)&lbl_1_data_3A2A0,
    (u8 *)&lbl_1_data_3A2AC,
    (u8 *)&lbl_1_data_3A2B8,
    (u8 *)&lbl_1_data_3A2C4,
    (u8 *)&lbl_1_data_3A2D0,
    (u8 *)&lbl_1_data_3A2D8,
    (u8 *)&lbl_1_data_3A2E4,
    (u8 *)&lbl_1_data_3A2F0,
    (u8 *)&lbl_1_data_3A2FC,
    (u8 *)&lbl_1_data_3A308,
    (u8 *)&lbl_1_data_3A314,
    (u8 *)&lbl_1_data_3A31C,
    (u8 *)&lbl_1_data_3A328,
    (u8 *)&lbl_1_data_3A334,
    (u8 *)&lbl_1_data_3A340,
    (u8 *)&lbl_1_data_3A34C,
    (u8 *)&lbl_1_data_3A358,
    (u8 *)&lbl_1_data_3A360,
    (u8 *)&lbl_1_data_3A36C,
    (u8 *)&lbl_1_data_3A378,
    (u8 *)&lbl_1_data_3A384,
    (u8 *)&lbl_1_data_3A390,
    (u8 *)&lbl_1_data_3A39C,
    (u8 *)&lbl_1_data_3A3A4,
    (u8 *)&lbl_1_data_3A3B0,
    (u8 *)&lbl_1_data_3A3BC,
    (u8 *)&lbl_1_data_3A3C8,
    (u8 *)&lbl_1_data_3A3D4,
    (u8 *)&lbl_1_data_3A3DC,
    (u8 *)&lbl_1_data_3A520,
    (u8 *)&lbl_1_data_3A524,
    (u8 *)&lbl_1_data_3A528,
    (u8 *)&lbl_1_data_3A52C,
    (u8 *)&lbl_1_data_3A530,
    (u8 *)&lbl_1_data_3A6A0,
    (u8 *)&lbl_1_data_3A6E4,
    (u8 *)&lbl_1_data_3A6E8,
    (u8 *)&lbl_1_data_3A6EC,
    (u8 *)&lbl_1_data_3A6F0,
    (u8 *)&lbl_1_data_3A6F4,
    (u8 *)&lbl_1_data_3A738,
    (u8 *)&lbl_1_data_3A77C,
    (u8 *)&lbl_1_data_3A780,
    (u8 *)&lbl_1_data_3A784,
    (u8 *)&lbl_1_data_3A788,
    (u8 *)&lbl_1_data_3A78C,
    (u8 *)&lbl_1_data_3A7D4,
    (u8 *)&lbl_1_data_3A80C,
    (u8 *)&lbl_1_data_3A810,
    (u8 *)&lbl_1_data_3A814,
    (u8 *)&lbl_1_data_3A818,
    (u8 *)&lbl_1_data_3A81C,
    (u8 *)&lbl_1_data_3A874,
    (u8 *)&lbl_1_data_3A87C,
    (u8 *)&lbl_1_data_3A880,
    (u8 *)&lbl_1_data_3A884,
    (u8 *)&lbl_1_data_3A888,
    (u8 *)&lbl_1_data_3A88C,
    (u8 *)&lbl_1_data_3A894,
    (u8 *)&lbl_1_data_3A89C,
    (u8 *)&lbl_1_data_3A8A0,
    (u8 *)&lbl_1_data_3A8A4,
    (u8 *)&lbl_1_data_3A8A8,
    (u8 *)&lbl_1_data_3A8AC,
    (u8 *)&lbl_1_data_3A8B4,
    (u8 *)&lbl_1_data_3A8BC,
    (u8 *)&lbl_1_data_3A8C0,
    (u8 *)&lbl_1_data_3A8C4,
    (u8 *)&lbl_1_data_3A8C8,
    (u8 *)&lbl_1_data_3A8CC,
    (u8 *)&lbl_1_data_3A8D4,
    (u8 *)&lbl_1_data_3A8DC,
    (u8 *)&lbl_1_data_3A8E0,
    (u8 *)&lbl_1_data_3A8E4,
    (u8 *)&lbl_1_data_3A8E8,
    (u8 *)&lbl_1_data_3A8EC,
    (u8 *)&lbl_1_data_3A8F4,
    (u8 *)&lbl_1_data_3A928,
    (u8 *)&lbl_1_data_3A92C,
    (u8 *)&lbl_1_data_3A930,
    (u8 *)&lbl_1_data_3A934,
    (u8 *)&lbl_1_data_3A938,
    (u8 *)&lbl_1_data_3A98C,
    (u8 *)&lbl_1_data_3A9E0,
    (u8 *)&lbl_1_data_3A9E4,
    (u8 *)&lbl_1_data_3A9E8,
    (u8 *)&lbl_1_data_3A9EC,
    (u8 *)&lbl_1_data_3A9F0,
    (u8 *)&lbl_1_data_3AA3C,
    (u8 *)&lbl_1_data_3AA44,
    (u8 *)&lbl_1_data_3AA48,
    (u8 *)&lbl_1_data_3AA4C,
    (u8 *)&lbl_1_data_3AA50,
    (u8 *)&lbl_1_data_3AA54,
    (u8 *)&lbl_1_data_3AA60,
    (u8 *)&lbl_1_data_3AAA0,
    (u8 *)&lbl_1_data_3AAB4,
    (u8 *)&lbl_1_data_3AAC8,
    (u8 *)&lbl_1_data_3AADC,
    (u8 *)&lbl_1_data_3AAF0,
    (u8 *)&lbl_1_data_3ABCC,
    (u8 *)&lbl_1_data_3AC48,
    (u8 *)&lbl_1_data_3AC58,
    (u8 *)&lbl_1_data_3AC68,
    (u8 *)&lbl_1_data_3AC78,
    (u8 *)&lbl_1_data_3AC88,
    (u8 *)&lbl_1_data_3AD68,
    (u8 *)&lbl_1_data_3ADD8,
    (u8 *)&lbl_1_data_3ADEC,
    (u8 *)&lbl_1_data_3AE00,
    (u8 *)&lbl_1_data_3AE14,
    (u8 *)&lbl_1_data_3AE28,
    (u8 *)&lbl_1_data_3AE2C,
    (u8 *)&lbl_1_data_3AED4,
    (u8 *)&lbl_1_data_3AEE4,
    (u8 *)&lbl_1_data_3AEF4,
    (u8 *)&lbl_1_data_3AF04,
    (u8 *)&lbl_1_data_3AF14,
    (u8 *)&lbl_1_data_3AF18,
    (u8 *)&lbl_1_data_3AFC0,
    (u8 *)&lbl_1_data_3AFD0,
    (u8 *)&lbl_1_data_3AFE0,
    (u8 *)&lbl_1_data_3AFF0,
    (u8 *)&lbl_1_data_3B000,
    (u8 *)&lbl_1_data_3B0B8,
    (u8 *)&lbl_1_data_3B0E0,
    (u8 *)&lbl_1_data_3B0F0,
    (u8 *)&lbl_1_data_3B100,
    (u8 *)&lbl_1_data_3B110,
    (u8 *)&lbl_1_data_3B120,
    (u8 *)&lbl_1_data_3B150,
    (u8 *)&lbl_1_data_3B198,
    (u8 *)&lbl_1_data_3B1A8,
    (u8 *)&lbl_1_data_3B1B8,
    (u8 *)&lbl_1_data_3B1C8,
    (u8 *)&lbl_1_data_3B1D8,
    (u8 *)&lbl_1_data_3B240,
    (u8 *)&lbl_1_data_3B278,
    (u8 *)&lbl_1_data_3B288,
    (u8 *)&lbl_1_data_3B298,
    (u8 *)&lbl_1_data_3B2A8,
    (u8 *)&lbl_1_data_3B2B8,
    (u8 *)&lbl_1_data_3B300,
    (u8 *)&lbl_1_data_3B32C,
    (u8 *)&lbl_1_data_3B340,
    (u8 *)&lbl_1_data_3B354,
    (u8 *)&lbl_1_data_3B368,
    (u8 *)&lbl_1_data_3B37C,
    (u8 *)&lbl_1_data_3B3AC,
    (u8 *)&lbl_1_data_3B3C0,
    (u8 *)&lbl_1_data_3B3D0,
    (u8 *)&lbl_1_data_3B3E0,
    (u8 *)&lbl_1_data_3B3F0,
    (u8 *)&lbl_1_data_3B400,
    (u8 *)&lbl_1_data_3B40C,
    (u8 *)&lbl_1_data_3B420,
    (u8 *)&lbl_1_data_3B434,
    (u8 *)&lbl_1_data_3B448,
    (u8 *)&lbl_1_data_3B45C,
    (u8 *)&lbl_1_data_3B470,
    (u8 *)&lbl_1_data_3B490,
    (u8 *)&lbl_1_data_3B4AC,
    (u8 *)&lbl_1_data_3B4C0,
    (u8 *)&lbl_1_data_3B4D4,
    (u8 *)&lbl_1_data_3B4E8,
    (u8 *)&lbl_1_data_3B4FC,
    (u8 *)&lbl_1_data_3B520,
    (u8 *)&lbl_1_data_3B540,
    (u8 *)&lbl_1_data_3B550,
    (u8 *)&lbl_1_data_3B560,
    (u8 *)&lbl_1_data_3B570,
    (u8 *)&lbl_1_data_3B580,
    (u8 *)&lbl_1_data_3B594,
    (u8 *)&lbl_1_data_3B5C8,
    (u8 *)&lbl_1_data_3B5DC,
    (u8 *)&lbl_1_data_3B5F0,
    (u8 *)&lbl_1_data_3B604,
    (u8 *)&lbl_1_data_3B618,
    (u8 *)&lbl_1_data_3B63C,
    (u8 *)&lbl_1_data_3B64C,
    (u8 *)&lbl_1_data_3B65C,
    (u8 *)&lbl_1_data_3B66C,
    (u8 *)&lbl_1_data_3B67C,
    (u8 *)&lbl_1_data_3B68C,
    (u8 *)&lbl_1_data_3B69C,
    (u8 *)&lbl_1_data_3B6C8,
    (u8 *)&lbl_1_data_3B6DC,
    (u8 *)&lbl_1_data_3B6F0,
    (u8 *)&lbl_1_data_3B704,
    (u8 *)&lbl_1_data_3B718
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") u32 lbl_1_data_3C1E4 __attribute__((aligned(4))) = 0x00000064U;
#pragma explicit_zero_data reset
extern char lbl_1_data_3C1E8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C1E8[13] __attribute__((aligned(8))) = "MEMMODE_SAVE";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C1F8[];
extern char lbl_1_data_3C20C[];
extern char lbl_1_data_3C21C[];
extern char lbl_1_data_3C22C[];
extern char lbl_1_data_3C244[];
extern char lbl_1_data_3C254[];
extern char lbl_1_data_3C284[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C1F8[20] __attribute__((aligned(8))) = "MEMMODE_SAVE_SECTOR";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C20C[13] __attribute__((aligned(4))) = "MEMMODE_LOAD";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C21C[13] __attribute__((aligned(4))) = "MEMMODE_LIST";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C22C[22] __attribute__((aligned(4))) = "MEMMODE_LIST_AND_LOAD";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C244[15] __attribute__((aligned(4))) = "MEMMODE_DELETE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C254[14] __attribute__((aligned(4))) = "MEMMODE_CHECK";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_3C264 lbl_1_data_3C264 __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_3C1E8,
    (u8 *)&lbl_1_data_3C1F8,
    (u8 *)&lbl_1_data_3C20C,
    (u8 *)&lbl_1_data_3C21C,
    (u8 *)&lbl_1_data_3C22C,
    (u8 *)&lbl_1_data_3C244,
    (u8 *)&lbl_1_data_3C254,
    0x00000000U
};
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C284[12] __attribute__((aligned(4))) = "MEMSUB_HALT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C290[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C290[13] __attribute__((aligned(8))) = "MEMSUB_ERROR";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C2A0[];
extern char lbl_1_data_3C2B4[];
extern char lbl_1_data_3C2C4[];
extern char lbl_1_data_3C2D4[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2A0[19] __attribute__((aligned(8))) = "MEMSUB_NOSAVE_EXIT";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2B4[13] __attribute__((aligned(4))) = "MEMSUB_MOUNT";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2C4[13] __attribute__((aligned(4))) = "MEMSUB_CHECK";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2D4[20] __attribute__((aligned(4))) = "MEMSUB_FORMAT_QUERY";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C2E8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2E8[14] __attribute__((aligned(8))) = "MEMSUB_FORMAT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C2F8[];
extern char lbl_1_data_3C30C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C2F8[18] __attribute__((aligned(8))) = "MEMSUB_GET_SERIAL";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C30C[18] __attribute__((aligned(4))) = "MEMSUB_DELETE_TMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C320[];
extern char lbl_1_data_3C334[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C320[18] __attribute__((aligned(8))) = "MEMSUB_CHECK_FREE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C334[19] __attribute__((aligned(4))) = "MEMSUB_CHECK_EXIST";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C348[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C348[23] __attribute__((aligned(8))) = "MEMSUB_OVERWRITE_QUERY";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C360[];
extern char lbl_1_data_3C374[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C360[19] __attribute__((aligned(8))) = "MEMSUB_DELETE_FILE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C374[18] __attribute__((aligned(4))) = "MEMSUB_CREATE_TMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C388[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C388[16] __attribute__((aligned(8))) = "MEMSUB_GET_STAT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C398[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C398[16] __attribute__((aligned(8))) = "MEMSUB_SAVE_TMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C3A8[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C3A8[16] __attribute__((aligned(8))) = "MEMSUB_SET_STAT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C3B8[];
extern char lbl_1_data_3C3CC[];
extern char lbl_1_data_3C3DC[];
extern char lbl_1_data_3C3F4[];
extern char lbl_1_data_3C404[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C3B8[18] __attribute__((aligned(8))) = "MEMSUB_DELETE_OLD";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C3CC[14] __attribute__((aligned(4))) = "MEMSUB_RENAME";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C3DC[23] __attribute__((aligned(4))) = "MEMSUB_CHECK_FREE_LAST";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C3F4[16] __attribute__((aligned(4))) = "MEMSUB_SAVE_END";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C404[19] __attribute__((aligned(4))) = "MEMSUB_NOLOAD_EXIT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C418[];
extern char lbl_1_data_3C42C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C418[18] __attribute__((aligned(8))) = "MEMSUB_FORMAT_END";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C42C[17] __attribute__((aligned(4))) = "MEMSUB_LOAD_FILE";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C440[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C440[16] __attribute__((aligned(8))) = "MEMSUB_LOAD_END";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C450[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C450[16] __attribute__((aligned(8))) = "MEMSUB_GET_LIST";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C460[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C460[16] __attribute__((aligned(8))) = "MEMSUB_LIST_END";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C470[];
extern char lbl_1_data_3C484[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C470[19] __attribute__((aligned(8))) = "MEMSUB_NOLIST_EXIT";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C484[19] __attribute__((aligned(4))) = "MEMSUB_DELETE_NAME";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C498[];
extern char lbl_1_data_3C4AC[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C498[18] __attribute__((aligned(8))) = "MEMSUB_DELETE_END";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C4AC[18] __attribute__((aligned(4))) = "MEMSUB_NODEL_EXIT";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C4C0[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C4C0[24] __attribute__((aligned(8))) = "MEMSUB_NOFILE_CHECKFREE";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C4D8[];
extern char lbl_1_data_3C4F4[];
extern char lbl_1_data_3C50C[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C4D8[25] __attribute__((aligned(8))) = "MEMSUB_NOLOAD_EXIT_NOMSG";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C4F4[23] __attribute__((aligned(4))) = "MEMSUB_GET_LIST_MIDDLE";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C50C[17] __attribute__((aligned(4))) = "MEMSUB_CHECK_END";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C520[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C520[22] __attribute__((aligned(8))) = "MEMSUB_GET_LIST_NOBAR";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C538[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C538[23] __attribute__((aligned(8))) = "MEMSUB_SAVE_SECTOR_TMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C550[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C550[23] __attribute__((aligned(8))) = "MEMSUB_SAVE_HEADER_TMP";
#pragma explicit_zero_data reset
extern char lbl_1_data_3C568[];
extern char lbl_1_data_3C578[];

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C568[16] __attribute__((aligned(8))) = "MEMSUB_ENCODING";
#pragma explicit_zero_data reset

#pragma explicit_zero_data on
__declspec(section ".data") char lbl_1_data_3C578[17] __attribute__((aligned(8))) = "MEMSUB_ATTRIBUTE";
#pragma explicit_zero_data reset

extern void fn_1_AAEB0(void);
extern void fn_1_AAF18(void);
extern void fn_1_AAF1C(void);
extern void fn_1_AB434(void);
extern void fn_1_AB438(void);
extern void fn_1_AB458(void);
extern void fn_1_AB478(void);
extern void fn_1_AB4F4(void);
extern void fn_1_AB598(void);
extern void fn_1_AB5CC(void);
extern void fn_1_AB61C(void);
extern void fn_1_AB64C(void);
extern void fn_1_AB75C(void);
extern void fn_1_AB7C4(void);
extern void fn_1_AB870(void);
extern void fn_1_AB880(void);
extern void fn_1_AB8D8(void);
extern void fn_1_AB93C(void);
extern void fn_1_AB98C(void);
extern void fn_1_AB99C(void);
extern void fn_1_ABA14(void);
extern void fn_1_ABA24(void);
extern void fn_1_ABA9C(void);
extern void fn_1_ABAAC(void);
extern void fn_1_ABB24(void);
extern void fn_1_ABB4C(void);
extern void fn_1_ABC5C(void);
extern void fn_1_ABC98(void);
extern void fn_1_ABCE8(void);
extern void fn_1_ABD58(void);
extern void fn_1_ABDA8(void);
extern void fn_1_ABDB8(void);
extern void fn_1_ABE14(void);
extern void fn_1_ABE88(void);
extern void fn_1_ABF44(void);
extern void fn_1_AC000(void);
extern void fn_1_AC12C(void);
extern void fn_1_AC188(void);
extern void fn_1_AC294(void);
extern void fn_1_AC2D8(void);
extern void fn_1_AC328(void);
extern void fn_1_AC38C(void);
extern void fn_1_AC3DC(void);
extern void fn_1_AC464(void);
extern void fn_1_AC4B4(void);
extern void fn_1_AC4C4(void);
extern void fn_1_AC53C(void);
extern void fn_1_AC6A4(void);
extern void fn_1_AC6A8(void);
extern void fn_1_AC6C8(void);
extern void fn_1_AC6CC(void);
extern void fn_1_AC6DC(void);
extern void fn_1_AC6E0(void);
extern void fn_1_AC700(void);
extern void fn_1_AC704(void);
extern void fn_1_AC74C(void);
extern void fn_1_AC79C(void);
extern void fn_1_AC904(void);
extern void fn_1_AC908(void);
extern void fn_1_AC928(void);
extern void fn_1_AC92C(void);
extern void fn_1_AC960(void);
extern void fn_1_ACA00(void);
extern void fn_1_ACA1C(void);
extern void fn_1_ACA78(void);
extern void fn_1_ACD00(void);
extern void fn_1_ACD04(void);
extern void fn_1_ACE7C(void);
extern void fn_1_ACE80(void);
extern void fn_1_ACEBC(void);
extern void fn_1_ACF0C(void);
extern void fn_1_ACF2C(void);
extern void fn_1_ACF30(void);
extern void fn_1_AD098(void);
extern void fn_1_AD09C(void);
extern void fn_1_AD0A0(void);
extern void fn_1_AD140(void);
extern void fn_1_AD164(void);
extern void fn_1_AD168(void);
extern void fn_1_AD1AC(void);
extern void fn_1_AD1E4(void);
extern void fn_1_AD264(CardTask *a);
extern void fn_1_AEC34(void);
extern void fn_1_AECCC(void);
extern void fn_1_B03A8(void);
extern void fn_1_B03CC(void);
extern void fn_1_B1710(void);
extern void fn_1_B171C(void);
extern void fn_1_B2770(void);
extern void fn_1_B277C(void);
extern void fn_1_B38F4(void);
extern void fn_1_B3900(void);
extern void fn_1_B40B4(void);
extern void fn_1_B40C0(void);
#pragma explicit_zero_data on
__declspec(section ".data") Data_lbl_1_data_3C58C lbl_1_data_3C58C __attribute__((aligned(4))) = {
    (u8 *)&lbl_1_data_3C284,
    (u8 *)&lbl_1_data_3C290,
    (u8 *)&lbl_1_data_3C2A0,
    (u8 *)&lbl_1_data_3C2B4,
    (u8 *)&lbl_1_data_3C2C4,
    (u8 *)&lbl_1_data_3C2D4,
    (u8 *)&lbl_1_data_3C2E8,
    (u8 *)&lbl_1_data_3C2F8,
    (u8 *)&lbl_1_data_3C30C,
    (u8 *)&lbl_1_data_3C320,
    (u8 *)&lbl_1_data_3C334,
    (u8 *)&lbl_1_data_3C348,
    (u8 *)&lbl_1_data_3C360,
    (u8 *)&lbl_1_data_3C374,
    (u8 *)&lbl_1_data_3C388,
    (u8 *)&lbl_1_data_3C398,
    (u8 *)&lbl_1_data_3C3A8,
    (u8 *)&lbl_1_data_3C3B8,
    (u8 *)&lbl_1_data_3C3CC,
    (u8 *)&lbl_1_data_3C3DC,
    (u8 *)&lbl_1_data_3C3F4,
    (u8 *)&lbl_1_data_3C404,
    (u8 *)&lbl_1_data_3C418,
    (u8 *)&lbl_1_data_3C42C,
    (u8 *)&lbl_1_data_3C440,
    (u8 *)&lbl_1_data_3C450,
    (u8 *)&lbl_1_data_3C460,
    (u8 *)&lbl_1_data_3C470,
    (u8 *)&lbl_1_data_3C484,
    (u8 *)&lbl_1_data_3C498,
    (u8 *)&lbl_1_data_3C4AC,
    (u8 *)&lbl_1_data_3C4C0,
    (u8 *)&lbl_1_data_3C4D8,
    (u8 *)&lbl_1_data_3C4F4,
    (u8 *)&lbl_1_data_3C50C,
    (u8 *)&lbl_1_data_3C520,
    (u8 *)&lbl_1_data_3C538,
    (u8 *)&lbl_1_data_3C550,
    (u8 *)&lbl_1_data_3C568,
    (u8 *)&lbl_1_data_3C578,
    0x00000000U,
    fn_1_AD1E4,
    fn_1_AEC34,
    fn_1_B03A8,
    fn_1_B1710,
    fn_1_B2770,
    fn_1_B38F4,
    fn_1_B40B4,
    0x00000000U,
    (void (*)(void))fn_1_AD264,
    fn_1_AECCC,
    fn_1_B03CC,
    fn_1_B171C,
    fn_1_B277C,
    fn_1_B3900,
    fn_1_B40C0,
    0x00000000U,
    fn_1_AAEB0,
    fn_1_AAF1C,
    fn_1_AB438,
    fn_1_AB478,
    fn_1_AB598,
    fn_1_AB61C,
    fn_1_AB75C,
    fn_1_AB870,
    fn_1_AB8D8,
    fn_1_AB98C,
    fn_1_ABA9C,
    fn_1_ABB24,
    fn_1_ABC5C,
    fn_1_ABCE8,
    fn_1_ABDA8,
    fn_1_ABE14,
    fn_1_AC294,
    fn_1_AC328,
    fn_1_AC3DC,
    fn_1_AC4B4,
    fn_1_AC53C,
    fn_1_AC6A8,
    fn_1_AC6E0,
    fn_1_AC704,
    fn_1_AC79C,
    fn_1_AC92C,
    fn_1_ACA78,
    fn_1_AC908,
    fn_1_ACE80,
    fn_1_ACF30,
    fn_1_ACF0C,
    fn_1_ABA14,
    fn_1_AC6CC,
    fn_1_AD09C,
    fn_1_ACD04,
    fn_1_ACA00,
    fn_1_ABF44,
    fn_1_AC12C,
    fn_1_AD140,
    fn_1_AD168,
    0x00000000U,
    fn_1_AAF18,
    fn_1_AB434,
    fn_1_AB458,
    fn_1_AB4F4,
    fn_1_AB5CC,
    fn_1_AB64C,
    fn_1_AB7C4,
    fn_1_AB880,
    fn_1_AB93C,
    fn_1_AB99C,
    fn_1_ABAAC,
    fn_1_ABB4C,
    fn_1_ABC98,
    fn_1_ABD58,
    fn_1_ABDB8,
    fn_1_ABE88,
    fn_1_AC2D8,
    fn_1_AC38C,
    fn_1_AC464,
    fn_1_AC4C4,
    fn_1_AC6A4,
    fn_1_AC6C8,
    fn_1_AC700,
    fn_1_AC74C,
    fn_1_AC904,
    fn_1_AC960,
    fn_1_ACD00,
    fn_1_AC928,
    fn_1_ACEBC,
    fn_1_AD098,
    fn_1_ACF2C,
    fn_1_ABA24,
    fn_1_AC6DC,
    fn_1_AD0A0,
    fn_1_ACE7C,
    fn_1_ACA1C,
    fn_1_AC000,
    fn_1_AC188,
    fn_1_AD164,
    fn_1_AD1AC,
    0x00000000U
};
#pragma explicit_zero_data reset

/* Obj_1_data_3C7B8 (header) does not reproduce the retail extent; the layout follows the retail data. */


extern s32 lbl_801A66B4;
extern s16 lbl_1_bss_960;
extern const f32 lbl_1_rodata_4CA8;

extern void *fn_1_45D0(u32, u32, u32, u32);
extern void fn_1_46B4(u32, u32, const char *, int);
extern s32 CARDUnmount(s32);
extern BOOL DVDOpen(const char *, Sig_DVDOpen_DVDFileInfo *);
extern s32 DVDClose(u32);
extern s32 fn_80006354(Sig_fn_800174D0_Fn800174D0Object *, void *, u32, u32);
extern s32 fn_80083BCC(void *, void *);
extern u32 fn_80083DB0(u32, u32);
extern u32 fn_1_1563E8(u32, u32);
extern char *strcat(char *, const char *);
extern char *strncpy(char *, const char *, size_t);
extern void OSPanic(const char *, int, const char *, ...);
extern void OSReport(const char *, ...);

#pragma section code_type ".fzgxpool"
static void fzgx_string_layout(void) {
    /* fzgx-allow: S2 layout primer: MWCC emits string literals in first-use order; the section is dropped at integration */
    OSReport("memcard.c");
    OSReport(".dat");
    OSReport("F-ZERO GX");
    OSReport("./memcard/");
    OSReport("sys.bin");
    OSReport("sys_e.bin");
    OSReport("DVDOpen: cannot open.\n");
    OSReport("avDVDRead: cannot read");
    OSReport("%1d Wrong Submode.\nresult: %d\nsubmode:%s\n");
    OSReport("halt.\n");
    OSReport("result: %d\n");
    OSReport("Wrong error occured.\n");
    OSReport("Please make caption list.\n");
    OSReport(".000");
    OSReport("submode    : %d\n");
    OSReport("submode req: %d\n");
    OSReport("submode error!!\n");
}
#pragma section code_type ".text"

void fn_1_AD264(CardTask *a)
{
    s32 wait;
    s8 timer;
    char path1[0x40];
    Sig_DVDOpen_DVDFileInfo info1;
    char path2[0x40];
    Sig_DVDOpen_DVDFileInfo info2;
    char path3[0x40];
    Sig_DVDOpen_DVDFileInfo info3;
    char path4[0x40];
    Sig_DVDOpen_DVDFileInfo info4;
    char path5[0x40];
    Sig_DVDOpen_DVDFileInfo info5;

    if (a->unk_04 == 0xFF) {
        return;
    }

    switch (a->unk_04) {
    default:
        OSReport((const char *)("submode    : %d\n"), a->unk_04);
        OSReport((const char *)("submode req: %d\n"), a->unk_03);
        OSPanic((const char *)("memcard.c"), 2653, (const char *)("submode error!!\n"));
        break;

    case 1: {
        a->unk_24->unk_08 &= ~0x200;
        if (a->unk_24->unk_08 & 0x8000) {
            a->unk_03 = 2;
        } else if ((((*(u16 *)&(lbl_1_bss_9F8.unk_8)) >> 8) & 1) && (a->unk_24->unk_08 & 0x800)) {
            a->unk_03 = 12;
            a->unk_24->unk_08 &= ~0x800;
            a->unk_24->unk_08 &= ~2;
            a->unk_24->unk_08 |= 0x200;
            a->unk_2A &= ~4;
            a->unk_08 = -1;
            a->unk_0A = -1;
        } else if ((lbl_1_bss_9F8.unk_8 >> 8) & 1) {
            a->unk_03 = 2;
        } else if (((lbl_1_bss_9F8.unk_8 >> 11) & 1) && !((*(CardMgr **)&a->unk_24)->unk_08 & 2)) {
            if (a->unk_0C != 0) {
                while (CARDUnmount(a->unk_00) == -1) {
                }
                fn_1_46B4(lbl_801A6410.unk_0, (u32)a->unk_0C, (const char *)("memcard.c"), 2681);
                a->unk_07 = 0;
                a->unk_0C = 0;
                {
                    CardMgr *mgr = a->unk_24;
                    mgr->unk_18 = 0;
                }
            }
            a->unk_03 = 3;
            a->unk_08 = -1;
            a->unk_0A = -1;
            a->unk_2A &= ~4;
            if (a->unk_24->unk_00 == 1) {
                s16 mode = lbl_1_bss_960;
                if (mode != 10 && mode != 3 && mode != 1) {
                    a->unk_24->unk_08 |= 0x2000;
                    a->unk_24->unk_08 |= 4;
                    lbl_1_bss_718B1 = 0;
                } else {
                    if (mode != 1) {
                        a->unk_24->unk_08 &= ~0x4000;
                        a->unk_24->unk_08 &= ~4;
                    } else {
                        a->unk_24->unk_08 |= 0x4000;
                        a->unk_24->unk_08 |= 4;
                    }
                    a->unk_24->unk_08 &= ~0x2000;
                    lbl_1_bss_718B1 = 0;
                }
            } else {
                CardTask *base = &lbl_1_bss_716C8[0];

                if (a == base) {
                    lbl_1_bss_718B1 = 0;
                } else if (a == base + 1) {
                    lbl_1_bss_718B1 = 1;
                }
            }
        } else if (((*(volatile u16 *)&lbl_1_bss_9F8.unk_8 /* Retail reloads this field. */ >> 10) & 1) && ((*(volatile CardMgr **)&a->unk_24 /* Retail reloads this field. */)->unk_08 & 0x400)) {
            a->unk_03 = 5;
            a->unk_24->unk_08 &= ~0x400;
            a->unk_24->unk_08 |= 0x200;
            a->unk_2A &= ~4;
            a->unk_2A |= 0x10;
        }
        lbl_1_bss_772C8__fzgx_offset_41 = 0;
        break;
    }

    case 2:
        if (a->unk_24->unk_08 & 0x8000) {
            a->unk_02 = 0xFE;
            break;
        }
        if (((lbl_1_bss_9F8.unk_8 >> 8) & 1)) {
            a->unk_02 = 0xFE;
        }
        break;

    case 3:
        if ((s8)a->unk_01 == -127) {
            a->unk_24->unk_04 = (s8)a->unk_01;
            a->unk_03 = 1;
            break;
        }
        switch (a->unk_24->unk_04) {
        case -128:
        case -5:
        case -3:
        case -2:
            a->unk_03 = 1;
            a->unk_06 = 3;
            break;
        case -13:
            if (a->unk_24->unk_08 & 0x8000) {
                a->unk_2A |= 4;
                a->unk_02 = 0xFE;
                break;
            }
            if (lbl_801A66B4 == 5) {
                a->unk_03 = 5;
                break;
            }
            a->unk_24->unk_08 |= 0x400;
            a->unk_03 = 1;
            break;
        case -6:
        case 0:
            a->unk_03 = 4;
            break;
        case -1:
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 38:
        a->unk_03 = 3;
        break;

    case 4:
        switch (a->unk_24->unk_04) {
        case -128:
        case -5:
        case -3:
            a->unk_03 = 1;
            break;
        case -6:
            if (a->unk_24->unk_08 & 0x8000) {
                a->unk_2A |= 4;
                a->unk_02 = 0xFE;
                break;
            }
            a->unk_03 = 5;
            break;
        case -13:
            if (a->unk_24->unk_08 & 0x8000) {
                a->unk_2A |= 4;
                a->unk_02 = 0xFE;
                break;
            }
            if (lbl_801A66B4 == 5) {
                a->unk_03 = 5;
                break;
            }
            a->unk_24->unk_08 |= 0x400;
            a->unk_03 = 1;
            break;
        case 0:
            a->unk_03 = 7;
            break;
        case -1:
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 5:
        if (a->unk_24->unk_04 == 0) {
            break;
        }
        if (!(a->unk_2A & 1)) {
            a->unk_28 = 12;
            a->unk_2A |= 1;
            wait = 0;
        } else {
            timer = a->unk_28;
            if (timer > 0) {
                a->unk_28 = timer - 1;
                wait = 0;
            } else {
                wait = 1;
            }
        }
        if (wait == 0) {
            break;
        }
        if (a->unk_24->unk_04 == 2 || a->unk_24->unk_01 == 1) {
            a->unk_24->unk_04 = -126;
            a->unk_03 = 1;
            break;
        }
        a->unk_03 = 6;
        a->unk_24->unk_08 |= 0x200;
        break;

    case 6:
        switch (a->unk_24->unk_04) {
        case -128:
        case -5:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 7;
            a->unk_24->unk_08 &= ~0x200;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 7: {
        CardMgr *m = a->unk_24;
        switch (m->unk_04) {
        case -128:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            if (m->unk_00 == 1) {
                u8 *buf;
                if (a->unk_24->unk_08 & 0x10000) {
                    buf = m->unk_94;
                    *(u16 *)(buf + 0x2200) = m->unk_18;
                    m = (*(CardMgr * *)&(a->unk_24));
                    *(u16 *)(buf + 0x7580) = m->unk_18 >> 16;
                    m = (*(CardMgr * *)&(a->unk_24));
                    *(u16 *)(buf + 0x2060) = m->unk_18 >> 32;
                    m = (*(CardMgr * *)&(a->unk_24));
                    *(u16 *)(buf + 0x2066) = m->unk_18 >> 48;
                    lbl_1_bss_718E0.unk_1A0 = *(u16 *)(buf + 0x2200);
                    lbl_1_bss_718E0.unk_5520 = *(u16 *)(buf + 0x7580);
                    lbl_1_bss_718E0.unk_0 = *(u16 *)(buf + 0x2060);
                    lbl_1_bss_718E0.unk_6 = *(u16 *)(buf + 0x2066);
                    a->unk_50 = 1;
                    a->unk_48 = a->unk_24->unk_18;
                    lbl_1_bss_7730A = a->unk_00;
                }
                if (a->unk_50 != 0) {
                    CardMgr *m = a->unk_24;
                    if (a->unk_48 == m->unk_18) {
                        a->unk_03 = 8;
                    } else {
                        m->unk_04 = -119;
                        a->unk_03 = 1;
                    }
                } else {
                    a->unk_24->unk_04 = -119;
                    a->unk_03 = 1;
                }
            } else {
                a->unk_03 = 8;
            }
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;
    }

    case 8:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -10:
        case -3:
            a->unk_03 = 1;
            break;
        case -4:
        case 0:
            a->unk_03 = 9;
            break;
        case -1:
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 9:
        switch (a->unk_24->unk_04) {
        case -128:
        case -6:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            if (a->unk_24->unk_08 & 0x1000) {
                char *tmp;
                u8 *p98;
                u8 *pBC;
                pBC = a->unk_24->unk_BC;
                p98 = a->unk_24->unk_98;
                tmp = fn_1_45D0(lbl_801A6410.unk_0, 0x20, (u32)("memcard.c"), 499);
                strncpy(tmp, (const char *)p98, 0x20);
                strncpy((char *)p98, (const char *)pBC, 0x20);
                strncpy((char *)pBC, tmp, 0x20);
                fn_1_46B4(lbl_801A6410.unk_0, (u32)tmp, (const char *)("memcard.c"), 503);
            }
            a->unk_03 = 10;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 10:
        switch (a->unk_24->unk_04) {
        case -128:
        case -10:
        case -6:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case -4:
            if (a->unk_24->unk_14 == 0) {
                a->unk_24->unk_04 = -8;
                a->unk_03 = 1;
                break;
            }
            if (a->unk_24->unk_10 < a->unk_24->unk_0C) {
                a->unk_24->unk_04 = -9;
                a->unk_03 = 1;
                break;
            }
            a->unk_03 = 13;
            {
                GhostFileNode *node = a->unk_24->unk_8C;
                a->unk_24->unk_94[2] = a->unk_24->unk_00;
                a->unk_24->unk_94[3] = node->unk_3E;
                strncpy((char *)a->unk_24->unk_94 + 4, (const char *)("F-ZERO GX"), 0x20);
                fn_80083DB0((u32)path1, (u32)("./memcard/"));
                if (lbl_801A66B4 != 5 && fn_80083BCC(node->unk_20, (void *)("sys.bin")) == 0) {
                    strcat(path1, (const char *)("sys_e.bin"));
                } else {
                    strcat(path1, node->unk_20);
                }
                if (!DVDOpen(path1, &info1)) {
                    OSPanic((const char *)("memcard.c"), 1290, (const char *)("DVDOpen: cannot open.\n"));
                }
                if (a->unk_24->unk_08 & 0x20) {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info1, a->unk_24->unk_94 + 0x1860, 0x800, 0x1800) == 0) {
                        OSPanic((const char *)("memcard.c"), 1295, (const char *)("avDVDRead: cannot read"));
                    }
                } else {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info1, a->unk_24->unk_94 + 0x60, 0x2000, 0) == 0) {
                        OSPanic((const char *)("memcard.c"), 1299, (const char *)("avDVDRead: cannot read"));
                    }
                }
                DVDClose((u32)&info1);
                a->unk_24->unk_08 |= 0x200;
            }
            break;
        case 0:
            if ((a->unk_24->unk_08 & 4) || (a->unk_24->unk_08 & 0x4000)) {
                if (a->unk_24->unk_10 < a->unk_24->unk_0C || a->unk_24->unk_14 == 0) {
                    a->unk_03 = 12;
                    break;
                }
                a->unk_03 = 13;
                {
                    GhostFileNode *node = a->unk_24->unk_8C;
                    a->unk_24->unk_94[2] = a->unk_24->unk_00;
                    a->unk_24->unk_94[3] = node->unk_3E;
                    strncpy((char *)a->unk_24->unk_94 + 4, (const char *)("F-ZERO GX"), 0x20);
                    fn_80083DB0((u32)path2, (u32)("./memcard/"));
                    if (lbl_801A66B4 != 5 && fn_80083BCC(node->unk_20, (void *)("sys.bin")) == 0) {
                        strcat(path2, (const char *)("sys_e.bin"));
                    } else {
                        strcat(path2, node->unk_20);
                    }
                    if (!DVDOpen(path2, &info2)) {
                        OSPanic((const char *)("memcard.c"), 1290, (const char *)("DVDOpen: cannot open.\n"));
                    }
                    if (a->unk_24->unk_08 & 0x20) {
                        if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info2, a->unk_24->unk_94 + 0x1860, 0x800, 0x1800) == 0) {
                            OSPanic((const char *)("memcard.c"), 1295, (const char *)("avDVDRead: cannot read"));
                        }
                    } else {
                        if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info2, a->unk_24->unk_94 + 0x60, 0x2000, 0) == 0) {
                            OSPanic((const char *)("memcard.c"), 1299, (const char *)("avDVDRead: cannot read"));
                        }
                    }
                    DVDClose((u32)&info2);
                    a->unk_24->unk_08 |= 0x200;
                }
                break;
            }
            a->unk_03 = 11;
            break;
        case -5:
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 11:
        if (a->unk_24->unk_04 == 0) {
            break;
        }
        if (!(a->unk_2A & 1)) {
            a->unk_28 = 12;
            a->unk_2A |= 1;
            wait = 0;
        } else {
            timer = a->unk_28;
            if (timer > 0) {
                a->unk_28 = timer - 1;
                wait = 0;
            } else {
                wait = 1;
            }
        }
        if (wait == 0) {
            break;
        }
        if (a->unk_24->unk_04 == 2 || a->unk_24->unk_01 == 1) {
            a->unk_24->unk_04 = -125;
            a->unk_03 = 1;
            break;
        }
        if (a->unk_24->unk_10 < a->unk_24->unk_0C || a->unk_24->unk_14 == 0) {
            a->unk_03 = 12;
            break;
        }
        if (a->unk_24->unk_08 & 0x1000) {
            a->unk_03 = 13;
            {
                GhostFileNode *node = a->unk_24->unk_8C;
                a->unk_24->unk_94[2] = a->unk_24->unk_00;
                a->unk_24->unk_94[3] = node->unk_3E;
                strncpy((char *)a->unk_24->unk_94 + 4, (const char *)("F-ZERO GX"), 0x20);
                fn_80083DB0((u32)path3, (u32)("./memcard/"));
                if (lbl_801A66B4 != 5 && fn_80083BCC(node->unk_20, (void *)("sys.bin")) == 0) {
                    strcat(path3, (const char *)("sys_e.bin"));
                } else {
                    strcat(path3, node->unk_20);
                }
                if (!DVDOpen(path3, &info3)) {
                    OSPanic((const char *)("memcard.c"), 1290, (const char *)("DVDOpen: cannot open.\n"));
                }
                if (a->unk_24->unk_08 & 0x20) {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info3, a->unk_24->unk_94 + 0x1860, 0x800, 0x1800) == 0) {
                        OSPanic((const char *)("memcard.c"), 1295, (const char *)("avDVDRead: cannot read"));
                    }
                } else {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info3, a->unk_24->unk_94 + 0x60, 0x2000, 0) == 0) {
                        OSPanic((const char *)("memcard.c"), 1299, (const char *)("avDVDRead: cannot read"));
                    }
                }
                DVDClose((u32)&info3);
                a->unk_24->unk_08 |= 0x200;
            }
        } else {
            a->unk_03 = 13;
            {
                GhostFileNode *node = a->unk_24->unk_8C;
                a->unk_24->unk_94[2] = a->unk_24->unk_00;
                a->unk_24->unk_94[3] = node->unk_3E;
                strncpy((char *)a->unk_24->unk_94 + 4, (const char *)("F-ZERO GX"), 0x20);
                fn_80083DB0((u32)path4, (u32)("./memcard/"));
                if (lbl_801A66B4 != 5 && fn_80083BCC(node->unk_20, (void *)("sys.bin")) == 0) {
                    strcat(path4, (const char *)("sys_e.bin"));
                } else {
                    strcat(path4, node->unk_20);
                }
                if (!DVDOpen(path4, &info4)) {
                    OSPanic((const char *)("memcard.c"), 1290, (const char *)("DVDOpen: cannot open.\n"));
                }
                if (a->unk_24->unk_08 & 0x20) {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info4, a->unk_24->unk_94 + 0x1860, 0x800, 0x1800) == 0) {
                        OSPanic((const char *)("memcard.c"), 1295, (const char *)("avDVDRead: cannot read"));
                    }
                } else {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info4, a->unk_24->unk_94 + 0x60, 0x2000, 0) == 0) {
                        OSPanic((const char *)("memcard.c"), 1299, (const char *)("avDVDRead: cannot read"));
                    }
                }
                DVDClose((u32)&info4);
                a->unk_24->unk_08 |= 0x200;
            }
        }
        break;

    case 12:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -10:
        case -4:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 13;
            {
                GhostFileNode *node = a->unk_24->unk_8C;
                a->unk_24->unk_94[2] = a->unk_24->unk_00;
                a->unk_24->unk_94[3] = node->unk_3E;
                strncpy((char *)a->unk_24->unk_94 + 4, (const char *)("F-ZERO GX"), 0x20);
                fn_80083DB0((u32)path5, (u32)("./memcard/"));
                if (lbl_801A66B4 != 5 && fn_80083BCC(node->unk_20, (void *)("sys.bin")) == 0) {
                    strcat(path5, (const char *)("sys_e.bin"));
                } else {
                    strcat(path5, node->unk_20);
                }
                if (!DVDOpen(path5, &info5)) {
                    OSPanic((const char *)("memcard.c"), 1290, (const char *)("DVDOpen: cannot open.\n"));
                }
                if (a->unk_24->unk_08 & 0x20) {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info5, a->unk_24->unk_94 + 0x1860, 0x800, 0x1800) == 0) {
                        OSPanic((const char *)("memcard.c"), 1295, (const char *)("avDVDRead: cannot read"));
                    }
                } else {
                    if (fn_80006354((Sig_fn_800174D0_Fn800174D0Object *)&info5, a->unk_24->unk_94 + 0x60, 0x2000, 0) == 0) {
                        OSPanic((const char *)("memcard.c"), 1299, (const char *)("avDVDRead: cannot read"));
                    }
                }
                DVDClose((u32)&info5);
                a->unk_24->unk_08 |= 0x200;
            }
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 13:
        switch (a->unk_24->unk_04) {
        case -128:
        case -12:
        case -9:
        case -8:
        case -7:
        case -5:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 39;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 39:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -12:
        case -9:
        case -8:
        case -7:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 14;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 14:
        switch (a->unk_24->unk_04) {
        case -128:
        case -10:
        case -4:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_24->unk_58 = (u32)(a->unk_24->unk_94 + 4) - (u32)a->unk_24->unk_94;
            a->unk_24->unk_4E = (a->unk_24->unk_4E & ~3) | 2;
            a->unk_24->unk_50 = (u32)(a->unk_24->unk_94 + 0x60) - (u32)a->unk_24->unk_94;
            a->unk_24->unk_54 = (a->unk_24->unk_54 & ~3) | 2;
            a->unk_24->unk_56 = (a->unk_24->unk_56 & ~3) | 3;
            a->unk_24->unk_56 &= ~0xC;
            a->unk_24->unk_4E &= ~4;
            *(u16 *)a->unk_24->unk_94 = (u16)fn_1_1563E8((u32)(a->unk_24->unk_94 + 2), a->unk_24->unk_0C - 2);
            a->unk_03 = 15;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 15:
        {
    CardMgr * fzgx_live = a->unk_24;
switch (fzgx_live->unk_04) {
        case -5:
            fzgx_live->unk_08 |= 2;
        case -128:
        case -14:
        case -11:
        case -10:
        case -4:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 16;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
}
        break;

    case 16:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -10:
        case -4:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            if (a->unk_24->unk_08 & 0x1000) {
                char *tmp;
                u8 *p98;
                u8 *pBC;
                a->unk_03 = 17;
                pBC = a->unk_24->unk_BC;
                p98 = a->unk_24->unk_98;
                tmp = fn_1_45D0(lbl_801A6410.unk_0, 0x20, (u32)("memcard.c"), 499);
                strncpy(tmp, (const char *)p98, 0x20);
                strncpy((char *)p98, (const char *)pBC, 0x20);
                strncpy((char *)pBC, tmp, 0x20);
                fn_1_46B4(lbl_801A6410.unk_0, (u32)tmp, (const char *)("memcard.c"), 503);
            } else {
                a->unk_03 = 17;
            }
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 17:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -10:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case -4:
        case 0:
            if (a->unk_24->unk_08 & 0x1000) {
                char *tmp;
                u8 *p98;
                u8 *pBC;
                pBC = a->unk_24->unk_BC;
                p98 = a->unk_24->unk_98;
                tmp = fn_1_45D0(lbl_801A6410.unk_0, 0x20, (u32)("memcard.c"), 499);
                strncpy(tmp, (const char *)p98, 0x20);
                strncpy((char *)p98, (const char *)pBC, 0x20);
                strncpy((char *)pBC, tmp, 0x20);
                fn_1_46B4(lbl_801A6410.unk_0, (u32)tmp, (const char *)("memcard.c"), 503);
                a->unk_03 = 18;
                a->unk_24->unk_08 &= ~0x200;
            } else {
                a->unk_03 = 18;
            }
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 18:
        switch (a->unk_24->unk_04) {
        case -5:
            a->unk_24->unk_08 |= 2;
        case -128:
        case -12:
        case -10:
        case -7:
        case -4:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 19;
            a->unk_24->unk_08 &= ~0x200;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 19:
        switch (a->unk_24->unk_04) {
        case -128:
        case -6:
        case -3:
            a->unk_03 = 1;
            break;
        case -1:
            break;
        case 0:
            a->unk_03 = 20;
            break;
        default:
            a->unk_03 = 0;
            break;
        }
        break;

    case 20:
        if (a->unk_24->unk_08 & 4) {
            if (!(a->unk_24->unk_08 & 8)) {
                a->unk_28 = 45;
                a->unk_24->unk_08 |= 8;
                wait = 0;
            } else {
                timer = a->unk_28;
                if (timer > 0) {
                    a->unk_28 = timer - 1;
                    wait = 0;
                } else {
                    wait = 1;
                }
            }
            if (wait == 0) {
                break;
            }
            ((lbl_1_bss_718B4)) /* Retail stores before the call reload. */ = a->unk_24->unk_04;
            fn_1_46B4(lbl_801A6410.unk_0, (u32)(*(CardMgr * *)&(a->unk_24)), (const char *)("memcard.c"), 1004);
            a->unk_24 = 0;
            a->unk_02 = 0xFF;
            a->unk_03 = 0xFF;
            a->unk_04 = 0xFF;
            a->unk_05 = 0xFF;
            a->unk_06 = 0xFF;
            a->unk_07 = 0;
            a->unk_08 = -1;
            a->unk_0A = -1;
            a->unk_30 = 0;
            a->unk_34 = (0.0f);
            a->unk_38 = (0.0f);
            a->unk_2A &= ~4;
            lbl_1_bss_772C8 = 0;
            lbl_1_bss_718B8 = 1;
        } else if (((lbl_1_bss_9F8.unk_8 >> 8) & 1)) {
            ((lbl_1_bss_718B4)) /* Retail stores before the call reload. */ = a->unk_24->unk_04;
            fn_1_46B4(lbl_801A6410.unk_0, (u32)(*(CardMgr * volatile *)&(a->unk_24)) /* Retail reloads after the store. */, (const char *)("memcard.c"), 1004);
            a->unk_24 = 0;
            a->unk_02 = 0xFF;
            a->unk_03 = 0xFF;
            a->unk_04 = 0xFF;
            a->unk_05 = 0xFF;
            a->unk_06 = 0xFF;
            a->unk_07 = 0;
            a->unk_08 = -1;
            a->unk_0A = -1;
            a->unk_30 = 0;
            a->unk_34 = (0.0f);
            a->unk_38 = (0.0f);
            a->unk_2A &= ~4;
            lbl_1_bss_772C8 = 0;
            lbl_1_bss_718B8 = 1;
        }
        break;

    }

    if (a->unk_24 != 0) {
        lbl_1_bss_718B4 = a->unk_24->unk_04;
    }
}
