#include "types.h"
#include "rel/title/globals.h"
#include "rel/title/operation.h"
extern u8 lbl_1_bss_38460[0x54];
extern s16 lbl_1_bss_96A;
extern u16 lbl_1_bss_9F8[];
extern u8 lbl_1_data_1E5C0[0x34];
extern u8 lbl_1_rodata_26F8[0x58];
extern u32 lbl_801A6410;
extern s32 lbl_801A66A0;
extern s32 lbl_801A66B4;
extern f32 lbl_8_rodata_160[10];
extern f32 lbl_8_rodata_198;
extern u8 lbl_8_rodata_408[0x8];
extern u32 fn_1_412A0(u32);
extern u32 fn_1_3EB78(u32, u32, u32, u32);
extern u32 fn_1_3ED8C(u32, u32, u32, u32, u32, u32, u32);
extern void fn_8_663C(void);
extern void fn_1_3EF08(u8);
extern void fn_1_3EF8C(u8);
extern void fn_1_3EFF0(u32, u8);
extern void fn_1_3F02C(u32);
extern f32 lbl_8006D0B4(f32);
extern u8 lbl_8_data_9AB8[0x18];
extern void fn_8_C9A8(s32, s32, f32);
extern void GXGetProjectionv(f32 *);
extern void C_MTXOrtho(f32 (*)[4], f32, f32, f32, f32, f32, f32);
extern void fn_800737E4(f32 (*)[4], s32);
extern void fn_80072270(f32 *);
extern void fn_1_56000(s32, s32, s32);
extern void fn_1_14DE80(void *, void **, void **, s32, f32);
extern void lbl_8006DAEC(void);
extern void fn_1_14E054(void *, void *, s32, f32);
extern void lbl_8006DBE4(void);
extern void fn_1_14E198(void *, void *, s32, f32);
extern void lbl_8006DC20(void);
extern f32 lbl_8_rodata_2FC[27];
extern u32 fn_800371F8(u32, void *);
extern void fn_8003462C(u32, u32, u32);
extern void fn_8007245C(u32);
extern void fn_80072864(u32);
extern void fn_800728A8(s32, s32, s32, s32);
extern void fn_80072AB0(s32, s32, s32);
extern void fn_80072C24(s32, s32, s32, s32, s32);
extern void fn_80072CC4(u32, u32, u32, u32, u32);
extern void fn_80072D64(u32, u32, u32, u32, u32, u32);
extern void fn_80072E20(s32, s32, s32, s32, u8, s32);
extern void fn_800734A8(u32, s32, s32, s32);
extern void fn_80073678(u32);
extern void fn_80073C6C(s32);
extern void fn_80074660(u32);
extern void fn_80074788(u32);
extern void fn_800747D0(u32, u32, u32, u32, u32, u32, u32);
extern void fn_80074918(u8, s32, u8);
extern void fn_1_4965C(u8);
extern f32 lbl_8006D188(u32);
extern void fn_1_55FF0(f32);
extern u32 fn_1_D0790(void);
extern int fn_8_CF58(void);
extern int fn_8_CF60(void);
extern int fn_8_CF68(void);
extern s32 fn_8_CF70(void);
extern char lbl_8_data_A0C4[];
extern char lbl_8_data_A174[];
extern char lbl_8_data_A178[];
extern char lbl_8_data_A17C[];
extern char lbl_8_data_A180[];
extern char lbl_8_data_A184[];
extern s32 fn_1_1555B0(s32);
extern void fn_1_14A1AC(u8);
extern void fn_1_14BC40(void);
extern void fn_1_1554D0(void);
extern void fn_1_14BCBC(void *, u32);
extern u32 fn_1_144F40(u32, void *);
extern void fn_8_D020(void);
extern u32 lbl_8_rodata_C24;
extern u32 lbl_8_rodata_C28;
extern s32 fn_1_14CEB8(u32);

typedef signed char fn_8_E440_s8;

typedef signed long fn_8_E440_s32;

typedef unsigned char fn_8_E440_u8;
typedef unsigned short fn_8_E440_u16;
typedef unsigned long fn_8_E440_u32;

typedef double fn_8_E440_f64;

typedef unsigned long fn_8_E440_size_t;

/* lbl_10_bss_55CD8: .bss size 0x4, 5 refs from sel.c */
typedef struct {
fn_8_E440_u32 unk_0; /* 12 loads, 7 stores */
fn_8_E440_u32 unk_4; /* 1 loads, 1 stores */
fn_8_E440_u32 unk_8; /* 5 loads, 1 stores */
fn_8_E440_u8 unk_C; /* 8 loads, 1 stores */
fn_8_E440_u8 unk_D; /* 5 loads, 4 stores */
fn_8_E440_u8 unk_E; /* 10 loads, 4 stores */
fn_8_E440_u8 unk_F; /* 3 loads, 12 stores */
fn_8_E440_u8 unk_10; /* 1 loads, 0 stores */
fn_8_E440_u8 unk_11; /* 2 loads, 1 stores */
fn_8_E440_u16 unk_12; /* 3 loads, 3 stores */
fn_8_E440_u8 unk_14; /* 2 loads, 2 stores */
fn_8_E440_u8 unk_15; /* 2 loads, 2 stores */
fn_8_E440_u8 unk_16; /* 2 loads, 2 stores */
fn_8_E440_u8 unk_17; /* 2 loads, 2 stores */
fn_8_E440_u32 unk_18; /* 1 loads, 1 stores */
fn_8_E440_u32 unk_1C; /* 1 loads, 1 stores */
fn_8_E440_u32 unk_20; /* 3 loads, 2 stores */
fn_8_E440_u8 pad_24[0x4];
fn_8_E440_u8 unk_28; /* 2 loads, 0 stores */
fn_8_E440_u8 pad_29[0xD];
fn_8_E440_u8 unk_36; /* 2 loads, 1 stores */
fn_8_E440_u8 unk_37; /* 0 loads, 1 stores */
fn_8_E440_u8 pad_38[0x2];
fn_8_E440_u8 unk_3A; /* 2 loads, 2 stores */
fn_8_E440_u8 unk_3B; /* 5 loads, 2 stores */
fn_8_E440_u32 unk_3C; /* 4 loads, 2 stores */
} Obj_10_bss_55CD8_Target;





extern fn_8_E440_u8 lbl_8_bss_555;
extern char *strncpy(char *, const char *, fn_8_E440_size_t);
extern fn_8_E440_s32 strncmp(const char *, const char *, fn_8_E440_size_t);

extern const fn_8_E440_f64 lbl_8_rodata_B68;
extern const fn_8_E440_u32 lbl_8_rodata_B60;
extern void *fn_1_45D0(fn_8_E440_u32, fn_8_E440_u32, fn_8_E440_u8 *, fn_8_E440_u32);
extern void fn_1_435C(fn_8_E440_u32);
extern fn_8_E440_s32 fn_1_3F8C(fn_8_E440_u32, fn_8_E440_u32, fn_8_E440_u32, fn_8_E440_u32);
extern void fn_8_D630(void);


extern fn_8_E440_u8 lbl_1_bss_A48[];


extern void fn_1_A2D84(fn_8_E440_u32);
typedef struct { fn_8_E440_u8 r, g, b, a; } MenuColor;
typedef struct {
fn_8_E440_u16 cur;
fn_8_E440_u16 max;
fn_8_E440_u8 *p4;
fn_8_E440_u8 *p8;
fn_8_E440_u8 *pC;
fn_8_E440_u32 pad;
} MenuEntry;
#pragma opt_common_subs off
void fn_8_E440(void) {
fn_8_E440_u8 *p;
void *rp;
fn_8_E440_u8 *q;
fn_8_E440_u32 cnt;
fn_8_E440_s32 flA;
fn_8_E440_s32 flB;
fn_8_E440_s32 flC;
fn_8_E440_u8 buf[2];
fn_8_E440_s32 i;
fn_8_E440_u16 *repeat;
fn_8_E440_u16 *held;
Obj_10_bss_55CD8_Target *state;
fn_8_E440_u8 *t8;
MenuEntry *e;
fn_8_E440_s32 inputIndex;
Obj_10_bss_55CD8_Target *active;
Obj_10_bss_55CD8_Target **inputRef;
fn_8_E440_s32 prev;
fn_8_E440_u8 *alternate;
MenuColor v68;
p = (*(fn_8_E440_u8 (*)[0xA0])&lbl_8_data_A1E8);
flA = 0;
flB = 0;
flC = 0;
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_0 >> 31) {
if (lbl_8_bss_555 == 0) {
goto end; /* matches retail's single early-exit block */
}
}
state = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550);
e = (MenuEntry *)state->unk_3C + state->unk_D;
t8 = (*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 8;
if ((((fn_8_E440_u16 *)t8)[state->unk_C * 10] >> 12) & 1) {
if (e->cur == e->max - 1) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_0 |= 0x20000000;
fn_1_A2D84(0xA9010F00);
} else {
MenuEntry *z;
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
z = (MenuEntry *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_3C;
for (i = 0; i < (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_3B; i++) {
z->cur = z->max - 1;
z++;
}
fn_1_A2D84(0xA9010F00);
}
} else if (((((fn_8_E440_u16 *)t8)[state->unk_C * 10] >> 8) & 1) && lbl_8_bss_555 == 0) {
fn_8_E440_s32 cur = e->cur;
if (cur == e->max - 1) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_0 |= 0x20000000;
fn_1_A2D84(0xA9010F00);
} else {
cnt = (fn_8_E440_u8)(state->unk_E);
flA = 1;
if (cnt == 7 && state->unk_36 != 0) {
flB = 1;
}
{
switch (state->unk_F) {
case 0: q = e->p4 + cur * 2; break;
case 1: q = e->p8 + cur * 2; break;
case 2: q = e->pC + cur * 2; break;
}
}
strncpy((char *)buf, (char *)q, 2);
if (strncmp((char *)q, (char *)(p + 0xb4), 2) == 0) {
strncpy((char *)((fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_E * 2 + 0x28), (char *)(p + 0xb0), 2);
} else {
strncpy((char *)((fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_E * 2 + 0x28), (char *)q, 2);
}
{
Obj_10_bss_55CD8_Target **advanceRef = &(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550);
Obj_10_bss_55CD8_Target *advance = *advanceRef;
if (advance->unk_E < 7) {
advance->unk_E = advance->unk_E + 1;
} else {
MenuEntry *z;
fn_8_E440_s32 j;
z = (MenuEntry *)advance->unk_3C;
for (j = 0; j < (*advanceRef)->unk_3B; j++) {
z->cur = z->max - 1;
z++;
}
}
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
}
} else if (((((fn_8_E440_u16 *)t8) [(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 9) & 1) && lbl_8_bss_555 == 0) {
fn_8_E440_u32 pos;
state = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550);
pos = state->unk_E;
flB = pos != 0;
if (pos == 7 && state->unk_36 != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_36 = 0;
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_37 = 0;
} else {
if (pos != 0) {
state->unk_E = state->unk_E - 1;
}
for (i = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_E; i <= 7; i++) {
if (i < 7) {
fn_8_E440_u8 *shift = (fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + i * 2;
shift[0x28] = shift[0x2a];
shift = (fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + i * 2;
shift[0x29] = shift[0x2b];
} else {
*((fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + i * 2 + 0x28) = 0;
*((fn_8_E440_u8 *)(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550) + i * 2 + 0x29) = 0;
}
}
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
cnt = (fn_8_E440_u8)((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_E);
} else {
held = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x10);
if (((held[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 3) & 1) || (((repeat = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12), repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10]) >> 3) & 1)) {
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D == 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_3B - 1;
} else {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D - 1;
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if (((held[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 2) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 2) & 1)) {
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D == (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_3B - 1) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D = 0;
} else {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_D + 1;
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if ((held[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] & 1) || (repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 8) & 1)) {
if (e->cur == 0) {
e->cur = e->max - 1;
} else {
e->cur = e->cur - 1;
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if (((held[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 1) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 1) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 9) & 1)) {
if (e->cur == e->max - 1) {
e->cur = 0;
} else {
e->cur = e->cur + 1;
}
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if ((((fn_8_E440_u16 *)t8)[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 11) & 1) {
flC = 1;
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F + 1;
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F > 2) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F == 1) {
alternate = e->p8;
if (alternate == 0) {
flC = 0;
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if (strncmp((char *)(alternate + e->cur * 2), (char *)(p + 0xb0), 2) == 0) {
flC = 0;
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
}
} else if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F == 2) {
alternate = e->pC;
if (alternate == 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
} else if (strncmp((char *)(alternate + e->cur * 2), (char *)(p + 0xb0), 2) == 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_F = 0;
}
}
}
}
{
register Obj_10_bss_55CD8_Target **ref = &(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550);
/* Observe the shared state pointer independently before this update stage. */
Obj_10_bss_55CD8_Target *before = *(Obj_10_bss_55CD8_Target **)ref;
Obj_10_bss_55CD8_Target *after;
fn_8_E440_s32 prev;
prev = *(fn_8_E440_s8 *)&before->unk_10;
before->unk_10 = ((fn_8_E440_s8 *)lbl_1_bss_A48)[before->unk_C << 4] >> 2;
after = *ref;
if (*(fn_8_E440_s8 *)&after->unk_10 == 0) {
fn_8_E440_u8 t = lbl_1_bss_A48[after->unk_C << 4];
if ((fn_8_E440_s8)t > 0) {
after->unk_10 = 1;
} else if ((fn_8_E440_s8)t < 0) {
*(fn_8_E440_s8 *)&after->unk_10 = -1;
} else {
*(fn_8_E440_s8 *)&after->unk_10 = prev < 0 ? -1 : 1;
}
}
}
{
register Obj_10_bss_55CD8_Target **smoothRef = &(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550);
/* Observe the shared state pointer again for the animation update. */
Obj_10_bss_55CD8_Target *phase = *(Obj_10_bss_55CD8_Target **)smoothRef;
fn_8_E440_u32 old12;
fn_8_E440_s32 x;
fn_8_E440_f64 d;
Obj_10_bss_55CD8_Target *smooth;
phase->unk_11 = phase->unk_11 - phase->unk_10;
smooth = *smoothRef;
old12 = smooth->unk_12;
x = smooth->unk_E * 56 + 98 - old12;
d = lbl_8_rodata_B68 * (fn_8_E440_f64)x;
if ((fn_8_E440_s32)d != 0) {
smooth->unk_12 = (fn_8_E440_s32)((fn_8_E440_f64)old12 + d);
} else {
fn_8_E440_s32 step;
if (x < 0) {
step = -1;
} else {
step = x > 0;
}
smooth->unk_12 += step;
}
}
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_14 != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_14 = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_14 - 1;
}
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_15 != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_15 = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_15 - 1;
}
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_16 != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_16 = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_16 - 1;
}
if ((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_17 != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_17 = (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_17 - 1;
}
q = (*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x10;
if (((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 3) & 1) || ((*(fn_8_E440_u16 *)((fn_8_E440_u32)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12) + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 3) & 1)) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_14 = 8;
}
if (((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 2) & 1) || ((*(fn_8_E440_u16 *)((fn_8_E440_u32)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12) + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 2) & 1)) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_15 = 8;
}
if ((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) & 1) || ((repeat = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12), repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10]) & 1) ||
((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 8) & 1)) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_16 = 8;
}
if (((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 1) & 1) || (((repeat = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12), repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10]) >> 1) & 1) ||
((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 9) & 1)) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_17 = 8;
}
if (flA != 0) {
v68 = *(const MenuColor *)&lbl_8_rodata_B60;
rp = fn_1_45D0 (*(fn_8_E440_u32 *)&(*(fn_8_E440_u32 *)&lbl_801A6410), 0x12, p + 0xa0, 0xd4);
*(fn_8_E440_u16 *)((fn_8_E440_u8 *)rp + 8) = (fn_8_E440_u16)((fn_8_E440_u32)(cnt & 0xFF) * 56 + 0x7e);
*(fn_8_E440_u16 *)((fn_8_E440_u8 *)rp + 10) = 0x17a;
*(fn_8_E440_u8 *)((fn_8_E440_u8 *)rp + 0) = 1;
*(fn_8_E440_u8 *)((fn_8_E440_u8 *)rp + 1) = 0x18;
*(fn_8_E440_u16 *)((fn_8_E440_u8 *)rp + 4) = 0x140;
*(fn_8_E440_u16 *)((fn_8_E440_u8 *)rp + 6) = 0xb2;
*(fn_8_E440_u8 *)((fn_8_E440_u8 *)rp + 2) = buf[0];
*(fn_8_E440_u8 *)((fn_8_E440_u8 *)rp + 3) = buf[1];
*(MenuColor *)((fn_8_E440_u8 *)rp + 0xd) = v68;
*(fn_8_E440_u8 *)((fn_8_E440_u8 *)rp + 0xc) = cnt;
fn_1_435C((*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_8);
fn_1_3F8C((fn_8_E440_u32)(p + 0xc8), (fn_8_E440_u32)fn_8_D630, (fn_8_E440_u32)rp, 0xb);
}
if (flB != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_20 |= ((fn_8_E440_u32)0x80000000 >> cnt);
}
if (flA != 0) {
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_3A = 12;
}
if (flA != 0) {
fn_1_A2D84(0xA9010F00);
}
if (flB != 0) {
fn_1_A2D84(0xA9010200);
}
if (flC != 0) {
fn_1_A2D84(0xA9010000);
}
if (((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 3) & 1) || (((repeat = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12), repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10]) >> 3) & 1) ||
((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 2) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 2) & 1)) {
fn_1_A2D84(0xA9010000);
}
if ((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) & 1) || ((repeat = (fn_8_E440_u16 *)((*(fn_8_E440_u8 (*)[])&lbl_1_bss_9F8) + 0x12), repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10]) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 8) & 1) ||
((*(fn_8_E440_u16 *)(q + (*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 20) >> 1) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 1) & 1) || ((repeat[(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_C * 10] >> 9) & 1)) {
fn_1_A2D84(0xA9010000);
}
if (lbl_8_bss_555 != 0) {
fn_1_A2D84(0xA9010200);
(*(Obj_10_bss_55CD8_Target * *)&lbl_8_bss_550)->unk_0 &= ~0x80000000u;
}
lbl_8_bss_555 = 0;
end:
return;
}
#pragma opt_common_subs reset
