#include "types.h"
#include "rel/interview/globals.h"
#include "rel/interview/interview.h"
extern f32 lbl_17_rodata_0[6];
extern const f32 lbl_17_rodata_1C;
extern u8 lbl_1_bss_5138[0x104];
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAB4;
extern u32 lbl_1_bss_6EAD0;
extern s16 lbl_1_bss_968;
extern s16 lbl_1_bss_96A;
extern u8 lbl_1_bss_9F8[0x50];
extern u8 lbl_1_bss_D58[0x18];
extern char * lbl_1_data_20D1C[];
extern u32 lbl_1_rodata_26F8;
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern void *lbl_801A6D00;
extern void *lbl_801A66CC;
extern void fn_1_407C(void);
extern void fn_1_3CC4(void);
extern void lbl_8006DD14(void *arg0, void *arg1);
extern void fn_1_B870(void);
extern void camera_update_state(void);
extern void lbl_8006DCA4(void);
extern void fn_8006F4E0(void *arg0);
extern f32 fn_1_A6FE8(void);
extern void fn_1_549F4(void *arg0, void *arg1, f32 arg2, f32 arg3, f32 arg4, f32 arg5);
extern void fn_1_A7024(f32 arg0, f32 arg1, f32 arg2, f32 arg3);
extern u8 lbl_17_data_63E30[32];
extern s16 lbl_1_bss_962;
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern const f32 lbl_17_rodata_18;
extern char *fn_80083DB0(char *, const char *);
extern char lbl_1_bss_198[];
extern const char *lbl_1_data_370[];
extern void fn_17_48D0(void);
extern void fn_17_4E54(void);
extern void fn_80007AB4(void *);
extern u8 lbl_1_data_2A7E0[];
extern void fn_1_56000(int, int, int);
extern void fn_1_A71CC(void);
extern void lbl_8006E0A4(void *);
extern void lbl_8006E14C(f32);
extern void fn_1_55FC4(f32);
extern void mathutil_mtxA_rotate_z(s16);
extern void fn_1_55FF0(f32);
extern void fn_1_A722C(void);
extern u8 lbl_17_data_62A48[660];
extern void fn_1_8F62C(void *);
extern void fn_1_9818C(s16 value);
extern void fn_1_8F494(void *arg0);
extern u32 lbl_17_rodata_1B8;
extern void fn_1_8F45C(void *, s32, u32, u32);
extern void fn_1_789E8(void);
extern void fn_1_9A5CC(void);
extern void fn_1_7E9C4(void);
extern void fn_1_7EAE8(void);
extern void fn_1_78EBC(void);
extern void fn_1_9A7BC(void);
extern void fn_1_7ACDC(int);
extern void fn_1_79100(void);
extern void fn_80006E10(const char *);
extern void fn_1_14D728(void *, void *);
extern void DCFlushRange(void *, u32);
extern void fn_1_7F518(s16, char *, s32);
extern s32 fn_1_12A350(char *, s32);
extern void fn_1_12AB38(const char *);
extern u32 fn_1_12AC00(const char *);
extern void fn_1_12A2D0(s32);
extern u32 fn_1_12A734(u32);
extern void fn_1_FE004(void);
extern void fn_1_FDEC8(void);
extern void fn_1_FDC00(void);
extern void lbl_8006E0B4(f32, f32, f32);
extern void lbl_8006DB74(void *);
extern void fn_1_14E5E4(void *, f32, s16);
extern void OSPanic(void *, s32, void *, ...);
extern void lbl_8006DAEC(void);
extern void fn_1_87610(void *, void *);
extern void fn_1_875B4(void *, f32, void *, s8);
extern void lbl_8006DC20(void);
extern void lbl_8006DBAC(void *);
extern void fn_1_FCFA4(void *);
extern void fn_1_14DBCC(void *);
extern void fn_1_7F934(void *);
extern void fn_1_FDFF4(void);
extern void fn_80071718(void *);
extern void fn_17_65F4(void);
extern void fn_17_613C(void);
extern u16 fn_1_48690(u32);
extern u16 fn_1_486C4(s32);
extern u32 fn_1_56018(s32);
extern void fn_1_5616C(s32, f32, f32);
extern u8 lbl_17_bss_314[64];
extern u32 lbl_17_rodata_25C[50];
extern void fn_1_7BCCC(f32 *value);
extern void fn_80035680(u8 *value, f32 a, f32 b, f32 c);
extern void fn_80035690(u8 *value, f32 a, f32 b, f32 c);
extern void fn_80035420(u8 *value, int index, f32 value2);
extern void fn_800356AC(u8 *value, u32 *data);
extern void GXInitLightDistAttn(u8 *value, int index, f32 a, f32 b);
extern void fn_1_7BB80(u8 *value, int index);
extern void fn_1_7BD6C(int value);
extern void lbl_8006D7F4(f32, f32, f32);
extern void camera_save_parameters(f32, f32);
extern f32 lbl_17_bss_354[7];
extern void fn_1_520A0(void);
extern void fn_1_52070(u32);
extern void fn_1_520CC(void);
extern void fn_1_141360(u32, s32, s32, s32, f32, f32);
extern void fn_1_494DC(s32);
extern void fn_17_9314(const char *text);
extern char *lbl_1_data_21078[];
extern char *lbl_1_data_212A8[];
extern void fn_1_49778(s32, s32, s32, s32);
extern void fn_1_49768(s32);

typedef struct {
    u8 pad[0x88];
    // Hardware-style shared state must be read exactly as published.
    int value;
} fn_17_4540_InterviewState;

typedef struct {
    u8 pad[0xc];
    // Hardware-style shared state must be read exactly as published.
    s16 value;
} fn_17_4540_InterviewData;





void fn_17_4540(void) {
    fn_17_4540_InterviewState *state = (*(fn_17_4540_InterviewState * *)&lbl_17_bss_D8);
    fn_17_4540_InterviewData *data = &(*(fn_17_4540_InterviewData *)&lbl_17_bss_60);

    if (state->value != 7)
        return;
    if (data->value == 8)
        return;
}
