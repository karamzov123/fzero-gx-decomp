#include "types.h"
#include "dolphin/types.h"
#include "rel/car_colchg/globals.h"
#include "rel/car_colchg/car_colchg.h"

struct CarColchgEntry {
    s16 unk0;
    u16 unk2;
    u32 unk4;
    u8 pad8[24];
};

struct Struct_lbl_1_bss_970
{
  u8 pad0[4];
  u8 unk4;
};

struct Car {
    u8 pad_0[0x3b8];
    s16 unk_3b8;
};

struct Car_9_1310 {
    u8 pad_0[0x3b8];
    s16 unk_3b8;
};

typedef struct { u32 words[2]; f32 x; f32 y; u32 rest[18]; } SelectionPanel;
u16 fn_1_3F8C(char *, void (*)(void), s32, s32);
extern u32 fn_1_435C(u32 value);
extern void fn_1_4A00(s32 enabled, u8 mode, void *value);
extern void fn_9_1BCC(void);
extern void colchg_selcar_disp(void *cars);
extern int fn_1_4C10(void);
extern s16 *lbl_1_data_1FB6C[];
extern void colchg_selmate_disp(u8 *car);
extern void OSReport(const char *format, ...);
extern void colchg_chgcol_disp(void *car);
extern void colchg_menu_disp(void);
extern void fn_1_426C(u32 arg0);
extern void colchg_ezsel_disp(void);
extern void colchg_save_disp(void);
extern u16 lbl_1_bss_968;
extern void fn_1_A8EB0(int arg0, int arg1);
extern void *fn_1_7F49C(s16 arg0, s16 arg1, void *arg2);
extern void fn_1_A8DD4(const char *format, ...);
extern void fn_1_80058(s8 arg0, u8 *arg1);
extern void fn_1_80C18(u8 *arg0, u8 *arg1, s8 arg2);
extern s16 lbl_1_bss_962;
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern struct Struct_lbl_1_bss_970 lbl_1_bss_970;
extern u16 lbl_1_bss_96A;
extern u32 lbl_801A6410;
extern void fn_1_7FA04(u32 arg0);
void fn_1_8D168(u32);
extern void fn_1_41A8(void);
extern void fn_1_46B4(u32 arg0, u32 arg1, const char *arg2, int arg3);
extern void fn_1_6400(void);
extern void fn_9_1AC4(void);
extern u32 lbl_801A66A0;
extern const f32 lbl_9_rodata_14;
extern const f32 lbl_9_rodata_18;
extern void fn_1_496FC(f32 value1, f32 value2);
extern void fn_1_4AE0C(const char *, ...);
void lbl_8006D7F4(f32, f32, f32);
void mathutil_mtxA_rotate_y(s32);
void mathutil_mtxA_rotate_x(s32);
void lbl_8006E14C(f32);
extern void fn_80072558(void);
extern void fn_1_870BC(struct Car *, s8, struct Car *, s32, u8, f32);
extern u8 lbl_1_rodata_26F8[88];
extern u16 lbl_1_bss_D58;
extern size_t strlen(const char *str);
extern char *fn_80083DB0(char *dst, const char *src);
extern void fn_1_4B83C(void *arg0, void *arg1, u32 arg2, const char *arg3);
extern int sprintf(char *s, const char *format, ...);
extern void fn_1_4B040(s32 value);
extern void fn_1_4955C(f32 value1, f32 value2);
extern s32 fn_9_120C(struct Car *car);
extern s32 fn_9_1310(struct Car_9_1310 *car);
void fn_1_8D3F8(void *, void *, void (*)(void), void *);
extern const f32 lbl_9_rodata_0;
extern char lbl_9_data_7C[];
extern char lbl_9_data_80[];
extern char lbl_9_data_84[];
extern void lbl_8006DCA4(void);
extern void lbl_8006E1D8(void *, f32, f32, f32);
extern void fn_1_7BCCC(void *);
extern void fn_80035680(void *, f32, f32, f32);
extern void fn_80035690(void *, f32, f32, f32);
extern void fn_80035420(void *, f32, s32);
extern void fn_800356AC(void *, void *);
extern void GXInitLightDistAttn(void *, s32, f32, f32);
extern void fn_1_7BB80(void *, s32);
extern u32 fn_1_7BD6C(s32 value);
extern void fn_80074CF4(f32 arg0, f32 arg1, f32 arg2);

struct fn_9_E4C_ColchgState {
    u8 pad[8];
    u16 flags;
    u8 pad_a[6];
    volatile u16 input_a; // Input state may be updated between reads.
    u16 input_b; // Input state may be updated between reads.
};





void fn_9_E4C(void) {
    struct fn_9_E4C_ColchgState *state;
    s8 change;

    if (fn_1_4C10() == 0) {
        state = &(*(struct fn_9_E4C_ColchgState *)&(*((struct Struct_lbl_1_bss_D58 *)&lbl_1_bss_D58)));
        if ((state->flags >> 9) & 1) {
            lbl_1_bss_96A = 0x72;
        }
        change = 0;
        if (((*(struct fn_9_E4C_ColchgState *)&(*((struct Struct_lbl_1_bss_D58 *)&lbl_1_bss_D58))).input_a & 1) || ((*(struct fn_9_E4C_ColchgState *)&(*((struct Struct_lbl_1_bss_D58 *)&lbl_1_bss_D58))).input_b & 1)) {
            change = -1;
        }
        if ((((*(struct fn_9_E4C_ColchgState *)&(*((struct Struct_lbl_1_bss_D58 *)&lbl_1_bss_D58))).input_a >> 1) & 1) ||
            (((*(struct fn_9_E4C_ColchgState *)&(*((struct Struct_lbl_1_bss_D58 *)&lbl_1_bss_D58))).input_b >> 1) & 1)) {
            change++;
        }
        if (change != 0) {
            s32 result;
            s32 value;
            value = *(s16 *)lbl_9_bss_8 + change;
            if (value > 40) {
                value = 0;
            } else {
                value = value < 0 ? 40 : value;
            }
            *(s16 *)lbl_9_bss_8 = value;
        }
        if ((state->flags >> 8) & 1) {
            lbl_1_bss_96A = 0x76;
        }
    }
}
