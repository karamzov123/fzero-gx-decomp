#include "types.h"
#include "rel/option/globals.h"

extern struct fn_4_347C_lbl_1_bss_9C8 lbl_1_bss_9C8;
extern u32 lbl_1_data_2AC0;
extern u32 lbl_1_data_2B40;
extern u32 lbl_1_data_2B50;
extern u32 lbl_1_data_2B58;
extern u32 lbl_4_data_14D0;
extern void fn_4_3128(void);
extern u32 fn_80008BA8(u32, u32, u32);
extern u32 fn_1_F7308(void);
extern u32 lbl_1_bss_AA0;
extern u32 lbl_1_data_2B60;
extern u32 lbl_4_data_2AE8;
extern u32 memcpy(u32, u32, u32);
extern void fn_4_63D4(void);
extern int fn_1_4C10(void);
extern u16 lbl_1_bss_96A;
extern u32 fn_4_0(u32, u32, u32, u32, u32);
extern u32 lbl_1_bss_9F8;
extern u8 lbl_4_data_2C58[84];
extern void fn_1_1280(u32);
extern void fn_1_A2D84(u32);
extern u32 fn_4_ABB0(void);
extern u32 fn_1_1380F0(u32);
extern u32 fn_1_13ABA8(u32);
extern u32 lbl_4_data_1A4;
extern s32 lbl_801A66B4;
extern u8 lbl_4_bss_5618;
extern u32 fn_1_B7E98(u32);
extern u32 fn_1_B800C(u32);
extern u32 fn_1_B80F0(u32);
extern u32 fn_1_B8170(u32);
extern u32 lbl_4_data_2DB4;
extern void fn_4_9AD0(void);
extern u8 *fn_4_A82C(u8 *);
extern void fn_80083DB0(u8 *, u32);
extern u32 fn_1_B9C0C(void);
extern s8 fn_1_BA144(u32 *);
extern u32 lbl_4_bss_5678;
extern u32 fn_1_B7C00(void);
extern u32 fn_1_BC310(void *);
extern u32 fn_1_C0510(u32);
extern u32 fn_1_C1394(void *);
extern s16 lbl_1_bss_962;
extern struct fn_4_9B0_lbl_4_data_1260 lbl_4_data_1260;
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern u32 fn_1_3CC4(u32);
extern u32 fn_1_407C(u32);
extern u32 fn_1_426C(u32);
extern void fn_4_AB90(void);
extern struct _prolog_lbl_1_bss_6EAD0 lbl_1_bss_6EAD0;
extern struct fn_4_869C_lbl_1_bss_718E0 lbl_1_bss_718E0;
extern s32 lbl_1_bss_970;
extern u16 lbl_1_bss_968;
extern s16 lbl_1_bss_960;
extern u8 lbl_1_bss_D58[0x18];
extern u32 lbl_1_rodata_26F8;
extern u8 lbl_4_rodata_0[0x4c];
extern u8 lbl_4_rodata_410[0x8];
extern u32 lbl_801A6410;
extern const f32 lbl_4_rodata_4C[45];
extern void fn_8006CE1C(f32);
extern void fn_1_1596DC(u32);
extern void fn_1_484CC(u32);
extern void fn_1_47A60(u32);
extern void fn_1_412A0(u32);
extern void fn_1_3C78(void);
extern void fn_1_41A8(void);
extern void fn_8004BF0C(u32, s32);
extern void ADXT_Stop(u32);
extern char *lbl_4_data_D6C[];
extern char *lbl_4_data_DA0[];
extern s8 fn_1_1ACC(s8, u8 *, u8 *);
extern u8 lbl_4_data_2D24[56];
extern u8 fn_4_ACF0__fzgx_offset_0[];
extern u8 fn_4_AD44__fzgx_offset_0[];
extern u8 fn_4_AD78__fzgx_offset_0[];
extern u8 fn_4_ADAC__fzgx_offset_0[];
extern u8 fn_4_ADB0__fzgx_offset_0[];
extern u8 fn_4_ADF0__fzgx_offset_0[];

extern u32 lbl_4_rodata_C2C;
extern u32 lbl_4_rodata_C30;




extern u32 fn_1_435C(u32);
extern s32 fn_1_45D0(u32, u32, u8 *, u32);
extern s32 fn_1_3F8C(u8 *, u32, u32, u32);
extern void fn_1_A2D84(u32);
extern s32 fn_1_14CEB8(u32);
extern void fn_80083DB0(u8 *, u32);
extern void fn_4_ADF4(void);
struct fn_4_D420_lbl_801A6410 {
    u32 unk_0;
};
typedef struct {
    u8 unk_0;
    u8 unk_1;
    u8 unk_2;
    u8 unk_3;
    u16 unk_4;
    u16 unk_6;
    u16 unk_8;
    u16 unk_A;
    u8 unk_C;
    u8 pad_D[0x3];
    u32 unk_10;
} Entry_4_D420;
typedef struct { u32 v; } Word;

#pragma opt_loop_invariants off
#pragma opt_lifetimes off
s32 fn_4_D420(void) {
    s32 bit;
    u8 *src;
    s32 i;
    Obj_4_bss_5680_Target *maskstate;
    struct { u8 value; } k;
    struct { s32 value; } n;
    s32 res;
    u8 *src2;
    u8 *data;
    Entry_4_D420 *t;
    Word c;
    Word c2;

    res = 0;
    data = lbl_4_data_2F78;
    if ((lbl_4_bss_5680->unk_0 >> 30) & 1) {
        c = *(Word *)&lbl_4_rodata_C30;
        fn_1_435C(lbl_4_bss_5680->unk_8);
        n.value = 0;
        i = 0;
        while (src = (u8 *)lbl_4_bss_5680 + 0x28 + i, src[0] != 0) {
            t = (Entry_4_D420 *)fn_1_45D0((*(struct fn_4_D420_lbl_801A6410 *)&lbl_801A6410).unk_0, 0x12, ((0xA0) + (data)), 0xD4);
            t->unk_8 = (u8)n.value * 0x38 + 0x7E;
            t->unk_A = 0x17A;
            t->unk_0 = 2;
            t->unk_1 = 0;
            t->unk_4 = t->unk_8;
            t->unk_6 = t->unk_A;
            t->unk_2 = src[0];
            t->unk_3 = src[1];
            *(u32 *)((u8 *)t + 0xD) = c.v;
            t->unk_C = n.value;
            fn_1_3F8C(data + 0xC8, (u32)&fn_4_ADF4, (u32)t, 0xB);
            i += 2;
            n.value += 1;
        }
        c2.v = lbl_4_bss_5680->unk_0;
        /* Retail reloads the target pointer after reading its flags. */
        (*(Obj_4_bss_5680_Target * *)&lbl_4_bss_5680)->unk_0 = c2.v & ~0x40000000;
    }
    if (lbl_4_bss_5680->unk_0 >> 31) {
        return 1;
    }
    if (((lbl_4_bss_5680->unk_0 >> 29) & 1) || ((lbl_4_bss_5680->unk_0 >> 28) & 1)) {
        fn_1_A2D84(0xA9010100);
        lbl_4_bss_5680->unk_0 &= ~0x20000000;
        lbl_4_bss_5680->unk_0 &= ~0x10000000;
        lbl_4_bss_5680->unk_0 |= 0x80000000;
        if (fn_1_14CEB8((u32)lbl_4_bss_5680 + 0x28) != 0) {
            bit = 0;
            lbl_4_bss_5680->unk_0 |= 0x40000000;
            while (((u8 *)lbl_4_bss_5680)[0x28 + bit * 2] != 0) {
                lbl_4_bss_5680->unk_20 |= 0x80000000 >> bit;
                bit++;
            }
        }
        if (((u8 *)lbl_4_bss_5680)[0x28] == 0) {
            if (lbl_801A66B4 == 5) {
                fn_80083DB0((u8 *)lbl_4_bss_5680 + 0x28, (u32)(data + 0x114));
            } else {
                fn_80083DB0((u8 *)lbl_4_bss_5680 + 0x28, (u32)(data + 0x120));
            }
            c2 = *(Word *)&lbl_4_rodata_C2C;
            fn_1_435C(lbl_4_bss_5680->unk_8);
            n.value = 0;
            while (src2 = (u8 *)lbl_4_bss_5680 + 0x28 + n.value * 2, src2[0] != 0) {
                k.value = n.value;
                t = (Entry_4_D420 *)fn_1_45D0((*(struct fn_4_D420_lbl_801A6410 *)&lbl_801A6410).unk_0, 0x12, ((0xA0) + (data)), 0xD4);
                t->unk_8 = k.value * 0x38 + 0x7E;
                t->unk_A = 0x17A;
                t->unk_0 = 2;
                t->unk_1 = 0;
                t->unk_4 = t->unk_8;
                t->unk_6 = t->unk_A;
                t->unk_2 = src2[0];
                t->unk_3 = src2[1];
                *(u32 *)((u8 *)t + 0xD) = c2.v;
                t->unk_C = k.value;
                fn_1_3F8C(data + 0xC8, (u32)&fn_4_ADF4, (u32)t, 0xB);
                n.value += 1;
            }
            lbl_4_bss_5680->unk_E = n.value;
        }
        res = 1;
    }
    return res;
}
#pragma opt_lifetimes reset

#pragma opt_loop_invariants reset
