#include "types.h"
#include "rel/pilotpoint/globals.h"
#include "rel/pilotpoint/pilotpoint.h"
extern const f32 lbl_14_rodata_0;
extern u32 lbl_1_bss_6EAB4;
extern u8 lbl_1_bss_6EAD0[0x708];
extern s16 lbl_1_bss_8B3A0;
extern s16 lbl_1_bss_96A;
extern u8 lbl_1_bss_9F8[0x50];
extern u8 lbl_1_bss_D58[0x18];
extern u8 lbl_1_data_1E5C0[0x34];
extern u32 lbl_1_rodata_26F8;
extern u32 lbl_801A63C0;
extern u8 lbl_801A6410[0x4];
extern s32 lbl_801A66A0;
extern s32 lbl_801A66B4;
extern u32 fn_1_3CC4(u32);
extern u32 fn_1_407C(u32);
extern u8 lbl_14_data_308[128];
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern void fn_1_128B60(u8 *, u8 *, u8 *, u8 *, u8 *, u8 *, u8 *, u8 *, u8 *, u8 *);
extern s16 fn_1_14F19C(s16, s16, u32);
extern s16 fn_1_14D5CC(s16, u32, u32);
extern s16 fn_1_14D670(void);
extern u32 fn_1_14D6D8(s16);
extern u32 fn_1_151BE8(s16, s16);
extern void fn_1_12B4EC(s16, s16);
extern void fn_14_315C(u32);
extern s16 fn_14_32DC(s16 *out);
extern s16 fn_14_3384(s16 *out);
extern s16 fn_14_3334(s16 *out);
extern s16 fn_14_33DC(s16 *out);
extern u32 fn_14_342C(void);
extern u32 fn_14_34A8(void);
extern void fn_14_3230(u16 *arg0, u16 *arg1, u16 *arg2);
extern void fn_1_A514C(s32);
extern u32 lbl_14_bss_8344;
extern void fn_1_9250C(void *);
extern u32 fn_14_DC6C(u32, u32);
extern u32 lbl_1_data_21078;
extern u32 lbl_1_data_212A8;
extern void fn_1_14E9E4(int, void *);
extern void fn_1_4962C(void);
extern u32 fn_80074188(u32, u32, u32, u32);
extern char *fn_1_14FEAC(s16, s16, s16, char *, s16);
extern char *fn_1_14EE00(s16, char *, s16);
extern char *fn_1_13F72C(f32, s16, char *);
extern void fn_1_494DC(s32);
extern void fn_1_49644(void);
extern void fn_14_58C4(u32 arg0, u32 arg1);
extern void fn_14_6758(s16 x, s16 y);
extern u8 lbl_14_bss_91F4[100];
extern void fn_1_1380F0(void*);
extern void fn_1_13D02C(void);
extern void fn_14_2590(void);
extern u32 lbl_14_data_2F48;
extern void fn_14_7584(void);
extern void OSReport(const char *, ...);
extern int fn_1_F8334(s16);
extern u32 OSGetTick(void);
extern u32 fn_1_F83F0(u32);
extern u32 lbl_14_bss_18;
extern u32 fn_1_47F74(u32);
extern void fn_1_F8B50(void);
extern void fn_14_82E4(s16, s16, s16);
extern u32 fn_1_48140(u32);
extern void fn_14_A3DC(void);
extern s32 fn_1_B7EC4(s32);
extern s32 fn_1_B7C5C(void);
extern s32 CARDProbeEx(s32, s32 *, s32 *);
extern f32 lbl_14_rodata_30;
extern u16 lbl_1_bss_968;
extern char *strncpy(char *, const char *, size_t);
extern size_t strlen(const char *);
extern u32 __cvt_fp2unsigned(f32);
extern f32 lbl_14_rodata_364;
extern const f64 lbl_14_rodata_110;
extern const f64 lbl_14_rodata_60;
extern u32 lbl_14_bss_C;
extern f32 fn_1_4B068(char *);
extern const char *lbl_14_data_BD4[];
extern const char *lbl_14_data_C54[];
extern const char *lbl_14_data_C9C[];
extern u32 lbl_14_data_6C8;

#include "types.h"
#include "rel/pilotpoint/pilotpoint.h"

extern f64 __fabs(f64);
struct fn_14_34FC_lbl_14_rodata_0 {
    u8 pad_0[0x60];
    f64 unk_60;
    u8 pad_68[0x50];
    f64 unk_B8;
    f64 unk_C0;
    u8 pad_C8[0x58];
    f32 unk_120;
    f32 unk_124;
};

struct Input34 {
    u8 pad[8];
    u16 pressed;
    u8 padA[6];
    volatile u16 repeat; /* volatile: retail re-reads the word at every test */
    u16 held;
};

extern void fn_1_A2D84(u32);

#pragma section code_type ".fzgxpool"
void fzgx_pool_primer(volatile f32 *f, volatile f64 *d, volatile s32 *i) { /* volatile sinks: pool primer */
    *f = 0.0f; *f = 167.0f; *f = 38.0f; *f = 90.0f;
    *f = 320.0f; *f = 216.0f; *f = 8.0f; *f = 96.0f;
    *f = 336.0f; *f = 380.0f; *d = 12.0;
    *f = 1.0f; *f = 99.0f; *f = 30.0f; *f = 140.0f;
    *f = 178.0f; *f = 254.0f; *f = 292.0f; *f = 541.0f;
    *f = 575.0f; *f = 98.0f; *f = 42.0f;
}
void fzgx_pool_primer_conversion(volatile f64 *d, volatile s32 *i) { /* volatile sinks: pool primer */
    *d = (f64)*i;
}
void fzgx_pool_primer_rest(volatile f32 *f, volatile f64 *d) { /* volatile sinks: pool primer */
    *d = 60.0; *d = 25.0; *d = 29.0;
}
const u32 fzgx_pool_table_80[10] = {
    0xA0FF00FF, 0xFFFFFF00, 0xA0FF00FF, 0xFFFFFF00,
    0xA0FF00FF, 0xFFFFFF00, 0xA0FF00FF, 0xFF8080FF,
    0xA0FF00FF, 0xFFFFFF00
};
void fzgx_pool_primer_tail(volatile f32 *f, volatile f64 *d) { /* volatile sinks: pool primer */
    *f = 396.0f; *f = 190.0f; *f = 0.5f;
    *d = 0.0; *d = 1.0; *d = 18.0;
    *f = 136.0f; *f = 0.55f; *f = 108.0f; *f = 300.0f;
    *f = 80.0f; *f = 400.0f; *f = 388.0f; *f = 97.0f;
    *f = 0.05f; *d = 90.0; *d = 30.0; *d = 2.0;
    *d = 4503599627370496.0;
    *d = 9751287953004544.0;
    *f = 10.0f; *f = 20.0f;
}
#pragma section code_type ".text"

#define flags34(i) (&((Obj_14_bss_110 *)((u8 *)&lbl_14_bss_110 + (i) * 8))->unk_C)
static inline s32 wrap34(s32 i, s32 min, s32 max) {
    return i > max ? min : i < min ? max : i;
}
static inline s32 available34(u32 flags) {
    s16 price;
    if (flags & 4) return 1;
    if (flags & 8) price = 15000;
    else if (flags & 16) price = 20000;
    else price = -1;
    if (price > 99900) return 0;
    return 1;
}
/* The flags word is read straight from the table: a helper parameter would copy it. */
#define mode34(entry) \
    (((entry) & 4) ? (lbl_14_bss_110.unk_0 | 0x80000000) : (lbl_14_bss_110.unk_0 & 0x7FFFFFFF))
u32 fn_14_34FC(void) {
    Obj_14_bss_110 * sel;
    f32 v0;
    f32 v1;
    s16 direction;
    s16 horizontal;
    s16 old;
    s16 candidate;
    s16 count;
    s16 i;
    s16 parent;
    u32 *flagbase;
    u32 result;
    f64 v3;
    sel = &lbl_14_bss_110;
    v0 = (f32)(s32)lbl_14_bss_92BC;
    v1 = (v0 - 10.0f) / 20.0f;
    result = 0;
    direction = 0;
    horizontal = 0;
    old = sel->unk_4;
    if ((s32)lbl_14_bss_92C0 == 1) {
        /* The timer is re-read through a different lvalue so the front end keeps
         * it a plain load temporary (the backend still folds it onto one lwz). */
        if ((((*(struct Input34 *)&lbl_1_bss_9F8).pressed >> 8) & 1) || *(s32 *)&lbl_14_bss_92BC > 300) {
            fn_1_A2D84(0xA9010100);
            lbl_14_bss_92C0 = 0;
            lbl_14_bss_92BC = 0;
        }
        return 0;
    }
    v3 = __fabs(v1);
    if (v3 <= 1.0 && v3 >= 0.0) return 0;
    if ((((*(struct Input34 *)&lbl_1_bss_9F8).repeat >> 1) & 1) || (((*(struct Input34 *)&lbl_1_bss_9F8).held >> 1) & 1)) direction = 1;
    if (((*(struct Input34 *)&lbl_1_bss_9F8).repeat & 1) || ((*(struct Input34 *)&lbl_1_bss_9F8).held & 1)) direction--;
    if ((((*(struct Input34 *)&lbl_1_bss_9F8).repeat >> 3) & 1) || (((*(struct Input34 *)&lbl_1_bss_9F8).held >> 3) & 1)) horizontal = -1;
    if ((((*(struct Input34 *)&lbl_1_bss_9F8).repeat >> 2) & 1) || (((*(struct Input34 *)&lbl_1_bss_9F8).held >> 2) & 1)) horizontal++;
    sel->unk_4 = wrap34(sel->unk_4 + direction, 0, 7);
    while ((*flags34(sel->unk_4) & 1) || !available34(*flags34(sel->unk_4))) {
        if (!direction) direction = 1;
        sel->unk_4 = wrap34(sel->unk_4 + direction, 0, 7);
    }
    flagbase = &lbl_14_bss_110.unk_C;
    /* Reload the selection after scanning the entry flags. */
    lbl_14_bss_110.unk_0 = mode34(flagbase[*(s16 *)&sel->unk_4 * 2]);
    if (lbl_14_bss_110.unk_0 & 0x80000000) {
        if (horizontal < 0) {
            candidate = *(s16 *)((u8 *)&lbl_14_bss_110 + 6);
            count = 0;
            /* (u32) keeps the index extension distinct from the `candidate + 1` below */
            while ((*flags34((u32)candidate) & 1) || !available34(*flags34((u32)candidate))) {
                candidate = wrap34(candidate + 1, 1, 7);
                if (count > 10) { candidate = 0; break; }
                count++;
            }
            sel->unk_4 = candidate;
        }
    } else if (horizontal > 0) {
        *(s16 *)((u8 *)&lbl_14_bss_110 + 6) = sel->unk_4;
        sel->unk_4 = 0;
    }
    lbl_14_bss_110.unk_0 = mode34(flagbase[sel->unk_4 * 2]);
    if (sel->unk_4 != old) fn_1_A2D84(0xA9010000);
    if (((*(struct Input34 *)&lbl_1_bss_9F8).pressed >> 8) & 1) {
        parent = sel->unk_4;
        if (flagbase[parent * 2] & 4) {
            result = 1;
            fn_1_A2D84(0xA9010200);
        } else if (available34(flagbase[parent * 2]) == 1) {
            flagbase[parent * 2] |= 0x40;
            while (*flags34(parent) & 2) parent--;
            flagbase[parent * 2] |= 1;
            lbl_14_bss_110.unk_48 = (*(u32 *)&lbl_801A66A0);
            lbl_14_bss_110.unk_0 &= ~0x60000000;
            if (flagbase[sel->unk_4 * 2] & 8) {
                lbl_14_bss_110.unk_0 |= 0x40000000;
                fn_1_A2D84(0xA9110400);
            }
            if (flagbase[sel->unk_4 * 2] & 16) {
                lbl_14_bss_110.unk_0 |= 0x20000000;
                fn_1_A514C(*(s16 *)((u8 *)&lbl_14_bss_110 + sel->unk_4 * 8 + 8));
            }
        }
    }
    for (i = 0; (u32)i < 8; i++) {
        Obj_14_bss_110 *entry = (Obj_14_bss_110 *)((u8 *)&lbl_14_bss_110 + i * 8);
        if (!(entry->unk_C & 1)) {
            parent = i;
            while (*flags34(parent) & 2) parent--;
            if (*flags34(parent) & 1) entry->unk_C |= 1;
        }
    }
    return result;
}
