#include "types.h"
#include "rel/title/globals.h"
#include "rel/title/operation.h"
extern u8 lbl_1_bss_38460[0x54];
extern s16 lbl_1_bss_96A;
extern u16 lbl_1_bss_9F8[];
extern u8 lbl_1_data_1E5C0[0x34];
extern u8 lbl_1_rodata_26F8[0x58];
extern u32 lbl_801A6410;
extern s32 lbl_801A66A0;
extern s32 lbl_801A66B4;
extern f32 lbl_8_rodata_160[10];
extern f32 lbl_8_rodata_198;
extern u8 lbl_8_rodata_408[0x8];
extern u32 fn_1_412A0(u32);
extern u32 fn_1_3EB78(u32, u32, u32, u32);
extern u32 fn_1_3ED8C(u32, u32, u32, u32, u32, u32, u32);
extern void fn_8_663C(void);
extern void fn_1_3EF08(u8);
extern void fn_1_3EF8C(u8);
extern void fn_1_3EFF0(u32, u8);
extern void fn_1_3F02C(u32);
extern f32 lbl_8006D0B4(f32);
extern u8 lbl_8_data_9AB8[0x18];
extern void fn_8_C9A8(s32, s32, f32);
extern void GXGetProjectionv(f32 *);
extern void C_MTXOrtho(f32 (*)[4], f32, f32, f32, f32, f32, f32);
extern void fn_800737E4(f32 (*)[4], s32);
extern void fn_80072270(f32 *);
extern void fn_1_56000(s32, s32, s32);
extern void fn_1_14DE80(void *, void **, void **, s32, f32);
extern void lbl_8006DAEC(void);
extern void fn_1_14E054(void *, void *, s32, f32);
extern void lbl_8006DBE4(void);
extern void fn_1_14E198(void *, void *, s32, f32);
extern void lbl_8006DC20(void);
extern f32 lbl_8_rodata_2FC[27];
extern u32 fn_800371F8(u32, void *);
extern void fn_8003462C(u32, u32, u32);
extern void fn_8007245C(u32);
extern void fn_80072864(u32);
extern void fn_800728A8(s32, s32, s32, s32);
extern void fn_80072AB0(s32, s32, s32);
extern void fn_80072C24(s32, s32, s32, s32, s32);
extern void fn_80072CC4(u32, u32, u32, u32, u32);
extern void fn_80072D64(u32, u32, u32, u32, u32, u32);
extern void fn_80072E20(s32, s32, s32, s32, u8, s32);
extern void fn_800734A8(u32, s32, s32, s32);
extern void fn_80073678(u32);
extern void fn_80073C6C(s32);
extern void fn_80074660(u32);
extern void fn_80074788(u32);
extern void fn_800747D0(u32, u32, u32, u32, u32, u32, u32);
extern void fn_80074918(u8, s32, u8);
extern void fn_1_4965C(u8);
extern f32 lbl_8006D188(u32);
extern void fn_1_55FF0(f32);
extern u32 fn_1_D0790(void);
extern int fn_8_CF58(void);
extern int fn_8_CF60(void);
extern int fn_8_CF68(void);
extern s32 fn_8_CF70(void);
extern char lbl_8_data_A0C4[];
extern char lbl_8_data_A174[];
extern char lbl_8_data_A178[];
extern char lbl_8_data_A17C[];
extern char lbl_8_data_A180[];
extern char lbl_8_data_A184[];
extern s32 fn_1_1555B0(s32);
extern void fn_1_14A1AC(u8);
extern void fn_1_14BC40(void);
extern void fn_1_1554D0(void);
extern void fn_1_14BCBC(void *, u32);
extern u32 fn_1_144F40(u32, void *);
extern void fn_8_D020(void);
extern u32 lbl_8_rodata_C24;
extern u32 lbl_8_rodata_C28;
extern s32 fn_1_14CEB8(u32);

#include "rel/title/operation.h"

extern u32 fn_1_435C(u32);
extern s32 fn_1_45D0(u32, u32, u8 *, u32);
extern s32 fn_1_3F8C(u8 *, u32, u32, u32);
extern void fn_1_A2D84(u32);
extern void fn_80083DB0(u8 *, u32);
extern void fn_8_D630(void);
struct fn_8_FC5C_lbl_801A6410 {
    u32 unk_0;
};
typedef struct {
    u8 unk_0;
    u8 unk_1;
    u8 unk_2;
    u8 unk_3;
    u16 unk_4;
    u16 unk_6;
    u16 unk_8;
    u16 unk_A;
    u8 unk_C;
    u8 pad_D[0x3];
    u32 unk_10;
} Entry_4_D420;
typedef struct { u32 v; } Word;

#pragma opt_loop_invariants off
#pragma opt_lifetimes off
s32 fn_8_FC5C(void) {
    s32 bit;
    u8 *src;
    s32 i;
    Obj_8_bss_550_Target *maskstate;
    struct { u8 value; } k;
    struct { s32 value; } n;
    s32 res;
    u8 *src2;
    u8 *data;
    Entry_4_D420 *t;
    Word c;
    Word c2;

    res = 0;
    data = lbl_8_data_A1E8;
    if ((lbl_8_bss_550->unk_0 >> 30) & 1) {
        c = *(Word *)&lbl_8_rodata_C28;
        fn_1_435C(lbl_8_bss_550->unk_8);
        n.value = 0;
        i = 0;
        while (src = (u8 *)lbl_8_bss_550 + 0x28 + i, src[0] != 0) {
            t = (Entry_4_D420 *)fn_1_45D0((*(struct fn_8_FC5C_lbl_801A6410 *)&lbl_801A6410).unk_0, 0x12, ((0xA0) + (data)), 0xD4);
            t->unk_8 = (u8)n.value * 0x38 + 0x7E;
            t->unk_A = 0x17A;
            t->unk_0 = 2;
            t->unk_1 = 0;
            t->unk_4 = t->unk_8;
            t->unk_6 = t->unk_A;
            t->unk_2 = src[0];
            t->unk_3 = src[1];
            *(u32 *)((u8 *)t + 0xD) = c.v;
            t->unk_C = n.value;
            fn_1_3F8C(data + 0xC8, (u32)&fn_8_D630, (u32)t, 0xB);
            i += 2;
            n.value += 1;
        }
        c2.v = lbl_8_bss_550->unk_0;
        /* Retail reloads the target pointer after reading its flags. */
        (*(Obj_8_bss_550_Target * *)&lbl_8_bss_550)->unk_0 = c2.v & ~0x40000000;
    }
    if (lbl_8_bss_550->unk_0 >> 31) {
        return 1;
    }
    if (((lbl_8_bss_550->unk_0 >> 29) & 1) || ((lbl_8_bss_550->unk_0 >> 28) & 1)) {
        fn_1_A2D84(0xA9010100);
        lbl_8_bss_550->unk_0 &= ~0x20000000;
        lbl_8_bss_550->unk_0 &= ~0x10000000;
        lbl_8_bss_550->unk_0 |= 0x80000000;
        if (fn_1_14CEB8((u32)lbl_8_bss_550 + 0x28) != 0) {
            bit = 0;
            lbl_8_bss_550->unk_0 |= 0x40000000;
            while (((u8 *)lbl_8_bss_550)[0x28 + bit * 2] != 0) {
                lbl_8_bss_550->unk_20 |= 0x80000000 >> bit;
                bit++;
            }
        }
        if (((u8 *)lbl_8_bss_550)[0x28] == 0) {
            if (lbl_801A66B4 == 5) {
                fn_80083DB0((u8 *)lbl_8_bss_550 + 0x28, (u32)(data + 0x114));
            } else {
                fn_80083DB0((u8 *)lbl_8_bss_550 + 0x28, (u32)(data + 0x120));
            }
            c2 = *(Word *)&lbl_8_rodata_C24;
            fn_1_435C(lbl_8_bss_550->unk_8);
            n.value = 0;
            while (src2 = (u8 *)lbl_8_bss_550 + 0x28 + n.value * 2, src2[0] != 0) {
                k.value = n.value;
                t = (Entry_4_D420 *)fn_1_45D0((*(struct fn_8_FC5C_lbl_801A6410 *)&lbl_801A6410).unk_0, 0x12, ((0xA0) + (data)), 0xD4);
                t->unk_8 = k.value * 0x38 + 0x7E;
                t->unk_A = 0x17A;
                t->unk_0 = 2;
                t->unk_1 = 0;
                t->unk_4 = t->unk_8;
                t->unk_6 = t->unk_A;
                t->unk_2 = src2[0];
                t->unk_3 = src2[1];
                *(u32 *)((u8 *)t + 0xD) = c2.v;
                t->unk_C = k.value;
                fn_1_3F8C(data + 0xC8, (u32)&fn_8_D630, (u32)t, 0xB);
                n.value += 1;
            }
            lbl_8_bss_550->unk_E = n.value;
        }
        res = 1;
    }
    return res;
}
#pragma opt_lifetimes reset

#pragma opt_loop_invariants reset
