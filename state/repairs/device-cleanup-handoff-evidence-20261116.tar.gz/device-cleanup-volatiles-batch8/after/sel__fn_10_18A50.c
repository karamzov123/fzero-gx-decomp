#include "types.h"

#include "rel/main_rel/globals.h"
#include "sofdec/sj.h"
#include "rel/sel/sel.h"
#include "font.h"

/* begin sofdec/adxt.h (deltawave784/fzgx, CC0) */
#ifndef SOFDEC_ADXT_H
#define SOFDEC_ADXT_H

/* CRI ADX talker (ADXT) handle, shared by the ADXT_* / adxt_* units of the DOL. */

/* begin layout_check.h (deltawave784/fzgx, CC0) */
#ifndef LAYOUT_CHECK_H
#define LAYOUT_CHECK_H

/* Compile-time layout checks for owned types. They declare array typedefs
 * only, so they emit no code or data under MWCC: a wrong size or offset is
 * a negative array bound and fails the compile. */
#define LAYOUT_CHECK_JOIN2(a, b) a##b
#define LAYOUT_CHECK_JOIN(a, b) LAYOUT_CHECK_JOIN2(a, b)
#define CHECK_SIZE(T, size) \
    typedef char LAYOUT_CHECK_JOIN(layout_size_, T)[(sizeof(T) == (size)) ? 1 : -1]
#define CHECK_OFFSET(T, field, offset) \
    typedef char LAYOUT_CHECK_JOIN(LAYOUT_CHECK_JOIN(layout_offset_, T), __LINE__) \
        [((unsigned long)&((T *)0)->field == (offset)) ? 1 : -1]

#endif

/* end layout_check.h */

typedef struct AdxSjdHandle AdxSjdHandle;

typedef struct ADXStream ADXStream;

typedef struct AXRNAHandle AXRNAHandle;

typedef struct LSCObject LSCObject;

typedef struct ADX_AMP ADX_AMP;

typedef struct ADXTHandle {
    s8 used;
    s8 status;
    s8 stream_type;
    s8 maximum_channels;
    AdxSjdHandle *decoder;
    ADXStream *stream;
    AXRNAHandle *rna;
    SJ *stream_sj;
    SJ *input_sj;
    SJ *output_sj[2];
    u8 *input_buffer;
    s32 input_buffer_size;
    s32 input_extra_size;
    u8 *output_buffer;
    s32 output_buffer_size;
    s32 output_buffer_distance;
    s32 server_frequency;
    s16 stream_buffer_sectors;
    s16 minimum_buffer_sectors;
    s16 output_volume;
    s16 output_pan[2];
    s16 field_46;
    s32 maximum_decode_samples;
    s32 loop_count;
    s32 link_data_length;
    s32 field_54;
    s32 field_58;
    s32 field_5C;
    s16 error_code;
    u8 reserved_62[2];
    s32 field_64;
    s16 field_68;
    s16 field_6A;
    s8 stream_loop_enabled;
    s8 auto_receiver;
    u8 reserved_6E[2];
    s8 suppress_playback;
    s8 decoder_ready;
    s8 paused;
    u8 reserved_73;
    ADX_AMP *amplifier;
    SJ *amplifier_input[2];
    SJ *amplifier_output[2];
    s32 time_offset;
    s32 eos_sector;
    s32 loop_sample_count;
    LSCObject *linked_stream_controller;
    s8 link_enabled;
    u8 reserved_99[3];
    u32 playback_time;
    s32 playback_start_vsync;
    s32 linked_decoded_samples;
    s8 pending_stream_start;
    u8 reserved_A9[3];
    u8 *work_end;
    const char *pending_filename;
    void *pending_directory;
    s32 pending_file_offset;
    s32 pending_file_sectors;
} ADXTHandle;

CHECK_OFFSET(ADXTHandle, decoder, 0x4);
CHECK_OFFSET(ADXTHandle, output_volume, 0x40);
CHECK_OFFSET(ADXTHandle, error_code, 0x60);
CHECK_OFFSET(ADXTHandle, stream_loop_enabled, 0x6C);
CHECK_OFFSET(ADXTHandle, amplifier, 0x74);
CHECK_OFFSET(ADXTHandle, linked_stream_controller, 0x94);
CHECK_OFFSET(ADXTHandle, playback_time, 0x9C);
CHECK_OFFSET(ADXTHandle, pending_file_sectors, 0xBC);
CHECK_SIZE(ADXTHandle, 0xC0);

#endif

/* end sofdec/adxt.h */



typedef struct {
    u8 pad[0x94];
    u32 flags;
} GlobalState;

typedef struct Sig_fn_1_152840_Entry {
    s16 id;
    u8 pad[2];
    u32 flags;
} Sig_fn_1_152840_Entry;

struct E9C8 { u8 pad[10]; s8 id; u8 pad2; };

typedef struct {
    u8 pad_000[0x174];
    f32 unk_174;
    u8 pad_178[0x180];
    f32 unk_2F8;
    f32 unk_2FC;
} SelFloatPool;

typedef struct {
u32 unk_0; /* 11 loads, 6 stores */
u32 unk_4; /* 1 loads, 1 stores */
u32 unk_8; /* 4 loads, 1 stores */
u8 unk_C; /* 8 loads, 1 stores */
u8 unk_D; /* 5 loads, 4 stores */
u8 unk_E; /* 10 loads, 3 stores */
u8 unk_F; /* 3 loads, 12 stores */
u8 unk_10; /* 1 loads, 0 stores */
u8 unk_11; /* 2 loads, 1 stores */
u16 unk_12; /* 3 loads, 3 stores */
u8 unk_14; /* 2 loads, 2 stores */
u8 unk_15; /* 2 loads, 2 stores */
u8 unk_16; /* 2 loads, 2 stores */
u8 unk_17; /* 2 loads, 2 stores */
u32 unk_18; /* 1 loads, 1 stores */
u32 unk_1C; /* 1 loads, 1 stores */
u32 unk_20; /* 3 loads, 2 stores */
u8 pad_24[0x4];
u8 unk_28; /* 1 loads, 0 stores */
u8 pad_29[0xD];
u8 unk_36; /* 2 loads, 1 stores */
u8 unk_37; /* 0 loads, 1 stores */
u8 pad_38[0x2];
u8 unk_3A; /* 2 loads, 2 stores */
u8 unk_3B; /* 5 loads, 2 stores */
u32 unk_3C; /* 4 loads, 2 stores */
} Obj_4_bss_5680_Target;

struct fn_10_9788_lbl_1_bss_962 {
    s16 unk_0;
};

typedef struct {
    ADXTHandle *unk_0;
    ADXTHandle *unk_4;
    u8 pad_8[0x8];
    u8 unk_10[0x4A248];
    u8 unk_4A258[1];
} SelSound;

typedef struct {
    ADXTHandle *voice;
    ADXTHandle *bgm;
} SelAdxPair;

struct fn_4_D420_lbl_801A6410 {
u32 unk_0;
};

typedef struct {
    u8 pad[0x324];
    u32 a;
    u8 pad0[0x43c];
    u32 b;
    u8 pad1[0x43c];
    u32 c;
    u8 pad2[0x43c];
    u32 d;
    u8 pad3[0x43c];
    u32 e;
    u8 pad4[0x43c];
    u32 f;
    u8 pad5[0x43c];
    u32 g;
    u8 pad6[0x43c];
    u32 h;
    u8 tail[0x11c];
} SelBlock;

typedef struct Fn10BD64 {
    s16 unk0;
    s16 unk2;
    s16 value4;
    s16 value6;
    s16 unk8;
    u8 padA[0x8A];
    u32 flags94;
} Fn10BD64;

typedef struct Entry9C8 {
    u8 pad_0[0xA];
    s8 field_A;
    u8 pad_B[1];
} Entry9C8;

struct fn_10_73AC_S9C8 { u8 pad[10]; s8 status; u8 padB; };

struct fn_10_8F0C_S9C8 {
    u8 pad0[0xa];
    s8 unk_A;
    u8 pad1[1];
};

struct ControllerState { u8 pad_0[10]; s8 unk_A; u8 pad_B; };

struct fn_10_CB20_S9C8 {
    u8 pad0[0xa];
    s8 fa;
    u8 pad1;
};

typedef struct SelContext {
    u8 pad[0xa4];
    u8 *entries;
} SelContext;

typedef struct fn_10_AB98_SelCursor {
    u8 pad_0[0x8C];
    s16 unk_8C;
    s16 unk_8E;
    s16 unk_90;
    u8 pad_92[2];
    u32 unk_94;
} fn_10_AB98_SelCursor;

typedef struct SelOwner {
    unsigned char pad_00A4[0xA4];
    void *entries;
} SelOwner;

typedef struct {
    u8 _pad_00[0xa4];
    u8 *entries;
} fn_10_C274_SelObject;

typedef struct fn_10_C298_SelObject {
    u8 _pad_a4[0xa4];
    u8 *entries;
} fn_10_C298_SelObject;

typedef struct {
    u8 pad[4];
    u32 flags;
} fn_10_3A98_SelSlot;

typedef struct { s16 key; u16 pad; u32 mask; } Sig_fn_1_152970_Fn152970Entry;

typedef struct fn_10_3DE0_SelObject {
    u8 pad000[0x390];
    u32 flags390;               /* 0x390 */
    u8 pad394[0xc];
    void *data3a0;              /* 0x3a0 */
    u32 result3a4;              /* 0x3a4 */
    u8 pad3a8[0x12];
    s16 slot3ba;                /* 0x3ba */
} fn_10_3DE0_SelObject;

typedef struct fn_10_3DE0_SelResult {
    fn_10_3DE0_SelObject *object;          /* 0x0 */
    u8 kind4;                   /* 0x4 */
    u8 pad05[0x10420 - 0x5];
    u32 zero10420;              /* 0x10420 */
    void (*cb10424)(void);      /* 0x10424 */
    void (*cb10428)(void);      /* 0x10428 */
    void (*cb1042c)(void);      /* 0x1042c */
} fn_10_3DE0_SelResult;

typedef struct fn_10_3DE0_SelEntry {
    u32 flags;                  /* 0x0 */
    u8 pad04;                   /* 0x4 */
    u8 value5;                  /* 0x5 */
    u8 pad06;                   /* 0x6 */
    u8 type7;                   /* 0x7 */
    u8 pad08[0x81a0 - 0x8];
    u8 source_index;            /* 0x81a0 */
    u8 pad81a1[0x81c0 - 0x81a1];
} fn_10_3DE0_SelEntry;

typedef struct {
    f64 unk_0;
} Sig_fn_1_B7F58_Result;

typedef struct {
    u32 unk_0;
    u32 unk_4;
} fn_10_12C14_SelResult;

typedef struct {
    s16 unk0;
    u8 pad2[2];
    s16 field4;
    s16 field6;
    s16 field8;
    u8 padA[0x8A];
    u32 flags;
} fn_10_BEF8_SelState;

typedef struct {
    u32 flags;
    u8 pad[0x81bc];
} fn_10_948C_SelEntry;

struct NavigationTable { s16 entry[12][8]; };

typedef struct PanelPacket {
    u32 id;
    f32 x, y, z;
    u8 pad_10[0x1c];
    f32 alpha;
    u32 mode;
    u32 unknown_34;
    u8 color[4];
    u8 pad_3c[0x1c];
} PanelPacket;

typedef struct {
    u8 r, g, b, a;
} fn_10_107D4_SelColor;

typedef struct {
    u32 image;
    f32 x, y, z;
    f32 scale_x, scale_y;
    f32 u0, v0, u1, v1;
    s16 rotation_z, rotation_y;
    f32 alpha;
    u32 flags;
    f32 depth;
    fn_10_107D4_SelColor color;
    fn_10_107D4_SelColor color_add;
    u32 format;
    u16 width, height;
    void *pixels;
    void *secondary;
    void *vertex_callback;
    u32 unk_54;
} fn_10_107D4_SelFontPacket;

typedef struct {
    u32 unk_00;
    f32 unk_04;
    f32 unk_08;
    f32 unk_0C;
    u8 pad_10[0x20];
    u32 unk_30;
    u8 pad_34[0x24];
} fn_10_10CA8_SelFontPacket;

typedef struct {
    u32 unk_00;
    f32 unk_04;
    f32 unk_08;
    f32 unk_0C;
    u8 pad_10[0x20];
    u32 unk_30;
    u8 pad_34[0x24];
} fn_10_10D2C_SelFontPacket;

typedef struct {
    u32 unk_00;
    f32 unk_04;
    f32 unk_08;
    f32 unk_0C;
    u8 pad_10[0x20];
    u32 unk_30;
    u8 pad_34[0x24];
} fn_10_10DB0_SelFontPacket;

struct fn_10_19F70_Copy88 { u32 a[22]; };

struct fn_10_13D64_lbl_10_rodata_158 {
    u8 pad_0[0x58];
    f32 unk_58;
    u8 pad_5C[0x134];
    f32 unk_190;
    u8 pad_194[0xC4];
    f32 unk_258;
    u8 pad_25C[0x34];
    f32 unk_290;
    u8 pad_294[0x208];
    f32 unk_49C;
};

struct fn_10_13E18_lbl_10_rodata_158 {
    u8 pad_0[0x58];
    f32 unk_58;
    u8 pad_5C[0x134];
    f32 unk_190;
    u8 pad_194[0xC4];
    f32 unk_258;
    u8 pad_25C[0x34];
    f32 unk_290;
    u8 pad_294[0x208];
    f32 unk_49C;
};

struct fn_10_1BCD0_lbl_10_rodata_158 {
    u8 pad_0[0x48];
    f32 unk_48;
    f32 unk_4C;
    u8 pad_50[0x8];
    f32 unk_58;
    u8 pad_5C[0xF4];
    f32 unk_150;
    u8 pad_154[0x23C];
    f32 unk_390;
    u8 pad_394[0x10C];
    f32 unk_4A0;
    u8 pad_4A4[0x388];
    f32 unk_82C;
    u8 pad_830[0x7A8];
    u32 unk_FD8;
    u32 unk_FDC;
    u32 unk_FE0;
    u32 unk_FE4;
    f32 unk_FE8;
    f32 unk_FEC;
    f32 unk_FF0;
};

struct fn_10_1E398_lbl_10_rodata_158 {
    u8 pad_0[0x174];
    f32 unk_174;
    u8 pad_178[0x180];
    f32 unk_2F8;
    f32 unk_2FC;
};

struct fn_10_1E67C_lbl_10_rodata_158 {
    u8 pad_0[0x48];
    f32 unk_48;
    u8 pad_4C[0xC];
    f32 unk_58;
    u8 pad_5C[0xBC];
    f32 unk_118;
    u8 pad_11C[0xEE4];
    f32 unk_1000;
};

typedef struct { u8 pad_0[4]; s16 unk_4,unk_6,unk_8; u8 pad_A[0x9A]; u8 *items; } Panel;

struct fn_10_18A50_Arg0 {
    u8 pad_0[0x8C];
    s16 unk_8C;
    u8 pad_8E[0x10];
    u8 unk_9E;
    u8 pad_9F[0x41];
    u32 unk_E0[4];
};

typedef struct {
    u8 pad_0[0x30];
    u16 unk_30;
    u16 unk_32;
    u32 unk_34;
    u8 pad_38[0xC];
    f32 unk_44;
    u8 pad_48[0x18];
    u32 unk_60;
    u8 pad_64[0x19C];
} SelView;

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} SelVec3;

struct Arg0 {
    u32 unk_0;
    u32 unk_4;
    u32 unk_8;
    u32 unk_C;
    u32 unk_10;
    u8 pad_14[0x10];
    u16 unk_24[6];
    u16 unk_30[6];
    u8 unk_3C[1];
};

typedef struct Sig_parse_format_MkVaListState {
    signed char gpr;
    signed char fpr;
    unsigned short reserved;
    char *input_arg_area;
    char *reg_save_area;
} Sig_parse_format___va_list[1];

typedef Sig_parse_format___va_list Sig_parse_format_va_list;

typedef struct {
    u32 value;
    u8 pad[0x1a - 4];
    u8 type;
    u8 pad1b;
    u8 field_1c;
    u8 field_1d;
    u8 field_1e;
    u8 field_1f;
} fn_10_2287C_SelObject;

struct fn_8_D630_rodata {
u8 pad_0[0x6A8];
f64 unk_6A8;
f64 unk_6B0;
f64 unk_6B8;
f32 unk_6C0;
f32 unk_6C4;
f64 unk_6C8;
f32 unk_6D0;
u8 pad_6D4[0x4];
f64 unk_6D8;
f64 unk_6E0;
f32 unk_6E8;
f32 unk_6EC;
f64 unk_6F0;
f64 unk_6F8;
};

typedef struct { u32 value; } EntryColor;

struct fn_8_D630_obj {
u8 unk_0;
u8 unk_1;
u8 unk_2;
u8 unk_3;
u16 unk_4;
u16 unk_6;
u16 unk_8;
u16 unk_A;
u8 unk_C;
u32 unk_D;
};
extern s16 lbl_1_bss_962;
extern s16 lbl_1_bss_968;
extern u32 *lbl_1_bss_6EAD0;
extern u32 lbl_801A6410;
extern void fn_10_95A0(SelBlock *data);
extern void fn_10_96F8(void *, void *);
extern void fn_10_D2C(void);
extern void fn_1_46B4(u32 arg0, u32 arg1, const char *arg2, int arg3);
extern u32 fn_1_435C(u32 value);
extern void fn_1_41A8(void);
extern void fn_1_6400(void);
extern void fn_1_46BFC(void);
extern s32 fn_1_46DC4(s32 value);
extern u32 fn_8004BF0C(u32 arg0, u32 arg1);
extern void fn_1_A0AA4(void);
extern void fn_1_1596DC(int index);
extern void fn_1_47A60(s16 index);
extern void fn_1_484CC(s32 index);
extern void fn_1_48140(int index);
extern void fn_1_412A0(u32 index);
extern s16 lbl_1_bss_964;
extern void fn_10_E294(void);
extern s32 fn_1_3F8C(u32 arg3, u32 arg0, u32 arg1, u32 index);
extern void fn_1_4A00(s32 fadeIn, u8 steps, u32 arg);
extern ADXTHandle *fn_8004CD70(s32 arg0, void *arg1, s32 arg2);
extern u32 fn_1_A176C(ADXTHandle *, u32);
extern void fn_1_12F1E8(s32 value);
extern u32 fn_1_426C(u32);
extern void fn_10_BD64(Fn10BD64 *self);
extern void fn_10_C594(void);
extern u8 lbl_1_bss_9C8[];
extern u16 lbl_1_bss_96A;
extern u8 lbl_1_bss_8CA24;
extern int fn_1_4C10(void);
extern int fn_1_D6690(void);
extern int fn_1_D6698(void);
extern s16 fn_10_3D64(void);
extern s16 fn_10_C258(SelContext *self, s32 index);
extern void fn_10_A90C(void *arg0);
extern void fn_10_AB98(fn_10_AB98_SelCursor *cursor);
extern u32 fn_10_AE14(void *obj);
extern s32 fn_1_12F228(void);
extern s32 fn_1_EB4BC(void);
extern u8 fn_1_B7C00(void);
extern void fn_10_C210(SelOwner *owner, int index);
extern void fn_10_C274(fn_10_C274_SelObject *object, int index);
extern void fn_10_C298(fn_10_C298_SelObject *self, int index);
extern void fn_1_12EF80(u32, void *, void *);
extern void fn_1_12F150(s16 index, u32 value_100, u32 value_110);
extern void fn_1_12F17C(void);
extern void fn_1_159440(int index, int flag);
extern void fn_1_46A60(void);
extern void fn_1_7B218(s32 enabled);
extern void fn_1_7B2E8(u32);
extern void fn_1_A2D84(u32 arg0);
extern void fn_1_A51C8(s16 index);
extern void fn_1_EB330(void);
extern u8 lbl_10_bss_51748[6];
extern void fn_1_EC910(void);
extern void fn_1_7B4C0(void);
extern void fn_10_BEF0();
extern s32 fn_1_128B00(s16 value);
extern s16 fn_1_14F270(s16 wanted, void *arg, u32 mask);
extern u32 fn_1_151BE8(s16 arg0, s16 arg1);
extern void fn_1_152970(s16 *, s16 *, s32, s32, fn_10_3A98_SelSlot *, s16, s16);
extern int lbl_1_bss_7180C;
extern int fn_1_B7E98(int index);
extern void fn_1_13F848(u32 arg0);
extern u32 fn_1_13F974(u32 slot_arg);
extern u32 fn_1_13F8B0(u32 key);
extern u32 fn_1_13F9DC(u32 slot);
extern void *fn_1_7F254(void *arg0, void *arg1);
extern void fn_1_FD324(void);
extern void fn_1_FDC00(void);
extern void fn_1_FD27C(void);
extern u32 fn_1_FD844(fn_10_3DE0_SelEntry *, void *);
extern void fn_1_4BB0(void);
extern void fn_1_12C0EC(void *);
extern void fn_10_BEF4();
extern void fn_1_12C000(void *, s32);
extern u8* fn_1_36AD0(void);
extern void fn_1_12F10C();
extern void fn_1_12AF7C(void);
extern void fn_1_A5330(u8 value, s16 index);
extern void fn_1_13F8C4();
extern void fn_1_13F9F0(void);
extern void fn_1_FDFF4(void);
extern u32 lbl_801A66C0;
extern s32 fn_1_467F4(void);
extern u32 fn_1_15BBC4(void);
extern int fn_1_B7F58(Sig_fn_1_B7F58_Result *);
extern u8 fn_10_26000(void);
extern void fn_1_14BD44(void *arg0, void *arg1);
extern void fn_10_260D4(void);
extern int fn_1_152840(s16, Sig_fn_1_152840_Entry *, s16, s16);
extern u32 lbl_1_bss_980[];
extern s16 lbl_1_bss_966;
extern s16 fn_10_4AE0(s16 player, s16 count);
extern void fn_80008BEC(void *dest, int value, u32 size);
extern void fn_80008BA8(u32 arg0, u32 arg1, u32 arg2);
extern u32 fn_10_13D64(u32 arg0, f32 arg1);
extern void fn_10_BEF8(fn_10_BEF8_SelState *state);
extern int fn_1_13FB24(u32 arg0);
extern u32 fn_1_F9FEC(void);
extern u32 lbl_801A66A8;
extern void fn_1_12F128(s16 index);
extern u32 fn_1_13FA88(s16 arg0);
extern void fn_10_CF30(u32);
extern void fn_10_25CB0(void);
extern s32 fn_10_25888(void);
extern void fn_10_25BC8(void);
extern void fn_10_1B684(void);
extern u8 lbl_10_bss_55600__fzgx_offset_1[7];
extern u8 lbl_10_bss_55600;
extern int fn_1_D66A8(void);
extern int fn_1_D66A0();
extern s32 fn_1_12F258(void);
extern void fn_1_14DB48(u32 *state, void *arg1, u32 arg2);
extern u32 lbl_10_data_564[];
extern void fn_1_12A2B8(u32 value);
extern void fn_1_12A2D0(s32 value);
extern void fn_1_12C5E4(void *value);
extern void fn_1_12A734(s32 idx);
extern void fn_80071718(void *value);
extern void *lbl_1_bss_6D82C;
extern void fn_1_14DBCC(void *);
extern struct NavigationTable lbl_10_rodata_94;
extern void fn_1_A2A70(u32 flags, s32 n);
extern int fn_1_D6680(void);
extern void fn_1_D66F4(void);
extern void fn_10_CFAC(u32, u32, u32, u32);
extern s16 lbl_10_bss_55608;
extern u32 fn_1_FA070(void);
extern u32 fn_1_FA0BC(s32 mode);
extern s16 fn_1_12EF24(s16 row, s16 column);
extern s32 fn_1_F89E4(u8);
extern u32 fn_1_4630();
extern void fn_1_130EE8(u32 arg0, u32 arg1);
extern u32 fn_1_1317B4(void);
extern int fn_1_B7C5C(void);
extern void fn_1_131004(void);
extern void fn_1_451E4(void);
extern void fn_1_3308(void);
extern void fn_1_D3214(void);
extern void VIWaitForRetrace(void);
extern s32 fn_1_13018(void);
extern s32 fn_8006FDEC(void);
extern u32 fn_1_4404(void *obj);
extern u32 fn_80008E84(u32 arg0);
extern u32 fn_1_46C60(void);
extern u32 lbl_10_bss_55664;
extern u8 lbl_1_bss_718E0;
extern s32 fn_1_B7C6C(u32 arg0);
extern u32 fn_1_B7CD4(void);
extern void fn_1_F79C8(void);
extern void fn_1_B7F24(void);
extern void fn_1_AA6D8(u32, u32, void *);
extern void fn_10_CEC4(u32);
extern u32 fn_10_13E18(u32 arg0, f32 arg1);
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern FontDrawPacket lbl_1_rodata_26F8;
extern u16 fn_1_48690(u32 unused);
extern f32 lbl_8006D188(s32);
extern f32 lbl_10_rodata_158[];
extern s32 lbl_801A66B4;
extern u32 fn_1_535A0(void *, f32,f32,f32,f32,f32,f32);
extern void fn_1_49514(u32 *value);
extern int sprintf(char *s, const char *format, ...);
extern void fn_1_496FC();
extern void fn_1_4955C();
extern void fn_1_14083C(s32, s32, f32, f32, s32, s32, s32);
extern void fn_10_E034(Panel *arg);
extern void fn_10_E600(void);
extern void fn_10_D044(void);
extern void fn_10_D5D4(void);
extern void fn_10_DAF8(void);
extern void fn_10_E45C(void);
extern u32 lbl_80000000;
extern void fn_1_134AD4(void);
extern void fn_10_13ECC(void);
extern void fn_10_10C24(void);
extern u32 fn_10_21C20(s16 row, s16 column);
extern void fn_1_1380F0();
extern void fn_1_133DBC(void* arg0);
extern int fn_10_91E8(void);
extern void fn_1_13ABA8(u32);
extern void fn_1_49410();
extern void fn_1_495B0(u32 value);
extern void fn_1_495C8(u8 value);
extern u32 lbl_10_bss_55688;
extern s32 lbl_10_bss_55684;
extern void fn_1_13D02C(void);
extern void fn_1_13B328(u32 arg0, s32 arg1);
extern void fn_1_50164();
extern void fn_1_50A90(void *,u32,u32,u32,u32);
extern void fn_1_4954C(f32 value);
extern void fn_1_495FC(void);
extern void fn_1_4966C(f32 value1, f32 value2);
extern void fn_10_F050(s32, s32);
extern u16 fn_1_486C4(u32 value);
extern s16 lbl_1_bss_8CA26;
extern void fn_10_FF54(void);
extern void fn_10_10168(void);
extern void *lbl_1_data_418D4[];
extern void fn_10_12C14(void);
extern void fn_10_19040(void);
extern void fn_10_1973C(void);
extern void fn_10_21C44(s32);
extern void fn_10_12024(void);
extern void fn_1_13DA0C(void);
extern void fn_1_13DC54(void);
extern void fn_1_13DDB8(void);
extern void fn_10_117D0(void);
extern void fn_10_10DB0(void);
extern void fn_10_18A50(struct fn_10_18A50_Arg0 *param0, u32 param1);
extern void fn_10_21DA8(void);
extern void fn_1_134EE4(s32 arg0, s32 arg1, s32 arg2, f32 farg0);
extern void fn_1_135894(void* arg0, void* arg1, void* arg2, void* arg3, void* arg4, void* arg5, void* arg6, f32 arg7, f32 arg8);
extern void fn_1_136174(s32,s32,s32,s32,s16,s32,s32,f32,f32);
extern void fn_1_13EDDC(u32 arg0, u32 arg1, u32 arg2, u32 arg3, s32 arg4);
extern void fn_1_1363F0(s16 arg0, s32 arg1, s32 arg2);
extern void fn_1_1368A0(s32 arg0, s16 arg1, s32 arg2, f32 farg0, f32 farg1, f32 farg2, f32 farg3, f32 farg4);
extern u32 fn_1_4CAC(void);
extern f32 fn_1_4C24(void);
extern void fn_1_4CDE4(f32 *x, f32 *y);
extern void *fn_1_7F49C(s16 arg0, s16 arg1, void *arg2);
extern void fn_1_4B040(s32 value);
extern void fn_10_FBEC(void *, f32, f32, f32, f32);
extern void fn_1_133968(void);
extern s16 fn_10_0(int first, int second, int third, int fourth);
extern void fn_10_10E34(void);
extern s32 fn_1_A5DC4(void);
extern void fn_1_13A848(s16 arg0, s16 arg1, void* arg2, void* arg3, int arg4, f32 arg5, f32 arg6);
extern void fn_1_13A9B8(s32, s16, s32, s16, s16, u32, s32, f32, f32);
extern void fn_10_19308(void);
extern void fn_10_107D4(void);
extern u8 fn_1_141F94(u32 arg0);
extern void fn_10_19F70(u32 arg0, u8 arg1);
extern void fn_10_13B24(s16, u8, u32);
extern void fn_10_1A458(void);
extern void fn_10_18DD0(void);
extern void fn_10_111E8(void);
extern void fn_1_133DE0(void* arg0);
extern void fn_10_139E4(void);
extern void fn_1_508C4(fn_10_107D4_SelFontPacket *, f32, f32);
extern u8 lbl_1_bss_8CA28;
extern u32 lbl_10_bss_51788[25];
extern u32 fn_10_13128(void *);
extern void fn_1_8D1C8(void *, void *, void *);
extern s32 fn_1_4FC50(FontDrawPacket *, u32, u16, u16, u32);
extern f32 lbl_10_rodata_5D0[990];
extern f32 lbl_10_rodata_3AC[119];
extern const f64 lbl_10_rodata_1E0;
extern void fn_1_51564(u16 first, u16 second, u16 third, u16 fourth, u16 fifth, u16 sixth);
extern u32 fn_1_5158C(FontDrawPacket *, u32, s16, s16);
extern u32 fn_1_53C9C(u32, u32, f32, f32, f32, f32, f32);
extern void fn_10_1C2D8(struct Arg0 *arg0);
extern const f32 lbl_10_rodata_1A4[15];
extern const f32 lbl_10_rodata_588;
extern const f64 lbl_10_rodata_1E8;
extern s16 fn_1_12F028(s16 value);
extern s16 lbl_10_bss_55AE0;
extern u32 fn_10_18C54(u32, u32, f32, u32);
extern u32 lbl_801A66A0;
extern void fn_800736C0(int, void *);
extern void fn_80073620(s32 index, s32 value);
extern void fn_80072CC4(s32 arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4);
extern void fn_80072E20(s32 arg0, s32 arg1, s32 arg2, s32 arg3, u8 arg4, s32 arg5);
extern void fn_10_12E34(void);
extern u32 fn_10_19924(void *);
extern s16 fn_1_12C7B8(s16 arg);
extern void fn_1_51914(void *);
extern void fn_1_51990(void *obj);
extern void fn_1_8CED0(void *, u16, u16);
extern void fn_10_19C90(void);
extern f32 fn_1_520F8(s32 value);
extern f32 fn_1_521B8(s32 value);
extern u16 fn_1_A5DB0(void);
extern u32 fn_10_19EC8(void *);
extern u32 fn_10_19F1C(void *);
extern void fn_10_1B6CC(void);
extern s32 fn_8008077C(u32 arg0, u32 arg1, u32 arg2);
extern void fn_1_49590();
extern void fn_1_4CE48(Obj_1_bss_4B9CC *obj, f32 limit);
extern u8 fn_10_13ECC__fzgx_offset_938[];
extern u8 fn_10_13ECC__fzgx_offset_940[];
extern u8 fn_10_13ECC__fzgx_offset_948[];
extern u8 fn_10_13ECC__fzgx_offset_950[];
extern u8 fn_10_13ECC__fzgx_offset_958[];
extern u8 fn_10_13ECC__fzgx_offset_960[];
extern u8 fn_10_13ECC__fzgx_offset_968[];
extern u8 fn_10_13ECC__fzgx_offset_970[];
extern u8 fn_10_13ECC__fzgx_offset_978[];
extern u8 fn_10_13ECC__fzgx_offset_980[];
extern u8 fn_10_13ECC__fzgx_offset_984[];
extern u8 lbl_10_data_1038__fzgx_offset_0[];
extern u8 lbl_10_data_103C__fzgx_offset_0[];
extern u8 lbl_10_data_10D0__fzgx_offset_0[];
extern u8 lbl_10_data_10F8__fzgx_offset_0[];
extern u8 lbl_10_data_1128__fzgx_offset_0[];
extern u8 lbl_10_data_1158__fzgx_offset_0[];
extern u8 lbl_10_data_1180__fzgx_offset_0[];
extern u8 lbl_10_data_11B8__fzgx_offset_0[];
extern u8 lbl_10_data_11CC__fzgx_offset_0[];
extern u8 lbl_10_data_11E8__fzgx_offset_0[];
extern u8 lbl_10_data_11F8__fzgx_offset_0[];
extern u8 lbl_10_data_1214__fzgx_offset_0[];
extern u8 lbl_10_data_1228__fzgx_offset_0[];
extern u8 lbl_10_data_1244__fzgx_offset_0[];
extern u8 lbl_10_data_1260__fzgx_offset_0[];
extern u8 lbl_10_data_1290__fzgx_offset_0[];
extern u8 lbl_10_data_12A8__fzgx_offset_0[];
extern u8 lbl_10_data_12C4__fzgx_offset_0[];
extern u8 lbl_10_data_1320__fzgx_offset_0[];
extern u8 lbl_10_data_1380__fzgx_offset_0[];
extern u8 lbl_10_data_13D0__fzgx_offset_0[];
extern u8 lbl_10_data_1418__fzgx_offset_0[];
extern u8 lbl_10_data_1424__fzgx_offset_0[];
extern u8 lbl_10_data_143C__fzgx_offset_0[];
extern u8 lbl_10_data_1464__fzgx_offset_0[];
extern u8 lbl_10_data_1490__fzgx_offset_0[];
extern u8 lbl_10_data_14B0__fzgx_offset_0[];
extern u8 lbl_10_data_14CC__fzgx_offset_0[];
extern u8 lbl_10_data_14E0__fzgx_offset_0[];
extern u8 lbl_10_data_14FC__fzgx_offset_0[];
extern u8 lbl_10_data_1514__fzgx_offset_0[];
extern u8 lbl_10_data_152C__fzgx_offset_0[];
extern u8 lbl_10_data_1538__fzgx_offset_0[];
extern u8 lbl_10_data_1548__fzgx_offset_0[];
extern u8 lbl_10_data_155C__fzgx_offset_0[];
extern u8 lbl_10_data_1574__fzgx_offset_0[];
extern u8 lbl_10_data_15C8__fzgx_offset_0[];
extern u8 lbl_10_data_161C__fzgx_offset_0[];
extern u8 lbl_10_data_16D0__fzgx_offset_0[];
extern u8 lbl_10_data_17A0__fzgx_offset_0[];
extern u8 lbl_10_data_1804__fzgx_offset_0[];
extern u8 lbl_10_data_1888__fzgx_offset_0[];
extern u8 lbl_10_data_18C0__fzgx_offset_0[];
extern u8 lbl_10_data_1908__fzgx_offset_0[];
extern u8 lbl_10_data_1958__fzgx_offset_0[];
extern u8 lbl_10_data_19B8__fzgx_offset_0[];
extern u8 lbl_10_data_19C0__fzgx_offset_0[];
extern u8 lbl_10_data_19E8__fzgx_offset_0[];
extern u8 lbl_10_data_1A0C__fzgx_offset_0[];
extern u8 lbl_10_data_1A18__fzgx_offset_0[];
extern u8 lbl_10_data_1A24__fzgx_offset_0[];
extern u8 lbl_10_data_1A2C__fzgx_offset_0[];
extern u8 lbl_10_data_1A58__fzgx_offset_0[];
extern u8 lbl_10_data_1A88__fzgx_offset_0[];
extern u8 lbl_10_data_1AB8__fzgx_offset_0[];
extern u8 lbl_10_data_1AE8__fzgx_offset_0[];
extern u8 lbl_10_data_1B18__fzgx_offset_0[];
extern u8 lbl_10_data_1B48__fzgx_offset_0[];
extern u8 lbl_10_data_1B5C__fzgx_offset_0[];
extern u8 lbl_10_data_1B74__fzgx_offset_0[];
extern u8 lbl_10_data_1B8C__fzgx_offset_0[];
extern u8 lbl_10_data_1BA4__fzgx_offset_0[];
extern u8 lbl_10_data_1BBC__fzgx_offset_0[];
extern u8 lbl_10_data_1BD4__fzgx_offset_0[];
extern u8 lbl_10_data_1BEC__fzgx_offset_0[];
extern u8 lbl_10_data_1C08__fzgx_offset_0[];
extern u8 lbl_10_data_1C24__fzgx_offset_0[];
extern u8 lbl_10_data_1C40__fzgx_offset_0[];
extern u8 lbl_10_data_1C5C__fzgx_offset_0[];
extern u8 lbl_10_data_1C70__fzgx_offset_0[];
extern u8 lbl_10_data_1C94__fzgx_offset_0[];
extern u8 lbl_10_data_1CBC__fzgx_offset_0[];
extern u8 lbl_10_data_1CE4__fzgx_offset_0[];
extern u8 lbl_10_data_1D0C__fzgx_offset_0[];
extern u8 lbl_10_data_1D34__fzgx_offset_0[];
extern u8 lbl_10_data_1D54__fzgx_offset_0[];
extern u8 lbl_10_data_1D5C__fzgx_offset_0[];
extern u8 lbl_10_data_1D68__fzgx_offset_0[];
extern u8 lbl_10_data_1D74__fzgx_offset_0[];
extern u8 lbl_10_data_1D80__fzgx_offset_0[];
extern u8 lbl_10_data_1D8C__fzgx_offset_0[];
extern u8 lbl_10_data_1D98__fzgx_offset_0[];
extern u8 lbl_10_data_1DA0__fzgx_offset_0[];
extern u8 lbl_10_data_1DAC__fzgx_offset_0[];
extern u8 lbl_10_data_1DB8__fzgx_offset_0[];
extern u8 lbl_10_data_1DC4__fzgx_offset_0[];
extern u8 lbl_10_data_1DD0__fzgx_offset_0[];
extern u8 lbl_10_data_1DDC__fzgx_offset_0[];
extern u8 lbl_10_data_1DF4__fzgx_offset_0[];
extern u8 lbl_10_data_1E10__fzgx_offset_0[];
extern u8 lbl_10_data_1E2C__fzgx_offset_0[];
extern u8 lbl_10_data_1E48__fzgx_offset_0[];
extern u8 lbl_10_data_1E64__fzgx_offset_0[];
extern u8 lbl_10_data_2288__fzgx_offset_0[];
extern u8 lbl_10_data_2294__fzgx_offset_0[];
extern u8 lbl_10_data_22A4__fzgx_offset_0[];
extern u8 lbl_10_data_22B4__fzgx_offset_0[];
extern u8 lbl_10_data_22C4__fzgx_offset_0[];
extern u8 lbl_10_data_22D4__fzgx_offset_0[];
extern u8 lbl_10_data_22E4__fzgx_offset_0[];
extern u8 lbl_10_data_22F0__fzgx_offset_0[];
extern u8 lbl_10_data_2300__fzgx_offset_0[];
extern u8 lbl_10_data_2310__fzgx_offset_0[];
extern u8 lbl_10_data_2320__fzgx_offset_0[];
extern u8 lbl_10_data_2330__fzgx_offset_0[];
extern u8 lbl_10_data_233C__fzgx_offset_0[];
extern u8 lbl_10_data_2348__fzgx_offset_0[];
extern u8 lbl_10_data_2358__fzgx_offset_0[];
extern u8 lbl_10_data_2368__fzgx_offset_0[];
extern u8 lbl_10_data_2378__fzgx_offset_0[];
extern u8 lbl_10_data_2388__fzgx_offset_0[];
extern u8 lbl_10_data_2394__fzgx_offset_0[];
extern u8 lbl_10_data_23A0__fzgx_offset_0[];
extern u8 lbl_10_data_23B0__fzgx_offset_0[];
extern u8 lbl_10_data_23C0__fzgx_offset_0[];
extern u8 lbl_10_data_23D0__fzgx_offset_0[];
extern u8 lbl_10_data_23E0__fzgx_offset_0[];
extern u8 lbl_10_data_23F0__fzgx_offset_0[];
extern u8 lbl_10_data_23FC__fzgx_offset_0[];
extern u8 lbl_10_data_240C__fzgx_offset_0[];
extern u8 lbl_10_data_241C__fzgx_offset_0[];
extern u8 lbl_10_data_242C__fzgx_offset_0[];
extern u8 lbl_10_data_243C__fzgx_offset_0[];
extern u8 lbl_10_data_244C__fzgx_offset_0[];
extern u8 lbl_10_data_2454__fzgx_offset_0[];
extern u8 lbl_10_data_2460__fzgx_offset_0[];
extern u8 lbl_10_data_246C__fzgx_offset_0[];
extern u8 lbl_10_data_2478__fzgx_offset_0[];
extern u8 lbl_10_data_2484__fzgx_offset_0[];
extern u8 lbl_10_data_2490__fzgx_offset_0[];
extern u8 lbl_10_data_249C__fzgx_offset_0[];
extern u8 lbl_10_data_24AC__fzgx_offset_0[];
extern u8 lbl_10_data_24BC__fzgx_offset_0[];
extern u8 lbl_10_data_24CC__fzgx_offset_0[];
extern u8 lbl_10_data_24DC__fzgx_offset_0[];
extern u8 lbl_10_data_24EC__fzgx_offset_0[];
extern u8 lbl_10_data_24F4__fzgx_offset_0[];
extern u8 lbl_10_data_2500__fzgx_offset_0[];
extern u8 lbl_10_data_250C__fzgx_offset_0[];
extern u8 lbl_10_data_2518__fzgx_offset_0[];
extern u8 lbl_10_data_2524__fzgx_offset_0[];
extern u8 lbl_10_data_2530__fzgx_offset_0[];
extern u8 lbl_10_data_2538__fzgx_offset_0[];
extern u8 lbl_10_data_2544__fzgx_offset_0[];
extern u8 lbl_10_data_2550__fzgx_offset_0[];
extern u8 lbl_10_data_255C__fzgx_offset_0[];
extern u8 lbl_10_data_2568__fzgx_offset_0[];
extern u8 lbl_10_data_2574__fzgx_offset_0[];
extern u8 lbl_10_data_2584__fzgx_offset_0[];
extern u8 lbl_10_data_2598__fzgx_offset_0[];
extern u8 lbl_10_data_25AC__fzgx_offset_0[];
extern u8 lbl_10_data_25C0__fzgx_offset_0[];
extern u8 lbl_10_data_25D4__fzgx_offset_0[];
extern u8 lbl_10_data_25E4__fzgx_offset_0[];
extern u8 lbl_10_data_25F0__fzgx_offset_0[];
extern u8 lbl_10_data_2600__fzgx_offset_0[];
extern u8 lbl_10_data_2614__fzgx_offset_0[];
extern u8 lbl_10_data_262C__fzgx_offset_0[];
extern u8 lbl_10_data_2638__fzgx_offset_0[];
extern u8 lbl_10_data_2648__fzgx_offset_0[];
extern u8 lbl_10_data_2654__fzgx_offset_0[];
extern u8 lbl_10_data_2664__fzgx_offset_0[];
extern u8 lbl_10_data_2674__fzgx_offset_0[];
extern u8 lbl_10_data_2684__fzgx_offset_0[];
extern u8 lbl_10_data_2694__fzgx_offset_0[];
extern u8 lbl_10_data_26A4__fzgx_offset_0[];
extern u8 lbl_10_data_26AC__fzgx_offset_0[];
extern u8 lbl_10_data_26B8__fzgx_offset_0[];
extern u8 lbl_10_data_26C4__fzgx_offset_0[];
extern u8 lbl_10_data_26D0__fzgx_offset_0[];
extern u8 lbl_10_data_26DC__fzgx_offset_0[];
extern u8 lbl_10_data_26EC__fzgx_offset_0[];
extern u8 lbl_10_data_26F4__fzgx_offset_0[];
extern u8 lbl_10_data_2700__fzgx_offset_0[];
extern u8 lbl_10_data_270C__fzgx_offset_0[];
extern u8 lbl_10_data_2718__fzgx_offset_0[];
extern u8 lbl_10_data_2724__fzgx_offset_0[];
extern u8 lbl_10_data_2730__fzgx_offset_0[];
extern u8 lbl_10_data_273C__fzgx_offset_0[];
extern u8 lbl_10_data_274C__fzgx_offset_0[];
extern u8 lbl_10_data_275C__fzgx_offset_0[];
extern u8 lbl_10_data_276C__fzgx_offset_0[];
extern u8 lbl_10_data_277C__fzgx_offset_0[];
extern u8 lbl_10_data_278C__fzgx_offset_0[];
extern u8 lbl_10_data_2794__fzgx_offset_0[];
extern u8 lbl_10_data_27A0__fzgx_offset_0[];
extern u8 lbl_10_data_27AC__fzgx_offset_0[];
extern u8 lbl_10_data_27B8__fzgx_offset_0[];
extern u8 lbl_10_data_27C4__fzgx_offset_0[];
extern u8 lbl_10_data_27D4__fzgx_offset_0[];
extern u8 lbl_10_data_27DC__fzgx_offset_0[];
extern u8 lbl_10_data_27E8__fzgx_offset_0[];
extern u8 lbl_10_data_27F4__fzgx_offset_0[];
extern u8 lbl_10_data_2800__fzgx_offset_0[];
extern u8 lbl_10_data_280C__fzgx_offset_0[];
extern u8 lbl_10_data_2818__fzgx_offset_0[];
extern u8 lbl_10_data_2824__fzgx_offset_0[];
extern u8 lbl_10_data_2834__fzgx_offset_0[];
extern u8 lbl_10_data_2844__fzgx_offset_0[];
extern u8 lbl_10_data_2854__fzgx_offset_0[];
extern u8 lbl_10_data_2864__fzgx_offset_0[];
extern u8 lbl_10_data_2870__fzgx_offset_0[];
extern u8 lbl_10_data_2880__fzgx_offset_0[];
extern u8 lbl_10_data_2894__fzgx_offset_0[];
extern u8 lbl_10_data_28A8__fzgx_offset_0[];
extern u8 lbl_10_data_28BC__fzgx_offset_0[];
extern u8 lbl_10_data_28D0__fzgx_offset_0[];
extern u8 lbl_10_data_28E0__fzgx_offset_0[];
extern u8 lbl_10_data_28E8__fzgx_offset_0[];
extern u8 lbl_10_data_28F4__fzgx_offset_0[];
extern u8 lbl_10_data_2900__fzgx_offset_0[];
extern u8 lbl_10_data_290C__fzgx_offset_0[];
extern u8 lbl_10_data_2918__fzgx_offset_0[];
extern u8 lbl_10_data_292C__fzgx_offset_0[];
extern u8 lbl_10_data_2938__fzgx_offset_0[];
extern u8 lbl_10_data_2948__fzgx_offset_0[];
extern u8 lbl_10_data_2958__fzgx_offset_0[];
extern u8 lbl_10_data_2968__fzgx_offset_0[];
extern u8 lbl_10_data_2978__fzgx_offset_0[];
extern u8 lbl_10_data_2988__fzgx_offset_0[];
extern u8 lbl_10_data_2998__fzgx_offset_0[];
extern u8 lbl_10_data_29AC__fzgx_offset_0[];
extern u8 lbl_10_data_29C0__fzgx_offset_0[];
extern u8 lbl_10_data_29D4__fzgx_offset_0[];
extern u8 lbl_10_data_29E8__fzgx_offset_0[];
extern u8 lbl_10_data_29FC__fzgx_offset_0[];
extern u8 lbl_10_data_2A08__fzgx_offset_0[];
extern u8 lbl_10_data_2A18__fzgx_offset_0[];
extern u8 lbl_10_data_2A28__fzgx_offset_0[];
extern u8 lbl_10_data_2A38__fzgx_offset_0[];
extern u8 lbl_10_data_2A48__fzgx_offset_0[];
extern u8 lbl_10_data_2A5C__fzgx_offset_0[];
extern u8 lbl_10_data_2A68__fzgx_offset_0[];
extern u8 lbl_10_data_2A78__fzgx_offset_0[];
extern u8 lbl_10_data_2A88__fzgx_offset_0[];
extern u8 lbl_10_data_2A98__fzgx_offset_0[];
extern u8 lbl_10_data_2AA8__fzgx_offset_0[];
extern u8 lbl_10_data_2ABC__fzgx_offset_0[];
extern u8 lbl_10_data_2AC4__fzgx_offset_0[];
extern u8 lbl_10_data_2ACC__fzgx_offset_0[];
extern u8 lbl_10_data_2AD4__fzgx_offset_0[];
extern u8 lbl_10_data_2ADC__fzgx_offset_0[];
extern u8 lbl_10_data_2AE4__fzgx_offset_0[];
extern u8 lbl_10_data_2AF0__fzgx_offset_0[];
extern u8 lbl_10_data_2AF8__fzgx_offset_0[];
extern u8 lbl_10_data_2B04__fzgx_offset_0[];
extern u8 lbl_10_data_2B10__fzgx_offset_0[];
extern u8 lbl_10_data_2B1C__fzgx_offset_0[];
extern u8 lbl_10_data_2B28__fzgx_offset_0[];
extern u8 lbl_10_data_2B3C__fzgx_offset_0[];
extern u8 lbl_10_data_2B50__fzgx_offset_0[];
extern u8 lbl_10_data_2B54__fzgx_offset_0[];
extern u8 lbl_10_data_2B5C__fzgx_offset_0[];
extern u8 lbl_10_data_2B64__fzgx_offset_0[];
extern u8 lbl_10_data_2B6C__fzgx_offset_0[];
extern u8 lbl_10_data_2B74__fzgx_offset_0[];
extern u8 lbl_10_data_2B88__fzgx_offset_0[];
extern u8 lbl_10_data_2B90__fzgx_offset_0[];
extern u8 lbl_10_data_2B9C__fzgx_offset_0[];
extern u8 lbl_10_data_2BA8__fzgx_offset_0[];
extern u8 lbl_10_data_2BB4__fzgx_offset_0[];
extern u8 lbl_10_data_2BC0__fzgx_offset_0[];
extern u8 lbl_10_data_2BCC__fzgx_offset_0[];
extern u8 lbl_10_data_2BD4__fzgx_offset_0[];
extern u8 lbl_10_data_2BE8__fzgx_offset_0[];
extern u8 lbl_10_data_2BF0__fzgx_offset_0[];
extern u8 lbl_10_data_2BF8__fzgx_offset_0[];
extern u8 lbl_10_data_2C08__fzgx_offset_0[];
extern u8 lbl_10_data_2C1C__fzgx_offset_0[];
extern u8 lbl_10_data_2C30__fzgx_offset_0[];
extern u8 lbl_10_data_2C44__fzgx_offset_0[];
extern u8 lbl_10_data_2C58__fzgx_offset_0[];
extern u8 lbl_10_data_2C68__fzgx_offset_0[];
extern u8 lbl_10_data_2C78__fzgx_offset_0[];
extern u8 lbl_10_data_2C8C__fzgx_offset_0[];
extern u8 lbl_10_data_2CA0__fzgx_offset_0[];
extern u8 lbl_10_data_2CB4__fzgx_offset_0[];
extern u8 lbl_10_data_2CC8__fzgx_offset_0[];
extern u8 lbl_10_data_3064__fzgx_offset_0[];
extern u8 lbl_10_data_30B0__fzgx_offset_0[];
extern u8 lbl_10_data_30C0__fzgx_offset_0[];
extern u8 lbl_10_data_30D0__fzgx_offset_0[];
extern u8 lbl_10_data_30E0__fzgx_offset_0[];
extern u8 lbl_10_data_30F0__fzgx_offset_0[];
extern u8 lbl_10_data_3148__fzgx_offset_0[];
extern u8 lbl_10_data_317C__fzgx_offset_0[];
extern u8 lbl_10_data_318C__fzgx_offset_0[];
extern u8 lbl_10_data_319C__fzgx_offset_0[];
extern u8 lbl_10_data_31AC__fzgx_offset_0[];
extern u8 lbl_10_data_31BC__fzgx_offset_0[];
extern u8 lbl_10_data_31F8__fzgx_offset_0[];
extern u8 lbl_10_data_3260__fzgx_offset_0[];
extern u8 lbl_10_data_326C__fzgx_offset_0[];
extern u8 lbl_10_data_3278__fzgx_offset_0[];
extern u8 lbl_10_data_3284__fzgx_offset_0[];
extern u8 lbl_10_data_3290__fzgx_offset_0[];
extern u8 lbl_10_data_330C__fzgx_offset_0[];
extern u8 lbl_10_data_3374__fzgx_offset_0[];
extern u8 lbl_10_data_3384__fzgx_offset_0[];
extern u8 lbl_10_data_3394__fzgx_offset_0[];
extern u8 lbl_10_data_33A4__fzgx_offset_0[];
extern u8 lbl_10_data_33B4__fzgx_offset_0[];
extern u8 lbl_10_data_3430__fzgx_offset_0[];
extern u8 lbl_10_data_34B8__fzgx_offset_0[];
extern u8 lbl_10_data_34C8__fzgx_offset_0[];
extern u8 lbl_10_data_34D8__fzgx_offset_0[];
extern u8 lbl_10_data_34E8__fzgx_offset_0[];
extern u8 lbl_10_data_34F8__fzgx_offset_0[];
extern u8 lbl_10_data_357C__fzgx_offset_0[];
extern u8 lbl_10_data_35F0__fzgx_offset_0[];
extern u8 lbl_10_data_3600__fzgx_offset_0[];
extern u8 lbl_10_data_3610__fzgx_offset_0[];
extern u8 lbl_10_data_3620__fzgx_offset_0[];
extern u8 lbl_10_data_3630__fzgx_offset_0[];
extern u8 lbl_10_data_36B8__fzgx_offset_0[];
extern u8 lbl_10_data_3700__fzgx_offset_0[];
extern u8 lbl_10_data_3710__fzgx_offset_0[];
extern u8 lbl_10_data_3720__fzgx_offset_0[];
extern u8 lbl_10_data_3730__fzgx_offset_0[];
extern u8 lbl_10_data_3740__fzgx_offset_0[];
extern u8 lbl_10_data_3788__fzgx_offset_0[];
extern u8 lbl_10_data_37AC__fzgx_offset_0[];
extern u8 lbl_10_data_37C0__fzgx_offset_0[];
extern u8 lbl_10_data_37D4__fzgx_offset_0[];
extern u8 lbl_10_data_37E8__fzgx_offset_0[];
extern u8 lbl_10_data_37FC__fzgx_offset_0[];
extern u8 lbl_10_data_3824__fzgx_offset_0[];
extern u8 lbl_10_data_38D0__fzgx_offset_0[];
extern u8 lbl_10_data_38E4__fzgx_offset_0[];
extern u8 lbl_10_data_38F8__fzgx_offset_0[];
extern u8 lbl_10_data_390C__fzgx_offset_0[];
extern u8 lbl_10_data_3920__fzgx_offset_0[];
extern u8 lbl_10_data_39CC__fzgx_offset_0[];
extern u8 lbl_10_data_39D8__fzgx_offset_0[];
extern u8 lbl_10_data_39E8__fzgx_offset_0[];
extern u8 lbl_10_data_39F8__fzgx_offset_0[];
extern u8 lbl_10_data_3A08__fzgx_offset_0[];
extern u8 lbl_10_data_3A30__fzgx_offset_0[];
extern u8 lbl_10_data_3A84__fzgx_offset_0[];
extern u8 lbl_10_data_3A98__fzgx_offset_0[];
extern u8 lbl_10_data_3AAC__fzgx_offset_0[];
extern u8 lbl_10_data_3AC0__fzgx_offset_0[];
extern u8 lbl_10_data_3AD4__fzgx_offset_0[];
extern u8 lbl_10_data_3B24__fzgx_offset_0[];
extern u8 lbl_10_data_3BD0__fzgx_offset_0[];
extern u8 lbl_10_data_3BE8__fzgx_offset_0[];
extern u8 lbl_10_data_3C00__fzgx_offset_0[];
extern u8 lbl_10_data_3C18__fzgx_offset_0[];
extern u8 lbl_10_data_3C30__fzgx_offset_0[];
extern u8 lbl_10_data_3CB4__fzgx_offset_0[];
extern u8 lbl_10_data_3D00__fzgx_offset_0[];
extern u8 lbl_10_data_3D10__fzgx_offset_0[];
extern u8 lbl_10_data_3D20__fzgx_offset_0[];
extern u8 lbl_10_data_3D30__fzgx_offset_0[];
extern u8 lbl_10_data_3D40__fzgx_offset_0[];
extern u8 lbl_10_data_3D98__fzgx_offset_0[];
extern u8 lbl_10_data_3DC0__fzgx_offset_0[];
extern u8 lbl_10_data_3DCC__fzgx_offset_0[];
extern u8 lbl_10_data_3DD8__fzgx_offset_0[];
extern u8 lbl_10_data_3DE4__fzgx_offset_0[];
extern u8 lbl_10_data_3DF0__fzgx_offset_0[];
extern u8 lbl_10_data_3E1C__fzgx_offset_0[];
extern u8 lbl_10_data_3E64__fzgx_offset_0[];
extern u8 lbl_10_data_3E74__fzgx_offset_0[];
extern u8 lbl_10_data_3E84__fzgx_offset_0[];
extern u8 lbl_10_data_3E94__fzgx_offset_0[];
extern u8 lbl_10_data_3EA4__fzgx_offset_0[];
extern u8 lbl_10_data_3F00__fzgx_offset_0[];
extern u8 lbl_10_data_3F68__fzgx_offset_0[];
extern u8 lbl_10_data_3F7C__fzgx_offset_0[];
extern u8 lbl_10_data_3F90__fzgx_offset_0[];
extern u8 lbl_10_data_3FA4__fzgx_offset_0[];
extern u8 lbl_10_data_3FB8__fzgx_offset_0[];
extern u8 lbl_10_data_4040__fzgx_offset_0[];
extern u8 lbl_10_data_408C__fzgx_offset_0[];
extern u8 lbl_10_data_40A4__fzgx_offset_0[];
extern u8 lbl_10_data_40BC__fzgx_offset_0[];
extern u8 lbl_10_data_40D4__fzgx_offset_0[];
extern u8 lbl_10_data_40EC__fzgx_offset_0[];
extern u8 lbl_10_data_4124__fzgx_offset_0[];
extern u8 lbl_10_data_4178__fzgx_offset_0[];
extern u8 lbl_10_data_4184__fzgx_offset_0[];
extern u8 lbl_10_data_4190__fzgx_offset_0[];
extern u8 lbl_10_data_419C__fzgx_offset_0[];
extern u8 lbl_10_data_41A8__fzgx_offset_0[];
extern u8 lbl_10_data_4200__fzgx_offset_0[];
extern u8 lbl_10_data_42E8__fzgx_offset_0[];
extern u8 lbl_10_data_42F4__fzgx_offset_0[];
extern u8 lbl_10_data_4300__fzgx_offset_0[];
extern u8 lbl_10_data_430C__fzgx_offset_0[];
extern u8 lbl_10_data_4318__fzgx_offset_0[];
extern u8 lbl_10_data_43DC__fzgx_offset_0[];
extern u8 lbl_10_data_441C__fzgx_offset_0[];
extern u8 lbl_10_data_442C__fzgx_offset_0[];
extern u8 lbl_10_data_443C__fzgx_offset_0[];
extern u8 lbl_10_data_444C__fzgx_offset_0[];
extern u8 lbl_10_data_445C__fzgx_offset_0[];
extern u8 lbl_10_data_44B4__fzgx_offset_0[];
extern u8 lbl_10_data_44E0__fzgx_offset_0[];
extern u8 lbl_10_data_44F4__fzgx_offset_0[];
extern u8 lbl_10_data_4508__fzgx_offset_0[];
extern u8 lbl_10_data_451C__fzgx_offset_0[];
extern u8 lbl_10_data_4530__fzgx_offset_0[];
extern u8 lbl_10_data_4554__fzgx_offset_0[];
extern u8 lbl_10_data_45AC__fzgx_offset_0[];
extern u8 lbl_10_data_45BC__fzgx_offset_0[];
extern u8 lbl_10_data_45CC__fzgx_offset_0[];
extern u8 lbl_10_data_45DC__fzgx_offset_0[];
extern u8 lbl_10_data_45EC__fzgx_offset_0[];
extern u8 lbl_10_data_463C__fzgx_offset_0[];
extern u8 lbl_10_data_4668__fzgx_offset_0[];
extern u8 lbl_10_data_4678__fzgx_offset_0[];
extern u8 lbl_10_data_4688__fzgx_offset_0[];
extern u8 lbl_10_data_4698__fzgx_offset_0[];
extern u8 lbl_10_data_46A8__fzgx_offset_0[];
extern u8 lbl_10_data_46FC__fzgx_offset_0[];
extern u8 lbl_10_data_472C__fzgx_offset_0[];
extern u8 lbl_10_data_4740__fzgx_offset_0[];
extern u8 lbl_10_data_4754__fzgx_offset_0[];
extern u8 lbl_10_data_4768__fzgx_offset_0[];
extern u8 lbl_10_data_477C__fzgx_offset_0[];
extern u8 lbl_10_data_47C4__fzgx_offset_0[];
extern u8 lbl_10_data_4810__fzgx_offset_0[];
extern u8 lbl_10_data_482C__fzgx_offset_0[];
extern u8 lbl_10_data_4848__fzgx_offset_0[];
extern u8 lbl_10_data_4864__fzgx_offset_0[];
extern u8 lbl_10_data_4880__fzgx_offset_0[];
extern u8 lbl_10_data_48C8__fzgx_offset_0[];
extern u8 lbl_10_data_48DC__fzgx_offset_0[];
extern u8 lbl_10_data_48F0__fzgx_offset_0[];
extern u8 lbl_10_data_4904__fzgx_offset_0[];
extern u8 lbl_10_data_4918__fzgx_offset_0[];
extern u8 lbl_10_data_492C__fzgx_offset_0[];
extern u8 lbl_10_data_4948__fzgx_offset_0[];
extern u8 lbl_10_data_4964__fzgx_offset_0[];
extern u8 lbl_10_data_4978__fzgx_offset_0[];
extern u8 lbl_10_data_498C__fzgx_offset_0[];
extern u8 lbl_10_data_49A0__fzgx_offset_0[];
extern u8 lbl_10_data_49B4__fzgx_offset_0[];
extern u8 lbl_10_data_49D0__fzgx_offset_0[];
extern u8 lbl_10_data_49E8__fzgx_offset_0[];
extern u8 lbl_10_data_4A00__fzgx_offset_0[];
extern u8 lbl_10_data_4A18__fzgx_offset_0[];
extern u8 lbl_10_data_4A30__fzgx_offset_0[];
extern u8 lbl_10_data_4A48__fzgx_offset_0[];
extern u8 lbl_10_data_4A68__fzgx_offset_0[];
extern u8 lbl_10_data_4AB4__fzgx_offset_0[];
extern u8 lbl_10_data_4DB0__fzgx_offset_0[];
extern u8 lbl_10_data_4DDC__fzgx_offset_0[];
extern u8 lbl_10_data_4DF0__fzgx_offset_0[];
extern u8 lbl_10_data_4E04__fzgx_offset_0[];
extern u8 lbl_10_data_4E18__fzgx_offset_0[];
extern u8 lbl_10_data_4E2C__fzgx_offset_0[];
extern u8 lbl_10_data_4E4C__fzgx_offset_0[];
extern u8 lbl_10_data_4E70__fzgx_offset_0[];
extern u8 lbl_10_data_4E84__fzgx_offset_0[];
extern u8 lbl_10_data_4E98__fzgx_offset_0[];
extern u8 lbl_10_data_4EAC__fzgx_offset_0[];
extern u8 lbl_10_data_4EC0__fzgx_offset_0[];
extern u8 lbl_10_data_4EF0__fzgx_offset_0[];
extern u8 lbl_10_data_4F18__fzgx_offset_0[];
extern u8 lbl_10_data_4F2C__fzgx_offset_0[];
extern u8 lbl_10_data_4F40__fzgx_offset_0[];
extern u8 lbl_10_data_4F54__fzgx_offset_0[];
extern u8 lbl_10_data_4F68__fzgx_offset_0[];
extern u8 lbl_10_data_4F88__fzgx_offset_0[];
extern u8 lbl_10_data_4FB4__fzgx_offset_0[];
extern u8 lbl_10_data_4FCC__fzgx_offset_0[];
extern u8 lbl_10_data_4FE4__fzgx_offset_0[];
extern u8 lbl_10_data_4FFC__fzgx_offset_0[];
extern u8 lbl_10_data_5014__fzgx_offset_0[];
extern u8 lbl_10_data_5038__fzgx_offset_0[];
extern u8 lbl_10_data_5064__fzgx_offset_0[];
extern u8 lbl_10_data_5074__fzgx_offset_0[];
extern u8 lbl_10_data_5084__fzgx_offset_0[];
extern u8 lbl_10_data_5094__fzgx_offset_0[];
extern u8 lbl_10_data_50A4__fzgx_offset_0[];
extern u8 lbl_10_data_50D4__fzgx_offset_0[];
extern u8 lbl_10_data_50EC__fzgx_offset_0[];
extern u8 lbl_10_data_5104__fzgx_offset_0[];
extern u8 lbl_10_data_511C__fzgx_offset_0[];
extern u8 lbl_10_data_5134__fzgx_offset_0[];
extern u8 lbl_10_data_514C__fzgx_offset_0[];
extern u8 lbl_10_data_516C__fzgx_offset_0[];
extern u8 lbl_10_data_51AC__fzgx_offset_0[];
extern u8 lbl_10_data_51C4__fzgx_offset_0[];
extern u8 lbl_10_data_51DC__fzgx_offset_0[];
extern u8 lbl_10_data_51F4__fzgx_offset_0[];
extern u8 lbl_10_data_520C__fzgx_offset_0[];
extern u8 lbl_10_data_5254__fzgx_offset_0[];
extern u8 lbl_10_data_5284__fzgx_offset_0[];
extern u8 lbl_10_data_5294__fzgx_offset_0[];
extern u8 lbl_10_data_52A4__fzgx_offset_0[];
extern u8 lbl_10_data_52B4__fzgx_offset_0[];
extern u8 lbl_10_data_52C4__fzgx_offset_0[];
extern u8 lbl_10_data_52F4__fzgx_offset_0[];
extern u8 lbl_10_data_535C__fzgx_offset_0[];
extern u8 lbl_10_data_5378__fzgx_offset_0[];
extern u8 lbl_10_data_5394__fzgx_offset_0[];
extern u8 lbl_10_data_53B0__fzgx_offset_0[];
extern u8 lbl_10_data_53CC__fzgx_offset_0[];
extern u8 lbl_10_data_541C__fzgx_offset_0[];
extern u8 lbl_10_data_5454__fzgx_offset_0[];
extern u8 lbl_10_data_5468__fzgx_offset_0[];
extern u8 lbl_10_data_547C__fzgx_offset_0[];
extern u8 lbl_10_data_5490__fzgx_offset_0[];
extern u8 lbl_10_data_54A4__fzgx_offset_0[];
extern u8 lbl_10_data_54E8__fzgx_offset_0[];
extern u8 lbl_10_data_54F4__fzgx_offset_0[];
extern u8 lbl_10_data_5504__fzgx_offset_0[];
extern u8 lbl_10_data_5514__fzgx_offset_0[];
extern u8 lbl_10_data_5524__fzgx_offset_0[];
extern u8 lbl_10_data_5534__fzgx_offset_0[];
extern u8 lbl_10_data_5540__fzgx_offset_0[];
extern u8 lbl_10_data_5560__fzgx_offset_0[];
extern u8 lbl_10_data_5570__fzgx_offset_0[];
extern u8 lbl_10_data_5580__fzgx_offset_0[];
extern u8 lbl_10_data_5590__fzgx_offset_0[];
extern u8 lbl_10_data_55A0__fzgx_offset_0[];
extern u8 lbl_10_data_55B8__fzgx_offset_0[];
extern u8 lbl_10_data_55D8__fzgx_offset_0[];
extern u8 lbl_10_data_56AC__fzgx_offset_0[];
extern u8 lbl_10_data_56C4__fzgx_offset_0[];
extern u8 lbl_10_data_56DC__fzgx_offset_0[];
extern u8 lbl_10_data_56F4__fzgx_offset_0[];
extern u8 lbl_10_data_570C__fzgx_offset_0[];
extern u8 lbl_10_data_57A0__fzgx_offset_0[];
extern u8 lbl_10_data_57F4__fzgx_offset_0[];
extern u8 lbl_10_data_5810__fzgx_offset_0[];
extern u8 lbl_10_data_582C__fzgx_offset_0[];
extern u8 lbl_10_data_5848__fzgx_offset_0[];
extern u8 lbl_10_data_5864__fzgx_offset_0[];
extern u8 lbl_10_data_589C__fzgx_offset_0[];
extern u8 lbl_10_data_590C__fzgx_offset_0[];
extern u8 lbl_10_data_5924__fzgx_offset_0[];
extern u8 lbl_10_data_593C__fzgx_offset_0[];
extern u8 lbl_10_data_5954__fzgx_offset_0[];
extern u8 lbl_10_data_596C__fzgx_offset_0[];
extern u8 lbl_10_data_59D0__fzgx_offset_0[];
extern u8 lbl_10_data_5A34__fzgx_offset_0[];
extern u8 lbl_10_data_5A48__fzgx_offset_0[];
extern u8 lbl_10_data_5A5C__fzgx_offset_0[];
extern u8 lbl_10_data_5A70__fzgx_offset_0[];
extern u8 lbl_10_data_5A84__fzgx_offset_0[];
extern u8 lbl_10_data_5AC4__fzgx_offset_0[];
extern u8 lbl_10_data_5AF0__fzgx_offset_0[];
extern u8 lbl_10_data_5B0C__fzgx_offset_0[];
extern u8 lbl_10_data_5B28__fzgx_offset_0[];
extern u8 lbl_10_data_5B44__fzgx_offset_0[];
extern u8 lbl_10_data_5B60__fzgx_offset_0[];
extern u8 lbl_10_data_5B90__fzgx_offset_0[];
extern u8 lbl_10_data_5BAC__fzgx_offset_0[];
extern u8 lbl_10_data_5BC0__fzgx_offset_0[];
extern u8 lbl_10_data_5BD4__fzgx_offset_0[];
extern u8 lbl_10_data_5BE8__fzgx_offset_0[];
extern u8 lbl_10_data_5BFC__fzgx_offset_0[];
extern u8 lbl_10_data_5DE4__fzgx_offset_0[];
extern u8 lbl_10_data_5DFC__fzgx_offset_0[];
extern u8 lbl_10_data_6188__fzgx_offset_0[];
extern u8 lbl_10_data_6194__fzgx_offset_0[];
extern u8 lbl_10_data_6238__fzgx_offset_0[];
extern u8 lbl_10_data_625C__fzgx_offset_0[];
extern u8 lbl_10_data_62A4__fzgx_offset_0[];
extern u8 lbl_10_data_62C4__fzgx_offset_0[];
extern u8 lbl_10_data_62F4__fzgx_offset_0[];
extern u8 lbl_10_data_6380__fzgx_offset_0[];
extern u8 lbl_10_data_6390__fzgx_offset_0[];
extern u8 lbl_10_data_63B4__fzgx_offset_0[];
extern u8 lbl_10_data_63C4__fzgx_offset_0[];
extern u8 lbl_10_data_63E8__fzgx_offset_0[];
extern u8 lbl_10_data_63F4__fzgx_offset_0[];
extern u8 lbl_10_data_6418__fzgx_offset_0[];
extern u8 lbl_10_data_6424__fzgx_offset_0[];
extern u8 lbl_10_data_6474__fzgx_offset_0[];
extern u8 lbl_10_data_6490__fzgx_offset_0[];
extern u8 lbl_10_data_6498__fzgx_offset_0[];
extern u8 lbl_10_data_64B4__fzgx_offset_0[];
extern u8 lbl_10_data_64BC__fzgx_offset_0[];
extern u8 lbl_10_data_6554__fzgx_offset_0[];
extern u8 lbl_10_data_6584__fzgx_offset_0[];
extern u8 lbl_10_data_65FC__fzgx_offset_0[];
extern u8 lbl_10_data_661C__fzgx_offset_0[];
extern u8 lbl_10_data_6654__fzgx_offset_0[];
extern u8 lbl_10_data_6670__fzgx_offset_0[];
extern u8 lbl_10_data_66DC__fzgx_offset_0[];
extern u8 lbl_10_data_FB4__fzgx_offset_0[];
extern u8 lbl_10_data_21B0__fzgx_offset_0[];
extern u8 lbl_10_data_21BC__fzgx_offset_0[];
extern u8 lbl_10_data_21C8__fzgx_offset_0[];
extern u8 lbl_10_data_21D4__fzgx_offset_0[];
extern u8 lbl_10_data_21E0__fzgx_offset_0[];
extern u8 lbl_10_data_21EC__fzgx_offset_0[];
extern u8 lbl_10_data_64F0__fzgx_offset_0[];
extern u8 lbl_10_data_650C__fzgx_offset_0[];
extern u8 lbl_10_data_6530__fzgx_offset_0[];
extern u8 lbl_10_data_65D4__fzgx_offset_0[];
extern u8 lbl_10_data_66A4__fzgx_offset_0[];
extern u8 lbl_10_data_D00__fzgx_offset_0[];
extern u8 lbl_10_data_D04__fzgx_offset_0[];
extern u8 lbl_10_data_D10__fzgx_offset_0[];
extern u8 lbl_10_data_D1C__fzgx_offset_0[];
extern u8 lbl_10_data_D28__fzgx_offset_0[];
extern u8 lbl_10_data_D34__fzgx_offset_0[];
extern u8 lbl_10_data_D3C__fzgx_offset_0[];
extern u8 lbl_10_data_D44__fzgx_offset_0[];
extern u8 lbl_10_data_D4C__fzgx_offset_0[];
extern u8 lbl_10_data_D54__fzgx_offset_0[];
extern u8 lbl_10_data_D60__fzgx_offset_0[];
extern u8 lbl_10_data_D70__fzgx_offset_0[];
extern u8 lbl_10_data_D80__fzgx_offset_0[];
extern u8 lbl_10_data_D88__fzgx_offset_0[];
extern u8 lbl_10_data_D90__fzgx_offset_0[];
extern u8 lbl_10_data_D9C__fzgx_offset_0[];
extern u8 lbl_10_data_DA8__fzgx_offset_0[];
extern u8 lbl_10_data_DB8__fzgx_offset_0[];
extern u8 lbl_10_data_DC0__fzgx_offset_0[];
extern u8 lbl_10_data_DCC__fzgx_offset_0[];
extern u8 lbl_10_data_DD8__fzgx_offset_0[];
extern u8 lbl_10_data_DE8__fzgx_offset_0[];
extern u8 lbl_10_data_DF0__fzgx_offset_0[];
extern u8 lbl_10_data_DFC__fzgx_offset_0[];
extern u8 lbl_10_data_E08__fzgx_offset_0[];
extern u8 lbl_10_data_E18__fzgx_offset_0[];
extern u8 lbl_10_data_E20__fzgx_offset_0[];
extern u8 lbl_10_data_E2C__fzgx_offset_0[];
extern u8 lbl_10_data_E34__fzgx_offset_0[];
extern u8 lbl_10_data_E40__fzgx_offset_0[];
extern u8 lbl_10_data_E50__fzgx_offset_0[];
extern u8 lbl_10_data_E5C__fzgx_offset_0[];
extern u8 lbl_10_data_E68__fzgx_offset_0[];
extern u8 lbl_10_data_E70__fzgx_offset_0[];
extern u8 lbl_10_data_E84__fzgx_offset_0[];
extern u8 lbl_10_data_E94__fzgx_offset_0[];
extern u8 lbl_10_data_EA4__fzgx_offset_0[];
extern u8 lbl_10_data_EB0__fzgx_offset_0[];
extern u8 lbl_10_data_EBC__fzgx_offset_0[];
extern u8 lbl_10_data_ECC__fzgx_offset_0[];
extern u8 lbl_10_data_ED4__fzgx_offset_0[];
extern u8 lbl_10_data_EE0__fzgx_offset_0[];
extern u8 lbl_10_data_EE8__fzgx_offset_0[];
extern u8 lbl_10_data_EF0__fzgx_offset_0[];
extern u8 lbl_10_data_EF8__fzgx_offset_0[];
extern int fn_1_D66B0(void);
extern u8 fn_1_128DD8(u8 value);
extern void *__cvt_fp2unsigned(f64);
extern void fn_1_5417C(void *arg);
extern u32 fn_1_53FE4(u32, u32);
extern void fn_1_4CF3C(const char *format, f32 x, ...);
extern int fn_10_1E57C(int, int, int);
extern void fn_10_1E67C(u32);
extern void fn_10_1BCD0(void);
extern void fn_10_1E9CC(s32, s32, s32, f32);
extern void fn_10_1F3B8(s32, s32, s32);
extern void fn_10_1FEF4(s32 arg0);
extern void fn_10_210F0(void);
extern void fn_10_1F688(s32, u32, f32);
extern f32 fn_1_4B090(s32 value);
extern void fn_1_53B14(s32 arg0, f32 arg1, f32 arg2, f32 arg3, f32 arg4, f32 arg5);
extern u32 lbl_10_bss_55B34[2];
extern u8 fn_10_8780(void);
extern f32 lbl_8006D0B4(f32);
extern void * fn_1_12F118(void);
extern f32 lbl_10_bss_55B3C[];
extern void fn_1_52088(void);
extern void fn_1_520A0(void);
extern void fn_1_520CC(void);
extern void fn_1_494DC(s16 index);
extern void fn_1_5233C(void *arg0, void *arg1);
extern void fn_1_49738(void *);
extern void fn_1_49748(f32 value);
extern void fn_1_4962C(void);
extern void fn_1_495A0(f32 value);
extern void fn_1_141338(u32 arg0, u32 arg1, u32 arg2, u32 arg3, f32 arg4);
extern void fn_1_140EE8(u8 arg0, int arg1, int arg2);
extern void fn_10_22330(int);
extern void fn_1_52070(u32 value);
extern void fn_1_1461C8(s32 mode, u32 index);
extern void fn_10_2287C(void);
extern void fn_1_144F40(int, u8 *);
extern void fn_10_266AC(void);
extern u32 *fn_1_156198(u32 arg0);
extern u64 fn_1_15AC10(void);
extern s16 fn_1_14F118(s16 value, void *table);
extern void fn_1_1598C4(s32 arg0, u8 arg1, u8 arg2, u8 arg3, u8 arg4, u8 arg5, u8 arg6, u32 arg7, u64 arg8, u8 arg10);
extern void fn_1_159AE0(void);
extern void fn_10_22998(fn_10_2287C_SelObject *object);
extern struct fn_8_D630_rodata lbl_10_rodata_1548;
extern u32 fn_1_4060(void);
extern s32 strncmp(const char *s1, const char *s2, size_t n);
extern char * strncpy(char *, const char *, size_t);
extern EntryColor lbl_10_rodata_1D64;
extern EntryColor lbl_10_rodata_1D68;
extern s32 fn_1_45D0();
extern s32 fn_1_14CEB8(u32);
extern char *fn_80083DB0(char *dst, const char *src);
extern void fn_10_2325C(struct fn_8_D630_obj *arg0);
extern void ADXT_Stop(ADXTHandle *handle);

void fn_10_18A50(struct fn_10_18A50_Arg0 *param0, u32 param1) {
    struct fn_10_18A50_Arg0 *arg0 = param0;
    s16 v10;
    u32 v12;
    u32 v11;
    f32 v1;
    f32 t1;
    u32 v9;
    u32 v8;
    s32 v6;
    s16 id = *(volatile s16 *)&arg0->unk_8C; /* Read the selection ID before polling. */
    struct { u32 value; } saved;
    saved.value = param1;
    if (fn_1_12F028(id) >= 2) {
        v10 = arg0->unk_E0[arg0->unk_9E];
        for (v6 = 0; v6 < 4; v6++) {
            if ((s8)lbl_1_bss_9C8[v6 * 12 + 10] != -1 &&
                (__rlwnm(*(u32 *)((((u8 *)&lbl_1_bss_8B3A0)) + 0x98), (v6 + 1) & 31, 31, 31))) {
                /* Controller state is polled again for each decision. */
                if ((((v8 = *(u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 16)) >> 1) & 1) ||
                    (((v9 = *(u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 18)) >> 1) & 1) || /* Poll the second controller state. */
                    (v8 & 1) || (v9 & 1)) {
                    v10 = arg0->unk_E0[v6];
                    /* Re-read controller state for this decision, as in retail. */
                    if (((*(volatile u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 16) >> 1) & 1) || /* Fresh poll. */
                        ((*(u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 18) >> 1) & 1)) { /* Fresh second-state poll. */
                        lbl_10_bss_55AE0 = 0;
                    }
                    if ((*(u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 16) & 1) ||
                        (*(u16 *)((((u8 *)&lbl_1_bss_9F8)) + v6 * 20 + 18) & 1)) {
                        lbl_10_bss_55AE0 = 1;
                    }
                }
            }
        }
        v11 = (lbl_801A66A0 - (s16)v10) * 21;
        v12 = 180;
        if (v11 <= 180) v12 = v11;
        v1 = lbl_8006D188((s32)(lbl_10_rodata_588 * (f32)v12));
        t1 = lbl_10_bss_55AE0 == 1 ? v1 : lbl_10_rodata_1A4[0];
        fn_10_18C54(38, saved.value, t1, 1);
        t1 = lbl_10_bss_55AE0 == 0 ? v1 : lbl_10_rodata_1A4[0];
        fn_10_18C54(38, saved.value, t1, 0);
    }
}
