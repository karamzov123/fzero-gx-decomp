#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/live_camera.h"

extern void OSPanic(u8 *file, int line, u8 *message, ...);
extern u32 fn_80008E30(u32);
extern u8 lbl_1_bss_17B4[12];
extern void fn_80083DB0(Obj_1_bss_3B30 *, void *);
extern u32 *fn_1_1304C(Obj_1_bss_3B30 *, u32);
extern u8 lbl_1_bss_1810[8984];
extern void fn_8000659C(void);
extern u32 OSIsThreadTerminated(u8 *);

extern void fn_1_6DD0(void *);
extern u32 *fn_1_1289C(u32 *);
extern s32 fn_1_4C10(void);
extern s32 fn_1_40BB4(void);
extern s32 fn_1_F2F34(void);
extern u32 fn_1_F45A4(void);
extern u32 fn_1_F4594(void);
extern f32 lbl_1_rodata_4E0[5];
extern f32 lbl_1_bss_1160[403];
extern void fn_1_5370(s32, s16);
extern f32 lbl_1_rodata_4F4[19];
extern const f64 lbl_1_rodata_548[2];
extern u32 lbl_801A63C0;
extern void fn_1_8636C(s16, void *);
extern void fn_1_862A8(s16, void *);
extern void lbl_8006DC6C(void *);
extern void lbl_8006E1B0(void *, void *);
extern s32 lbl_8006D24C(f32, f32);
extern int sprintf(char *, const char *, ...);

extern s32 fn_1_45B2C(void *arg0);
extern void fn_1_458A0(void *arg0, void *arg1, u32 arg2, u32 arg3);

u8 fn_1_1350C(void *arg0, u8 *arg1) {
    s32 size;
    u8 result;
    if (lbl_1_bss_3B28 == 0) {
        size = lbl_1_data_5180;
        /* volatile: the shared streaming state is read in program order, not CSEd or hoisted */
        if (*(volatile u32 *)&lbl_1_bss_3B2C + *(volatile u32 *)&lbl_1_data_5180 > (u32)fn_1_45B2C(arg0)) {
            size = (fn_1_45B2C(arg0) - lbl_1_bss_3B2C + 0x1F) & ~0x1F;
        }
        if (size > 0) {
            fn_1_458A0(arg0, arg1, size, lbl_1_bss_3B2C);
        }
        /* volatile: the two global words are accumulated in the order retail loads them */
        *(volatile u32 *)&lbl_1_bss_3B2C += *(volatile u32 *)&lbl_1_data_5180;
    }
    /* volatile: the index counter is a live shared object, read and advanced as written */
    result = arg1[(lbl_1_bss_3B28)];
    /* volatile: the index counter is a live shared object, read and advanced as written */
    (*(volatile u32 *)&lbl_1_bss_3B28)++;
    /* volatile: the index counter is a live shared object, read and advanced as written */
    if (*(volatile u32 *)&lbl_1_bss_3B28 >= *(volatile u32 *)&lbl_1_data_5180) {
        lbl_1_bss_3B28 = 0;
    }
    return result;
}
