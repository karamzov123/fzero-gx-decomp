#include "types.h"
#include "rel/customize/globals.h"
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAD0;
extern u8 lbl_1_bss_7F0C0[0x5360];
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_970;
extern u8 lbl_1_bss_9F8[];
extern s32 lbl_3_bss_120;
extern s16 lbl_3_bss_20[104];
extern u8 lbl_3_bss_20854[0xc];
extern u8 lbl_3_bss_20860[0x1100];
extern u8 lbl_3_bss_21960[10368];
extern u8 lbl_3_bss_2437C[44];
extern u32 lbl_3_bss_243A8;
extern u32 lbl_3_bss_243C0;
extern u32 lbl_3_bss_2C7C0[66624];
extern s16 lbl_3_bss_6D8C0[600];
extern u32 lbl_3_bss_6DE20;
extern u8 lbl_3_bss_7DB60[0x520];
extern u8 lbl_3_bss_7E080[0x4];
extern s32 lbl_3_bss_8;
extern s32 lbl_3_data_11D4;
extern s32 lbl_3_data_11D8;
extern char lbl_3_data_15CC[5];
extern s32 lbl_3_data_B8;
extern const char * lbl_3_data_E80[12];
extern u8 lbl_3_rodata_1A4[0xa4];
extern u8 lbl_3_rodata_F8[0xa4];
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern void fn_3_8F8(void);
extern void fn_3_BA0(void);
extern void fn_3_1308C(u32, u32, u32);
extern void fn_3_11F60(u32, u32);
extern void fn_1_A0680(void);
extern void fn_1_3CF0(u32, u32);
extern void fn_1_5124(u32, u32);
extern void fn_80074CF4(f32, f32, f32);
extern void OSReport(const char *format, ...);
extern void *memset(void *, int, u32);
extern u16 fn_1_A5DB0(void);
extern u16 fn_1_A5D88(void);
extern void fn_1_411A4(u32);
extern u32 fn_1_7BA08(u16, u16, u16);
extern void fn_1_7BA48(u32);
extern s32 fn_1_465D0(const char *, s32);
extern void fn_1_545B8(void);
extern void fn_1_7BAF8(void);
extern u32 lbl_801A66C8[];
extern void fn_3_11FA0(void);
extern void fn_3_130A8(void);
extern void fn_1_3C78(void);
extern void fn_1_41A8(void);
extern void fn_1_6400(void);
extern void fn_1_8D168(void *);
extern void fn_1_412A0(u32);
extern void fn_1_56298(f32, f32, f32, f32);
extern void fn_1_A0AA4(void);
extern s32 fn_1_46DC4(s32);
extern void fn_1_53C9C(void *color, char *text, f32 x, f32 y, f32 scale, f32 spacing, f32 alpha);
extern void fn_3_968C();
extern void fn_3_60C8(void);
extern u8 fn_1_F8C50(s32);
extern void fn_3_7A30(void);
extern void fzgx_pool_f32(f32);
extern void fzgx_pool_f64(f64);
extern void fzgx_pool_addr(void *);
extern void fn_3_2BFB4(void);
extern char lbl_3_data_15D8[];
extern void fn_3_3438(void);
extern u32 fn_1_B7F08(void);
extern s32 fn_1_F7954(void);
extern void fn_3_23524(void);
extern void fn_3_78C8(s32);
extern void fn_3_BA74(void);
extern s16 fn_1_F7B80(void);

#include "rel/customize/globals.h"

typedef struct {
    u8 pad_0[0x390];
    u32 unk_390;
    u8 pad_394[0x3a0 - 0x394];
    void *unk_3a0;
    u32 unk_3a4;
    u8 pad_3a8[0x3ba - 0x3a8];
    u16 unk_3ba;
    u8 pad_3bc[0x440 - 0x3bc];
} fn_3_4C58_Entry;

typedef struct {
    u32 unk_0;
    u8 unk_4;
    u8 pad_5[7];
    u32 unk_c;
    u8 pad_10[0x10420 - 0x10];
    u32 unk_420;
    u32 unk_424;
    u32 unk_428;
    u32 unk_42c;
    u8 pad_430[0x10440 - 0x10430];
} Dst;

typedef struct { u32 w[41]; } Copy164;
extern void fn_3_5D84(s32);
extern void fn_80008BEC(void *, int, u32);
extern void fn_1_47F74(s32);
extern void *fn_1_7F254(void *, void *);
extern void fn_1_FD844(void *, void *);
extern s32 fn_1_FD324(void *);
extern void fn_1_FD27C(void *, void *);
extern void fn_1_FDC00(void *, void *, f32);
extern s32 lbl_3_bss_2C70C[45];









void fn_3_4C58(void) {
    s32 i;
    s32 j;
    for (i = 0; (s16)i < 4; i++) fn_3_5D84(i);
    fn_80008BEC(lbl_3_bss_2C70C, 0, 0xa4);

    for (j = 0; (s16)j < 4; j++) {
        volatile Copy164 loc = (*(Copy164 *)&lbl_3_rodata_F8); /* Complete the table copy before selecting an entry. */
        Obj_3_bss_140 *m = (Obj_3_bss_140 *)((u8 *)&lbl_3_bss_140 + ((0x81c0) * (j)));
        u32 flags = *(volatile u32 *)&m->unk_0; /* Read after the initialization copy. */
        if ((flags & 0x80000000) != 0 && (flags & 0x40000000) == 0) {
            if (lbl_3_bss_2C70C[m->pad_9[0x81a0 - 9]] == 0) {
                fn_1_47F74(loc.w[m->pad_9[0x81a0 - 9]]);
                lbl_3_bss_2C70C[m->pad_9[0x81a0 - 9]] = 1;
            }
        }
    }

    fn_80008BEC((*(Dst (*)[4])&lbl_3_bss_2C7C0), 0, 0x41100);
    for (i = 0; (s16)i < 4; i++) {
        Obj_3_bss_140 *m = (Obj_3_bss_140 *)((u8 *)&lbl_3_bss_140 + i * 0x81c0);
        Dst *dst = &(*(Dst (*)[4])&lbl_3_bss_2C7C0)[i];
        fn_3_4C58_Entry *entry = &(*(fn_3_4C58_Entry (*)[4])&lbl_3_bss_20860)[i];
        u8 *src = &(*(u8 (*)[4 * 0xa20])&lbl_3_bss_21960)[i * 0xa20];
        u8 v5 = m->unk_5;
        dst->unk_c = 0x80000000;
        if (m->unk_7 == 0) continue;
        if ((m->unk_0 & 0x80000000) == 0) continue;
        if ((m->unk_0 & 0x40000000) != 0) {
            m->unk_8 = 3;
            entry->unk_390 = 0x04000000;
            entry->unk_3a0 = src;
        } else {
            m->unk_5 = *((u8 *)m + 0x81a0);
            if (m->unk_5 == 40) m->unk_8 = 3;
            else if (m->unk_5 == 4) m->unk_8 = 2;
            else m->unk_8 = 1;
        }
        if (m->unk_7 != 0 && m->unk_7 <= 4) {
            if (entry->unk_3a4 == 0) entry->unk_3a4 = (u32)fn_1_7F254(m, (void *)2);
            entry->unk_3ba = 1;
            dst->unk_4 = 4;
            dst->unk_0 = (u32)entry;
            *(volatile u32 *)&dst->unk_428 = (u32)fn_1_FDC00; /* Ordered callback setup. */
            *(volatile u32 *)&dst->unk_42c = (u32)fn_1_FD27C; /* Ordered callback setup. */
            *(volatile u32 *)&dst->unk_424 = (u32)fn_1_FD324; /* Ordered callback setup. */
            (dst->unk_420) = 0; /* Ordered callback setup. */
            dst->unk_c = 0x20000000;
            fn_1_FD844(m, dst);
            if ((m->unk_0 & 0x40000000) != 0) {
                entry->unk_390 &= ~0x04000000;
                entry->unk_3a0 = 0;
            } else m->unk_5 = v5;
        }
    }
}
