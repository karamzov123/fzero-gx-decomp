#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/memcard.h"
extern void* lbl_801A6410;
extern int fn_1_45D0(void *arg0, int arg1, Obj_1_data_3C7B8 *arg2, int arg3);
extern void fn_1_AB45C(void);
extern void CARDMountAsync(u8, u32, void (*)(void), s32);
extern int CARDGetSerialNo(u8 value, void *data);
extern void CARDCheckAsync(u8 byte_val, int value);
extern void CARDFormatAsync(u8 byte, int value);
extern const f32 lbl_1_rodata_4CA8;
extern const f64 lbl_1_rodata_4CB0;
extern const f32 lbl_1_rodata_4CAC;
extern void fn_80083DB0(void *dst, void *src);
extern void strcat(void *dst, void *src);
extern void CARDDeleteAsync(u8 byte, void *data, int arg);
extern s32 CARDFreeBlocks(u8 byte_val, void *arg1, void *arg2);
extern s32 CARDOpen(u8 byte_val, void *arg1, void *arg2);
extern void CARDFastDeleteAsync(u8 byte_val, void *arg, s32 zero);
extern void CARDCreateAsync(u8 byte_val, void *arg1, void *arg2, void *arg3, u32 arg4);
extern void CARDSetStatusAsync(u8 id, void *arg, void *data, int zero);
extern void CARDRenameAsync(u8 id, void *data1, void *data2, int zero);
extern void CARDReadAsync(void *arg0, void *arg1, void *arg2, int arg3, int arg4);
extern const f64 lbl_1_rodata_4CC8;
extern void fn_80030754(u8 value, void *data, int size, int mode);
extern u8 lbl_1_bss_71810[161];
extern u8 lbl_1_bss_718B8;
extern u8 lbl_1_bss_718B8__fzgx_offset_1[7];
extern int fn_8002A744(void);
extern void fn_8002A74C(u16 value);
extern int fn_8002DFE0(int arg0, u32 arg1, int arg2);
extern int CARDCheck(int arg0);
extern void fn_1_B9C38(s32 index);
extern void fn_1_1596DC(u32);
extern void fn_1_484CC(u32);
extern void fn_80008BEC(void *dst, s32 value, s32 size);
extern void fn_1_AA6D8(s32 arg0, u32 arg1, void *arg2);
extern void fn_1_F755C(u8 value);
extern void fn_1_A6840(u8 value);
extern void OSPanic(void *arg0, u32 arg1, ...);
extern void fn_1_F79C8(void);
extern void *lbl_801A6410;
extern void strncpy(void *arg0, void *arg1, int arg2);
extern u32 lbl_1_bss_77310[28];
extern u32 lbl_1_bss_7730C;
extern u8 lbl_1_bss_772C8[66];
extern u32 fn_1_4630(void *heap, u32 size, void *file, s32 line);
extern s32 fn_8002FC14(s32 chan, void *fileName);
extern s32 fn_80030338(s32 chan, void *oldName, void *newName);
extern const f64 lbl_1_rodata_4CB8;
extern void fn_1_C36EC(void);

extern void fn_1_A2DC4(u32);

typedef struct {
    u8 pad_0[0x24];
    void *unk_24;
    u8 pad_28[0x2];
    u8 unk_2A;
} MemcardArg;

typedef struct {
    u8 pad_0[0x1];
    u8 unk_1;
    u8 pad_2[0x2];
    s32 unk_4;
} MemcardState;

/* fzgx-allow: A1 absolute retail data address */
#define DATA_A9011300 0xA9011300
/* fzgx-allow: A1 absolute retail data address */
#define DATA_A9011100 0xA9011100

void fn_1_AB64C(MemcardArg *arg) {
    MemcardState *state;
    s32 value;

    if ((arg->unk_2A & 1) == 0) {
        state = (MemcardState *)arg->unk_24;
        if (((lbl_1_bss_9F8.unk_10 & 1) != 0 ||
             (lbl_1_bss_9F8.unk_12 & 1) != 0) &&
            state->unk_1 == 1) {
            fn_1_A2DC4(DATA_A9011300);
            state->unk_1 = 0;
        /* Volatile prevents the compiler from reusing the first status read. */
        } else if ((((*((u16 *)&lbl_1_bss_9F8.unk_10) >> 1) & 1) != 0 ||
                    ((lbl_1_bss_9F8.unk_12 >> 1) & 1) != 0) &&
                   state->unk_1 == 0) {
            fn_1_A2DC4(DATA_A9011300);
            state->unk_1 = 1;
        }

        if (((lbl_1_bss_9F8.unk_8 >> 8) & 1) != 0) {
            fn_1_A2DC4(DATA_A9011100);
            value = 1;
        } else {
            value = 0;
        }
        state = (MemcardState *)arg->unk_24;
        state->unk_4 = value;
        state = (MemcardState *)arg->unk_24;
        if (state->unk_4 == 2) {
            state->unk_1 = 1;
        }
    }
}
