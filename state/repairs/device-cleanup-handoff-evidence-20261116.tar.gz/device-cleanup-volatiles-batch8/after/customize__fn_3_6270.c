#include "types.h"

typedef struct {
    u16 unk_0;
    u8 pad_2[0x6];
    u16 unk_8;
    u8 pad_A[0x6];
    u16 unk_10;
    u16 unk_12;
} Pad_1_bss_9F8;

/* retail reads and writes +0x0 as a word (lwz/stw), where globals.h types it as bytes */
typedef struct {
    u32 unk_0;
    s16 unk_4;
    s16 unk_6;
    u8 pad_8[0x1C];
    u32 unk_24;
    u8 pad_28[0x8];
} View_3_bss_F0;

/* the retail TU's .bss objects this function uses, at their retail offsets, so MWCC addresses them off one
 * section base; the fzgx_pool_gap_ objects span the retail objects in between, which this function does not touch */
u8 fzgx_obj_lbl_3_bss_0[8];
s32 fzgx_obj_lbl_3_bss_8;
u8 fzgx_pool_gap_C[0xE4];
View_3_bss_F0 fzgx_obj_lbl_3_bss_F0;
s32 fzgx_obj_lbl_3_bss_120;
u8 fzgx_pool_gap_124[0x20844 - 0x124];
s16 fzgx_obj_lbl_3_bss_20844;
s16 fzgx_pool_gap_20846;
u8 fzgx_pool_gap_20848[8];
u32 fzgx_obj_lbl_3_bss_20850;
u8 fzgx_pool_gap_20854[0x243A8 - 0x20854];
u32 fzgx_obj_lbl_3_bss_243A8;

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_bss_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits .bss objects in first-access order */
    s = *(u8 *)&fzgx_obj_lbl_3_bss_0;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_8;
    s = *(u8 *)&fzgx_pool_gap_C;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_F0;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_120;
    s = *(u8 *)&fzgx_pool_gap_124;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_20844;
    s = *(u8 *)&fzgx_pool_gap_20846;
    s = *(u8 *)&fzgx_pool_gap_20848;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_20850;
    s = *(u8 *)&fzgx_pool_gap_20854;
    s = *(u8 *)&fzgx_obj_lbl_3_bss_243A8;
}
#pragma section code_type ".text"

extern Pad_1_bss_9F8 lbl_1_bss_9F8[];
extern s16 lbl_1_bss_96A;
extern u32 lbl_1_bss_6EAB4;
extern u32 lbl_3_data_B4;
extern u32 lbl_801A66A8;

extern void fn_3_679C(void);
extern int fn_1_4C10(void);
extern void fn_1_1280(u32);
extern void fn_1_4A00(s32, u8, u32);
extern void fn_1_A2D84(u32);

static inline int input_blocked(View_3_bss_F0 *obj) {
    if ((obj->unk_24 & 0x80000000) && !(obj->unk_24 & 1) && !(obj->unk_0 & 2)) {
        return 1;
    }
    if (fn_1_4C10()) {
        return 1;
    }
    return 0;
}

/* the pad part as a helper: its locals take their own registers, as in retail */
static inline void pad_input(void) {
    s16 horiz;
    s16 vert;
    s32 port;
    s32 next;

    horiz = 0;
    vert = 0;
    port = fzgx_obj_lbl_3_bss_F0.unk_6;
    if ((lbl_1_bss_9F8[port].unk_10 >> 3) & 1 || (lbl_1_bss_9F8[port].unk_12 >> 3) & 1) {
        vert--;
        fn_1_A2D84(0xA9010000);
        lbl_801A66A8 = 0;
    }
    if ((lbl_1_bss_9F8[port].unk_10 >> 2) & 1 || (lbl_1_bss_9F8[port].unk_12 >> 2) & 1) {
        vert++;
        fn_1_A2D84(0xA9010000);
        lbl_801A66A8 = 0;
    }
    next = fzgx_obj_lbl_3_bss_20844 + vert;
    fzgx_obj_lbl_3_bss_20844 = next > 2 ? 0 : (next < 0 ? 2 : next);

    if ((lbl_1_bss_9F8[port].unk_8 >> 9) & 1) {
        horiz = -1;
        fn_1_A2D84(0xA9010200);
    }
    if ((lbl_1_bss_9F8[port].unk_8 >> 8) & 1) {
        horiz = 1;
        fn_1_A2D84(0xA9010100);
    }

    if (horiz == -1) {
        if (fzgx_obj_lbl_3_bss_8 != 0) {
            fzgx_obj_lbl_3_bss_120 = 0x5D;
            fn_1_1280(1);
            lbl_3_data_B4 = 0x5C;
            fzgx_obj_lbl_3_bss_F0.unk_0 |= 0x1000000;
        } else {
            fn_1_4A00(0, 15, fzgx_obj_lbl_3_bss_20850);
            fzgx_obj_lbl_3_bss_243A8 = 0;
            lbl_1_bss_6EAB4 |= 0x24;
            fzgx_obj_lbl_3_bss_120 = 0x5C;
        }
    } else if (horiz != 0) {
        switch (fzgx_obj_lbl_3_bss_20844) {
        case 0:
            fn_1_4A00(0, 15, fzgx_obj_lbl_3_bss_20850);
            fzgx_obj_lbl_3_bss_243A8 = 0;
            fzgx_obj_lbl_3_bss_120 = 0x6D;
            break;
        case 1:
            fn_1_4A00(0, 15, fzgx_obj_lbl_3_bss_20850);
            fzgx_obj_lbl_3_bss_243A8 = 0;
            fzgx_obj_lbl_3_bss_120 = 0x67;
            break;
        case 2:
            fn_1_4A00(0, 15, fzgx_obj_lbl_3_bss_20850);
            fzgx_obj_lbl_3_bss_243A8 = 0;
            fzgx_obj_lbl_3_bss_120 = 0x6F;
            break;
        }
    }
}

void fn_3_6270(void) {
    s32 prev;

    fn_3_679C();
    if (fzgx_obj_lbl_3_bss_120 == -1) {
        fn_1_4C10();
    }
    if (input_blocked(&fzgx_obj_lbl_3_bss_F0)) {
        return;
    }
    prev = fzgx_obj_lbl_3_bss_120;
    if (prev != -1) {
        fzgx_obj_lbl_3_bss_120 = -1;
        lbl_1_bss_96A = prev;
        return;
    }

    pad_input();
}
