#include "types.h"
#include "rel/main_rel/globals.h"

#pragma section code_type ".fzgxpool"
static const u32 fzgx_pool_table1[1] = {0x42700000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const u32 *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.10000000149011612f;
    s = 32767.0f;
}
static const u32 fzgx_pool_table2[5] = {0x3D4CCCCD, 0x3FB1EB85, 0x1EB851EC, 0x469C4000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 4503599627370496.0;
    s = 1.0f;
    s = -0.029999999329447746f;
}
static const u32 fzgx_pool_table3[2] = {0x402E0000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const u32 *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table4[2] = {0x3FF80000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 0.5;
    s = 0.0f;
    s = 0.5f;
}
static const u32 fzgx_pool_table5[29] = {0x41000000, 0x437F0000, 0x41700000, 0x3E4CCCCD, 0x3DA3D70A, 0x3E800000, 0x3F7AE148, 0x3F7D70A4, 0x42200000, 0x41A00000, 0x3FC00000, 0x3EE66666, 0xC0000000, 0x3DAAAAAB, 0x3E19999A, 0x3E000000, 0xBECCCCCD, 0xBE99999A, 0x40000000, 0x437A0000, 0x3FE33333, 0x33333333, 0x3FD99999, 0x9999999A, 0x3E99999A, 0xBB83126F, 0x3C888889, 0x47800000, 0x45800000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const u32 *volatile cp; cp = fzgx_pool_table5; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.9599999785423279f;
}
static const u32 fzgx_pool_table6[3] = {0x3ECCCCCD, 0x3D4ED917, 0x3D50E560};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.949999988079071f;
}
static const u32 fzgx_pool_table7[49] = {0x3F666666, 0x00000000, 0x4062C000, 0x00000000, 0x40240000, 0x00000000, 0x40080000, 0x00000000, 0x00000000, 0x3DCCCCCD, 0xC019999A, 0x40A00000, 0x3FF33333, 0x33333333, 0x3FB99999, 0x9999999A, 0x41200000, 0x41900000, 0x3FE66666, 0x66666666, 0x40490000, 0x00000000, 0x00000000, 0x3DCCCCCD, 0xC019999A, 0x41980000, 0x40380000, 0x00000000, 0x3F3504F3, 0x00000000, 0x00000000, 0x00000000, 0x406FE000, 0x00000000, 0x3FECCCCC, 0xCCCCCCCD, 0x3B83126F, 0x3A83126F, 0x3C23D70A, 0xB4000000, 0x43700000, 0x42C80000, 0x43960000, 0x43480000, 0x461C4000, 0x459C4000, 0x434C0000, 0x42AA0000, 0xBD4CCCCD};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const u32 *volatile cp; cp = fzgx_pool_table7; }  /* fzgx-allow: S2 pool primer sink */
#pragma section code_type ".text"

typedef struct Fn5D91CVec {
    f32 x;
    f32 y;
    f32 z;
} Fn5D91CVec;

typedef struct Fn5D91CObj {
    u8 unk_0;
    u8 pad_1[7];
    u32 unk_8;
    u8 pad_c[4];
    s32 unk_10;
    u8 pad_14[0x14];
    f32 unk_28;
    u8 pad_2c[8];
    u32 unk_34;
    u8 pad_38[4];
    Fn5D91CVec unk_3c;
    Fn5D91CVec unk_48;
    s16 unk_54;
    s16 unk_56;
    s16 unk_58;
    s16 unk_5a;
    s16 unk_5c;
    s16 unk_5e;
    Fn5D91CVec unk_60;
    u8 pad_6c[0x1c];
    f32 unk_88;
    f32 unk_8c;
    u8 pad_90[4];
    f32 unk_94;
    f32 unk_98;
    f32 unk_9c;
    u8 pad_a0[0x14];
    f32 unk_b4;
    u8 unk_b8[4];
} Fn5D91CObj;

extern s32 lbl_1_bss_6C85C;
extern s32 fn_1_66B8(void *, f32);
extern void lbl_8006D8D8(s16);
extern void mathutil_mtxA_rotate_x(s16);
extern void mathutil_mtxA_rotate_z(s16);
extern void lbl_8006E1C0(Fn5D91CVec *, Fn5D91CVec *);
extern void lbl_8006E1B0(Fn5D91CVec *, Fn5D91CVec *);
extern f32 lbl_8006D0B4(f32);
extern void lbl_8006DC6C(void *);
extern void fn_8006E250(Fn5D91CVec *, Fn5D91CVec *);
extern void fn_8006E2B0(Fn5D91CVec *, Fn5D91CVec *);

static inline void set_translation(Fn5D91CObj *obj) {
    f32 x, y, z;
    /* volatile: keeps x's load first (locked-cache column idiom). */
    x = (obj->unk_94);
    y = obj->unk_98;
    z = obj->unk_9c;
    *(f32 *)(0xE0000000 + 0x0C) = x;
    *(f32 *)(0xE0000000 + 0x1C) = y;
    *(f32 *)(0xE0000000 + 0x2C) = z;
}

static inline f32 length(Fn5D91CVec *v) {
    f32 x, y, z, sum;
    x = v->x;
    sum = x * x;
    y = v->y;
    sum += y * y;
    z = v->z;
    sum += z * z;
    return lbl_8006D0B4(sum);
}

/* opt_dead_assignments off keeps z as its own value in the dot product, so up.z takes f4 as in retail
 * (the same pragma and z copy as the sibling fn_1_60880 in avline.c) */
#pragma opt_dead_assignments off
void fn_1_5D91C(Fn5D91CObj *obj) {
    Fn5D91CVec pos;
    Fn5D91CVec vel;
    Fn5D91CVec up;
    f32 len;
    f32 spin;
    f32 z;

    obj->unk_0 = 2;
    if (obj->unk_34 != 0) {
        if (++lbl_1_bss_6C85C > 200) {
            obj->unk_0 = 3;
        }
        if (fn_1_66B8(&obj->unk_3c, 4.0f) == 0) {
            obj->unk_0 = 3;
        }
        obj->unk_48.y += -0.06f;
        lbl_8006D8D8(obj->unk_56);
        mathutil_mtxA_rotate_x(obj->unk_54);
        mathutil_mtxA_rotate_z(obj->unk_58);
        up.x = 0.0f;
        up.y = 1.0f;
        up.z = 0.0f;
        lbl_8006E1C0(&up, &up);
        length(&obj->unk_48);
        len = up.x * obj->unk_48.x;
        len += up.y * obj->unk_48.y;
        z = up.z;
        len += z * obj->unk_48.z;
        len = -0.03f * len;
        obj->unk_48.x += (f32)(up.x * len);
        obj->unk_48.y += (f32)(up.y * len);
        obj->unk_48.z += (f32)(up.z * len);
        obj->unk_48.x *= 0.96f;
        obj->unk_48.y *= 0.96f;
        obj->unk_48.z *= 0.96f;
        lbl_8006DC6C(obj->unk_b8);
        set_translation(obj);
        fn_8006E250(&obj->unk_3c, &pos);
        fn_8006E2B0(&obj->unk_48, &vel);
        if (pos.y < -0.5f) {
            lbl_1_data_1D628 = lbl_1_data_1D628 * 1103515245 + 12345;
            vel.y = -1.0f * vel.y + (f64)(vel.y * ((f32)((lbl_1_data_1D628 >> 16) & 0x7FFF) / 32767.0f - 0.5));
            lbl_8006E1C0(&up, &up);
            vel.x = vel.x + (f64)(0.2 * up.x * vel.y);
            vel.y = vel.y + (f64)(0.2 * up.y * vel.y);
            vel.z = vel.z + (f64)(0.2 * up.z * vel.y);
        }
        lbl_8006E1B0(&pos, &obj->unk_3c);
        lbl_8006E1C0(&vel, &obj->unk_48);
        obj->unk_3c.x += obj->unk_48.x;
        obj->unk_3c.y += obj->unk_48.y;
        obj->unk_3c.z += obj->unk_48.z;
        spin = 512.0f / obj->unk_28;
        obj->unk_5a += (s32)(spin * (obj->unk_48.x + obj->unk_48.y));
        obj->unk_5c += (s32)(spin * (obj->unk_48.y + obj->unk_48.z));
        obj->unk_5e += (s32)(spin * (obj->unk_48.z + obj->unk_48.x));
        obj->unk_5a -= obj->unk_5a >> 5;
        obj->unk_5c -= obj->unk_5c >> 5;
        obj->unk_5e -= obj->unk_5e >> 5;
        obj->unk_54 += obj->unk_5a;
        obj->unk_56 += obj->unk_5c;
        obj->unk_58 += obj->unk_5e;
    } else {
        obj->unk_60 = obj->unk_3c;
        len = 1.0f - obj->unk_88;
        obj->unk_48.x *= len;
        obj->unk_48.y *= len;
        obj->unk_48.z *= len;
        len = length(&obj->unk_48);
        lbl_1_data_1D628 = lbl_1_data_1D628 * 1103515245 + 12345;
        obj->unk_48.x += (f32)(0.1f * (len * ((f32)((lbl_1_data_1D628 >> 16) & 0x7FFF) / 32767.0f - 0.5f)));
        lbl_1_data_1D628 = lbl_1_data_1D628 * 1103515245 + 12345;
        obj->unk_48.y += (f32)(0.1f * (len * ((f32)((lbl_1_data_1D628 >> 16) & 0x7FFF) / 32767.0f - 0.5f)));
        lbl_1_data_1D628 = lbl_1_data_1D628 * 1103515245 + 12345;
        obj->unk_48.z += (f32)(0.1f * (len * ((f32)((lbl_1_data_1D628 >> 16) & 0x7FFF) / 32767.0f - 0.5f)));
        obj->unk_48.y += -0.03f;
        obj->unk_3c.x += obj->unk_48.x;
        obj->unk_3c.y += obj->unk_48.y;
        obj->unk_3c.z += obj->unk_48.z;
        if (((obj->unk_8 >> 12) & 1) == 0) {
            lbl_8006DC6C(obj->unk_b8);
            set_translation(obj);
            fn_8006E250(&obj->unk_3c, &pos);
            fn_8006E2B0(&obj->unk_48, &vel);
            if (pos.y < -0.5f) {
                lbl_1_data_1D628 = lbl_1_data_1D628 * 1103515245 + 12345;
                vel.y = -1.0f * vel.y + (f64)(vel.y * ((f32)((lbl_1_data_1D628 >> 16) & 0x7FFF) / 32767.0f - 0.5));
                vel.z = 0.95f * vel.z;
            }
            lbl_8006E1B0(&pos, &obj->unk_3c);
            lbl_8006E1C0(&vel, &obj->unk_48);
        }
        obj->unk_88 += (f32)(0.03f * (obj->unk_8c - obj->unk_88));
        obj->unk_b4 *= 1.0f - 1.0f / (obj->unk_10 + 1);
    }
}
#pragma opt_dead_assignments reset
