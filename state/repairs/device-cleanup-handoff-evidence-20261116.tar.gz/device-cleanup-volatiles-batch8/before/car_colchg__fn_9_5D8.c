#include "types.h"
#include "rel/car_colchg/globals.h"
#include "rel/car_colchg/car_colchg.h"


extern struct Struct_lbl_1_bss_D58 lbl_1_bss_D58;
s32 fn_1_4C10(void);
s32 fn_1_4C10(void);
extern u16 lbl_1_bss_96A;
extern struct Entry *lbl_1_data_1FB6C[];

#include "types.h"
#include "rel/car_colchg/globals.h"






s32 fn_1_4C10(void);

struct fn_9_5D8_ColchgState {
    u8 unk_0[8];
    u16 flags_8;
    u8 unk_A[6];
    u16 flags_10;
    u16 flags_12;
};

struct ColchgVolFlags {
    u8 unk_0[8];
    u16 flags_8;
    u8 unk_A[6];
    volatile u16 flags_10;  /* retail re-reads it for the second test: keep the loads distinct */
    volatile u16 flags_12;  /* retail re-reads it for the second test: keep the loads distinct */
};

void fn_9_5D8(void) {
    s8 delta;
    struct fn_9_5D8_ColchgState *state;
    s16 *selection;
    s16 *entry;
    s32 value;

    if (fn_1_4C10() == 0) {
        state = (struct fn_9_5D8_ColchgState *)&lbl_1_bss_D58;
        if ((state->flags_8 >> 9) & 1) {
            (*(s16 *)&lbl_1_bss_96A) = 0x72;
        }
        delta = 0;
        if ((((struct ColchgVolFlags *)&lbl_1_bss_D58)->flags_10 & 1) ||
            (((struct ColchgVolFlags *)&lbl_1_bss_D58)->flags_12 & 1)) {
            delta = -1;
        }
        if ((((struct ColchgVolFlags *)&lbl_1_bss_D58)->flags_10 >> 1 & 1) ||
            (((struct ColchgVolFlags *)&lbl_1_bss_D58)->flags_12 >> 1 & 1)) {
            delta++;
        }
        if (delta != 0) {
            selection = &lbl_9_bss_8->unk_0;
            value = *selection + delta;
            *selection = value > 40 ? 0 : value < 0 ? 40 : value;
        }
        selection = &lbl_9_bss_8->unk_0;
        entry = (*(s16 * (*)[])&lbl_1_data_1FB6C)[*selection];
        if (((state->flags_8 >> 8) & 1) && *entry != -1) {
            (*(s16 *)&lbl_1_bss_96A) = 0x76;
        }
    }
}
