#include "types.h"
#include "rel/main_rel/globals.h"

extern struct ArenaData lbl_1_data_8;
extern u32 OSGetArenaLo(void);
extern u32 OSGetArenaHi(void);
extern void OSSetArenaLo(u32 arena_lo);
extern u16 lbl_1_bss_990[28];
extern u8 lbl_1_bss_D78;
extern u8 lbl_1_bss_DA6;
extern u32 lbl_1_bss_DB0[2];
extern u32 lbl_1_bss_DA8;
extern void fn_1_43A4(void);
extern u32 lbl_1_data_2C70;
extern void fn_80008E84(u32 value);
extern u32 lbl_1_bss_DAC;
extern struct fn_1_634_lbl_1_bss_54 lbl_1_bss_54;
extern u32 fn_8006FFC4(u32);
extern u32 fn_1_48780(void);
extern u32 lbl_801A66B4;
extern u32 lbl_801A66BC;
extern struct fn_1_904_lbl_1_bss_4 lbl_1_bss_4;
extern struct fn_1_914_lbl_1_bss_0 lbl_1_bss_0;
extern u16 lbl_1_bss_96A;
extern u32 fn_1_37E98(void);
extern u32 lbl_1_bss_96C;
extern u32 camera_set_state_flag(u32);
extern u32 fn_1_D31E0(u32);
extern struct fn_1_12B4_lbl_1_bss_962 lbl_1_bss_962;
extern u32 lbl_1_data_2A20;
extern u32 lbl_1_data_7C0;
extern u32 fn_1_15659C(u32);
extern u32 fn_80008BEC(void *, u32, u32);
extern u8 lbl_1_bss_978[];
extern u32 lbl_1_data_2B78;
extern u32 OSGetTick(u32);
extern u32 lbl_1_bss_D7C;
extern u8 lbl_1_bss_DA4;
extern char lbl_1_data_2C9C[20];
extern char lbl_1_data_2CB0[31];
extern void OSPanic(const char *message, int line, const char *file, ...);
extern void fn_80009AA8(u32 value, u32 count, const char *file, int line);
extern u32 fn_1_156754(u32);
extern u32 fn_1_A5864(void);
extern u32 fn_1_F7578(void);
extern struct fn_1_3C98_lbl_1_bss_DA5 lbl_1_bss_DA5;
extern u32 fn_80008EC8(u32, u32, u32);
extern u32 fn_800793D4(u32, u32, u32);
extern struct fn_1_48B0_lbl_801A6CF8 lbl_801A6CF8;
extern u32 lbl_801A6CFC;
extern struct fn_1_44B4_lbl_1_bss_DB8 lbl_1_bss_DB8;
extern struct fn_1_4438_lbl_1_bss_DC4 lbl_1_bss_DC4;
extern u8 lbl_1_bss_8E6B0[308];
extern void fn_1_14FCE4(void *data, s32 value);
extern struct fn_1_798_slot lbl_1_bss_8E7E4[];
extern u8 lbl_1_bss_AA0[336];
extern u8 lbl_1_rodata_108[88];
extern u32 fn_80008BA8(void *, void *, u32);
extern void fn_1_3BDC(u32 arg0);
extern u32 fn_1_3C18(s32);

#include "dolphin/types.h"
#include "dolphin/hw_regs.h"

#ifndef GAME_MAIN_REL__PROLOG_TYPES_H
#define GAME_MAIN_REL__PROLOG_TYPES_H

#endif  // GAME_MAIN_REL__PROLOG_TYPES_H

extern u8 lbl_1_rodata_C4[60];

struct fn_1_1FE8_Arg1 {
    s8 unk_0; s8 unk_1; s8 unk_2; s8 unk_3;
    u8 unk_4; u8 unk_5; u8 unk_6; u8 unk_7;
};
static inline s32 absval(s32 x) { return __abs(x); }
s8 fn_1_1FE8(u16 *arg0, struct fn_1_1FE8_Arg1 *arg1, u32 arg2, s8 arg3) {
    u32 v1 = (u16)arg2;
    s8 v5 = 0;
    u8 *v7;
    u16 v2;
    u32 v6;
    u32 v3;
    s32 v0;
    if ((arg2 >> 15) & 1) return 0;
    v6 = v1 & 15;
    if (v6) {
        v2 = *arg0;
        v3 = __cntlzw(v6);
        while (v6 != 0) {
            v7 = &lbl_1_rodata_C4[(31-v3)*2];
            if (__rlwnm(v2, (v7[0]+1)&31, 31, 31)) v5 -= 25;
            if (__rlwnm(v2, (v7[1]+1)&31, 31, 31)) v5 += 25;
            v6 &= ~(0x80000000U >> v3);
            v3 = __cntlzw(v6);
        }
    }
    if (v5 != 0) {
        v0 = arg3 + v5;
        v5 = (v0 < -100) ? -100 : ((v0 > 100) ? 100 : v0);
    }
    v1 = arg2 & 0x3f0;
    if (!v1) return v5;
    if ((v1 >> 4) & 1) { if (v5 < __abs((s8)arg1->unk_0)) v5 = arg1->unk_0; }
    if ((v1 >> 5) & 1) { if (v5 < __abs((s8)arg1->unk_1)) v5 = arg1->unk_1; }
    if ((v1 >> 6) & 1) { if (v5 < __abs((s8)arg1->unk_2)) v5 = arg1->unk_2; }
    if ((v1 >> 7) & 1) { if (v5 < __abs((s8)arg1->unk_3)) v5 = arg1->unk_3; }
    if ((v1 >> 8) & 1) { if (v5 < __abs(arg1->unk_5 - arg1->unk_4)) v5 = arg1->unk_5 - arg1->unk_4; }
    if ((v1 >> 9) & 1) { s32 v27 = arg1->unk_6 - arg1->unk_7; if (v5 < __abs(v27)) v5 = v27; }
    return v5;
}
