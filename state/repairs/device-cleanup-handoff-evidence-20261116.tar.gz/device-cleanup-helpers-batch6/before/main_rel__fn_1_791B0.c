#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/screen_effect.h"

extern u32 lbl_1_bss_6C8DC[2];
extern u32 lbl_801A6410;
extern void fn_1_46B4(u32 arg0, u32 arg1, void *arg2, u32 arg3);
extern void fn_1_727BC(u32 arg0, u32 arg1, void *arg2);
extern void fn_1_76A94(void *arg0, u32 arg1);
extern void fn_1_76DBC(void);
extern void fn_1_4E500(void);
extern void fn_1_4E638(int);
extern void fn_1_4E6F4(void);
extern void fn_80073778(void *arg0, int arg1);
extern s32 fn_1_A5D9C(void);
extern const f32 lbl_1_rodata_31AC;
extern u32 fn_80008E84(u32 arg);
extern void fn_1_77238(void);
extern void fn_1_772E0(void);
extern void fn_1_77384(void *arg);
extern void fn_80072864(int arg0);
extern void fn_800745A4(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5);
extern void fn_80074660(int arg0);
extern void fn_80073678(int arg0);
extern void fn_80073898(int arg0);
extern void fn_80074788(int arg0);
extern void fn_800738E0(int arg0, int arg1, int arg2);
extern void fn_80073D60(int arg0, int arg1, int arg2, int arg3, int arg4);
extern void fn_800734A8(int arg0, int arg1, int arg2, int arg3);
extern void fn_80072EDC(int arg0, int arg1);
extern f32 lbl_1_rodata_31B0[10];
extern const f64 lbl_1_rodata_31A0;
extern void lbl_8006D784(f32 *arg);
extern void fn_80073A58(int arg0, f32 *arg1, int arg2);
extern void fn_800739E0(int arg0, int arg1, int arg2);
extern void GXLoadTexMtxImm(f32 *arg0, int arg1, int arg2);
extern void fn_8006FDEC(void);
extern void fn_8006FEFC(void);
extern void fn_8006FD1C(void);
extern void fn_1_79810(void);
extern void fn_1_79948(void);
extern void fn_1_791B0(void);
extern void fn_1_9A1E8(void);
extern void fn_1_9A864(void);
extern u8 fn_1_7B074(void);
extern void fn_80071718(void *arg);
extern void fn_800711A8(void *arg);
extern void fn_1_14CB4(void);
extern void fn_1_FA84(void);
extern const f32 lbl_1_rodata_32CC;
extern void fn_1_79C88(void *arg0, s32 arg1, f32 arg2, s32 arg3);
extern void lbl_8006DBAC(void *arg0);
extern void lbl_8006E1B0(void *arg0, void *arg1);
extern void sprintf(char *dst, const char *format, ...);
extern void fn_1_465D0(char *text, int arg);
extern void fn_1_14D5C(void *object, int arg);
extern void fn_1_46EA8(int value);
extern void fn_1_12620(void *object);
extern void fn_1_46DC4(void *obj);

extern void fn_1_727BC();
extern void fn_8006FDEC(void);
extern void fn_80071718(void *);
extern void fn_800711A8(void *);
extern u32 fn_8003526C(u32, u32);
extern u32 fn_80074300(u32, u32, u32, u32);
extern u32 fn_80074438(u32, u32, u32, u32);

typedef struct {
    Obj_1_bss_6D778_At0 *unk_0;
    const u8 *unk_4;
} ScreenEffectEntry;

typedef struct {
    s32 count;
    u8 pad_4[0x4];
    ScreenEffectEntry *entries;
} ScreenEffectTable;

static inline ScreenEffectEntry *fn_1_791B0_array_read(ScreenEffectEntry *array) { return array; }
#pragma opt_common_subs off
void fn_1_791B0(void) {
    struct { s32 value; } i;
    ScreenEffectTable *table;

    lbl_1_bss_6D778.unk_0 = 0;
    if (lbl_1_data_1DFA4.unk_8 < 0) {
        return;
    }

    table = (ScreenEffectTable *)lbl_1_bss_6D774;
    if (table == 0) {
        return;
    }

    for (i.value = 0; i.value < table->count; i.value++) {
        if (fn_1_791B0_array_read(table->entries)[i.value].unk_4[0] == 'C' &&
            fn_1_791B0_array_read(table->entries)[i.value].unk_4[3] == '_' &&
            fn_1_791B0_array_read(table->entries)[i.value].unk_4[4] == 'M' &&
            fn_1_791B0_array_read(table->entries)[i.value].unk_4[5] == 'A' &&
            fn_1_791B0_array_read(table->entries)[i.value].unk_4[6] == 'P' &&
            fn_1_791B0_array_read(table->entries)[i.value].unk_4[7] == '\0') {
            lbl_1_bss_6D778.unk_0 = fn_1_791B0_array_read(table->entries)[i.value].unk_0;
            return;
        }
    }
}
#pragma opt_common_subs reset
