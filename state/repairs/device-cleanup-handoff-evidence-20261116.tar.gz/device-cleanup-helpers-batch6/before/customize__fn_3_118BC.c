#include "types.h"
#include "rel/customize/globals.h"
#include "rel/customize/emb_paste_editor.h"


extern u8 lbl_3_bss_8F200[];
extern void fn_1_FC414(void *, int);
extern u8 lbl_3_bss_A1778[12];
extern s16 lbl_1_bss_96A;
extern void fn_1_4A00(int, int, u32);
extern void fn_1_FDFF4(void);
extern void fn_1_435C(u32);
extern void fn_1_426C(s16);
extern void fn_80008BA8(struct Sig_fn_8004E278_fn_8004E278_Arg0 *, u32, u32);
extern void fn_80008BEC(struct Sig_fn_8004E278_fn_8004E278_Arg0 *, int, u32);
extern u16 lbl_1_bss_9F8[];
extern u8 lbl_3_rodata_4C8[0xc];
extern u8 lbl_3_rodata_4D4[0xc];
extern u32 lbl_801A6410;
extern u32 lbl_801A66B4;
extern u8 lbl_3_data_3234[168];
extern u8 lbl_3_data_3360__fzgx_offset_0[];
extern u8 lbl_3_data_336C__fzgx_offset_0[];
extern u8 lbl_3_data_3370__fzgx_offset_0[];
extern u8 lbl_3_data_3380__fzgx_offset_0[];
extern u8 lbl_3_data_3388__fzgx_offset_0[];
extern u8 lbl_3_data_3398__fzgx_offset_0[];
extern u8 lbl_3_data_33A8__fzgx_offset_0[];
extern u8 lbl_3_data_33BC__fzgx_offset_0[];
extern u8 lbl_3_data_33CC__fzgx_offset_0[];
extern u8 lbl_3_data_33DC__fzgx_offset_0[];
extern u8 lbl_3_data_33E4__fzgx_offset_0[];
extern u8 lbl_3_data_33F0__fzgx_offset_0[];
extern u8 lbl_3_data_33F8__fzgx_offset_0[];
extern u8 lbl_3_data_3400__fzgx_offset_0[];
extern u8 lbl_3_data_3408__fzgx_offset_0[];
extern u8 lbl_3_data_3410__fzgx_offset_0[];
extern u8 lbl_3_data_3420__fzgx_offset_0[];
extern u8 lbl_3_data_342C__fzgx_offset_0[];
extern u8 lbl_3_data_3444__fzgx_offset_0[];

extern u32 fn_3_11A38(void);
extern void fn_1_A2D84(u32);



static inline u16 *fn_3_118BC_array_read(u16 *array) { return array; }
#pragma opt_propagation off
void fn_3_118BC(void) {
    u16 *p;
    u32 v;

    fn_3_11A38();
    p = lbl_1_bss_9F8;
    p += 4;
    v = fn_3_118BC_array_read(p)[lbl_3_bss_7EDD8.unk_14 * 10];
    if (((v >> 4) & 1) || ((v >> 9) & 1)) {
        fn_1_A2D84(0xa9010200);
        lbl_3_bss_7EDD8.unk_C = lbl_3_bss_7EDD8.unk_10;
        lbl_3_bss_7EDD8.unk_10 = 0x1000000;
    }
}
#pragma opt_propagation reset
