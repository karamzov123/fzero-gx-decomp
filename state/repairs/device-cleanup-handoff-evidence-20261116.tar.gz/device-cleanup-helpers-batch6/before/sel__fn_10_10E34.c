#include "types.h"
#include "rel/sel/globals.h"
#include "rel/sel/sel.h"
extern u32 lbl_10_bss_51788[25];
extern f32 lbl_10_bss_55B3C[];
extern u8 lbl_10_rodata_1548[0x8];
extern const f32 lbl_10_rodata_158[19];
extern u8 lbl_10_rodata_1D64[0x4];
extern u8 lbl_10_rodata_1D68[0x8];
extern u8 lbl_10_rodata_94[0xc4];
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAB4;
extern u32 * lbl_1_bss_6EAD0;
extern int lbl_1_bss_7180C;
extern u32 lbl_1_bss_718E0;
extern s16 lbl_1_bss_8B3A0;
extern s16 lbl_1_bss_8CA26;
extern s16 lbl_1_bss_960;
extern s16 lbl_1_bss_962;
extern s16 lbl_1_bss_966;
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_980[4];
extern s8 lbl_1_bss_9C;
extern u8 lbl_1_bss_9C8[];
extern u8 lbl_1_bss_9F8[];
extern const char * lbl_1_data_2AA24[];
extern const char * lbl_1_data_2BD54[][6];
extern char * lbl_1_data_418D4[];
extern char lbl_1_rodata_26F8;
extern const u8 lbl_1_rodata_D5B8[];
extern const u32 lbl_1_rodata_D870[];
extern u32 lbl_801A6410;
extern u32 lbl_801A66A0;
extern u32 lbl_801A66A8;
extern s32 lbl_801A66B4;
extern u16 lbl_801A66C0;
extern void fn_800713E0(u32, u32);
extern void fn_1_8019C(u32);
extern void fn_1_12B3F8(void *, u32, u32, void *, void *, void *);
extern void fn_1_12C6BC(u32);
extern void fn_10_1B658(void);
extern void fn_1_8F494(void *value);
extern void fn_10_1B65C(void);
extern void fn_10_1B6A8(void);
extern void OSReport(const char *, ...);
extern void fn_1_12F358(s16);
extern s32 fn_1_1310E0(void);
extern void fn_1_131084(u32, s32);
extern void fn_10_1B660(void);
extern void fn_1_7B558(u32, u32, u32, u32, u32, u32, f32);
extern void fzgx_pool_sink_f32(f32);
extern void fzgx_pool_sink_f64(f64);
extern void fn_80074188(s16, s16, s16, s16);

#include "font.h"

#pragma section code_type ".fzgxpool"
static const unsigned long fzgx_pool_table1[17] = {0x00000000, 0x0000B500, 0x0000B600, 0x0000AD00, 0x0000B300, 0x0000B800, 0x0000B200, 0x0000B100, 0x0000AE00, 0x0000B400, 0x0000B900, 0x0000B000, 0x0000AF00, 0x0000B700, 0x00000000, 0x00000000, 0x00F0F0FF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const unsigned long *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.0f;
    s = 0.5f;
    s = 0.0f;
    s = 0.20000000298023224f;
    s = 0.4000000059604645f;
    s = 320.0f;
    s = 3.0f;
    s = 323.0f;
    s = 4.0f;
    s = 5.0f;
    s = 6.0f;
    s = 0.25f;
    s = 16384.0f;
    s = 65536.0f;
    s = 60.0f;
    s = 1.875f;
    s = 0.5555555820465088f;
    d = 4503601774854144.0;
    d = 4503599627370496.0;
}
static const unsigned long fzgx_pool_table3[24] = {0x00110012, 0x00130014, 0x00150012, 0x00130014, 0x00000000, 0x00F0F0FF, 0x00000000, 0x00F0F0FF, 0x00010002, 0x00030004, 0x00050006, 0x00070008, 0x0009000A, 0x000B000C, 0x00110012, 0x00130014, 0x00150012, 0x00130014, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0x00FF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const unsigned long *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 59.0f;
    s = 82.0f;
    s = 77.0f;
    s = 98.0f;
    s = 25.0f;
    s = 115.0f;
    s = 0.699999988079071f;
    s = 9.0f;
    s = 0.6666666865348816f;
    s = 431.0f;
}
static const unsigned long fzgx_pool_table5[2] = {0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const unsigned long *volatile cp; cp = fzgx_pool_table5; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 61.0f;
    s = 81.0f;
    s = 110.0f;
    s = 40.0f;
    s = 80.0f;
    s = 210.0f;
    s = 230.0f;
    s = 367.0f;
    s = 55.0f;
    s = 76.0f;
    s = 100.0f;
    s = 365.0f;
    s = 75.0f;
    s = 117.0f;
    s = 0.4583333432674408f;
    s = 165.0f;
    s = 155.0f;
    s = 87.0f;
    s = 184.0f;
    s = 90.0f;
    s = 381.0f;
    s = 475.0f;
    s = 174.0f;
    s = 423.0f;
    s = 194.0f;
    s = 8192.0f;
    s = 20.0f;
    s = -8192.0f;
    s = 362.0f;
    s = 524.0f;
    s = 72.0f;
    s = 11.0f;
    s = 0.8999999761581421f;
    s = 0.5416666865348816f;
    s = -4.0f;
    s = 334.0f;
    s = 341.0f;
    s = -6.0f;
    s = 0.625f;
    s = 346.0f;
    s = 211.0f;
    s = 161.0f;
    s = 192.0f;
    s = 0.07000000029802322f;
}
static const unsigned long fzgx_pool_table7[15] = {0x00170018, 0x0019001A, 0x001B001C, 0x001D001E, 0x001F0021, 0x00220000, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0xFFFFFF00, 0x00FF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const unsigned long *volatile cp; cp = fzgx_pool_table7; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime8(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 119.0f;
    s = 141.0f;
    s = 160.0f;
    s = 163.0f;
    s = 43.0f;
    s = 130.0f;
}
static const unsigned long fzgx_pool_table9[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep9(void) { const unsigned long *volatile cp; cp = fzgx_pool_table9; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime10(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    d = 90.0;
    d = 67.5;
    d = 22.5;
    s = 22.5f;
    s = 0.009999999776482582f;
    s = 0.9166666865348816f;
    s = 2.0f;
    s = 240.0f;
    s = 9.999999747378752e-05f;
    s = 278.0f;
    s = 316.0f;
}
static const unsigned long fzgx_pool_table11[1] = {0xFFFFFFFF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep11(void) { const unsigned long *volatile cp; cp = fzgx_pool_table11; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime12(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.75f;
    s = 250.0f;
    s = 373.0f;
    s = 354.0f;
    s = 68.0f;
    s = 0.8666666746139526f;
    s = -1.0f;
    s = 140.0f;
    s = 50.0f;
    s = 0.10000000149011612f;
    s = 620.0f;
    s = 24.0f;
    s = 10.0f;
    s = 384.0f;
    s = 640.0f;
    s = 0.5833333134651184f;
    s = 0.6000000238418579f;
}
static const unsigned long fzgx_pool_table13[2] = {0x000000FF, 0x000000FF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep13(void) { const unsigned long *volatile cp; cp = fzgx_pool_table13; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime14(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 17.0f;
    s = 338.0f;
    s = 150.0f;
    s = 15.0f;
    s = 317.0f;
    s = -106.0f;
    s = 318.0f;
    s = 106.0f;
    s = 333.0f;
    s = -87.0f;
    s = 0.09000000357627869f;
    s = -11.0f;
    s = 645.0f;
    s = 721.0f;
    s = 330.0f;
    s = 0.9900000095367432f;
    s = 167.0f;
    s = 38.0f;
}
/* the remaining pool words (colour image 0x300, 8.0, 366.0, 12.0, 14.0, 0.76) are emitted by fn_10_10E34 itself in first-use order */
#pragma section code_type ".text"

typedef struct {
    u8 pad_0[0x9E];
    u8 player; /* 0x9E */
    u8 pad_9F[0x41];
    u32 unk_E0[4];
    u32 unk_F0[8];
    s32 unk_110[4];
} SelBlinkState;

typedef struct {
    u8 r, g, b, a;
} fn_10_10E34_SelColor;






extern s8 fn_1_A5DC4(void);
extern void fn_10_12E34(FontDrawPacket *packet, FontVertex *vertices);

static inline const unsigned long fn_10_10E34_array_read(const unsigned long *array, s32 index) { return array[index]; }
void fn_10_10E34(void) {
    FontDrawPacket packet;
    s32 xs[2];
    s32 j;
    s32 i;
    f32 scale;
    s32 blink;
    s32 player;

    player = (*(SelBlinkState *)&lbl_1_bss_8B3A0).player;
    xs[0] = (fn_1_A5DC4() ? 72 : 88) + 8;
    xs[1] = 640.0f - (fn_1_A5DC4() ? 72 : 88) - 8.0f;
    for (i = 0; i < 2; i++) {
        packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
        packet.image = 0x12;
        packet.x = xs[i];
        packet.y = 366.0f;
        packet.z = 90.0f;
        packet.scale_x *= 12.0f;
        packet.scale_y *= 14.0f;
        packet.flags = 10;
        {
            fn_10_10E34_SelColor col = { 0, 0, 0, 0xFF };
            *(fn_10_10E34_SelColor *)packet.color = col;
        }
        fn_1_4F734(&packet);
        for (j = 0; j < 3; j++) {
            scale = (f32)(0.76f * j) + 0.76f * (lbl_801A66A0 % 60) / 60.0f;
            packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
            packet.image = 0x9A18;
            packet.x = xs[i];
            packet.y = 366.0f;
            packet.z = 88 - j;
            packet.rotation_y = 0xEEE;
            packet.scale_x *= scale;
            packet.scale_y *= scale;
            packet.flags = 10;
            if (i == 1) {
                blink = 0;
                if (lbl_801A66A0 - (*(SelBlinkState *)&lbl_1_bss_8B3A0).unk_E0[(s16)player] > 30 ||
                    ((*(SelBlinkState *)&lbl_1_bss_8B3A0).unk_F0[(s16)player] != 0 && (*(SelBlinkState *)&lbl_1_bss_8B3A0).unk_110[(s16)player] != 0)) {
                    blink = 1;
                }
                *(f32 *)&packet.unk_54 = blink != 0;
                if (!*(f32 *)&packet.unk_54) {
                    packet.flags |= 0x4000000;
                    packet.vertex_callback = fn_10_12E34;
                }
            }
            packet.alpha = 0.5f;
            fn_1_4F734(&packet);
        }
    }
}
#pragma opt_dead_assignments reset
