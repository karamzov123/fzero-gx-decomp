#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/bg_cas.h"
extern void fn_80008BEC(void *arg0, int arg1, int arg2);
extern void fn_1_FCA10(void);
extern int fn_1_FCF50(void);
extern void *fn_1_563B8(void *);
extern f32 lbl_1_rodata_761C[13];
extern void fn_1_7EB8C(void *, f32);
extern void fn_1_7F20C(void *, s32, f32);
extern void lbl_8006DB74(void *);
extern void lbl_8006DBAC(void *);
extern void fn_1_FD3A8(void);
extern void *memset(void *, int, u32);
extern void fn_1_FE7D8(u8 *, s32);
extern void fn_1_FF420(u8 *);
extern void fn_80074788(int);
extern void fn_80072864(int);
extern void fn_800745A4(int, int, int, int, int, int);
extern void fn_800734A8(int, int, int, int);
extern void fn_80072AB0(int, int, int);
extern void fn_800735C8(int, int);
extern void fn_80073620(int, int);
extern void fn_80073C6C(int);
extern void fn_80072C24(int, int, int, int, int);
extern void fn_80072D64(int, int, int, int, int, int);
extern void fn_80072CC4(int, int, int, int, int);
extern void fn_80072E20(int, int, int, int, int, int);
extern void fn_80073678(int);
extern void fn_80074660(int);
extern void fn_80074918(int, int, int);
extern void fn_800720B0(int);
extern void fn_1_9A508(Obj_1_data_2A7E0 *arg0);
extern void fn_1_9AD54(void);
extern void fn_1_9AD88(void);
extern void fn_1_10069C(Obj_1_data_2A7E0_At3C *);
extern void fn_1_FF038(Obj_1_data_2A7E0_At3C *);
extern const f64 lbl_1_rodata_760C;
extern void OSPanic(const char *, int, const char *, ...);
extern void lbl_8006D758(void);
extern void lbl_8006E13C(void *);
extern void lbl_8006E0A4(void *);
extern void fn_80008BA8(void *, void *, u32);
extern u8 lbl_1_bss_851E0[36];
extern void fn_1_7F230(void *, s32, f32);
extern void fn_1_FFC60(Obj_1_data_2A7E0_At3C *arg0);
extern void fn_1_FEC7C(void *object);
extern const f32 lbl_1_rodata_76A8;

typedef struct {
    u32 b0 : 5;
    u32 b5 : 1;
    u32 rest : 26;
} FDB40Bits;

static inline u32 rotl(u32 x, int n) { return (x >> n) & 1; }

s32 fn_1_FDB40(void **arg0) {
    u8 *p;
    u8 *q;
    if (arg0 == 0) {
        return 0;
    }
    p = *arg0;
    if (p == 0) {
        return 0;
    }
    if (*(s16 *)(p + 800) >= 4) {
        return 0;
    }
    if (*(u32 *)(p + 932) == 0) {
        return 0;
    }
    if (*(s16 *)(p + 954) == 5) {
        return 0;
    }
    if (__rlwnm(*(u32 *)(p + 912), 6, 31, 31) && *(u32 *)(p + 928) == 0) {
        return 0;
    }
    if ((*(u32 *)(p + 912) & 0x200000) != 0) {
        return 0;
    }
    q = *(u8 **)(p + 812);
    if (q != 0 && (*(u32 *)(q + 1420) & 0x10) != 0) {
        return 0;
    }
    return 1;
}
