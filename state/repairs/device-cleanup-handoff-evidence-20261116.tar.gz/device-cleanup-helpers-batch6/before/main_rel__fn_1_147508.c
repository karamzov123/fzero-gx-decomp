#include "types.h"
#include "font.h"
#include "rel/main_rel/sel_static_disp.h"

/* Raw retail literal-pool bits. Volatile stores keep the shared-pool literals emitted. */
#pragma section code_type ".fzgxpool"
static const u32 fzgx_pool_table_0[71] = {
    0x00000000, 0x00000000, 0x00000000, 0x3DCCCCCD,
    0x3F800000, 0x3F800000, 0x00000000, 0x00000000,
    0x3F800000, 0x3F800000, 0x00000000, 0x3F800000,
    0x04000000, 0x00000000, 0xFFFFFFFF, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x00000000,
    0 /* unused relocation addend */, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x3DCCCCCD, 0x3F800000, 0x3F800000,
    0x00000000, 0x00000000, 0x3F800000, 0x3F800000,
    0x00000000, 0x3F800000, 0x04000000, 0x00000000,
    0xFFFFFFFF, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x00000000, 0 /* unused relocation addend */, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x3DCCCCCD,
    0x3F800000, 0x3F800000, 0x00000000, 0x00000000,
    0x3F800000, 0x3F800000, 0x00000000, 0x3F800000,
    0x04000000, 0x00000000, 0xFFFFFFFF, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x00000000,
    0 /* unused relocation addend */, 0x00000000, 0x00000000, 0x3F755555,
    0x41B80000, 0x40000000, 0x3F2AAAAB,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_11C(volatile f32 *out) { *out = 0.5f; }

static const u32 fzgx_pool_table_120[2] = {
    0x3F155555, 0x00000000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_128(volatile f64 *out) { *out = 4503601774854144.0; }

static const u32 fzgx_pool_table_130[24] = {
    0x44150000, 0x44040000, 0x0000001A, 0x00000023,
    0x0000009C, 0x000000A5, 0x00000018, 0x00000021,
    0x00000085, 0x0000008E, 0x000000F2, 0x000000FB,
    3233857536U, 3229614080U, 0x42200000, 0x43F00000,
    0x44200000, 0x47AFC800, 0x3E99999A, 0x3F333333,
    0xBF800000, 0x43500000, 0xC47A0000, 0xC2480000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_190(volatile f32 *out) { *out = 1.0f; }

static const u32 fzgx_pool_table_194[11] = {
    0x41200000, 0x430C0000, 0x43600000, 0x437E0000,
    0x43800000, 3233808384U, 0x40A00000, 0x40800000,
    0x41400000, 0x41700000, 0x00000000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_1C0(volatile f64 *out) { *out = 4503599627370496.0; }

static const u32 fzgx_pool_table_1C8[26] = {
    0x4E4F204E, 0x414D4500, 0x4E4F2044, 0x41544100,
    0x42C80000, 0x43AF0000, 0x42300000, 0x41000000,
    0xFFFFFFFF, 0x00F0E6FF, 0x007873FF, 0xA0FF00FF,
    0x0000001A, 0x00000023, 0x0000013C, 0x00000145,
    0x00000018, 0x00000021, 0x00000065, 0x0000006E,
    0x000000B2, 0x000000BB, 0x41F00000, 0x3F400000,
    0x42580000, 0x43AB8000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_230(volatile f32 *out) { *out = 65536.0f; }

static const u32 fzgx_pool_table_234[117] = {
    0x42F00000, 0x3EB33333, 0xFFFFFFFF, 0x00F0E6FF,
    0x007873FF, 0xFFFF00FF, 0xFFFF00FF, 2155937791U,
    0x0000001A, 0x00000023, 0x0000013C, 0x00000145,
    0x00000018, 0x00000021, 0x00000065, 0x0000006E,
    0x000000B2, 0x000000BB, 0x19FF1900, 0x19FF1900,
    0x00000000, 0x00000000, 0x00000000, 0x00000000,
    0x00000000, 0x00000000, 0x00000000, 0x406FE000,
    0x00000000, 0x41A00000, 0x0000001A, 0x00000023,
    0x0000013C, 0x00000145, 0xFFFFFF00, 0x19FF1900,
    0x0000001A, 0x00000023, 0x0000013C, 0x00000145,
    0x19FF1900, 0x00FFFFFF, 0x00FFFFFF, 0xFFFFFF00,
    0x3F4CCCCD, 3221225472U, 0x0000001A, 0x00000023,
    0x0000013C, 0x00000145, 0x00000018, 0x00000021,
    0x0000001A, 0x00000023, 0x0000013C, 0x00000145,
    0x00000018, 0x00000021, 0xFFFF00FF, 0x19FF1900,
    0x00000000, 0x0000001A, 0x00000023, 0x0000013C,
    0x00000145, 0x19FF1900, 0 /* unused relocation addend */, 0 /* unused relocation addend */,
    0 /* unused relocation addend */, 0 /* unused relocation addend */, 0 /* unused relocation addend */, 0 /* unused relocation addend */,
    0 /* unused relocation addend */, 0 /* unused relocation addend */, 0x42880000, 0x42AC0000,
    0x3EC00000, 0x42A00000, 0x41600000, 0x41A80000,
    0x3F8CCCCD, 0x43C78000, 0x440F8000, 0x3F59999A,
    0x43FF0000, 0x19FF1900, 0x19FF1900, 0xF4962800,
    0xF4962800, 0xFFFF0000, 0x00000000, 0xFFFFFF00,
    0xF4962800, 0xF4962800, 0xFFFF0000, 0x00000000,
    0xFFFFFF00, 0xF4962800, 0xFFFF00FF, 0x00000000,
    0x19FF1900, 0x19FF1900, 0xF4962800, 0xF4962800,
    2155937536U, 0x00000000, 0xFFFFFF00, 0xF4962800,
    0xF4962800, 2155937536U, 0x00000000, 0xFFFFFF00,
    0x43B10000, 0x42A80000, 0x41B00000, 0x3F266666,
    0x43400000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_408(volatile f32 *out) { *out = 48.0f; }

static const u32 fzgx_pool_table_40C[16] = {
    0x42380000, 0x425C0000, 0xFADC82FF, 0x00000000,
    0x441FC000, 0x43EF8000, 0x43A00000, 0x428C0000,
    0x42E00000, 0x43F60000, 0x42040000, 0x41980000,
    0x41C00000, 0x42480000, 0x41E80000, 0x42900000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_44C(volatile f32 *out) { *out = 47.0f; }

static const u32 fzgx_pool_table_450[14] = {
    0x00009736, 0x00009737, 0x00009738, 0x00009739,
    0x0000973A, 0x0000973B, 0x0000973C, 0x0000973D,
    0x42340000, 0x42280000, 0x42180000, 0x00000000,
    3233857536U, 0x42240000,
};

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_488(volatile f32 *out) { *out = 255.0f; }

/* Volatile sink preserves the shared literal pool. */
void fzgx_pool_primer_48C(volatile f32 *out) { *out = 60.0f; }
#pragma section code_type ".text"

typedef struct fn_1_147508_Color {
    u8 r, g, b, a;
} fn_1_147508_Color;

typedef struct fn_1_147508_Entry {
    u8 pad_0[0x20];
    s32 unk_20;
    s32 unk_24;
    u8 pad_28[0xD];
    u8 unk_35;
    u8 pad_36;
    u8 unk_37;
    u8 unk_38;
    u8 unk_39;
    u8 pad_3A[0x12];
    s32 unk_4C;
    u8 pad_50[0x14];
    s32 unk_64;
    u8 pad_68[0xC];
    s32 unk_74;
    u8 pad_78[0x5C];
    FontDrawPacket packet;
} fn_1_147508_Entry;


extern f32 lbl_8006D188(s32);
extern s16 fn_1_12C930(s16);
extern s32 fn_8006FC1C(const char *, const char *);
extern s32 lbl_801A66A4;
extern char *fn_1_14FEAC(u8, u8, u8, char *, void *);
extern s32 fn_1_155F7C(void);
extern s32 fn_1_155F8C(void);

extern char *fn_1_7F49C(u8, void *, char *);
extern void fn_1_149C2C(void);
extern void fn_1_49410(void);
extern void fn_1_494DC(s16);
extern void fn_1_49514(fn_1_147508_Color);
extern void fn_1_4954C(f32);
extern void fn_1_49590(f32);
extern void fn_1_495B0(u32);
extern void fn_1_4962C(void);
extern void fn_1_496FC(f32, f32);
extern void fn_1_49738(void (*)(void));

#pragma opt_propagation off
static inline BOOL fn_1_147508_le(u32 a, u32 b) {
    return ((b | ~a) - ((b - a) >> 1)) >> 31;
}

static inline BOOL fn_1_147508_inRange(s32 m, s32 lo, s32 hi) {
    return m == lo || m == hi;
}

static inline BOOL fn_1_147508_isModeA(s32 m) {
    return fn_1_147508_inRange(m, 8, 9) || m == 10;
}

static inline BOOL fn_1_147508_isModeB2(s32 m) {
    return fn_1_147508_inRange(m, 4, 5) || m == 9;
}

static inline BOOL fn_1_147508_isModeB1(s32 m) {
    return fn_1_147508_isModeB2(m) || m == 10;
}

static inline BOOL fn_1_147508_isModeB(s32 m) {
    return fn_1_147508_isModeB1(m) || m == 6;
}

static inline BOOL fn_1_147508_isValidChar(u32 c) {
    BOOL valid = c <= 74;
    return valid;
}

static inline BOOL fn_1_147508_validName(u8 a, u8 b, u8 c) {
    return fn_1_147508_isValidChar(a) && fn_1_147508_isValidChar(b) && fn_1_147508_isValidChar(c);
}

#define IS_MODE_A(m) fn_1_147508_isModeA(m)
#define IS_MODE_B(m) fn_1_147508_isModeB(m)
#define IS_VALID_CHAR(c) fn_1_147508_isValidChar(c)

#pragma opt_propagation off
static inline void fn_1_147508_setPacket(FontDrawPacket *p, u32 image, f32 x, f32 y) {
    p->image = image;
    p->x = x;
    p->y = y;
    p->z = 48.0f;
}

void fn_1_147508(s32 mode, fn_1_147508_Entry *entry) {
    u32 x;
    u32 y;
    s32 show;
    f32 px, py;
    s32 iy, ix;
    u32 image;
    FontDrawPacket packet;
    fn_1_147508_Color color;
    char buf[0x100];

    x = entry->unk_74 + 160;
    y = entry->unk_64 + 37;
    if (IS_MODE_A(mode) || IS_MODE_B(mode)) {
        s32 packetIY, packetIX;
        u32 packetImage;
        packet = entry->packet;
        packetImage = 0x9724;
        packetIX = entry->unk_74 + 126;
        packetIY = entry->unk_64 + 32;
        fn_1_147508_setPacket(&packet, packetImage, packetIX, packetIY);
        fn_1_4F734(&packet);
    }
    if (!IS_MODE_B(mode)) {
        return;
    }
    fn_1_49410();
    fn_1_494DC(22);
    fn_1_495B0(0x80000000);
    fn_1_49738(fn_1_149C2C);
    fn_1_4954C(47.0f);
    fn_1_4962C();
    fn_1_49590(0.5f);
    fn_1_496FC(x, y);
    if (mode == 10 || mode == 6) {
        show = entry->unk_20 == 0;
    } else if (IS_MODE_B(mode)) {
        show = 0;
        if (fn_1_155F7C() != 0 && entry->unk_20 == fn_1_155F8C()) {
            show = 1;
        }
    } else {
        show = lbl_1_bss_3C30.unk_8 > entry->unk_4C;
    }
    if (show) {
        color.a = 255;
        color.b = 255;
        color.r = 255;
        px = 1.0f - lbl_8006D188((s32)(65536.0f * (f32)(lbl_801A66A4 % 60) / 60.0f));
        {
            f32 half = 0.5f;
            py = px * half;
        }
        color.g = 255.0f * py;
        fn_1_49514(color);
    }
    if (lbl_1_bss_8E52C != 0) {
        if (fn_8006FC1C(((char **)&lbl_1_data_212A8)[fn_1_12C930((s16)entry->unk_24)], (char *)lbl_1_data_425C8)) {
            fn_1_4A0D8((char *)lbl_1_data_425D8);
        } else {
            fn_1_4A0D8(((char **)&lbl_1_data_212A8)[fn_1_12C930((s16)entry->unk_24)]);
        }
    } else if (entry->unk_35 < 41) {
        fn_1_4A0D8(fn_1_7F49C(entry->unk_35, 0, buf));
    } else if (IS_VALID_CHAR(entry->unk_37) && IS_VALID_CHAR(entry->unk_38) && IS_VALID_CHAR(entry->unk_39)) {
        fn_1_4A0D8(fn_1_14FEAC(entry->unk_37, entry->unk_38, entry->unk_39, buf, 0));
    }
}
