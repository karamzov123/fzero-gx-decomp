#include "types.h"
#include "rel/customize/globals.h"
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAD0;
extern u8 lbl_1_bss_7F0C0[0x5360];
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_970;
extern u8 lbl_1_bss_9F8[];
extern s32 lbl_3_bss_120;
extern s16 lbl_3_bss_20[104];
extern u8 lbl_3_bss_20854[0xc];
extern u8 lbl_3_bss_20860[0x1100];
extern u8 lbl_3_bss_21960[10368];
extern u8 lbl_3_bss_2437C[44];
extern u32 lbl_3_bss_243A8;
extern u32 lbl_3_bss_243C0;
extern u32 lbl_3_bss_2C7C0[66624];
extern s16 lbl_3_bss_6D8C0[600];
extern u32 lbl_3_bss_6DE20;
extern u8 lbl_3_bss_7DB60[0x520];
extern u8 lbl_3_bss_7E080[0x4];
extern s32 lbl_3_bss_8;
extern s32 lbl_3_data_11D4;
extern s32 lbl_3_data_11D8;
extern char lbl_3_data_15CC[5];
extern s32 lbl_3_data_B8;
extern const char * lbl_3_data_E80[12];
extern u8 lbl_3_rodata_1A4[0xa4];
extern u8 lbl_3_rodata_F8[0xa4];
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern void fn_3_8F8(void);
extern void fn_3_BA0(void);
extern void fn_3_1308C(u32, u32, u32);
extern void fn_3_11F60(u32, u32);
extern void fn_1_A0680(void);
extern void fn_1_3CF0(u32, u32);
extern void fn_1_5124(u32, u32);
extern void fn_80074CF4(f32, f32, f32);
extern void OSReport(const char *format, ...);
extern void *memset(void *, int, u32);
extern u16 fn_1_A5DB0(void);
extern u16 fn_1_A5D88(void);
extern void fn_1_411A4(u32);
extern u32 fn_1_7BA08(u16, u16, u16);
extern void fn_1_7BA48(u32);
extern s32 fn_1_465D0(const char *, s32);
extern void fn_1_545B8(void);
extern void fn_1_7BAF8(void);
extern u32 lbl_801A66C8[];
extern void fn_3_11FA0(void);
extern void fn_3_130A8(void);
extern void fn_1_3C78(void);
extern void fn_1_41A8(void);
extern void fn_1_6400(void);
extern void fn_1_8D168(void *);
extern void fn_1_412A0(u32);
extern void fn_1_56298(f32, f32, f32, f32);
extern void fn_1_A0AA4(void);
extern s32 fn_1_46DC4(s32);
extern void fn_1_53C9C(void *color, char *text, f32 x, f32 y, f32 scale, f32 spacing, f32 alpha);
extern void fn_3_968C();
extern void fn_3_60C8(void);
extern u8 fn_1_F8C50(s32);
extern void fn_3_7A30(void);
extern void fzgx_pool_f32(f32);
extern void fzgx_pool_f64(f64);
extern void fzgx_pool_addr(void *);
extern void fn_3_2BFB4(void);
extern char lbl_3_data_15D8[];
extern void fn_3_3438(void);
extern u32 fn_1_B7F08(void);
extern s32 fn_1_F7954(void);
extern void fn_3_23524(void);
extern void fn_3_78C8(s32);
extern void fn_3_BA74(void);
extern s16 fn_1_F7B80(void);

#include "rel/customize/globals.h"

typedef struct fn_3_CB4_CustomizeData {
    u8 pad_0[0x630];
    char *names[6];
    u8 pad_648[0xe80 - 0x648];
    char *paths[1][6];
    u8 pad_e98[0x15cc - 0xe98];
    char suffix[4];
} fn_3_CB4_CustomizeData;

typedef struct CustomizePool {
    f32 values[0x58 / 4];
    u32 color;
    f32 more[9];
} CustomizePool;

/* integer address sums keep the table base as its own addi (lwzx form) */
#pragma opt_propagation off
#pragma opt_common_subs off
#define PATH(data) (*(char **)(((u32)(data) + 0xe80) + (lbl_3_bss_2437C[0] * 0x18 + lbl_801A66B4 * 4)))

extern f32 lbl_3_rodata_0[];
extern u8 lbl_3_bss_2437C[44];
extern s32 lbl_801A66B4;
extern void fn_3_BFC(char *, void *, const char *, const char *);
extern u32 fn_1_4AEC0(u32);
extern void fn_1_4AEB4(f32);
extern void fn_1_49410(void);
extern void fn_1_4966C(f32, f32);
extern void fn_1_495B0(u32);
extern void fn_1_49590(f32);

static inline char *CustomizeName(fn_3_CB4_CustomizeData *data, s32 selected) {
    char **names = (char **)((u32)data + 0x630);
    return names[selected];
}

#pragma opt_lifetimes off
void fn_3_CB4(char *name) {
    fn_3_CB4_CustomizeData *data;
    CustomizePool *pool;
    u32 color;
    char buffer[0x400];
    char **names;
    u32 paths;
    s32 row;
    s32 offset;

    pool = (CustomizePool *)lbl_3_rodata_0;
    data = (fn_3_CB4_CustomizeData *)&lbl_3_data_0;
    color = pool->color;
    fn_1_4AEC0(1);
    fn_1_4AEB4(pool->more[0]);
    fn_1_49410();
    fn_1_4966C(pool->more[1], pool->more[2]);
    if (lbl_801A66B4 != 5) {
        fn_1_495B0(0x80000000);
        fn_1_49590(pool->values[0x14 / 4]);
        fn_1_4966C(pool->more[1], pool->more[3]);
    }
    row = lbl_3_bss_2437C[0] * 0x18;
    offset = row + lbl_801A66B4 * 4;
    paths = (u32)data + 0xe80;
    fn_3_BFC(buffer, name, data->suffix, *(char **)(paths + offset));
    {
        u32 paths;
        s32 row;
        s32 offset;
        row = lbl_3_bss_2437C[0] * 0x18;
        offset = row + lbl_801A66B4 * 4;
        paths = (u32)data + 0xe80;
        fn_3_BFC(buffer, buffer, data->suffix, *(char **)(paths + offset));
    }
    {
        u32 paths;
        s32 row;
        s32 offset;
        row = lbl_3_bss_2437C[0] * 0x18;
        offset = row + lbl_801A66B4 * 4;
        paths = (u32)data + 0xe80;
        fn_3_BFC(buffer, buffer, data->suffix, *(char **)(paths + offset));
    }
    {
        names = data->names;
        if (name == names[lbl_801A66B4]) {
            names = (char **)&color;
            fn_1_53C9C(names, buffer, pool->values[1], pool->more[4], pool->more[5], pool->more[6], pool->more[7]);
        } else {
            names = (char **)&color;
            fn_1_53C9C(names, buffer, pool->values[1], pool->more[4], pool->more[5], pool->more[6], pool->more[8]);
        }
    }
    fn_1_4AEC0(0);
    fn_1_4AEB4(pool->values[0x44 / 4]);
}
