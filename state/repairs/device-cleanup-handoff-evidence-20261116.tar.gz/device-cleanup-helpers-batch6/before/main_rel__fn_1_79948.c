#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/screen_effect.h"

extern u32 lbl_1_bss_6C8DC[2];
extern u32 lbl_801A6410;
extern void fn_1_46B4(u32 arg0, u32 arg1, void *arg2, u32 arg3);
extern void fn_1_727BC(u32 arg0, u32 arg1, void *arg2);
extern void fn_1_76A94(void *arg0, u32 arg1);
extern void fn_1_76DBC(void);
extern void fn_1_4E500(void);
extern void fn_1_4E638(int);
extern void fn_1_4E6F4(void);
extern void fn_80073778(void *arg0, int arg1);
extern s32 fn_1_A5D9C(void);
extern const f32 lbl_1_rodata_31AC;
extern u32 fn_80008E84(u32 arg);
extern void fn_1_77238(void);
extern void fn_1_772E0(void);
extern void fn_1_77384(void *arg);
extern void fn_80072864(int arg0);
extern void fn_800745A4(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5);
extern void fn_80074660(int arg0);
extern void fn_80073678(int arg0);
extern void fn_80073898(int arg0);
extern void fn_80074788(int arg0);
extern void fn_800738E0(int arg0, int arg1, int arg2);
extern void fn_80073D60(int arg0, int arg1, int arg2, int arg3, int arg4);
extern void fn_800734A8(int arg0, int arg1, int arg2, int arg3);
extern void fn_80072EDC(int arg0, int arg1);
extern f32 lbl_1_rodata_31B0[10];
extern const f64 lbl_1_rodata_31A0;
extern void lbl_8006D784(f32 *arg);
extern void fn_80073A58(int arg0, f32 *arg1, int arg2);
extern void fn_800739E0(int arg0, int arg1, int arg2);
extern void GXLoadTexMtxImm(f32 *arg0, int arg1, int arg2);
extern void fn_8006FDEC(void);
extern void fn_8006FEFC(void);
extern void fn_8006FD1C(void);
extern void fn_1_79810(void);
extern void fn_1_79948(void);
extern void fn_1_791B0(void);
extern void fn_1_9A1E8(void);
extern void fn_1_9A864(void);
extern u8 fn_1_7B074(void);
extern void fn_80071718(void *arg);
extern void fn_800711A8(void *arg);
extern void fn_1_14CB4(void);
extern void fn_1_FA84(void);
extern const f32 lbl_1_rodata_32CC;
extern void fn_1_79C88(void *arg0, s32 arg1, f32 arg2, s32 arg3);
extern void lbl_8006DBAC(void *arg0);
extern void lbl_8006E1B0(void *arg0, void *arg1);
extern void sprintf(char *dst, const char *format, ...);
extern void fn_1_465D0(char *text, int arg);
extern void fn_1_14D5C(void *object, int arg);
extern void fn_1_46EA8(int value);
extern void fn_1_12620(void *object);
extern void fn_1_46DC4(void *obj);

extern void fn_1_727BC();
extern void fn_8006FDEC(void);
extern void fn_80071718(void *);
extern void fn_800711A8(void *);
extern u32 fn_8003526C(u32, u32);
extern u32 fn_80074300(u32, u32, u32, u32);
extern u32 fn_80074438(u32, u32, u32, u32);

extern u32 lbl_1_bss_6C8DC[2];
extern u32 lbl_801A6410;
extern void fn_1_46B4(u32 arg0, u32 arg1, void *arg2, u32 arg3);
extern void fn_1_727BC(u32 arg0, u32 arg1, void *arg2);
extern void fn_1_76A94(void *arg0, u32 arg1);
extern void fn_1_76DBC(void);
extern void fn_1_4E500(void);
extern void fn_1_4E638(int);
extern void fn_1_4E6F4(void);
extern void fn_80073778(void *arg0, int arg1);
extern s32 fn_1_A5D9C(void);
extern const f32 lbl_1_rodata_31AC;
extern u32 fn_80008E84(u32 arg);
extern void fn_1_77238(void);
extern void fn_1_772E0(void);
extern void fn_1_77384(void *arg);
extern void fn_80072864(int arg0);
extern void fn_800745A4(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5);
extern void fn_80074660(int arg0);
extern void fn_80073678(int arg0);
extern void fn_80073898(int arg0);
extern void fn_80074788(int arg0);
extern void fn_800738E0(int arg0, int arg1, int arg2);
extern void fn_80073D60(int arg0, int arg1, int arg2, int arg3, int arg4);
extern void fn_800734A8(int arg0, int arg1, int arg2, int arg3);
extern void fn_80072EDC(int arg0, int arg1);
extern f32 lbl_1_rodata_31B0[10];
extern const f64 lbl_1_rodata_31A0;
extern void lbl_8006D784(f32 *arg);
extern void fn_80073A58(int arg0, f32 *arg1, int arg2);
extern void fn_800739E0(int arg0, int arg1, int arg2);
extern void GXLoadTexMtxImm(f32 *arg0, int arg1, int arg2);
extern void fn_8006FDEC(void);
extern void fn_8006FEFC(void);
extern void fn_8006FD1C(void);
extern void fn_1_79810(void);
extern void fn_1_79948(void);
extern void fn_1_791B0(void);
extern void fn_1_9A1E8(void);
extern void fn_1_9A864(void);
extern u8 fn_1_7B074(void);
extern void fn_80071718(void *arg);
extern void fn_800711A8(void *arg);
extern void fn_1_14CB4(void);
extern void fn_1_FA84(void);
extern const f32 lbl_1_rodata_32CC;
extern void fn_1_79C88(void *arg0, s32 arg1, f32 arg2, s32 arg3);
extern void lbl_8006DBAC(void *arg0);
extern void lbl_8006E1B0(void *arg0, void *arg1);
extern void sprintf(char *dst, const char *format, ...);
extern void fn_1_465D0(char *text, int arg);
extern void fn_1_14D5C(void *object, int arg);
extern void fn_1_46EA8(int value);
extern void fn_1_12620(void *object);
extern void fn_1_46DC4(void *obj);

extern void fn_1_727BC();
extern void fn_8006FDEC(void);
extern void fn_80071718(void *);
extern void fn_800711A8(void *);
extern u32 fn_8003526C(u32, u32);
extern u32 fn_80074300(u32, u32, u32, u32);
extern u32 fn_80074438(u32, u32, u32, u32);

extern u32 lbl_1_bss_6C8DC[2];
extern u32 lbl_801A6410;
extern void fn_1_46B4(u32 arg0, u32 arg1, void *arg2, u32 arg3);
extern void fn_1_727BC(u32 arg0, u32 arg1, void *arg2);
extern void fn_1_76A94(void *arg0, u32 arg1);
extern void fn_1_76DBC(void);
extern void fn_1_4E500(void);
extern void fn_1_4E638(int);
extern void fn_1_4E6F4(void);
extern void fn_80073778(void *arg0, int arg1);
extern s32 fn_1_A5D9C(void);
extern const f32 lbl_1_rodata_31AC;
extern u32 fn_80008E84(u32 arg);
extern void fn_1_77238(void);
extern void fn_1_772E0(void);
extern void fn_1_77384(void *arg);
extern void fn_80072864(int arg0);
extern void fn_800745A4(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5);
extern void fn_80074660(int arg0);
extern void fn_80073678(int arg0);
extern void fn_80073898(int arg0);
extern void fn_80074788(int arg0);
extern void fn_800738E0(int arg0, int arg1, int arg2);
extern void fn_80073D60(int arg0, int arg1, int arg2, int arg3, int arg4);
extern void fn_800734A8(int arg0, int arg1, int arg2, int arg3);
extern void fn_80072EDC(int arg0, int arg1);
extern f32 lbl_1_rodata_31B0[10];
extern const f64 lbl_1_rodata_31A0;
extern void lbl_8006D784(f32 *arg);
extern void fn_80073A58(int arg0, f32 *arg1, int arg2);
extern void fn_800739E0(int arg0, int arg1, int arg2);
extern void GXLoadTexMtxImm(f32 *arg0, int arg1, int arg2);
extern void fn_8006FDEC(void);
extern void fn_8006FEFC(void);
extern void fn_8006FD1C(void);
extern void fn_1_79810(void);
extern void fn_1_79948(void);
extern void fn_1_791B0(void);
extern void fn_1_9A1E8(void);
extern void fn_1_9A864(void);
extern u8 fn_1_7B074(void);
extern void fn_80071718(void *arg);
extern void fn_800711A8(void *arg);
extern void fn_1_14CB4(void);
extern void fn_1_FA84(void);
extern const f32 lbl_1_rodata_32CC;
extern void fn_1_79C88(void *arg0, s32 arg1, f32 arg2, s32 arg3);
extern void lbl_8006DBAC(void *arg0);
extern void lbl_8006E1B0(void *arg0, void *arg1);
extern void sprintf(char *dst, const char *format, ...);
extern void fn_1_465D0(char *text, int arg);
extern void fn_1_14D5C(void *object, int arg);
extern void fn_1_46EA8(int value);
extern void fn_1_12620(void *object);
extern void fn_1_46DC4(void *obj);

extern void fn_1_727BC();
extern void fn_8006FDEC(void);
extern void fn_80071718(void *);
extern void fn_800711A8(void *);
extern u32 fn_8003526C(u32, u32);
extern u32 fn_80074300(u32, u32, u32, u32);
extern u32 fn_80074438(u32, u32, u32, u32);


typedef struct ScreenFx {
    s8 type;
    u8 pad_1[3];
    f32 unk_4;
    f32 unk_8;
    u8 unk_C;
    u8 unk_D;
    u8 unk_E;
    u8 active;
    u32 unk_10;
    void *unk_14;
} ScreenFx;

typedef struct ScreenFxEntry {
    s8 key;
    s8 type;
    u8 pad_2[2];
    f32 unk_4;
    f32 unk_8;
    u8 unk_C;
    u8 unk_D;
    u8 unk_E;
    u8 pad_F;
} ScreenFxEntry;

extern u32 fn_1_7AA50(f32);
extern void fn_1_7E8F4(void);

/* file-scope objects of the retail TU, in retail order: MWCC addresses them off one section base */
Obj_1_bss_6D600 lbl_1_bss_6D600;
ScreenFx lbl_1_bss_6D620[4];
ScreenFx lbl_1_bss_6D620__fzgx_offset_60[4];
ScreenFx lbl_1_bss_6D620__fzgx_offset_C0[4];
ScreenFx lbl_1_bss_6D620__fzgx_offset_120;
ScreenFx lbl_1_bss_6D758;

const ScreenFxEntry lbl_1_rodata_3278[5] = {
    { 4, 5, { 0, 0 }, -200.0f, 1000.0f, 0x00, 0x6E, 0x96, 0 },
    { 8, 5, { 0, 0 }, -200.0f, 2000.0f, 0x0A, 0x0A, 0x28, 0 },
    { 7, 4, { 0, 0 }, 0.0f, 3000.0f, 0x17, 0x1A, 0x1D, 0 },
    { 12, 2, { 0, 0 }, 0.0f, 820.0f, 0x6E, 0x78, 0x79, 0 },
    { -1, 4, { 0, 0 }, 0.0f, 100.0f, 0, 0, 0, 0 },
};

#pragma section code_type ".fzgxpool"
static void fzgx_bss_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits .bss objects in first-access order */
    s = *(u8 *)&lbl_1_bss_6D600;
    s = *(u8 *)&lbl_1_bss_6D620;
    s = *(u8 *)&lbl_1_bss_6D620__fzgx_offset_60;
    s = *(u8 *)&lbl_1_bss_6D620__fzgx_offset_C0;
    s = *(u8 *)&lbl_1_bss_6D620__fzgx_offset_120;
    s = *(u8 *)&lbl_1_bss_6D758;
}

extern void fzgx_pool_sink_p(const void *);
extern void fzgx_pool_sink_f(f32);
extern void fzgx_pool_sink_d(f64);
static const f32 fzgx_pool_word_50[1] = { 0.03125f };
static const f32 fzgx_pool_word_54[1] = { 1.0f };
static const f64 fzgx_pool_dword_58[1] = { 4503601774854144.0 };
static const f64 fzgx_pool_dword_60[1] = { 4503599627370496.0 };
static const f32 fzgx_pool_word_68[1] = { 0.016666668f };
static const u32 fzgx_pool_word_6C[1] = { 0xFFFFFFFF };

/* primes the TU literal pool in retail order behind the table */
static void fzgx_pool_primer(void) {
    fzgx_pool_sink_p(lbl_1_rodata_3278);
    fzgx_pool_sink_p(fzgx_pool_word_50);
    fzgx_pool_sink_p(fzgx_pool_word_54);
    fzgx_pool_sink_p(fzgx_pool_dword_58);
    fzgx_pool_sink_p(fzgx_pool_dword_60);
    fzgx_pool_sink_p(fzgx_pool_word_68);
    fzgx_pool_sink_p(fzgx_pool_word_6C);
    fzgx_pool_sink_f(0.0f);
    fzgx_pool_sink_f(640.0f);
    fzgx_pool_sink_f(480.0f);
    fzgx_pool_sink_f(320.0f);
    fzgx_pool_sink_f(240.0f);
    fzgx_pool_sink_f(0.03f);
    fzgx_pool_sink_f(0.75f);
    fzgx_pool_sink_f(0.02f);
    fzgx_pool_sink_f(1.5f);
    fzgx_pool_sink_f(360.0f);
    fzgx_pool_sink_f(128.0f);
    fzgx_pool_sink_f(0.5f);
    fzgx_pool_sink_f(8.0f);
    fzgx_pool_sink_f(408.0f);
    fzgx_pool_sink_f(100.0f);
}
#pragma section code_type ".text"

static inline void fx_reset(ScreenFx *e) {
    e->active = 0;
    e->type = 5;
    e->unk_4 = 0.0f;
    e->unk_8 = 100.0f;
    e->unk_C = 0;
    e->unk_D = 0;
    e->unk_E = 0;
}

static inline void fx_lookup(ScreenFx *e, s32 key) {
    const ScreenFxEntry *ent;

    fx_reset(e);
    for (ent = lbl_1_rodata_3278; ent->key != -1; ent++) {
        if (ent->key == lbl_1_data_2A7E0.unk_0) {
            e->active = 1;
            e->type = ent->type;
            e->unk_4 = ent->unk_4;
            e->unk_8 = ent->unk_8;
            e->unk_C = ent->unk_C;
            e->unk_D = ent->unk_D;
            e->unk_E = ent->unk_E;
        }
    }
}

static inline void fx_set(ScreenFx *e, const ScreenFxEntry *ent) {
    e->active = 1;
    e->type = ent->type;
    e->unk_4 = ent->unk_4;
    e->unk_8 = ent->unk_8;
    e->unk_C = ent->unk_C;
    e->unk_D = ent->unk_D;
    e->unk_E = ent->unk_E;
}

void fn_1_79948(void) {
    ScreenFx *e;
    const ScreenFxEntry *ent;
    s32 i;
    ScreenFx tmp;

    if (lbl_1_bss_3BE0 != NULL && lbl_1_bss_3BE0->unk_80 != 0) {
        lbl_1_bss_6D758.active = 1;
        lbl_1_bss_6D758.type = lbl_1_bss_3BE0->unk_84 != 0 ? *(s8 *)lbl_1_bss_3BE0->unk_84 : 4;
        fn_1_7AA50(0.0f);
    } else {
        fx_reset(&lbl_1_bss_6D758);
    }

    e = &lbl_1_bss_6D620__fzgx_offset_120;
    fx_reset(e);
    for (ent = lbl_1_rodata_3278; ent->key != -1; ent++) {
        if (ent->key == lbl_1_data_2A7E0.unk_0) {
            e->active = 1;
            lbl_1_bss_6D620__fzgx_offset_120.type = ent->type;
            e->unk_4 = ent->unk_4;
            e->unk_8 = ent->unk_8;
            e->unk_C = ent->unk_C;
            e->unk_D = ent->unk_D;
            e->unk_E = ent->unk_E;
        }
    }

    for (i = 0; i < 4; i++) {
        lbl_1_bss_6D620[i] = lbl_1_bss_6D758;
        lbl_1_bss_6D620[i].unk_14 = &lbl_1_bss_6D758;
        lbl_1_bss_6D620[i].unk_10 = 0x20;
        lbl_1_bss_6D620__fzgx_offset_60[i] = lbl_1_bss_6D620[i];
        lbl_1_bss_6D620__fzgx_offset_C0[i] = lbl_1_bss_6D620[i];
    }
    fn_1_7E8F4();
}
