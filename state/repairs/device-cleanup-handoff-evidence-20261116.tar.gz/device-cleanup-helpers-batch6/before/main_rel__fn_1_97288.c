#include "types.h"
#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/motasglist.h"
#include "dolphin/hw_regs.h"
#include "types.h"
#include "sofdec/sj.h"
#include "rel/main_rel/rob.h"

#ifndef GAME_MAIN_REL_MOTASGLIST_TYPES_H
#define GAME_MAIN_REL_MOTASGLIST_TYPES_H

/* begin game/main_rel/shared_types.h (fork-deltawave784/windows-and-types@215f1cd8) */
#ifndef GAME_MAIN_REL_SHARED_TYPES_H
#define GAME_MAIN_REL_SHARED_TYPES_H

// Types that two or more main_rel TU type headers defined identically; one definition here so
// the TU headers can be included together. Hand-owned (librarian).


typedef struct Sig_fn_1_41488_Fn41488Data {
    u32 count;
    char *strings;
} Sig_fn_1_41488_Fn41488Data;

#endif  // GAME_MAIN_REL_SHARED_TYPES_H

typedef struct Fn142AD0Pair {
    u32 a;
    u32 b;
} Fn142AD0Pair;

typedef struct Fn142AD0Entry {
    u8 pad0[0x88];
    u8 value88[0x0C];
    f32 x;
    u8 pad98[0x0C];
    f32 y;
    u8 padA8[0x0C];
    f32 z;
    Fn142AD0Pair sourceB8;
    u32 sourceC0;
    Fn142AD0Pair sourceC4;
    u32 sourceCC;
    u8 padD0[4];
    u16 keys[6][2][3];
    u32 keysF[3][2][3];
    u8 quat[0x10];
    Fn142AD0Pair value174;
    u32 value17C;
    Fn142AD0Pair value180;
    u32 value188;
} Fn142AD0Entry;

typedef struct Fn142AD0Key {
    u16 value0;
    u16 value1;
    u16 value2;
    u16 value3;
    f32 value4;
    f32 value5;
    f32 value6;
} Fn142AD0Key;

typedef struct Fn142AD0Object {
    u16 count;
    u16 flags;
    u8 pad4[4];
    Fn142AD0Entry *entries;
    u8 padC[0x20];
    f32 value2C;
    f32 value30;
    f32 value34;
    f32 value38;
    u8 pad3C[4];
    Fn142AD0Key cur;
    u8 pad54[4];
    Fn142AD0Key prev;
} Fn142AD0Object;

typedef struct Fn142E74Pair {
    u32 a;
    u32 b;
} Fn142E74Pair;

typedef struct Fn142E74Entry {
    u8 pad0[0xB8];
    Fn142E74Pair sourceB8;
    u32 sourceC0;
    Fn142E74Pair sourceC4;
    u32 sourceCC;
    u8 padD0[0xA4];
    Fn142E74Pair value174;
    u32 value17C;
    Fn142E74Pair value180;
    u32 value188;
} Fn142E74Entry;

typedef struct Fn142E74Object {
    u16 count;
    u16 flags;
    u8 pad4[4];
    Fn142E74Entry *entries;
    u8 padC[0x0C];
    f32 value0;
    f32 value1;
    f32 value2;
    u8 pad24[0x1C];
    u16 flags40;
} Fn142E74Object;

extern int fn_1_41488(Sig_fn_1_41488_Fn41488Data *, const char *);
extern void fn_1_4270C(Fn142AD0Object *object, void *arg1, u32 arg2);

#endif  // GAME_MAIN_REL_MOTASGLIST_TYPES_H

/* end game/main_rel/motasglist_types.h */
/* begin sofdec/adxt.h (fork-deltawave784/windows-and-types@215f1cd8) */
#ifndef SOFDEC_ADXT_H
#define SOFDEC_ADXT_H

/* CRI ADX talker (ADXT) handle, shared by the ADXT_* / adxt_* units of the DOL. */

/* begin layout_check.h (fork-deltawave784/windows-and-types@215f1cd8) */
#ifndef LAYOUT_CHECK_H
#define LAYOUT_CHECK_H

/* Compile-time layout checks for owned types. They declare array typedefs
 * only, so they emit no code or data under MWCC: a wrong size or offset is
 * a negative array bound and fails the compile. */
#define LAYOUT_CHECK_JOIN2(a, b) a##b
#define LAYOUT_CHECK_JOIN(a, b) LAYOUT_CHECK_JOIN2(a, b)
#define CHECK_SIZE(T, size) \
    typedef char LAYOUT_CHECK_JOIN(layout_size_, T)[(sizeof(T) == (size)) ? 1 : -1]
#define CHECK_OFFSET(T, field, offset) \
    typedef char LAYOUT_CHECK_JOIN(LAYOUT_CHECK_JOIN(layout_offset_, T), __LINE__) \
        [((unsigned long)&((T *)0)->field == (offset)) ? 1 : -1]

#endif

/* end layout_check.h */

typedef struct AdxSjdHandle AdxSjdHandle;

typedef struct ADXStream ADXStream;

typedef struct AXRNAHandle AXRNAHandle;

typedef struct LSCObject LSCObject;

typedef struct ADX_AMP ADX_AMP;

typedef struct ADXTHandle {
    s8 used;
    s8 status;
    s8 stream_type;
    s8 maximum_channels;
    AdxSjdHandle *decoder;
    ADXStream *stream;
    AXRNAHandle *rna;
    SJ *stream_sj;
    SJ *input_sj;
    SJ *output_sj[2];
    u8 *input_buffer;
    s32 input_buffer_size;
    s32 input_extra_size;
    u8 *output_buffer;
    s32 output_buffer_size;
    s32 output_buffer_distance;
    s32 server_frequency;
    s16 stream_buffer_sectors;
    s16 minimum_buffer_sectors;
    s16 output_volume;
    s16 output_pan[2];
    s16 field_46;
    s32 maximum_decode_samples;
    s32 loop_count;
    s32 link_data_length;
    s32 field_54;
    s32 field_58;
    s32 field_5C;
    s16 error_code;
    u8 reserved_62[2];
    s32 field_64;
    s16 field_68;
    s16 field_6A;
    s8 stream_loop_enabled;
    s8 auto_receiver;
    u8 reserved_6E[2];
    s8 suppress_playback;
    s8 decoder_ready;
    s8 paused;
    u8 reserved_73;
    ADX_AMP *amplifier;
    SJ *amplifier_input[2];
    SJ *amplifier_output[2];
    s32 time_offset;
    s32 eos_sector;
    s32 loop_sample_count;
    LSCObject *linked_stream_controller;
    s8 link_enabled;
    u8 reserved_99[3];
    u32 playback_time;
    s32 playback_start_vsync;
    s32 linked_decoded_samples;
    s8 pending_stream_start;
    u8 reserved_A9[3];
    u8 *work_end;
    const char *pending_filename;
    void *pending_directory;
    s32 pending_file_offset;
    s32 pending_file_sectors;
} ADXTHandle;

CHECK_OFFSET(ADXTHandle, decoder, 0x4);
CHECK_OFFSET(ADXTHandle, output_volume, 0x40);
CHECK_OFFSET(ADXTHandle, error_code, 0x60);
CHECK_OFFSET(ADXTHandle, stream_loop_enabled, 0x6C);
CHECK_OFFSET(ADXTHandle, amplifier, 0x74);
CHECK_OFFSET(ADXTHandle, linked_stream_controller, 0x94);
CHECK_OFFSET(ADXTHandle, playback_time, 0x9C);
CHECK_OFFSET(ADXTHandle, pending_file_sectors, 0xBC);
CHECK_SIZE(ADXTHandle, 0xC0);

#endif

/* end sofdec/adxt.h */

#pragma section code_type ".fzgxpool"
extern u8 lbl_1_data_26D50__fzgx_offset_0[];
extern u8 lbl_1_data_26D54__fzgx_offset_0[];
extern u8 lbl_1_data_26D5C__fzgx_offset_0[];
extern u8 lbl_1_data_26D64__fzgx_offset_0[];
extern u8 lbl_1_data_26D6C__fzgx_offset_0[];
extern u8 lbl_1_data_26D74__fzgx_offset_0[];
extern u8 lbl_1_data_26D7C__fzgx_offset_0[];
extern u8 lbl_1_data_26D84__fzgx_offset_0[];
static const union { u32 w[73]; const unsigned long v[73]; } fzgx_pool_init_fzgx_pool_table1 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    (u32)lbl_1_data_26D50__fzgx_offset_0, (u32)lbl_1_data_26D50__fzgx_offset_0, (u32)lbl_1_data_26D54__fzgx_offset_0, (u32)lbl_1_data_26D5C__fzgx_offset_0, (u32)lbl_1_data_26D64__fzgx_offset_0, (u32)lbl_1_data_26D50__fzgx_offset_0, (u32)lbl_1_data_26D6C__fzgx_offset_0, (u32)lbl_1_data_26D54__fzgx_offset_0,
    (u32)lbl_1_data_26D5C__fzgx_offset_0, (u32)lbl_1_data_26D64__fzgx_offset_0, (u32)lbl_1_data_26D50__fzgx_offset_0, (u32)lbl_1_data_26D74__fzgx_offset_0, (u32)lbl_1_data_26D7C__fzgx_offset_0, (u32)lbl_1_data_26D84__fzgx_offset_0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table1.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.0f;
    s = 1.0f;
    s = 100.0f;
    s = 180.0f;
    s = 32767.0f;
    d = 4503601774854144.0;
}
static const union { u32 w[3]; const unsigned long v[3]; } fzgx_pool_init_fzgx_pool_table3 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    0xFFFFFFFF, 0xBF800000, 0xFFFFFFFF
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table3.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 55.0f;
    s = 30.0f;
    s = 1000.0f;
    s = 3.003967046737671f;
}
static const union { u32 w[15]; const unsigned long v[15]; } fzgx_pool_init_fzgx_pool_table5 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    0x0, 0x0, 0x0, 0x3B963DC5, 0xBD6DD053, 0xBD953A3F, 0x3B963DC5, 0xBD6DD053,
    0x3CF0307F, 0xBB963DC5, 0xBD6DD053, 0xBD953A3F, 0xBB963DC5, 0xBD6DD053, 0x3CF0307F
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table5.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 182.04444885253906f;
    s = 0.20250000059604645f;
    s = 0.06499999761581421f;
    s = 0.08500000089406967f;
    d = 0.05;
    s = 0.05000000074505806f;
    s = 0.004999999888241291f;
    s = -0.017500000074505806f;
    s = 65535.0f;
    d = 4503599627370496.0;
    s = 50.0f;
    s = -1.0f;
}
static const union { u32 w[3]; const unsigned long v[3]; } fzgx_pool_init_fzgx_pool_table7 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    0x40406080, 0x0, 0x204080
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table7.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime8(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.5f;
}
static const union { u32 w[2]; const unsigned long v[2]; } fzgx_pool_init_fzgx_pool_table9 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    0x0, 0x0
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep9(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table9.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime10(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = -0.08500000089406967f;
}
static const union { u32 w[18]; const unsigned long v[18]; } fzgx_pool_init_fzgx_pool_table11 = {{  /* fzgx-allow: A1 retail data bytes and bindings */
    0x0, 0xBDAE147B, 0x0, 0x0, 0x3F800000, 0x0, 0x3F800000, 0x0,
    0x0, 0x0, 0x3F800000, 0x0, 0x0, 0x0, 0x3F800000, 0x0,
    0x0, 0x3F800000
}};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep11(void) { const unsigned long *volatile cp; cp = fzgx_pool_init_fzgx_pool_table11.v; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime12(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.25f;
    s = 0.15000000596046448f;
    s = 65536.0f;
}
#pragma section code_type ".text"

struct fn_1_97288_Arg0 {
    u8 pad_0[0x1E4];
    u32 unk_1E4;
};
struct fn_1_97288_lbl_1_rodata_3E48 {
    u8 pad_0[0x124];
    f32 unk_124;
    u8 pad_128[0x4];
    f32 unk_12C;
    u8 pad_130[0x8];
    f64 unk_138;
    u8 pad_140[0x80];
    f64 unk_1C0;
    u8 pad_1C8[0x74];
    f32 unk_23C;
};
struct fn_1_97288_lbl_1_data_209C0 {
    u8 pad_0[0x6400];
    u32 unk_6400[6];
    f32 unk_6418;
};

extern int sprintf(char *, const char *, ...);
extern const struct fn_1_97288_lbl_1_rodata_3E48 lbl_1_rodata_3E48;
extern u8 * fn_80083970(u8 *, const u8 *);
extern void ADXT_Stop(ADXTHandle *);
extern void fn_1_4270C(struct Fn142AD0Object *, void *, u32);
extern void fn_1_42AD0(Fn142AD0Object *, void *, u32, u16, u16);
extern void fn_1_42E74(Fn142E74Object *);
extern void fn_8004D18C(ADXTHandle *, u32);

static inline f32 fn97288_ufloat(u32 x, f64 bias) { return (f32)x; }
static inline f32 fn97288_sfloat(s32 x, f64 bias) { return (f32)x; }
static inline f32 fn97288_clamp(f32 x, const struct fn_1_97288_lbl_1_rodata_3E48 *r, struct fn_1_97288_lbl_1_data_209C0 *d) {
    return x < (0.0f) ? (0.0f) : x > d->unk_6418 ? d->unk_6418 : x;
}
/* integer address sum keeps the table base (addi rT, base, 0x6400) separate from the lwzx index */
#pragma opt_propagation off
static inline const char *fn97288_table(u32 base, s32 index) { const char **table = (const char **)(base + 0x6400); return table[index]; }
#pragma opt_propagation off

#pragma opt_lifetimes off
#pragma opt_common_subs on
#pragma opt_strength_reduction off
void fn_1_97288(struct fn_1_97288_Arg0 *arg0, f32 arg1) {
    const struct fn_1_97288_lbl_1_rodata_3E48 *p_lbl_1_rodata_3E48;
    struct fn_1_97288_lbl_1_data_209C0 *p_lbl_1_data_209C0;
    u32 v0;
    u32 v2;
    u8 v3;
    int v4;
    u32 v5;
    u32 v6;
    u32 v8;
    u32 v7;
    struct { f32 value; } zero;
    f32 v9;
    u32 v13;
    u32 v14;
    u32 v15;
    u32 v12;
    u32 v16;
    u8 v17;
    f64 v18;
    f32 v19;
    f32 v20;
    f32 v21;
    f32 v22;
    f32 v1;
    int v23;
    s32 v24;
    int v25;
    f32 v26;
    s32 v27;
    s32 v28;
    f32 v10;
    struct { u32 a[16]; } loc_50;
    struct { u16 a[12]; } loc_38;
    struct { u16 a[12]; } loc_20;
    struct { u16 a[12]; } loc_8;
    int t0;
    u8 * t3;
    int t4;
    u8 * t5;
    u8 * t6;
    int t7;
    u8 * t8;
    u8 * t9;
    u8 * t10;
    int t11;
    int t12;
    int t14;
    int t17;
    u32 v0_2;
    p_lbl_1_rodata_3E48 = (const struct fn_1_97288_lbl_1_rodata_3E48 *)&lbl_1_rodata_3E48;
    arg0->unk_1E4 = 0;
    p_lbl_1_data_209C0 = (struct fn_1_97288_lbl_1_data_209C0 *)&lbl_1_data_209C0;
    v1 = arg1;
    if ((s8)*(u8 *)((u8 *)(u32)arg0 + 1161) != 0) {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1200);
    v2 = *(u32 *)((u8 *)(u32)arg0 + 464);
    v3 = *(u8 *)((u8 *)v0 + (*(u32 *)((u8 *)(u32)arg0 + 1184) << 2));
    v0 = *(u32 *)((u8 *)v2 + 36);
    v4 = fn_1_41488((Sig_fn_1_41488_Fn41488Data *)v0, fn97288_table((u32)p_lbl_1_data_209C0, v3 >> 5));
    if ((u32)v4 == 0xFFFFFFFF) {
    v4 = 0;
    }
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    *(u16 *)((u8 *)(u32)arg0 + 456) = v4;
    fn_1_4270C((struct Fn142AD0Object *)v0, (void *)0, (v4 & 0xFFFF));
    ADXT_Stop((ADXTHandle *)lbl_1_bss_6EAD0.unk_0->unk_4);
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1204);
    t3 = (u8 *)(fn_80083970((u8 *)v0, (const u8 *)((u8 *)(u32)p_lbl_1_data_209C0 + 29384)));
    v0 = (u32)(t3);
    if ((u32)v0 != 0) {
    v0 = (u32)&loc_50;
    t4 = sprintf((char *)(u32)v0, (const char *)(u32)((u8 *)(u32)p_lbl_1_data_209C0 + 29392), *(u32 *)((u8 *)(u32)arg0 + 1204));
    v0 = t4;
    } else {
    if (fn_80083970(*(u8 **)((u8 *)arg0 + 1204), (u8 *)p_lbl_1_data_209C0 + 832) ||
        fn_80083970(*(u8 **)((u8 *)arg0 + 1204), (u8 *)p_lbl_1_data_209C0 + 680)) {
    v0 = (u32)&loc_50;
    t7 = sprintf((char *)(u32)v0, (const char *)(u32)((u8 *)(u32)p_lbl_1_data_209C0 + 29408), (*(u32 *)((u8 *)(u32)arg0 + 1204) + 5));
    v0 = t7;
    } else {
    if (fn_80083970(*(u8 **)((u8 *)arg0 + 1204), (u8 *)p_lbl_1_data_209C0 + 29436) ||
        fn_80083970(*(u8 **)((u8 *)arg0 + 1204), (u8 *)p_lbl_1_data_209C0 + 840) ||
        fn_80083970(*(u8 **)((u8 *)arg0 + 1204), (u8 *)p_lbl_1_data_209C0 + 844)) {
    v0 = (u32)&loc_50;
    t11 = sprintf((char *)(u32)v0, (const char *)(u32)((u8 *)(u32)p_lbl_1_data_209C0 + 29444), (*(u32 *)((u8 *)(u32)arg0 + 1204) + 4));
    v0 = t11;
    } else {
    v0 = (u32)&loc_50;
    t12 = sprintf((char *)(u32)v0, (const char *)(u32)((u8 *)(u32)p_lbl_1_data_209C0 + 29392), *(u32 *)((u8 *)(u32)arg0 + 1204));
    v0 = t12;
    }
    }
    }
    fn_8004D18C((ADXTHandle *)lbl_1_bss_6EAD0.unk_0->unk_4, (u32)&loc_50);
    *(u8 *)((u8 *)(u32)arg0 + 1161) = 0;
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1200);
    v5 = ((*(u8 *)((u8 *)v0 + (*(u32 *)((u8 *)(u32)arg0 + 1184) << 2)) >> 5) & 0x7);
    *(u8 *)((u8 *)(u32)arg0 + 1163) = v5;
    *(u8 *)((u8 *)(u32)arg0 + 1162) = v5;
    *(u32 *)((u8 *)(u32)arg0 + 1164) = 0;
    } else {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1196);
    v6 = *(u32 *)((u8 *)(u32)arg0 + 1184);
    if ((s32)v6 < (s32)(v0 - 1)) {
    v0 = (v6 + 1);
    *(u32 *)((u8 *)(u32)arg0 + 1184) = v0;
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1184);
    v7 = *(u32 *)((u8 *)(u32)arg0 + 1200);
    v8 = (v0 << 2);
    v1 = fn97288_ufloat(*(u32 *)((u8 *)v7 + v8) & 0x1FFFFFFF, (4503599627370496.0));
    v9 = (f32)(v1 / (65536.0f));
    v10 = fn97288_clamp(v9, p_lbl_1_rodata_3E48, p_lbl_1_data_209C0);
    v0 = *(u8 *)((u8 *)(u32)arg0 + 1162);
    v0 = (s8)v0;
    if ((s32)v0 == (s32)((*(u8 *)((u8 *)v7 + v8) >> 5) & 0x7)) {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1164);
    *(u32 *)((u8 *)(u32)arg0 + 1164) = (v0 + 1);
    } else {
    *(u32 *)((u8 *)(u32)arg0 + 1164) = 1;
    *(u8 *)((u8 *)(u32)arg0 + 1163) = *(u8 *)((u8 *)(u32)arg0 + 1162);
    v1 = *(f32 *)((u8 *)(u32)arg0 + 1176);
    *(f32 *)((u8 *)(u32)arg0 + 1180) = v1;
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1200);
    *(u8 *)((u8 *)(u32)arg0 + 1162) = ((*(u8 *)((u8 *)v0 + (*(u32 *)((u8 *)(u32)arg0 + 1184) << 2)) >> 5) & 0x7);
    *(f32 *)((u8 *)(u32)arg0 + 1172) = ((0.0f));
    v0 = *(u32 *)((u8 *)(u32)arg0 + 1196);
    v12 = *(u32 *)((u8 *)(u32)arg0 + 1184);
    v0--;
    v16 = v12;
    v15 = (v12 << 2);
    for (; (s32)v16 < (s32)v0; v15 += 4, v16++) {
    if ((s8)*(u8 *)((u8 *)arg0 + 1162) != (s32)((*(u8 *)(*(u8 **)((u8 *)arg0 + 1200) + v15) >> 5) & 7)) break;
    }
    v0 = (v16 - v12);
    *(u32 *)((u8 *)(u32)arg0 + 1168) = (s32)v0 < 2 ? 2 : (s32)v0 > 8 ? 8 : v0;
    }
    v1 = ((f32)*(s32 *)((u8 *)arg0 + 1168) - (f32)*(s32 *)((u8 *)arg0 + 1164)) /
         (f32)*(s32 *)((u8 *)arg0 + 1168);
    *(f32 *)((u8 *)arg0 + 1172) = v1;
    v1 = *(f32 *)((u8 *)arg0 + 1172);
    if (v1 < 0.0f) {
        *(f32 *)((u8 *)arg0 + 1172) = 0.0f;
    }
    v1 = v10 / p_lbl_1_data_209C0->unk_6418;
    *(f32 *)((u8 *)arg0 + 1176) = v1;
    v1 = *(f32 *)((u8 *)arg0 + 1176);
    if (v1 < (0.0f)) {
        *(f32 *)((u8 *)arg0 + 1176) = (0.0f);
    }
    if (*(f32 *)((u8 *)arg0 + 1172) > (0.0f)) {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    v0 = *(u32 *)((u8 *)v0 + 36);
    v23 = fn_1_41488((Sig_fn_1_41488_Fn41488Data *)v0, fn97288_table((u32)p_lbl_1_data_209C0, (s8)*(u8 *)((u8 *)(u32)arg0 + 1163)));
    if ((u32)v23 == 0xFFFFFFFF) {
    v23 = 0;
    }
    v24 = (s32)((100.0f) * *(f32 *)((u8 *)arg0 + 1180));
    loc_38.a[2] = 0xFFFF;
    loc_38.a[3] = v24;
    loc_38.a[1] = v24;
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    *(u16 *)((u8 *)(u32)arg0 + 456) = v23;
    fn_1_4270C((struct Fn142AD0Object *)v0, (void *)&loc_38, (v23 & 0xFFFF));
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    fn_1_42E74((Fn142E74Object *)v0);
    }
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    v0 = *(u32 *)((u8 *)v0 + 36);
    v25 = fn_1_41488((Sig_fn_1_41488_Fn41488Data *)v0, fn97288_table((u32)p_lbl_1_data_209C0, (s8)*(u8 *)((u8 *)(u32)arg0 + 1162)));
    if ((u32)v25 == 0xFFFFFFFF) {
    v25 = 0;
    }
    v27 = (s32)((100.0f) * *(f32 *)((u8 *)arg0 + 1176));
    loc_20.a[2] = 0xFFFF;
    loc_20.a[3] = v27;
    loc_20.a[1] = v27;
    v1 = *(f32 *)((u8 *)(u32)arg0 + 1172);
    if (v1 <= (0.0f)) {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    *(u16 *)((u8 *)(u32)arg0 + 456) = v25;
    fn_1_4270C((struct Fn142AD0Object *)v0, (void *)&loc_20, (v25 & 0xFFFF));
    } else {
    v0 = *(u32 *)((u8 *)(u32)arg0 + 464);
    *(u16 *)((u8 *)(u32)arg0 + 456) = v25;
    fn_1_42AD0((Fn142AD0Object *)v0, (void *)&loc_20, (v25 & 0xFFFF), 100, 84);
    }
    v0_2 = *(u32 *)((u8 *)(u32)arg0 + 432);
    if (v0_2 != 0 && *(u32 *)((u8 *)(u32)arg0 + 436) != 0) {
    v28 = (s32)((100.0f) * *(f32 *)((u8 *)arg0 + 1176));
    loc_8.a[2] = 0xFFFF;
    loc_8.a[3] = v28;
    loc_8.a[1] = v28;
    fn_1_4270C((struct Fn142AD0Object *)v0_2, (void *)&loc_8, *(u16 *)((u8 *)(u32)arg0 + 424));
    }
    }
    }
    return;
}
#pragma opt_lifetimes reset
