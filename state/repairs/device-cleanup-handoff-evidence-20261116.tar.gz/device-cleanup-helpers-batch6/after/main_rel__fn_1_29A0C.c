#include "types.h"
#include "dolphin/hw_regs.h"
#include "psvec.h"

#ifndef GAME_VEC3_H
#define GAME_VEC3_H
typedef struct Vec3 {
    f32 x;
    f32 y;
    f32 z;
} Vec3;
#endif

typedef struct {
    f32 x;
    f32 y;
    f32 z;
    f32 w;
} Quat;

typedef struct {
    f32 unk_0[3][4];
} Mtx34;

typedef struct {
    u32 unk_0;
    s16 unk_4;
    s16 unk_6;
    f32 unk_8;
    u8 pad_C[0x10];
    f32 unk_1C;
    u8 pad_20[0x5C];
    Vec3 unk_7C;
    u8 pad_88[0xC];
    Vec3 unk_94;
    u32 unk_A0;
    f32 unk_A4;
    u32 unk_A8;
    f32 unk_AC;
    f32 unk_B0;
    f32 unk_B4;
    u8 pad_B8[0xC];
    f32 unk_C4;
    f32 unk_C8;
    u8 pad_CC[0x20];
    Mtx34 unk_EC;
    u8 pad_11C[0x30];
    Mtx34 unk_14C;
    f32 unk_17C;
    u8 pad_180[0xC];
    f32 unk_18C;
    u32 unk_190;
    u8 pad_194[0x2];
    u8 unk_196;
    u8 pad_197[0x59];
    f32 unk_1F0;
    u8 pad_1F4[0x24];
    u32 unk_218;
    u8 pad_21C[0x8];
    f32 unk_224;
    u8 pad_228[0x2C];
    f32 unk_254;
    u8 pad_258[0xB4];
    f32 unk_30C;
    u8 pad_310[0x168];
    f32 unk_478;
    u8 pad_47C[0x5];
    u8 unk_481;
    u8 pad_482[0x2E];
    s16 unk_4B0;
    u8 pad_4B2[0x22];
    f32 unk_4D4;
    f32 unk_4D8;
    u8 pad_4DC[0x8];
    f32 unk_4E4;
    f32 unk_4E8;
    f32 unk_4EC;
    u8 pad_4F0[0x9C];
    u32 unk_58C;
    u8 pad_590[0x34];
    Quat unk_5C4;
    f32 unk_5D4;
    u8 pad_5D8[0x8];
    Mtx34 unk_5E0;
} Machine;

typedef struct {
    u8 pad_0[0x390];
    u32 unk_390;
} Other;

typedef struct {
    f32 unk_0;
    f32 unk_4;
} Rodata3508;

#define LC ((f32 *)LC_BASE)

/* the .rodata pool of stcoli.c from lbl_1_rodata_840 up to this function's last literal at 0xB70 */
#pragma section code_type ".fzgxpool"
static const u32 fzgx_pool_table1[3] = {0x42500000, 0x3D800000, 0x42340000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const u32 *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.0f;
}
static const u32 fzgx_pool_table2[1] = {0x3FD9999A};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.0f;
    s = 0.10000000149011612f;
    s = 0.5f;
    d = 4503599627370496.0;
}
static const u32 fzgx_pool_table3[6] = {0x42200000, 0x43AE0000, 0x42100000, 0x40800000, 0x3F19999A, 0x40A00000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const u32 *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.05000000074505806f;
}
static const u32 fzgx_pool_table4[9] = {0x447A0000, 0x41000000, 0x00000000, 0x406B0000, 0x00000000, 0x40000000, 0x00000000, 0x3E800000, 0x3D8F5C29};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.20000000298023224f;
}
static const u32 fzgx_pool_table5[3] = {0x00000000, 0x3FEAE147, 0xAE147AE1};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const u32 *volatile cp; cp = fzgx_pool_table5; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 2.0f;
}
static const u32 fzgx_pool_table6[7] = {0x3FE66666, 0x3FB33333, 0x3FC00000, 0x3F99999A, 0x40133333, 0x3ECCCCCD, 0x404CCCCD};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.15000000596046448f;
}
static const u32 fzgx_pool_table7[5] = {0xBE800000, 0x3E23D70A, 0x3DF5C28F, 0x3DA3D70A, 0x3EE66666};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep7(void) { const u32 *volatile cp; cp = fzgx_pool_table7; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.699999988079071f;
}
static const u32 fzgx_pool_table8[28] = {0x00000000, 0x3FE33333, 0x40000000, 0x3E9EB852, 0x3CF5C28F, 0x3C23D70A, 0x442F0000, 0x3FE23D70, 0xA3D70A3D, 0x3F11EB85, 0x00000000, 0x00000000, 0x00000000, 0x3F800000, 0xBDCCCCCD, 0x43480000, 0x3CA3D70A, 0x3F847AE1, 0x40000000, 0x3D23D70A, 0x3F4CCCCD, 0x402BC71C, 0x71C71C72, 0x415E38E4, 0x34000000, 0x44480000, 0x3F733333, 0x400CCCCD};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime8(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -0.5f;
}
static const u32 fzgx_pool_table9[2] = {0x3B03126F, 0x3A83126F};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep9(void) { const u32 *volatile cp; cp = fzgx_pool_table9; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.30000001192092896f;
}
static const u32 fzgx_pool_table10[11] = {0x00000000, 0x3FD99999, 0x9999999A, 0x3FB99999, 0x9999999A, 0x42A00000, 0x44D48000, 0x40568000, 0x00000000, 0x3EAAAAAB, 0xC59C4000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep10(void) { const u32 *volatile cp; cp = fzgx_pool_table10; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime10(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 900.0f;
}
static const u32 fzgx_pool_table11[13] = {0xC61C4000, 0x41200000, 0x42C80000, 0x43C80000, 0x3F7D70A4, 0x41A00000, 0x3F8147AE, 0x3FF00000, 0x00000000, 0x3FE19999, 0xA0000000, 0x4059999A, 0x3F400000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep11(void) { const u32 *volatile cp; cp = fzgx_pool_table11; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime11(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 182.04444885253906f;
}
static const u32 fzgx_pool_table12[68] = {0xC2340000, 0x3FEDA12F, 0x684BDA13, 0x401638E3, 0x8E38E38E, 0x3F90A3D7, 0x00000000, 0x3FB99999, 0xA0000000, 0x3FD33333, 0x40000000, 0x3FA7B425, 0xED097B42, 0x3F666666, 0x3F8E147B, 0x3F62F684, 0xBDA12F68, 0x3FE00000, 0x00000000, 0x3F72F684, 0xBDA12F68, 0x3F97B425, 0xED097B42, 0x44FA0000, 0x43FA0000, 0x3FC99999, 0x9999999A, 0x3F23D70A, 0x3EB33333, 0x3FFDA12F, 0x684BDA13, 0x400B3333, 0x40000000, 0x3FFB3333, 0x40000000, 0x40080000, 0x00000000, 0x3FF80000, 0x00000000, 0xBECCCCCD, 0x00000000, 0x4009ED09, 0x7B425ED1, 0xBF800000, 0x38D1B717, 0x3C656042, 0x41100000, 0x42700000, 0x40400000, 0x3E2AAAAB, 0x44960000, 0x44C80000, 0x00000000, 0x408F4000, 0x00000000, 0x3FE66666, 0x60000000, 0x3E800000, 0x00000000, 0x3B449BA6, 0x3E000000, 0xC4FA0000, 0x44160000, 0x40C00000, 0x43960000, 0x3F8E38E4, 0x461C4000, 0xC0400000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep12(void) { const u32 *volatile cp; cp = fzgx_pool_table12; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime12(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 10430.3779296875f;
}
static const u32 fzgx_pool_table13[5] = {0x00000000, 0x00000000, 0x3F7DF3B6, 0x3C03126F, 0x42480000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep13(void) { const u32 *volatile cp; cp = fzgx_pool_table13; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime13(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 15.0f;
}
static const u32 fzgx_pool_table14[12] = {0x457A0000, 0x00000000, 0x400CCCCC, 0xCCCCCCCD, 0x3FA66666, 0x3C1374BD, 0x40C38300, 0x00000000, 0x42390000, 0x44898000, 0x42F00000, 0xC2480000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep14(void) { const u32 *volatile cp; cp = fzgx_pool_table14; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime14(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 4503601774854144.0;
    s = 30.0f;
    s = -0.20000000298023224f;
    s = 90.0f;
    s = 0.006000000052154064f;
    d = 4.62962962962963;
    s = -5.0f;
    s = 4.5f;
    s = 3640.0f;
    s = 2.5f;
    s = -0.30000001192092896f;
    s = 5.999999848427251e-05f;
    s = 65536.0f;
}
#pragma section code_type ".text"

extern s32 lbl_801A66A0;
extern const Rodata3508 lbl_1_rodata_3508[2];
extern f32 lbl_8006D188(s16);
extern f32 lbl_8006D0B4(f32);
extern void lbl_8006E1F0(Vec3 *, f32, f32, f32);
extern void lbl_8006DA50(void);
extern void lbl_8006DAEC(void);
extern void lbl_8006DB30(void);
extern void lbl_8006DB74(void *);
extern void lbl_8006DBAC(void *);
extern void lbl_8006D758(void);
extern void lbl_8006DFC4(void *);
extern void lbl_8006E1C0(Vec3 *, Vec3 *);
extern void lbl_8006E0A4(Vec3 *);
extern void lbl_8006E14C(f32);
extern void mathutil_mtxA_rotate_x(s32);
extern void mathutil_mtxA_rotate_y(s32);
extern void mathutil_mtxA_rotate_z(s32);
extern void mathutil_mtxA_from_quat(Quat *);
extern void fn_8006E5FC(Quat *);
extern void fn_8006EB4C(Quat *, Quat *, Quat *, f32);
extern Other *fn_1_868C0(s8);

#define CLAMP(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))

/* the same-TU fn_1_29968, which retail inlines here */
static inline void fn_1_29A0C_present(Machine *m)
{
    f32 v;

    lbl_8006DAEC();
    v = m->unk_30C / -m->unk_254;
    v = CLAMP(v - 1.0f, -0.2f, 0.2f);
    mathutil_mtxA_rotate_x((s32)(182.04444885253906f * (30.0f * v)));
    lbl_8006DB74(&m->unk_5E0);
    lbl_8006DB30();
}

static inline f32 fn_1_29A0C_length(Vec3 *p)
{
    f32 x = p->x, y = p->y, z = p->z;
    f32 v1 = x * x;
    v1 = y * y + v1;
    v1 = z * z + v1;
    return lbl_8006D0B4(v1);
}


/* retail's in-place fmadds translate (x = x * lift + LC[3] in one register) needs opt_lifetimes off */
#pragma opt_lifetimes off
void fn_1_29A0C(Machine *m)
{
    Mtx34 mtx;
    Vec3 pos;
    Quat q;
    Vec3 jitter;
    f32 a;
    f32 t;
    f32 sway;
    f32 bounce;
    f32 speed;
    f32 scale;
    f32 pitch;
    f32 grip;
    f32 amp;
    s32 angle;
    u32 hash;
    s16 index;

    if (m->unk_224 > 2.0f) {
        sway = 0.0f;
    } else {
        sway = (2.0f - m->unk_224) / 2.0f;
    }
    if (m->unk_481 < 90) {
        sway *= m->unk_481 / 90.0f;
    }
    m->unk_5D4 = m->unk_5D4 + (f32)(0.05f * (sway - m->unk_5D4));
    a = m->unk_5D4;
    t = (s16)(182.04444885253906f * (0.5f * (a * lbl_8006D188((s16)(lbl_801A66A0 * 0x109)))));
    bounce = 0.006f * (a * lbl_8006D188((s16)(lbl_801A66A0 * 0x1A3)));
    if (m->unk_481 < 90 && m->unk_6 > 40) {
        bounce = bounce + (f32)(0.5f * (1.0f - m->unk_481 / 90.0f));
    }
    lbl_8006E1F0(&pos, 0.0f, bounce - (f32)(0.2f * a), 0.0f);
    psvec_add(&pos, &m->unk_7C, &pos);
    lbl_8006DA50();
    LC[3] = 0.0f;
    LC[7] = 0.0f;
    LC[11] = 0.0f;
    lbl_8006DB74(&m->unk_EC);
    fn_1_29A0C_present(m);
    mathutil_mtxA_rotate_z((s32)(10430.3779296875f * (m->unk_4EC / m->unk_B4)));
    mathutil_mtxA_rotate_y((s32)(10430.3779296875f * (m->unk_4E8 / m->unk_B0)));
    mathutil_mtxA_rotate_x((s32)(10430.3779296875f * (m->unk_4E4 / m->unk_AC)));
    lbl_8006DAEC();
    if (m->unk_58C & 0x20) {
        lbl_8006DBAC(&m->unk_14C);
    } else {
        lbl_8006DAEC();
        lbl_8006D758();
        if (m->unk_0 & 0x400) {
            m->unk_4D8 = m->unk_4D8 + (f32)(0.05f * (m->unk_4D4 - m->unk_4D8));
            mathutil_mtxA_rotate_y((s32)(182.04444885253906f * m->unk_4D8));
        }
        speed = fn_1_29A0C_length(&m->unk_94) / m->unk_8 / 4.62962962962963;
        scale = m->unk_1C / 15.0f;
        m->unk_4B0 = 182.04444885253906f * (scale * (-5.0f * m->unk_1F0 * speed));
        angle = (s16)(10430.3779296875f * (speed * (4.5f * (m->unk_A4 / m->unk_B0))));
        angle += m->unk_4B0;
        grip = 1.0f - __abs(angle) / 3640.0f;
        if (grip < 0.0f) {
            grip = 0.0f;
        }
        pitch = grip * (0.7f * (m->unk_C8 / m->unk_AC));
        a = 2.5f * (m->unk_C4 / m->unk_B4);
        if (pitch > 0.3f) {
            pitch = 0.3f;
        } else if (pitch < -0.3f) {
            pitch = -0.3f;
        }
        if (a > 0.5f) {
            a = 0.5f;
        } else if (a < -0.5f) {
            a = -0.5f;
        }
        mathutil_mtxA_rotate_x((s32)(10430.3779296875f * pitch));
        angle += (s16)(10430.3779296875f * -a);
        if (angle > 0x238E) {
            angle = 0x238E;
        } else if (angle < -0x238E) {
            angle = -0x238E;
        }
        mathutil_mtxA_rotate_z((s32)(angle + t));
        fn_8006E5FC(&q);
        fn_8006EB4C(&m->unk_5C4, &m->unk_5C4, &q, 0.2f);
        mathutil_mtxA_from_quat(&m->unk_5C4);
        lbl_8006DB74(&mtx);
        lbl_8006DB30();
        lbl_8006DFC4(&mtx);
        if (m->unk_190 != 0) {
            if (m->unk_196 != 0) {
                mathutil_mtxA_rotate_y((s16)-m->unk_190);
            } else {
                mathutil_mtxA_rotate_y((s16)m->unk_190);
            }
        }
    }
    /* the locked-cache matrix (LC_BASE) gets the position as its translation */
    {
        f32 z, y, x;
        x = *(volatile f32 *)&pos.x;  /* fzgx-allow: S2 volatile view keeps the verified load order */
        y = pos.y;
        z = pos.z;
        LC[3] = x;
        LC[7] = y;
        LC[11] = z;
    }
    amp = 5.999999848427251e-05f * m->unk_478;
    hash = (*(u32 *)(&m->unk_94.z)) ^ ((*(u32 *)(&m->unk_94.x)) ^ (*(u32 *)(&m->unk_94.y)));
    t = amp * ((u16)(hash ^ m->unk_A0) / 65536.0f);
    mathutil_mtxA_rotate_z((s32)(10430.3779296875f * (amp * ((u16)(hash ^ (*(u32 *)(&m->unk_A4))) / 65536.0f))));
    mathutil_mtxA_rotate_x((s32)(10430.3779296875f * t));
    if (m->unk_0 & 0x20) {
        f32 w = m->unk_C8;
        if (w < 0.0f) {
            w = 0.0f;
        }
        m->unk_18C = m->unk_18C + (f32)(0.2f * ((f32)(4.5f * (w / m->unk_AC)) - m->unk_18C));
        if (m->unk_18C > 0.3f) {
            m->unk_18C = 0.3f;
        }
    } else {
        m->unk_18C = m->unk_18C - (f32)(0.05f * m->unk_18C);
    }
    /* and is raised along its y column by M+0x18C */
    {
        f32 z;
        f32 y;
        f32 x;
        f32 lift;
        x = LC[1];
        y = LC[5];
        z = LC[9];
        lift = m->unk_18C;
        x = x * lift + LC[3];
        y = y * lift + LC[7];
        z = z * lift + LC[11];
        LC[3] = x;
        LC[7] = y;
        LC[11] = z;
    }
    if ((m->unk_218 >> 29) & 1) {
        t = 0.1f + m->unk_17C / 900.0f;
        if (t > 1.0f) {
            t = 1.0f;
        }
        jitter.x = (u16)(hash ^ (*(u32 *)(&m->unk_A4))) / 65536.0f - 0.5f;
        jitter.y = 0.0f;
        jitter.z = (u16)(hash ^ m->unk_A8) / 65536.0f - 0.5f;
        lbl_8006E1C0(&jitter, &jitter);
        psvec_scale(&jitter, 0.15f * t, &jitter);
        lbl_8006E0A4(&jitter);
    }
    if (fn_1_868C0(m->unk_4)->unk_390 & 0x100000) {
        index = m->unk_6;
        lbl_8006E14C(index >= 2 ? 1.0f : lbl_1_rodata_3508[index].unk_0);
    }
    lbl_8006DB74(&m->unk_14C);
    lbl_8006DB30();
}
#pragma opt_lifetimes reset
