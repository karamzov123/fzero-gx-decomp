#include "types.h"
#include "rel/winning/globals.h"
#include "rel/winning/winning.h"
extern f32 lbl_15_rodata_0[25];
extern u8 lbl_1_bss_5138[];
extern u8 lbl_1_bss_525C[0x198];
extern u8 lbl_1_bss_6EAD0[0x708];
extern u16 lbl_1_bss_96A;
extern u8 lbl_1_bss_9F8;
extern u8 lbl_1_bss_D58[0x18];
extern u8 lbl_1_data_2A7E0[0xf8];
extern u32 lbl_1_rodata_26F8;
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern void fn_8006CE1C(f32);
extern void fn_1_47A60(u32);
extern void fn_1_48140(u32);
extern void fn_1_407C(void);
extern void fn_1_3CC4(void);
extern s32 fn_1_8DB94(void);
extern void fn_1_106EB0(void);
extern s32 camera_get_flags(void);
extern void camera_update(void);
extern u32 fn_1_58C4(void);
extern void fn_1_5948(s32);
extern void fn_1_9A770(void);
extern void fn_1_627C(s32);
extern u8 lbl_15_data_70[32];
extern u32 lbl_1_bss_71688;
extern u32 lbl_1_bss_7168C;
extern u8 lbl_1_bss_25E98;
extern u32 fn_1_8E728(void *, u32);
extern u32 lbl_15_bss_9C[13];
extern void fn_1_8F494(void *);
extern f32 fn_1_A71AC(void);
extern u32 fn_1_129D9C(void *, void *, u32, u32, u32, u32, u32, f32);
extern void lbl_8006D7DC(void *);
extern void lbl_8006DB74(void *);
extern void lbl_8006DFC4(void *);
extern u32 fn_1_7ACDC(u32);
extern void fn_1_789E8(void);
extern void fn_1_78EBC(void);
extern void fn_1_7E9C4(void);
extern void fn_1_9A5CC(void);
extern void fn_1_9A7BC(void);
extern u16 lbl_15_bss_154;
extern u8 fn_15_1D7C__fzgx_offset_0[];
extern u8 fn_15_1DF4__fzgx_offset_0[];
extern u8 fn_15_1EE0__fzgx_offset_0[];
extern u8 fn_15_2E8C__fzgx_offset_104[];
extern u8 fn_15_2E8C__fzgx_offset_10C[];
extern u8 fn_15_2E8C__fzgx_offset_110[];
extern u8 fn_15_2E8C__fzgx_offset_DC[];
extern u8 fn_15_2E8C__fzgx_offset_E4[];
extern u8 fn_15_2E8C__fzgx_offset_EC[];
extern u8 fn_15_3AC__fzgx_offset_0[];
extern u8 fn_15_4578__fzgx_offset_864[];
extern u8 fn_15_4578__fzgx_offset_86C[];
extern u8 fn_15_4578__fzgx_offset_874[];
extern u8 fn_15_4578__fzgx_offset_87C[];
extern u8 fn_15_4578__fzgx_offset_884[];
extern u8 fn_15_4578__fzgx_offset_88C[];
extern u8 fn_15_4578__fzgx_offset_894[];
extern u8 fn_15_4578__fzgx_offset_89C[];
extern u8 fn_15_4578__fzgx_offset_8A4[];
extern u8 fn_15_4578__fzgx_offset_8AC[];
extern u8 fn_15_4578__fzgx_offset_8B4[];
extern u8 fn_15_4578__fzgx_offset_8BC[];
extern u8 fn_15_4578__fzgx_offset_8C0[];
extern u8 fn_15_644__fzgx_offset_0[];
extern u8 fn_15_B8C__fzgx_offset_0[];
extern u8 lbl_15_data_0__fzgx_offset_0[];
extern u8 lbl_15_data_10__fzgx_offset_0[];
extern u8 lbl_15_data_18__fzgx_offset_0[];
extern u8 lbl_15_data_1C2C__fzgx_offset_0[];
extern u8 lbl_15_data_1C34__fzgx_offset_0[];
extern u8 lbl_15_data_1C40__fzgx_offset_0[];
extern u8 lbl_15_data_1C50__fzgx_offset_0[];
extern u8 lbl_15_data_1C5C__fzgx_offset_0[];
extern u8 lbl_15_data_1C68__fzgx_offset_0[];
extern u8 lbl_15_data_1C70__fzgx_offset_0[];
extern u8 lbl_15_data_1C74__fzgx_offset_0[];
extern u8 lbl_15_data_1C78__fzgx_offset_0[];
extern u8 lbl_15_data_1C7C__fzgx_offset_0[];
extern u8 lbl_15_data_1D10__fzgx_offset_0[];
extern u8 lbl_15_data_1D20__fzgx_offset_0[];
extern u8 lbl_15_data_1D30__fzgx_offset_0[];
extern u8 lbl_15_data_1D40__fzgx_offset_0[];
extern u8 lbl_15_data_1DB0__fzgx_offset_0[];
extern u8 lbl_15_data_1DCC__fzgx_offset_0[];
extern u8 lbl_15_data_1DF8__fzgx_offset_0[];
extern u8 lbl_15_data_1E0C__fzgx_offset_0[];
extern u8 lbl_15_data_1E24__fzgx_offset_0[];
extern u8 lbl_15_data_1E3C__fzgx_offset_0[];
extern u8 lbl_15_data_1E54__fzgx_offset_0[];
extern u8 lbl_15_data_1E84__fzgx_offset_0[];
extern u8 lbl_15_data_1E8C__fzgx_offset_0[];
extern u8 lbl_15_data_1E9C__fzgx_offset_0[];
extern u8 lbl_15_data_1EAC__fzgx_offset_0[];
extern u8 lbl_15_data_1EBC__fzgx_offset_0[];
extern u8 lbl_15_data_30__fzgx_offset_0[];
extern u8 lbl_15_data_38__fzgx_offset_0[];
extern u8 lbl_15_data_40__fzgx_offset_0[];
extern u8 lbl_15_data_48__fzgx_offset_0[];
extern u8 lbl_15_data_60__fzgx_offset_0[];
extern u8 lbl_15_data_68__fzgx_offset_0[];
extern u8 lbl_15_data_8__fzgx_offset_0[];
extern u8 lbl_1_data_2B0D4[];
extern char *lbl_1_data_2BD54[][6];
extern void fn_1_3EF14(void *);
extern void fn_1_520A0(void);
extern void fn_1_52070(u32);
extern void fn_1_141360(u8, s32, s32, s32, f32, f32);
extern void fn_1_520CC(void);
extern void fn_1_494DC(s16);
extern void fn_1_495B0(u32);
extern void fn_1_495C8(u8);
extern void fn_1_49590(f32);
extern void fn_1_495A0(f32);
extern void fn_1_50A90(void *, s32, s32, s32, s32);
extern void *memcpy(void *, const void *, u32);
extern int sprintf(char *, const char *, ...);
extern s16 fn_1_12EF24(s16, s16);
extern u16 fn_1_48690(u32);
extern void fn_1_CFCA4(const char *, f32, f32, f32);
extern void fn_1_4962C(void);
extern char *fn_1_5415C(s32, s32);
extern f64 __fabs(f64);
extern u8 lbl_15_bss_3F8[136];
extern u32 lbl_15_rodata_19C[20];
extern void fn_1_7BCCC(void *);
extern void fn_80035680(void *, f32, f32, f32);
extern void fn_80035690(void *, f32, f32, f32);
extern void fn_80035420(void *, u32, f32);
extern void fn_800356AC(void *, void *);
extern void GXInitLightDistAttn(void *, f32, f32, u32);
extern void fn_1_7BB80(void *, u32);
extern void fn_1_7BD6C(u32);
extern u8 lbl_15_bss_2C__fzgx_offset_9;
extern s16 lbl_1_bss_960;

#include "rel/winning/winning.h"

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void prime1(void){ volatile f32 s; volatile f64 d; s=0.0f; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t2[14] = {0xff00ff,0x808080ff,0xffffffff,0xc3acef3b,0x43fc728f,0x44241408,0xc3ad35a2,0x43fe58b4,0x44243fbe,0x0,0x3f800000,0x0,0xc3acef3b,0x43fc728f}; // fzgx-allow: A1 0x808080FF is an RGBA colour constant in this table, not an address
__declspec(section ".fzgxpool") static void keep2(void){ const u32 *volatile cp; cp=fzgx_pool_t2; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t3[1] = {0x44241408};
__declspec(section ".fzgxpool") static void keep3(void){ const u32 *volatile cp; cp=fzgx_pool_t3; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t4[6] = {0xc3ad35a2,0x43fe58b4,0x44243fbe,0x0,0x3f800000,0x0};
__declspec(section ".fzgxpool") static void keep4(void){ const u32 *volatile cp; cp=fzgx_pool_t4; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
__declspec(section ".fzgxpool") static void prime5(void){ volatile f32 s; volatile f64 d; s=200.0f;s=1.0f; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t6[1] = {0xffc800ff};
__declspec(section ".fzgxpool") static void keep6(void){ const u32 *volatile cp; cp=fzgx_pool_t6; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
__declspec(section ".fzgxpool") static void prime7(void){ volatile f32 s; volatile f64 d; s=30.0f;d=0.01;s=2.0f;s=320.0f;s=240.0f;s=20.0f;s=10.0f;s=0.5f;s=3.0f;s=0.03999999910593033f;d=4503601774854144.0; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t8[3] = {0x0,0x0,0x43480000};
__declspec(section ".fzgxpool") static void keep8(void){ const u32 *volatile cp; cp=fzgx_pool_t8; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
__declspec(section ".fzgxpool") static void prime9(void){ volatile f32 s; volatile f64 d; s=0.6000000238418579f; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t10[5] = {0xff,0x404040ff,0x404088ff,0xaaaaaaff,0xff0000ff};
__declspec(section ".fzgxpool") static void keep10(void){ const u32 *volatile cp; cp=fzgx_pool_t10; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t11[1] = {0x0};
__declspec(section ".fzgxpool") static void keep11(void){ const u32 *volatile cp; cp=fzgx_pool_t11; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t12[1] = {0x0};
__declspec(section ".fzgxpool") static void keep12(void){ const u32 *volatile cp; cp=fzgx_pool_t12; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
static const u32 fzgx_pool_t13[1] = {0x0};
__declspec(section ".fzgxpool") static void keep13(void){ const u32 *volatile cp; cp=fzgx_pool_t13; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
__declspec(section ".fzgxpool") static void prime14(void){ volatile f32 s; volatile f64 d; s=1.5f;s=-0.8999999761581421f; } // fzgx-allow: S2 layout primer sink: MWCC emits the literal pool in first-access order
#pragma section code_type ".text"
struct fn_15_27D4_Vec3 { f32 x,y,z; };
struct fn_15_27D4_Arg0 {
u8 pad_0[0x18]; u32 unk_18; u8 pad_1C[0x6C]; s32 unk_88;
u8 pad_8C[0x1C]; struct fn_15_27D4_Vec3 unk_A8; u8 pad_B4[4]; f32 unk_B8; u8 pad_BC[0x408]; u8 unk_4C4;
};
struct fn_15_27D4_Dst { u8 pad_0[0xC]; struct fn_15_27D4_Vec3 unk_C; };
struct fn_15_27D4_Tab {
u8 pad_0[0x1C]; struct fn_15_27D4_Vec3 unk_1C,unk_28,unk_34;
u8 pad_40[0xC]; struct fn_15_27D4_Dst *unk_4C[2]; struct fn_15_27D4_Dst *unk_54;
};
struct fn_15_27D4_lbl_1_data_2A7E0 { u8 pad_0[0x3C]; struct fn_15_27D4_Tab *unk_3C; };
struct fn_15_27D4_lbl_15_rodata_0 {
u8 pad_0[0x5C]; f32 unk_5C; u8 pad_60[0x24]; f32 unk_84;
u8 pad_88[0x34]; struct fn_15_27D4_Vec3 unk_BC; f32 unk_C8,unk_CC;
};
struct fn_15_27D4_St {u8 pad_0[0x192];u8 unk_192;};




extern struct fn_15_27D4_St *lbl_15_bss_2C;
struct fn_15_2620_Arg0;
extern void fn_15_2620(struct fn_15_2620_Arg0 *);
static inline f32 fn_15_27D4_operand(f32 right,f32 left){return left+right;}
void fn_15_27D4(struct fn_15_27D4_Arg0 *arg0){
f32 *fzgx_value;
struct fn_15_27D4_Tab *fzgx_live_;
f32 fzgx_live;
struct fn_15_27D4_Tab *p_tab;
struct fn_15_27D4_lbl_15_rodata_0 *p_ro;
struct fn_15_27D4_Dst *p_dst;
struct fn_15_27D4_St *p_st;
u8 v0;
v0=arg0->unk_4C4;
p_ro=&(*(struct fn_15_27D4_lbl_15_rodata_0 *)&lbl_15_rodata_0);
fzgx_live_=(*(struct fn_15_27D4_lbl_1_data_2A7E0 *)&lbl_1_data_2A7E0).unk_3C;
p_tab=fzgx_live_;
switch((s32)v0){
case 0: arg0->unk_A8=p_tab->unk_1C;break;
case 1: arg0->unk_A8=p_tab->unk_28;break;
case 2: arg0->unk_A8=p_tab->unk_34;break;
default: arg0->unk_A8=p_tab->unk_34;
arg0->unk_A8.x=arg0->unk_A8.x-1.0f;
arg0->unk_A8.y=arg0->unk_A8.y-0.5f;break;
}
if(lbl_15_bss_14 & 0x80){
p_st=lbl_15_bss_2C;
switch((s32)p_st->unk_192){
case 4:
switch((s32)arg0->unk_4C4){
case 0:
arg0->unk_A8.x=1.0f+p_tab->unk_1C.x;
arg0->unk_A8.y=0.5f+p_tab->unk_1C.y;
arg0->unk_A8.z=1.5f+p_tab->unk_1C.z;break;
case 1:
fzgx_value=&arg0->unk_A8.x;
*fzgx_value=1.0f+p_tab->unk_28.x;
arg0->unk_A8.y=0.5f+p_tab->unk_28.y;
arg0->unk_A8.z=1.5f+p_tab->unk_28.z;break;
case 2:
arg0->unk_A8.x=1.0f+p_tab->unk_34.x;
arg0->unk_A8.y=0.5f+p_tab->unk_34.y;
arg0->unk_A8.z=1.5f+p_tab->unk_34.z;break;
default:
arg0->unk_A8.x=-0.899999976f+p_tab->unk_34.x;
arg0->unk_A8.y=p_tab->unk_34.y;
arg0->unk_A8.z=1.5f+p_tab->unk_34.z;break;
}break;
case 3:
fzgx_live=arg0->unk_A8.z;
arg0->unk_A8.z=fn_15_27D4_operand(1.5f,fzgx_live);break;
case 2:
switch((s32)arg0->unk_4C4){
case 0:
arg0->unk_A8.x=1.0f+p_tab->unk_1C.x;
arg0->unk_A8.y=p_tab->unk_1C.y;
arg0->unk_A8.z=1.5f+p_tab->unk_1C.z;break;
case 1:
arg0->unk_A8.x=1.0f+p_tab->unk_34.x;
arg0->unk_A8.y=p_tab->unk_34.y;
arg0->unk_A8.z=1.5f+p_tab->unk_34.z;break;
default:break;
}
p_dst=(p_tab->unk_54);
p_dst->unk_C=*(const struct fn_15_27D4_Vec3 *)fzgx_pool_t11;break;
default:break;
}
p_dst=*(p_tab->unk_4C+arg0->unk_4C4);
p_dst->unk_C=arg0->unk_A8;
}
arg0->unk_B8=1.0f;
fn_15_2620((struct fn_15_2620_Arg0 *)arg0);
if(arg0->unk_88==1){arg0->unk_18=arg0->unk_18|0x20000000;}
}
