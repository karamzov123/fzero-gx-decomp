#include "types.h"

/* Volatile sinks retain the native literals in retail pool order. */
#pragma section code_type ".fzgxpool"
void fzgx_pool_primer_000(void) {
    /* Volatile keeps these primer stores and their literals. */
    volatile f32 f;
    /* Volatile retains double literals in the shared retail pool. */
    volatile f64 d;
    f = 60.0f;
    f = 0.10000000149011612f;
    f = 32767.0f;
    f = 0.05000000074505806f;
    d = 0.07;
    f = 20000.0f;
    d = 4503599627370496.0;
    f = 1.0f;
    f = -0.029999999329447746f;
    d = 15.0;
    d = 4503601774854144.0;
    d = 1.5;
    d = 0.5;
    f = 0.0f;
    f = 0.5f;
    f = 8.0f;
    f = 255.0f;
    f = 15.0f;
    f = 0.20000000298023224f;
    f = 0.07999999821186066f;
    f = 0.25f;
    f = 0.9800000190734863f;
    f = 0.9900000095367432f;
    f = 40.0f;
    f = 20.0f;
    f = 1.5f;
    f = 0.44999998807907104f;
    f = -2.0f;
    f = 0.0833333358168602f;
    f = 0.15000000596046448f;
    f = 0.125f;
    f = -0.4000000059604645f;
    f = -0.30000001192092896f;
    f = 2.0f;
    f = 250.0f;
    d = 0.6;
    d = 0.4;
    f = 0.30000001192092896f;
    f = -0.004000000189989805f;
    f = 0.01666666753590107f;
    f = 65536.0f;
    f = 4096.0f;
    f = 0.9599999785423279f;
    f = 0.4000000059604645f;
    f = 0.05050000175833702f;
    f = 0.050999999046325684f;
    f = 0.949999988079071f;
    f = 0.8999999761581421f;
    d = 150.0;
    d = 10.0;
    d = 3.0;
}
#pragma section code_type ".text"

/* Retail floating-point table; values are not addresses. */
const f32 fzgx_pool_table_100[4] = {
    0.0f, 0.10000000149011612f, -2.4000000953674316f, 5.0f
};

#pragma section code_type ".fzgxpool"
void fzgx_pool_primer_110(void) {
    /* Volatile keeps these primer stores and their literals. */
    volatile f32 f;
    /* Volatile retains double literals in the shared retail pool. */
    volatile f64 d;
    d = 1.2;
    d = 0.1;
    f = 10.0f;
    f = 18.0f;
    d = 0.7;
    d = 50.0;
}
#pragma section code_type ".text"

/* Retail floating-point table; values are not addresses. */
const f32 fzgx_pool_table_138[4] = {
    0.0f, 0.10000000149011612f, -2.4000000953674316f, 19.0f
};

#pragma section code_type ".fzgxpool"
void fzgx_pool_primer_148(void) {
    /* Volatile keeps these primer stores and their literals. */
    volatile f32 f;
    /* Volatile retains double literals in the shared retail pool. */
    volatile f64 d;
    d = 24.0;
    f = 0.7071067690849304f;
}
#pragma section code_type ".text"

const u32 fzgx_pool_table_154[3] = {
    0x00000000, 0x00000000, 0x00000000
};

#pragma section code_type ".fzgxpool"
void fzgx_pool_primer_160(void) {
    /* Volatile keeps these primer stores and their literals. */
    volatile f32 f;
    /* Volatile retains double literals in the shared retail pool. */
    volatile f64 d;
    d = 255.0;
    d = 0.9;
    f = 0.004000000189989805f;
    f = 0.0010000000474974513f;
    f = 0.009999999776482582f;
    f = -1.1920928955078125e-7f;
    f = 240.0f;
    f = 100.0f;
    f = 300.0f;
    f = 200.0f;
    f = 10000.0f;
    f = 5000.0f;
    f = 204.0f;
    f = 85.0f;
    f = -0.05000000074505806f;
    f = 4.0f;
    f = -0.05999999865889549f;
    f = -0.5f;
    f = -1.0f;
    d = 0.2;
    f = 512.0f;
    f = 0.029999999329447746f;
    f = 51.0f;
    f = 88.0f;
    d = -3.0;
    f = 4.5f;
    f = 6.0f;
}
#pragma section code_type ".text"

/* Retail floating-point table; values are not addresses. */
const f32 fzgx_pool_table_1e0[26] = {
    1.100000023841858f, 0.0f, 0.8999999761581421f, -1.100000023841858f, 0.0f, 0.8999999761581421f, 0.0f, 0.0f, -0.699999988079071f, 0.0f, 0.0f, 0.0f, 1.2000000476837158f, 50.0f, 0.02500000037252903f, 0.800000011920929f, 0.0625f, 2.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -3.0f, 0.0f
};

#pragma section code_type ".fzgxpool"
void fzgx_pool_primer_248(void) {
    /* Volatile keeps these primer stores and their literals. */
    volatile f32 f;
    /* Volatile retains double literals in the shared retail pool. */
    volatile f64 d;
    d = 0.01;
    f = 1.8600000143051147f;
    d = 210.0;
    d = 0.02;
    d = 0.003;
    d = -0.699999988079071;
    d = -0.029999999329447746;
    d = 0.141;
    d = 0.699999988079071;
    d = 1.0;
    d = 0.3;
    d = 0.800000011920929;
    d = 12.0;
    f = -0.8999999761581421f;
    f = 0.07000000029802322f;
    f = 0.6000000238418579f;
    f = 30.0f;
    f = 1.059999942779541f;
    f = 28.0f;
    d = 5.0;
}
#pragma section code_type ".text"


typedef struct EffVec3 {
    f32 x;
    f32 y;
    f32 z;
} EffVec3;

typedef struct EffRot3 {
    s16 x;
    s16 y;
    s16 z;
} EffRot3;

struct Eff62E9C {
    u8 pad_0[0x10];
    s32 unk_10;
    u8 pad_14[0x8];
    f32 r;
    f32 g;
    f32 b;
    f32 size;
    u8 pad_2C[0x8];
    void *unk_34;
    u8 pad_38[0x4];
    EffVec3 pos;
    u8 pad_48[0xC];
    EffRot3 rot;
};

struct EffPacket62E9C {
    f32 unk_0;
    f32 unk_4;
    f32 mtx[12];
    u8 pad_38[0x4];
    u8 color[4];
};

extern f32 lbl_8006D0B4(f32);
extern void lbl_8006DCA4(void);
extern u32 fn_1_58C4(void);
extern void fn_1_681C(u8, EffVec3 *);
extern int fn_1_9F914(void *, void *);
extern void lbl_8006D7DC(EffVec3 *);
extern void lbl_8006E1B0(EffVec3 *, EffVec3 *);
extern void lbl_8006DB74(f32 *);
extern void mathutil_mtxA_rotate_x(s16);
extern void mathutil_mtxA_rotate_y(s16);
extern void mathutil_mtxA_rotate_z(s16);
extern void *memset(void *, int, u32);

#define MIN(a, b) (((a) < (b)) ? (a) : (b))

static inline f32 eff_dist_to(struct Eff62E9C *e, EffVec3 *p) {
    f32 dx;
    f32 dy;
    f32 dz;
    f32 sq;
    dx = e->pos.x;
    dx -= p->x;
    sq = dx * dx;
    dy = e->pos.y;
    dy -= p->y;
    sq += dy * dy;
    dz = e->pos.z;
    dz -= p->z;
    sq += dz * dz;
    return lbl_8006D0B4(sq);
}


void fn_1_62E9C(struct Eff62E9C *e) {
    struct EffPacket62E9C pkt;
    EffVec3 tpos;
    EffVec3 cam;
    f32 alpha;
    f32 dist;
    u32 count;
    u32 i;

    alpha = 1.0f;
    lbl_8006DCA4();
    lbl_8006E1B0(&e->pos, &tpos);
    lbl_8006D7DC(&tpos);
    mathutil_mtxA_rotate_y(e->rot.y);
    mathutil_mtxA_rotate_x(e->rot.x);
    mathutil_mtxA_rotate_z(e->rot.z);

    count = fn_1_58C4();
    fn_1_681C(0, &cam);
    dist = eff_dist_to(e, &cam);
    for (i = 1; i < count; i++) {
        fn_1_681C(i, &cam);
        /* the macro evaluates the distance twice, as retail does */
        if (dist < eff_dist_to(e, &cam)) {
            dist = dist;
        } else {
            dist = eff_dist_to(e, &cam);
        }
    }

    if (dist <= 5.0) {
        return;
    }
    if (dist < 20.0f) {
        dist = dist / 20.0f;
    } else {
        dist = 1.0f;
    }
    memset(&pkt, 0, sizeof(pkt));
    lbl_8006DB74(pkt.mtx);
    pkt.unk_0 = 0.70710677f * e->size;
    if (e->unk_10 < 12) {
        alpha *= 0.083333336f * (f32)e->unk_10;
    }
    pkt.color[0] = (u8)(s32)(dist * (255.0f * e->r * alpha));
    pkt.color[1] = (u8)(s32)(dist * (255.0f * e->g * alpha));
    pkt.color[2] = (u8)(s32)(dist * (255.0f * e->b * alpha));
    /* Publish the alpha and second size component in packet order. */
    *(volatile u8 *)&pkt.color[3] = (u8)(s32)(255.0f * dist);
    /* Volatile preserves this size store after the alpha-byte store. */
    *(volatile f32 *)&pkt.unk_4 = pkt.unk_0;
    fn_1_9F914(&pkt, e->unk_34);
}
