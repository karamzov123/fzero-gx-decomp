#include "types.h"
#include "rel/sel/globals.h"
#include "rel/sel/sel.h"
extern u32 lbl_10_bss_51788[25];
extern f32 lbl_10_bss_55B3C[];
extern u8 lbl_10_rodata_1548[0x8];
extern const f32 lbl_10_rodata_158[19];
extern u8 lbl_10_rodata_1D64[0x4];
extern u8 lbl_10_rodata_1D68[0x8];
extern u8 lbl_10_rodata_94[0xc4];
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAB4;
extern u32 * lbl_1_bss_6EAD0;
extern int lbl_1_bss_7180C;
extern u32 lbl_1_bss_718E0;
extern s16 lbl_1_bss_8B3A0;
extern s16 lbl_1_bss_8CA26;
extern s16 lbl_1_bss_960;
extern s16 lbl_1_bss_962;
extern s16 lbl_1_bss_966;
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_980[4];
extern s8 lbl_1_bss_9C;
extern u8 lbl_1_bss_9C8[];
extern u8 lbl_1_bss_9F8[];
extern const char * lbl_1_data_2AA24[];
extern const char * lbl_1_data_2BD54[][6];
extern char * lbl_1_data_418D4[];
extern char lbl_1_rodata_26F8;
extern const u8 lbl_1_rodata_D5B8[];
extern const u32 lbl_1_rodata_D870[];
extern u32 lbl_801A6410;
extern u32 lbl_801A66A0;
extern u32 lbl_801A66A8;
extern s32 lbl_801A66B4;
extern u16 lbl_801A66C0;
extern void fn_800713E0(u32, u32);
extern void fn_1_8019C(u32);
extern void fn_1_12B3F8(void *, u32, u32, void *, void *, void *);
extern void fn_1_12C6BC(u32);
extern void fn_10_1B658(void);
extern void fn_1_8F494(void *value);
extern void fn_10_1B65C(void);
extern void fn_10_1B6A8(void);
extern void OSReport(const char *, ...);
extern void fn_1_12F358(s16);
extern s32 fn_1_1310E0(void);
extern void fn_1_131084(u32, s32);
extern void fn_10_1B660(void);
extern void fn_1_7B558(u32, u32, u32, u32, u32, u32, f32);
extern void fzgx_pool_sink_f32(f32);
extern void fzgx_pool_sink_f64(f64);
extern void fn_80074188(s16, s16, s16, s16);

#include "rel/sel/sel.h"

typedef struct fn_10_FF54_SelEntry {
    u8 pad_0[0xe];
    s16 unk_E;
    u8 pad_10[0x10];
} fn_10_FF54_SelEntry;

typedef struct fn_10_FF54_SelState {
    fn_10_FF54_SelEntry entries[4];
    u8 pad_80[0x14];
    u32 flags;
    u32 bits;
    u8 pad_9c[2];
    u8 unk_9E;
    u8 pad_9f[5];
    u8 *items;
} fn_10_FF54_SelState;









extern void fn_10_12C14(void);
extern void fn_10_19040(void);
extern void fn_10_1973C(void);
extern void fn_10_21C44(s32);
extern void fn_10_12024(void);
extern void fn_10_117D0(void);
extern void fn_10_10DB0(void);
extern void fn_10_18A50(void *, u32);
extern void fn_10_21DA8(void);
extern void *fn_10_21C20(s32, s16);
extern void fn_1_13D02C(void);
extern void fn_1_49410(void);
extern void fn_1_133DBC(s32);
extern void fn_1_134AD4(void);
extern void fn_1_13DA0C(void);
extern void fn_1_13DC54(void);
extern void fn_1_13DDB8(void);
extern void fn_1_1380F0(void *);
extern void fn_1_13B328(u32, s32);
extern void fn_1_134EE4(s32, s32, s32, f32);
extern void fn_1_135894(s16, s16, s32, s32, s32, s32, s32, f32, f32);
extern void fn_1_136174(s16, s32, s32, s32, s16, s32, s32, f32, f32);
extern void fn_1_13EDDC(s32, s32, s32, s32, s32);
extern void fn_1_1363F0(s32, s32, s32);
extern void fn_1_1368A0(s32, s32, s32, f32, f32, f32, f32, f32);

#pragma opt_common_subs off
void fn_10_FF54(void) {
    f32 *pool = (*(f32 (*)[19])&lbl_10_rodata_158);
    s32 idx = (*(fn_10_FF54_SelState *)&lbl_1_bss_8B3A0).unk_9E;
    s16 val = (*(fn_10_FF54_SelState *)&lbl_1_bss_8B3A0).entries[(s16)idx].unk_E;

    fn_1_13D02C();
    fn_1_49410();
    if (((*(fn_10_FF54_SelState *)&lbl_1_bss_8B3A0).flags & 0x80000000) == 0) {
        lbl_10_bss_55690.unk_0 = lbl_10_bss_55690.unk_4 = ((f32 *)(pool))[17];
        fn_10_12C14();
        fn_10_19040();
        fn_10_1973C();
        fn_10_21C44(val);
    }
    fn_10_12024();
    fn_1_133DBC(1);
    fn_1_134AD4();
    fn_1_13DA0C();
    fn_1_13DC54();
    fn_1_13DDB8();
    fn_10_117D0();
    fn_10_10DB0();
    fn_10_18A50(&(*(fn_10_FF54_SelState *)&lbl_1_bss_8B3A0), 0xac);
    if ((*(fn_10_FF54_SelState *)&lbl_1_bss_8B3A0).items[0x19] != 0) {
        fn_10_21DA8();
        fn_1_1380F0((*(void * (*)[])&lbl_1_data_418D4)[lbl_801A66B4]);
    } else {
        fn_1_1380F0(fn_10_21C20(8, (s16)lbl_801A66B4));
    }
    fn_1_13B328(0x40800000, 0);
    fn_1_134EE4(0, 1, 0, ((f32 *)(pool))[19]);
    fn_1_135894(0xd5, 0x16e - (lbl_801A66B4 == 5 ? 0 : (val > 0x28 ? 4 : 7)), 6, val, 0, idx, 0, ((f32 *)(pool))[17], ((f32 *)(pool))[17]);
    fn_1_136174(0xd5, 0x163, 1, val, (s16)lbl_801A66B4, idx, 0, ((f32 *)(pool))[18], ((f32 *)(pool))[18]);
    fn_1_13EDDC(0x1f9, 0x181, val, idx, 0);
    fn_1_1363F0(idx, 0, 1);
    fn_1_1368A0(val, idx, 0, ((f32 *)(pool))[157], ((f32 *)(pool))[158], ((f32 *)(pool))[159], ((f32 *)(pool))[17], ((f32 *)(pool))[17]);
}
#pragma opt_common_subs reset
