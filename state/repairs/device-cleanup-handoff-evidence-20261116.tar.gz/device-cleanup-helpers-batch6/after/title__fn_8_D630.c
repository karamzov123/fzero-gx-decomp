#include "types.h"
#include "rel/title/globals.h"
#include "rel/title/operation.h"
extern u8 lbl_1_bss_38460[0x54];
extern s16 lbl_1_bss_96A;
extern u16 lbl_1_bss_9F8[];
extern u8 lbl_1_data_1E5C0[0x34];
extern u8 lbl_1_rodata_26F8[0x58];
extern u32 lbl_801A6410;
extern s32 lbl_801A66A0;
extern s32 lbl_801A66B4;
extern f32 lbl_8_rodata_160[10];
extern f32 lbl_8_rodata_198;
extern u8 lbl_8_rodata_408[0x8];
extern u32 fn_1_412A0(u32);
extern u32 fn_1_3EB78(u32, u32, u32, u32);
extern u32 fn_1_3ED8C(u32, u32, u32, u32, u32, u32, u32);
extern void fn_8_663C(void);
extern void fn_1_3EF08(u8);
extern void fn_1_3EF8C(u8);
extern void fn_1_3EFF0(u32, u8);
extern void fn_1_3F02C(u32);
extern f32 lbl_8006D0B4(f32);
extern u8 lbl_8_data_9AB8[0x18];
extern void fn_8_C9A8(s32, s32, f32);
extern void GXGetProjectionv(f32 *);
extern void C_MTXOrtho(f32 (*)[4], f32, f32, f32, f32, f32, f32);
extern void fn_800737E4(f32 (*)[4], s32);
extern void fn_80072270(f32 *);
extern void fn_1_56000(s32, s32, s32);
extern void fn_1_14DE80(void *, void **, void **, s32, f32);
extern void lbl_8006DAEC(void);
extern void fn_1_14E054(void *, void *, s32, f32);
extern void lbl_8006DBE4(void);
extern void fn_1_14E198(void *, void *, s32, f32);
extern void lbl_8006DC20(void);
extern f32 lbl_8_rodata_2FC[27];
extern u32 fn_800371F8(u32, void *);
extern void fn_8003462C(u32, u32, u32);
extern void fn_8007245C(u32);
extern void fn_80072864(u32);
extern void fn_800728A8(s32, s32, s32, s32);
extern void fn_80072AB0(s32, s32, s32);
extern void fn_80072C24(s32, s32, s32, s32, s32);
extern void fn_80072CC4(u32, u32, u32, u32, u32);
extern void fn_80072D64(u32, u32, u32, u32, u32, u32);
extern void fn_80072E20(s32, s32, s32, s32, u8, s32);
extern void fn_800734A8(u32, s32, s32, s32);
extern void fn_80073678(u32);
extern void fn_80073C6C(s32);
extern void fn_80074660(u32);
extern void fn_80074788(u32);
extern void fn_800747D0(u32, u32, u32, u32, u32, u32, u32);
extern void fn_80074918(u8, s32, u8);
extern void fn_1_4965C(u8);
extern f32 lbl_8006D188(u32);
extern void fn_1_55FF0(f32);
extern u32 fn_1_D0790(void);
extern int fn_8_CF58(void);
extern int fn_8_CF60(void);
extern int fn_8_CF68(void);
extern s32 fn_8_CF70(void);
extern char lbl_8_data_A0C4[];
extern char lbl_8_data_A174[];
extern char lbl_8_data_A178[];
extern char lbl_8_data_A17C[];
extern char lbl_8_data_A180[];
extern char lbl_8_data_A184[];
extern s32 fn_1_1555B0(s32);
extern void fn_1_14A1AC(u8);
extern void fn_1_14BC40(void);
extern void fn_1_1554D0(void);
extern void fn_1_14BCBC(void *, u32);
extern u32 fn_1_144F40(u32, void *);
extern void fn_8_D020(void);
extern u32 lbl_8_rodata_C24;
extern u32 lbl_8_rodata_C28;
extern s32 fn_1_14CEB8(u32);

typedef signed short fn_8_D630_s16;
typedef signed long fn_8_D630_s32;

typedef unsigned char fn_8_D630_u8;
typedef unsigned short fn_8_D630_u16;
typedef unsigned long fn_8_D630_u32;

typedef float fn_8_D630_f32;
typedef double fn_8_D630_f64;

typedef unsigned long fn_8_D630_size_t;

/* lbl_4_bss_5680: .bss size 0x4, referenced by 8 functions, shape {'object': 112, 'pointer': 28} */
typedef struct {
fn_8_D630_u32 unk_0; /* 11 loads, 6 stores */
fn_8_D630_u32 unk_4; /* 1 loads, 1 stores */
fn_8_D630_u32 unk_8; /* 4 loads, 1 stores */
fn_8_D630_u8 unk_C; /* 8 loads, 1 stores */
fn_8_D630_u8 unk_D; /* 5 loads, 4 stores */
fn_8_D630_u8 unk_E; /* 10 loads, 3 stores */
fn_8_D630_u8 unk_F; /* 3 loads, 12 stores */
fn_8_D630_u8 unk_10; /* 1 loads, 0 stores */
fn_8_D630_u8 unk_11; /* 2 loads, 1 stores */
fn_8_D630_u16 unk_12; /* 3 loads, 3 stores */
fn_8_D630_u8 unk_14; /* 2 loads, 2 stores */
fn_8_D630_u8 unk_15; /* 2 loads, 2 stores */
fn_8_D630_u8 unk_16; /* 2 loads, 2 stores */
fn_8_D630_u8 unk_17; /* 2 loads, 2 stores */
fn_8_D630_u32 unk_18; /* 1 loads, 1 stores */
fn_8_D630_u32 unk_1C; /* 1 loads, 1 stores */
fn_8_D630_u32 unk_20; /* 3 loads, 2 stores */
fn_8_D630_u8 pad_24[0x4];
fn_8_D630_u8 unk_28; /* 1 loads, 0 stores */
fn_8_D630_u8 pad_29[0xD];
fn_8_D630_u8 unk_36; /* 2 loads, 1 stores */
fn_8_D630_u8 unk_37; /* 0 loads, 1 stores */
fn_8_D630_u8 pad_38[0x2];
fn_8_D630_u8 unk_3A; /* 2 loads, 2 stores */
fn_8_D630_u8 unk_3B; /* 5 loads, 2 stores */
fn_8_D630_u32 unk_3C; /* 4 loads, 2 stores */
} fn_8_D630_Obj_4_bss_5680_Target;



/* lbl_4_data_2F78: .data size 0xA0, referenced by 5 functions, shape {} */
extern fn_8_D630_u8 lbl_8_data_A1E8[0xA0];

/* lbl_4_bss_5684: .bss size 0x1, referenced by 3 functions, shape {'object': 3} */
extern fn_8_D630_u8 lbl_8_bss_554;

extern void fn_1_A2D84(fn_8_D630_u32);

typedef struct fn_8_D630_FontDrawPacket fn_8_D630_FontDrawPacket;
typedef struct fn_8_D630_FontVertex {
fn_8_D630_f32 x, y, z;
} fn_8_D630_FontVertex;
struct fn_8_D630_FontDrawPacket {
fn_8_D630_u32 image;
fn_8_D630_f32 x, y, z;
fn_8_D630_f32 scale_x, scale_y;
fn_8_D630_f32 u0, v0, u1, v1;
fn_8_D630_s16 rotation_z, rotation_y;
fn_8_D630_f32 alpha;
fn_8_D630_u32 flags;
fn_8_D630_f32 depth;
fn_8_D630_u8 color[4], color_add[4];
fn_8_D630_u32 format;
fn_8_D630_u16 width, height;
void* pixels;
fn_8_D630_FontDrawPacket* secondary;
void (*vertex_callback)(fn_8_D630_FontDrawPacket* packet, fn_8_D630_FontVertex* vertices);
fn_8_D630_u32 unk_54;
};
void fn_1_4A0D8(const char* text);
void fn_1_4AE0C(const char* format, ...);
int fn_1_4F734(fn_8_D630_FontDrawPacket* packet);
void fn_1_4EDAC(fn_8_D630_FontDrawPacket* packet, fn_8_D630_f32 width, fn_8_D630_f32 height);
void fn_1_51678(fn_8_D630_FontDrawPacket* packet, fn_8_D630_u32 image, fn_8_D630_s16 x, fn_8_D630_s16 y, fn_8_D630_s16 width, fn_8_D630_s16 height);
void fn_1_517EC(fn_8_D630_FontDrawPacket* packet, fn_8_D630_s16 x, fn_8_D630_s16 y, fn_8_D630_s16 width, fn_8_D630_s16 height,
fn_8_D630_s16 texture_width, fn_8_D630_s16 texture_height);
#pragma section code_type ".fzgxpool"
static const fn_8_D630_u32 fzgx_pool_table1[360] = {0x89709094, 0x00000000, 0x82608261, 0x82628263, 0x82648265, 0x82668267, 0x82688269, 0x826A826B, 0x826C826D, 0x826E826F, 0x82708271, 0x82728273, 0x82748275, 0x82768277, 0x82788279, 0x82818282, 0x82838284, 0x82858286, 0x82878288, 0x8289828A, 0x828B828C, 0x828D828E, 0x828F8290, 0x82918292, 0x82938294, 0x82958296, 0x82978298, 0x8299829A, 0x824F8250, 0x82518252, 0x82538254, 0x82558256, 0x82578258, 0x81E781E8, 0x00000000, 0x82818282, 0x82838284, 0x82858286, 0x82878288, 0x8289828A, 0x828B828C, 0x828D828E, 0x828F8290, 0x82918292, 0x82938294, 0x82958296, 0x82978298, 0x8299829A, 0x82608261, 0x82628263, 0x82648265, 0x82668267, 0x82688269, 0x826A826B, 0x826C826D, 0x826E826F, 0x82708271, 0x82728273, 0x82748275, 0x82768277, 0x82788279, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x00000000, 0x8B4C8D86, 0x00000000, 0x81418142, 0x814C814D, 0x81458143, 0x81448146, 0x81478148, 0x8149817B, 0x817C815E, 0x81818183, 0x8184814F, 0x81518160, 0x81628175, 0x81768169, 0x816A816F, 0x8170816D, 0x816E818F, 0x81908193, 0x81948195, 0x81968197, 0x81E781E8, 0x00000000, 0x82D082E7, 0x82AA82C8, 0x00000000, 0x82A082A2, 0x82A482A6, 0x82A882A9, 0x82AB82AD, 0x82AF82B1, 0x82B382B5, 0x82B782B9, 0x82BB82BD, 0x82BF82C2, 0x82C482C6, 0x82C882C9, 0x82CA82CB, 0x82CC82CD, 0x82D082D3, 0x82D682D9, 0x82DC82DD, 0x82DE82DF, 0x82E082E2, 0x82E482E6, 0x82E782E8, 0x82E982EA, 0x82EB82ED, 0x82EE82EF, 0x82F082F1, 0x82AA82AC, 0x82AE82B0, 0x82B282B4, 0x82B682B8, 0x82BA82BC, 0x82BE82C0, 0x82C382C5, 0x82C782CE, 0x82D182D4, 0x82D782DA, 0x82CF82D2, 0x82D582D8, 0x82DB829F, 0x82A182A3, 0x82A582A7, 0x82C182E1, 0x82E382E5, 0x82EC81E7, 0x81E80000, 0x829F82A1, 0x82A382A5, 0x82A782AA, 0x82AC82AE, 0x82B082B2, 0x82B482B6, 0x82B882BA, 0x82BC82BE, 0x82C082C1, 0x82C582C7, 0x81408140, 0x81408140, 0x814082CE, 0x82D182D4, 0x82D782DA, 0x81408140, 0x81408140, 0x814082E1, 0x82E382E5, 0x81408140, 0x81408140, 0x814082EC, 0x81408140, 0x81408140, 0x82A982AB, 0x82AD82AF, 0x82B182B3, 0x82B582B7, 0x82B982BB, 0x82BD82BF, 0x82C282C4, 0x82C682CF, 0x82D282D5, 0x82D882DB, 0x82CD82D0, 0x82D382D6, 0x82D982A0, 0x82A282A4, 0x82A682A8, 0x82C282E2, 0x82E482E6, 0x82ED8140, 0x81400000, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x814082C3, 0x81408140, 0x81408140, 0x81408140, 0x814082CF, 0x82D282D5, 0x82D882DB, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x82C18140, 0x814082CD, 0x82D082D3, 0x82D682D9, 0x82CE82D1, 0x82D482D7, 0x82DA8140, 0x81408140, 0x81408140, 0x82C38140, 0x81408140, 0x81408140, 0x81400000, 0x834A835E, 0x834A8369, 0x00000000, 0x83418343, 0x83458347, 0x8349834A, 0x834C834E, 0x83508352, 0x83548356, 0x8358835A, 0x835C835E, 0x83608363, 0x83658367, 0x8369836A, 0x836B836C, 0x836D836E, 0x83718374, 0x82D6837A, 0x837D837E, 0x83808381, 0x83828384, 0x83868388, 0x8389838A, 0x838B838C, 0x838D838F, 0x83908391, 0x83928393, 0x8394834B, 0x834D834F, 0x83518353, 0x83558357, 0x8359835B, 0x835D835F, 0x83618364, 0x83668368, 0x836F8372, 0x837582D7, 0x837B8370, 0x83738376, 0x82D8837C, 0x83408342, 0x83448346, 0x83488395, 0x83968362, 0x83838385, 0x8387838E, 0x81E781E8, 0x00000000, 0x83408342, 0x83448346, 0x8348834B, 0x834D834F, 0x83518353, 0x83558357, 0x8359835B, 0x835D835F, 0x83618362, 0x83668368, 0x81408140, 0x81408140, 0x8140836F, 0x83728375, 0x82D7837B, 0x81408140, 0x81408140, 0x81408383, 0x83858387, 0x81408140, 0x81408140, 0x8140838E, 0x81408140, 0x81408140, 0x8345834A, 0x834C834E, 0x83508352, 0x83548356, 0x8358835A, 0x835C835E, 0x83608363, 0x83658367, 0x83708373, 0x837682D8, 0x837C836E, 0x83718374, 0x82D6837A, 0x83418343, 0x83458347, 0x8349834A, 0x83508363, 0x83848386, 0x8388838F, 0x81408140, 0x00000000, 0x81408140, 0x83948140, 0x81408395, 0x81408140, 0x83968140, 0x81408140, 0x81408140, 0x81408140, 0x81408364, 0x81408140, 0x81408140, 0x81408140, 0x81408370, 0x83738376, 0x82D8837C, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x81408140, 0x83448395, 0x81408140, 0x83968140, 0x81408140, 0x81408140, 0x81408140, 0x81408362, 0x81408140, 0x836E8371, 0x837482D6, 0x837A836F, 0x83728375, 0x82D7837B, 0x81408140, 0x83948140, 0x8140834B, 0x83518364, 0x81408140, 0x81408140, 0x81408140, 0x00000000}; /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const fn_8_D630_u32 *volatile cp; cp = fzgx_pool_table1; } /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
volatile fn_8_D630_f32 s; volatile fn_8_D630_f64 d; /* fzgx-allow: S2 pool primer sinks */
s = 225.43910217285156f;
}
static const fn_8_D630_u32 fzgx_pool_table3[65] = {0x74616C20, 0x4C657474, 0x65727300, 0x82608261, 0x82628263, 0x82648265, 0x82668267, 0x82688269, 0x826A826B, 0x826C826D, 0x826E826F, 0x82708271, 0x82728273, 0x82748275, 0x82768277, 0x82788279, 0x81E781E8, 0x00000000, 0x536D616C, 0x6C204C65, 0x74746572, 0x73000000, 0x82818282, 0x82838284, 0x82858286, 0x82878288, 0x8289828A, 0x828B828C, 0x828D828E, 0x828F8290, 0x82918292, 0x82938294, 0x82958296, 0x82978298, 0x8299829A, 0x81E781E8, 0x00000000, 0x5369676E, 0x73000000, 0x81438144, 0x81488149, 0x817B817C, 0x815E815F, 0x81818183, 0x81848146, 0x8147814C, 0x814D814F, 0x81518162, 0x8169816A, 0x816D816E, 0x816F8170, 0x81908193, 0x81948195, 0x81968197, 0x81E781E8, 0x00000000, 0x4E756D62, 0x65727300, 0x824F8250, 0x82518252, 0x82538254, 0x82558256, 0x82578258, 0x81E781E8, 0x00000000}; /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const fn_8_D630_u32 *volatile cp; cp = fzgx_pool_table3; } /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
volatile fn_8_D630_f32 s; volatile fn_8_D630_f64 d; /* fzgx-allow: S2 pool primer sinks */
d = 0.21;
d = 1.6666666666666667;
d = 0.5;
s = 48.0f;
s = 0.25f;
d = 1.0;
s = 0.12999999523162842f;
s = 0.0f;
d = 1.5;
d = 2.0;
s = 1.6666666269302368f;
s = 0.0625f;
d = 4503601774854144.0;
d = 4503599627370496.0;
}
#pragma section code_type ".text"
struct fn_8_D630_rodata {
fn_8_D630_u8 pad_0[0x6A8];
fn_8_D630_f64 unk_6A8;
fn_8_D630_f64 unk_6B0;
fn_8_D630_f64 unk_6B8;
fn_8_D630_f32 unk_6C0;
fn_8_D630_f32 unk_6C4;
fn_8_D630_f64 unk_6C8;
fn_8_D630_f32 unk_6D0;
fn_8_D630_u8 pad_6D4[0x4];
fn_8_D630_f64 unk_6D8;
fn_8_D630_f64 unk_6E0;
fn_8_D630_f32 unk_6E8;
fn_8_D630_f32 unk_6EC;
fn_8_D630_f64 unk_6F0;
fn_8_D630_f64 unk_6F8;
};

#pragma pack(1)
struct fn_8_D630_obj {
fn_8_D630_u8 unk_0;
fn_8_D630_u8 unk_1;
fn_8_D630_u8 unk_2;
fn_8_D630_u8 unk_3;
fn_8_D630_u16 unk_4;
fn_8_D630_u16 unk_6;
fn_8_D630_u16 unk_8;
fn_8_D630_u16 unk_A;
fn_8_D630_u8 unk_C;
fn_8_D630_u32 unk_D;
};
#pragma pack()










extern void fn_1_46B4(fn_8_D630_u32, fn_8_D630_u32, const char *, int);
extern fn_8_D630_u32 fn_1_4060(void);
extern fn_8_D630_s32 strncmp(const char *, const char *, fn_8_D630_size_t);
extern char * strncpy(char *, const char *, fn_8_D630_size_t);
extern void fn_1_49410(void);
extern void fn_1_494DC(fn_8_D630_s16);
extern void fn_1_495C8(fn_8_D630_u8);
extern void fn_1_49514(fn_8_D630_u32 *);
extern void fn_1_496FC(fn_8_D630_f32, fn_8_D630_f32);
extern void fn_1_4955C(fn_8_D630_f32, fn_8_D630_f32);
extern void fn_1_495A0(fn_8_D630_f32);
extern void fn_1_A2D84(fn_8_D630_u32);
extern int fn_1_4F734(fn_8_D630_FontDrawPacket *);
extern void fn_1_4A0D8(const char *);
#pragma pool_data on
#pragma fp_contract off
#pragma opt_common_subs off
static inline fn_8_D630_s32 fn_4_ADF4_sign(fn_8_D630_s32 x) { return x < 0 ? -1 : x > 0; }
void fn_8_D630(struct fn_8_D630_obj *arg0)
{
struct fn_8_D630_obj *p;
struct fn_8_D630_rodata *r;
fn_8_D630_u8 *d;
fn_8_D630_u8 name[4];
fn_8_D630_u8 ph[4];
fn_8_D630_u32 col1;
fn_8_D630_u32 col2;
fn_8_D630_u32 col3;
fn_8_D630_u32 col4;
fn_8_D630_FontDrawPacket loc_20;
fn_8_D630_f32 f;
fn_8_D630_f32 scale;
fn_8_D630_u32 t;
fn_8_D630_u32 n2;
fn_8_D630_s32 e;
p = arg0;
r = &(*(struct fn_8_D630_rodata *)&lbl_8_rodata_408);
d = (*(fn_8_D630_u8 (*)[])&lbl_8_data_A1E8);
if ((*(fn_8_D630_u8 *)&lbl_8_bss_554) != 0) {
fn_1_46B4((*(fn_8_D630_u32 *)&lbl_801A6410), (fn_8_D630_u32)p, (const char *)(d + 0xA0), 0xFB);
fn_1_4060();
return;
}
n2 = (p->unk_C + 1) & 0x1F;
t = (*(fn_8_D630_Obj_4_bss_5680_Target * *)&lbl_8_bss_550)->unk_20;
if (__rlwnm(t, n2, 31, 31) != 0) {
if (p->unk_0 != 1 || p->unk_1 != 0x18) {
p->unk_0 = 4;
p->unk_1 = 0x10;
(*(fn_8_D630_Obj_4_bss_5680_Target * *)&lbl_8_bss_550)->unk_20 &= ~(0x80000000U >> p->unk_C);
if (strncmp((const char *)p + 2, (const char *)(d + 0xB0), 2) == 0) {
strncpy((char *)p + 2, (const char *)(d + 0xB4), 2);
name[0] = p->unk_2;
name[1] = p->unk_3;
}
}
}
name[0] = p->unk_2;
name[1] = p->unk_3;
name[2] = 0;
fn_1_49410();
fn_1_494DC(0x2A);
fn_1_495C8(9);
switch (p->unk_0) {
case 1:
{
fn_8_D630_u16 c4 = p->unk_4;
fn_8_D630_s32 t4 = (fn_8_D630_s32)p->unk_8 - (fn_8_D630_s32)c4;
fn_8_D630_f64 dd = 0.21 * (fn_8_D630_f64)t4;
if ((fn_8_D630_s32)dd != 0) {
p->unk_4 = (fn_8_D630_u16)(fn_8_D630_s32)((fn_8_D630_f64)(fn_8_D630_u32)c4 + dd);
} else {
e = fn_4_ADF4_sign(t4);
/* Retail rereads the position after selecting the one-step adjustment. */
p->unk_4 = *(volatile fn_8_D630_u16 *)&p->unk_4 + e;
}
{
fn_8_D630_u16 c6 = p->unk_6;
fn_8_D630_s32 t6 = (fn_8_D630_s32)p->unk_A - (fn_8_D630_s32)c6;
dd = 0.21 * (fn_8_D630_f64)t6;
if ((fn_8_D630_s32)dd != 0) {
p->unk_6 = (fn_8_D630_u16)(fn_8_D630_s32)((fn_8_D630_f64)(fn_8_D630_u32)c6 + dd);
} else {
e = fn_4_ADF4_sign(t6);
/* Retail rereads the position after selecting the one-step adjustment. */
p->unk_6 = *(volatile fn_8_D630_u16 *)&p->unk_6 + e;
}
}
}
col1 = p->unk_D;
fn_1_49514(&col1);
fn_1_496FC((fn_8_D630_f32)p->unk_4, (fn_8_D630_f32)p->unk_6);
{
fn_8_D630_f64 scale_d = 1.6666666666666667 * (0.5 + (fn_8_D630_f32)(0x18 - p->unk_1) / 48.0f);
fn_1_4955C(scale_d, scale_d);
}
if (p->unk_1 == 1) {
p->unk_0 = 2;
p->unk_4 = p->unk_8;
p->unk_6 = p->unk_A;
}
break;
case 2:
if (p->unk_1 == 0) {
p->unk_1 = 4;
fn_1_A2D84(0xA9010100);
}
*(fn_8_D630_u32 *)ph = p->unk_D;
{
fn_8_D630_f32 quarter = 0.25f;
f = (fn_8_D630_f32)p->unk_1 * quarter;
{
ph[0] += (255 - ph[0]) * f;
ph[1] += (255 - ph[1]) * f;
ph[2] += (255 - ph[2]) * f;
}
}
col2 = *(fn_8_D630_u32 *)ph;
fn_1_49514(&col2);
fn_1_496FC((fn_8_D630_f32)p->unk_4, (fn_8_D630_f32)p->unk_6);
{
fn_8_D630_f64 scale_d = 1.6666666666666667 * (1.0 + 0.5 * (fn_8_D630_f64)f);
fn_1_4955C(scale_d, scale_d);
}
loc_20 = *(fn_8_D630_FontDrawPacket *)(&(*(fn_8_D630_u32 *)&lbl_1_rodata_26F8));
loc_20.image = 0x8F09;
loc_20.x = (fn_8_D630_f32)p->unk_4;
loc_20.y = (fn_8_D630_f32)p->unk_6;
loc_20.z = 0.13f;
loc_20.scale_x = loc_20.scale_y = (1.5 + 2.0 * (fn_8_D630_f64)f);
loc_20.flags = 0xA;
fn_1_4F734((fn_8_D630_FontDrawPacket *)&loc_20);
if (p->unk_1 == 1) {
p->unk_0 = 3;
if (strncmp((const char *)p + 2, (const char *)(d + 0xB4), 2) == 0) {
strncpy((char *)p + 2, (const char *)(d + 0xB0), 2);
name[0] = p->unk_2;
name[1] = p->unk_3;
}
}
break;
case 3:
col3 = p->unk_D;
fn_1_49514(&col3);
fn_1_496FC((fn_8_D630_f32)p->unk_4, (fn_8_D630_f32)p->unk_6);
fn_1_4955C(1.6666666f, 1.6666666f);
break;
case 4:
if (p->unk_1 == 0) {
fn_1_46B4((*(fn_8_D630_u32 *)&lbl_801A6410), (fn_8_D630_u32)p, (const char *)(d + 0xA0), 0x169);
fn_1_4060();
return;
}
col4 = p->unk_D;
fn_1_49514(&col4);
fn_1_496FC((fn_8_D630_f32)p->unk_4, (fn_8_D630_f32)p->unk_6);
{
fn_8_D630_f64 scale_d = 1.6666666666666667 * (1.0 + 0.5 * (fn_8_D630_f32)(0x10 - p->unk_1));
fn_1_4955C(scale_d, scale_d);
}
{
fn_8_D630_f32 alpha = (fn_8_D630_f32)p->unk_1;
alpha *= 0.0625f;
fn_1_495A0(alpha);
}
break;
}
fn_1_4A0D8((const char *)name);
p->unk_1--;
}
#pragma opt_common_subs reset
