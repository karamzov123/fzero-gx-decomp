#include "types.h"
#include "rel/sel/globals.h"
#include "rel/sel/sel.h"
extern u32 lbl_10_bss_51788[25];
extern f32 lbl_10_bss_55B3C[];
extern u8 lbl_10_rodata_1548[0x8];
extern const f32 lbl_10_rodata_158[19];
extern u8 lbl_10_rodata_1D64[0x4];
extern u8 lbl_10_rodata_1D68[0x8];
extern u8 lbl_10_rodata_94[0xc4];
extern u32 lbl_1_bss_6D82C;
extern u32 lbl_1_bss_6EAB4;
extern u32 * lbl_1_bss_6EAD0;
extern int lbl_1_bss_7180C;
extern u32 lbl_1_bss_718E0;
extern s16 lbl_1_bss_8B3A0;
extern s16 lbl_1_bss_8CA26;
extern s16 lbl_1_bss_960;
extern s16 lbl_1_bss_962;
extern s16 lbl_1_bss_966;
extern s16 lbl_1_bss_96A;
extern s32 lbl_1_bss_980[4];
extern s8 lbl_1_bss_9C;
extern u8 lbl_1_bss_9C8[];
extern u8 lbl_1_bss_9F8[];
extern const char * lbl_1_data_2AA24[];
extern const char * lbl_1_data_2BD54[][6];
extern char * lbl_1_data_418D4[];
extern char lbl_1_rodata_26F8;
extern const u8 lbl_1_rodata_D5B8[];
extern const u32 lbl_1_rodata_D870[];
extern u32 lbl_801A6410;
extern u32 lbl_801A66A0;
extern u32 lbl_801A66A8;
extern s32 lbl_801A66B4;
extern u16 lbl_801A66C0;
extern void fn_800713E0(u32, u32);
extern void fn_1_8019C(u32);
extern void fn_1_12B3F8(void *, u32, u32, void *, void *, void *);
extern void fn_1_12C6BC(u32);
extern void fn_10_1B658(void);
extern void fn_1_8F494(void *value);
extern void fn_10_1B65C(void);
extern void fn_10_1B6A8(void);
extern void OSReport(const char *, ...);
extern void fn_1_12F358(s16);
extern s32 fn_1_1310E0(void);
extern void fn_1_131084(u32, s32);
extern void fn_10_1B660(void);
extern void fn_1_7B558(u32, u32, u32, u32, u32, u32, f32);
extern void fzgx_pool_sink_f32(f32);
extern void fzgx_pool_sink_f64(f64);
extern void fn_80074188(s16, s16, s16, s16);

#include "sofdec/sj.h"
#include "font.h"

/* begin sofdec/adxt.h (deltawave784/fzgx, CC0) */
#ifndef SOFDEC_ADXT_H
#define SOFDEC_ADXT_H

/* CRI ADX talker (ADXT) handle, shared by the ADXT_* / adxt_* units of the DOL. */

/* begin layout_check.h (deltawave784/fzgx, CC0) */
#ifndef LAYOUT_CHECK_H
#define LAYOUT_CHECK_H

/* Compile-time layout checks for owned types. They declare array typedefs
 * only, so they emit no code or data under MWCC: a wrong size or offset is
 * a negative array bound and fails the compile. */
#define LAYOUT_CHECK_JOIN2(a, b) a##b
#define LAYOUT_CHECK_JOIN(a, b) LAYOUT_CHECK_JOIN2(a, b)
#define CHECK_SIZE(T, size) \
    typedef char LAYOUT_CHECK_JOIN(layout_size_, T)[(sizeof(T) == (size)) ? 1 : -1]
#define CHECK_OFFSET(T, field, offset) \
    typedef char LAYOUT_CHECK_JOIN(LAYOUT_CHECK_JOIN(layout_offset_, T), __LINE__) \
        [((unsigned long)&((T *)0)->field == (offset)) ? 1 : -1]

#endif

/* end layout_check.h */

typedef struct fn_10_E600_AdxSjdHandle fn_10_E600_AdxSjdHandle;

typedef struct fn_10_E600_ADXStream fn_10_E600_ADXStream;

typedef struct fn_10_E600_AXRNAHandle fn_10_E600_AXRNAHandle;

typedef struct fn_10_E600_LSCObject fn_10_E600_LSCObject;

typedef struct fn_10_E600_ADX_AMP fn_10_E600_ADX_AMP;

typedef struct fn_10_E600_ADXTHandle {
    s8 used;
    s8 status;
    s8 stream_type;
    s8 maximum_channels;
    fn_10_E600_AdxSjdHandle *decoder;
    fn_10_E600_ADXStream *stream;
    fn_10_E600_AXRNAHandle *rna;
    SJ *stream_sj;
    SJ *input_sj;
    SJ *output_sj[2];
    u8 *input_buffer;
    s32 input_buffer_size;
    s32 input_extra_size;
    u8 *output_buffer;
    s32 output_buffer_size;
    s32 output_buffer_distance;
    s32 server_frequency;
    s16 stream_buffer_sectors;
    s16 minimum_buffer_sectors;
    s16 output_volume;
    s16 output_pan[2];
    s16 field_46;
    s32 maximum_decode_samples;
    s32 loop_count;
    s32 link_data_length;
    s32 field_54;
    s32 field_58;
    s32 field_5C;
    s16 error_code;
    u8 reserved_62[2];
    s32 field_64;
    s16 field_68;
    s16 field_6A;
    s8 stream_loop_enabled;
    s8 auto_receiver;
    u8 reserved_6E[2];
    s8 suppress_playback;
    s8 decoder_ready;
    s8 paused;
    u8 reserved_73;
    fn_10_E600_ADX_AMP *amplifier;
    SJ *amplifier_input[2];
    SJ *amplifier_output[2];
    s32 time_offset;
    s32 eos_sector;
    s32 loop_sample_count;
    fn_10_E600_LSCObject *linked_stream_controller;
    s8 link_enabled;
    u8 reserved_99[3];
    u32 playback_time;
    s32 playback_start_vsync;
    s32 linked_decoded_samples;
    s8 pending_stream_start;
    u8 reserved_A9[3];
    u8 *work_end;
    const char *pending_filename;
    void *pending_directory;
    s32 pending_file_offset;
    s32 pending_file_sectors;
} fn_10_E600_ADXTHandle;

CHECK_OFFSET(fn_10_E600_ADXTHandle, decoder, 0x4);
CHECK_OFFSET(fn_10_E600_ADXTHandle, output_volume, 0x40);
CHECK_OFFSET(fn_10_E600_ADXTHandle, error_code, 0x60);
CHECK_OFFSET(fn_10_E600_ADXTHandle, stream_loop_enabled, 0x6C);
CHECK_OFFSET(fn_10_E600_ADXTHandle, amplifier, 0x74);
CHECK_OFFSET(fn_10_E600_ADXTHandle, linked_stream_controller, 0x94);
CHECK_OFFSET(fn_10_E600_ADXTHandle, playback_time, 0x9C);
CHECK_OFFSET(fn_10_E600_ADXTHandle, pending_file_sectors, 0xBC);
CHECK_SIZE(fn_10_E600_ADXTHandle, 0xC0);

#endif

/* end sofdec/adxt.h */


#pragma section code_type ".fzgxpool"
static const u32 fzgx_pool_table1[17] = {0x00000000, 0x0000B500, 0x0000B600, 0x0000AD00, 0x0000B300, 0x0000B800, 0x0000B200, 0x0000B100, 0x0000AE00, 0x0000B400, 0x0000B900, 0x0000B000, 0x0000AF00, 0x0000B700, 0x00000000, 0x00000000, 0x00F0F0FF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep1(void) { const u32 *volatile cp; cp = fzgx_pool_table1; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime2(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.0f;
    s = 0.5f;
    s = 0.0f;
    s = 0.20000000298023224f;
    s = 0.4000000059604645f;
    s = 320.0f;
    s = 3.0f;
    s = 323.0f;
    s = 4.0f;
    s = 5.0f;
    s = 6.0f;
    s = 0.25f;
    s = 16384.0f;
    s = 65536.0f;
    s = 60.0f;
    s = 1.875f;
    s = 0.5555555820465088f;
    d = 4503601774854144.0;
    d = 4503599627370496.0;
}
static const u32 fzgx_pool_table3[24] = {0x00110012, 0x00130014, 0x00150012, 0x00130014, 0x00000000, 0x00F0F0FF, 0x00000000, 0x00F0F0FF, 0x00010002, 0x00030004, 0x00050006, 0x00070008, 0x0009000A, 0x000B000C, 0x00110012, 0x00130014, 0x00150012, 0x00130014, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0xFFFFFF00, 0x00FF0000, 0x00FF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep3(void) { const u32 *volatile cp; cp = fzgx_pool_table3; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime4(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 59.0f;
    s = 82.0f;
    s = 77.0f;
    s = 98.0f;
    s = 25.0f;
    s = 115.0f;
    s = 0.699999988079071f;
    s = 9.0f;
    s = 0.6666666865348816f;
    s = 431.0f;
}
static const u32 fzgx_pool_table5[2] = {0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep5(void) { const u32 *volatile cp; cp = fzgx_pool_table5; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime6(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 61.0f;
    s = 81.0f;
    s = 110.0f;
    s = 40.0f;
    s = 80.0f;
    s = 210.0f;
    s = 230.0f;
    s = 367.0f;
    s = 55.0f;
    s = 76.0f;
    s = 100.0f;
    s = 365.0f;
    s = 75.0f;
    s = 117.0f;
    s = 0.4583333432674408f;
    s = 165.0f;
    s = 155.0f;
    s = 87.0f;
    s = 184.0f;
    s = 90.0f;
    s = 381.0f;
    s = 475.0f;
    s = 174.0f;
    s = 423.0f;
    s = 194.0f;
    s = 8192.0f;
    s = 20.0f;
    s = -8192.0f;
    s = 362.0f;
    s = 524.0f;
    s = 72.0f;
    s = 11.0f;
    s = 0.8999999761581421f;
    s = 0.5416666865348816f;
    s = -4.0f;
    s = 334.0f;
    s = 341.0f;
    s = -6.0f;
    s = 0.625f;
    s = 346.0f;
}
#pragma section code_type ".text"

typedef struct fn_10_E600_SelState {
    u8 pad_00[0x94];
    u32 flags;
    u32 bits;
    u8 pad_9c[8];
    u8 *items;
    u8 pad_a8[0x38];
    u32 selections[4];
} fn_10_E600_SelState;

typedef struct fn_10_E600_PanelPacket {
    u32 id;
    f32 x, y, z;
    u8 pad_10[0x1c];
    f32 alpha;
    u32 mode;
    u32 unknown_34;
    u8 color[4];
    u8 pad_3c[0x1c];
} fn_10_E600_PanelPacket;










extern u32 lbl_801A66A8;
extern u32 lbl_10_bss_55688;
extern s32 lbl_10_bss_55684;
extern void fn_1_13D02C(void);
extern void fn_10_10C24(void);
extern const char *fn_10_21C20(s32, s16);
extern void fn_1_1380F0(void);
extern void fn_1_134AD4(void);
extern void fn_1_133DBC(s32);
extern void fn_1_13B328(u32,s32);
extern f32 lbl_8006D188(s32);
extern void fn_1_50164(f32,f32,f32,f32,void *);
extern void fn_1_50A90(void *,u32,u32,u32,u32);
extern void fn_1_495C8(s32);
extern void fn_1_4954C(f32);
extern void fn_1_4955C(f32,f32);
extern void fn_1_496FC(f32,f32);

extern void fn_1_49410(void);
extern void fn_1_495FC(void);
extern void fn_1_4966C(f32,f32);
extern void fn_1_4A0D8(const char *);
extern void fn_10_F050(s32,s32);

#define P(o) ((o)==0x44 ? 1.0f : (o)==0x48 ? 0.5f : (o)==0x4c ? 0.0f : (o)==0x58 ? 320.0f : (o)==0x74 ? 16384.0f : (o)==0x78 ? 65536.0f : (o)==0x7c ? 60.0f : (o)==0x128 ? 61.0f : (o)==0x12c ? 81.0f : (o)==0x130 ? 110.0f : (o)==0x134 ? 40.0f : (o)==0x138 ? 80.0f : (o)==0x13c ? 210.0f : (o)==0x140 ? 230.0f : (o)==0x144 ? 367.0f : (o)==0x148 ? 55.0f : (o)==0x14c ? 76.0f : (o)==0x150 ? 100.0f : (o)==0x154 ? 365.0f : (o)==0x158 ? 75.0f : (o)==0x15c ? 117.0f : (o)==0x160 ? 0.4583333432674408f : (o)==0x164 ? 165.0f : (o)==0x168 ? 155.0f : (o)==0x16c ? 87.0f : (o)==0x170 ? 184.0f : (o)==0x174 ? 90.0f : (o)==0x178 ? 381.0f : (o)==0x17c ? 475.0f : (o)==0x180 ? 174.0f : (o)==0x184 ? 423.0f : (o)==0x188 ? 194.0f : (o)==0x18c ? 8192.0f : (o)==0x190 ? 20.0f : (o)==0x194 ? -8192.0f : (o)==0x198 ? 362.0f : (o)==0x19c ? 524.0f : (o)==0x1a0 ? 72.0f : (o)==0x1a4 ? 11.0f : (o)==0x1a8 ? 0.9f : (o)==0x1ac ? 0.5416666865348816f : (o)==0x1b0 ? -4.0f : (o)==0x1b4 ? 334.0f : (o)==0x1b8 ? 341.0f : (o)==0x1bc ? -6.0f : (o)==0x1c0 ? 0.625f : (o)==0x1c4 ? 346.0f : 0.0f)
#define WAVE() lbl_8006D188((s32)(P(0x74) + (f32)(P(0x78) * (f32)(lbl_801A66A8 % 60)) / P(0x7c)))
#define DRAW() fn_1_4F734((FontDrawPacket *)&packet)
#define COLOR(i,o) packet.color[i] = (u8)(P(o) + (f32)(P(o) * WAVE()))


void fn_10_E600(void) {
    f32 *pool;
    u8 *item;
    s32 selected;
    s16 kind;
    fn_10_E600_PanelPacket packet;
    s16 index;
    u32 previous;
    u32 current;
    s32 countdown;
    s32 angle;
    f32 wave;
    pool = (*(f32 (*)[19])&lbl_10_rodata_158);
    selected = 0;
    item = (*(fn_10_E600_SelState *)&lbl_1_bss_8B3A0).items + (s16)(lbl_1_bss_962 - 14) * 0x94;
    kind = *(s16 *)(item + *(s16 *)(item + 0x14) * 4);
    if (kind == 9) selected = 1;
    else if (kind == 10) selected = 0;
    fn_1_13D02C();
    fn_10_10C24();
    fn_10_21C20(4, (s16)lbl_801A66B4);
    fn_1_1380F0();
    fn_1_134AD4();
    fn_1_133DBC(1);
    fn_1_13B328(0x40800000,1);
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f42;
    packet.x = P(0x128);
    packet.y = P(0x12c);
    packet.z = P(0x130);
    packet.alpha = P(0x48);
    if (!selected) packet.color[0] = packet.color[1] = packet.color[2] = 0;
    else {
        COLOR(0,0x134);
        COLOR(1,0x138);
        COLOR(2,0x138);
    }
    fn_1_50164(P(0x13c),P(0x140),P(0x44),P(0x44),&packet);
    DRAW();
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f42;
    packet.x = P(0x144);
    packet.y = P(0x12c);
    packet.z = P(0x130);
    packet.alpha = P(0x48);
    if (selected) packet.color[0] = packet.color[1] = packet.color[2] = 0;
    else {
        COLOR(0,0x134);
        COLOR(1,0x138);
        COLOR(2,0x138);
    }
    fn_1_50164(P(0x13c),P(0x140),P(0x44),P(0x44),&packet);
    DRAW();
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f26;
    packet.x = P(0x148);
    packet.y = P(0x14c);
    packet.z = P(0x150);
    packet.mode = 5;
    fn_1_50A90(&packet,30,30,220,240);
    packet.x = P(0x154);
    packet.mode = 5;
    fn_1_50A90(&packet,30,30,220,240);
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f1e;
    packet.x = P(0x158);
    packet.y = P(0x15c);
    packet.z = P(0x150);
    packet.mode = 5;
    DRAW();
    fn_1_495C8(1);
    fn_1_4954C(P(0x44));
    fn_1_4955C(P(0x160),P(0x160));
    fn_1_496FC(P(0x164),P(0x168));
    fn_1_4AE0C(fn_10_21C20(16,(s16)lbl_801A66B4));
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f0c;
    packet.x = P(0x16c);
    packet.y = P(0x170);
    packet.z = P(0x174);
    packet.mode = 5;
    DRAW();
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 0x9f1f;
    packet.x = P(0x178);
    packet.y = P(0x150);
    packet.z = P(0x174);
    packet.mode = 5;
    DRAW();
    fn_1_495C8(1);
    fn_1_4954C(P(0x44));
    fn_1_4955C(P(0x160),P(0x160));
    fn_1_496FC(P(0x17c),P(0x180));
    fn_1_4AE0C(fn_10_21C20(17,(s16)lbl_801A66B4));
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.x = P(0x184);
    packet.y = P(0x188);
    packet.z = P(0x174);
    packet.id = 0x9f0d;
    packet.mode = 5;
    DRAW();
    if (lbl_10_bss_55688 != (current = (*(fn_10_E600_SelState *)&lbl_1_bss_8B3A0).selections[(s16)*((u8 *)&(*(fn_10_E600_SelState *)&lbl_1_bss_8B3A0) + 0x9e)])) {
        lbl_10_bss_55688 = current;
        lbl_10_bss_55684 = 10;
    }
    countdown = lbl_10_bss_55684 - 1;
    countdown = countdown < 0 ? 0 : countdown > 10 ? 10 : (u32)lbl_10_bss_55684 - 1;
    lbl_10_bss_55684 = countdown;
    if (selected) {
        angle = (s32)(P(0x18c) * lbl_8006D188((s32)((f32)(P(0x78) * (f32)(countdown % 20)) / P(0x190))));
    } else {
        angle = (s32)(P(0x194) * lbl_8006D188((s32)((f32)(P(0x78) * (f32)(countdown % 20)) / P(0x190))));
    }
    fn_10_F050(0,angle);
    packet = (*(const fn_10_E600_PanelPacket *)&lbl_1_rodata_26F8);
    packet.id = 12;
    packet.x = P(0x58);
    packet.y = P(0x198);
    packet.z = P(0x174);
    packet.mode = 10;
    fn_1_50164(P(0x19c),P(0x1a0),P(0x1a4),P(0x1a4),&packet);
    fn_1_49410();
    fn_1_495C8(1);
    fn_1_4954C(P(0x44));
    fn_1_495FC();
    fn_1_4966C(P(0x4c),P(0x1a8));
    fn_1_4955C(P(0x1ac),P(0x1ac));
    if (selected) {
        if (lbl_801A66B4 == 0) {
            fn_1_4966C(P(0x1b0),P(0x1a8));
            fn_1_496FC(P(0x58),P(0x1b4));
        } else {
            fn_1_4966C(P(0x4c),P(0x1a8));
            fn_1_496FC(P(0x58),P(0x1b8));
        }
        fn_1_4A0D8(fn_10_21C20(19,(s16)lbl_801A66B4));
    } else {
        if (lbl_801A66B4 == 0) fn_1_4966C(P(0x1bc),P(0x1a8));
        else fn_1_4966C(P(0x4c),P(0x1a8));
        fn_1_4955C(P(0x1c0),P(0x1c0));
        fn_1_496FC(P(0x58),P(0x1c4));
        fn_1_4A0D8(fn_10_21C20(20,(s16)lbl_801A66B4));
    }
}
