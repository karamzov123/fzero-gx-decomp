#include "dolphin/types.h"

extern u8 fn_1_3F114(void);
extern const f64 lbl_1_rodata_6B68;
extern const f32 lbl_1_rodata_6BD0;
extern const f64 lbl_1_rodata_6C88;
extern const f32 lbl_1_rodata_6CB8;
extern const f32 lbl_1_rodata_6B60;
extern const f32 lbl_1_rodata_6D34;
extern const f32 lbl_1_rodata_6D10;

typedef struct {
    u8 b0;
    s8 b1;
    u8 pad2[4];
    u16 h6;
    u8 pad8[8];
} GhostKey;

/* File-scope objects in retail order. */
u8 lbl_1_bss_7B180[0x8];
u8 fzgx_pool_lbl_1_bss_7B188[0x24];
u8 lbl_1_bss_7B1AC[0x13D8];
void *lbl_1_bss_7C584[127];
f32 *lbl_1_bss_7C584__fzgx_offset_1FC[5];
u8 lbl_1_bss_7C584__fzgx_offset_210[0x78];
s8 *lbl_1_bss_7C584__fzgx_offset_288[5];
u16 *lbl_1_bss_7C584__fzgx_offset_29C[5];
u8 fzgx_pool_lbl_1_bss_7C584__fzgx_offset_2B0[0x30];
GhostKey *lbl_1_bss_7C85C__fzgx_offset_8;
u8 fzgx_pool_lbl_1_bss_7C85C__fzgx_offset_C[0x118];
u16 lbl_1_bss_7C94C__fzgx_offset_34[16];
u32 lbl_1_bss_7C94C__fzgx_offset_54;
u32 lbl_1_bss_7C94C__fzgx_offset_58[5];
u8 fzgx_pool_lbl_1_bss_7C94C__fzgx_offset_6C[0x2060];
u32 lbl_1_bss_7EA00__fzgx_offset_18;
f32 lbl_1_bss_7EA00__fzgx_offset_1C;
f32 lbl_1_bss_7EA00__fzgx_offset_20;
s8 lbl_1_bss_7EA00__fzgx_offset_24;

#pragma section code_type ".fzgxpool"
static void fzgx_bss_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits .bss objects in first-access order */
    s = *(u8 *)&lbl_1_bss_7B180;
    s = *(u8 *)&fzgx_pool_lbl_1_bss_7B188;
    s = *(u8 *)&lbl_1_bss_7B1AC;
    s = *(u8 *)&lbl_1_bss_7C584;
    s = *(u8 *)&lbl_1_bss_7C584__fzgx_offset_1FC;
    s = *(u8 *)&lbl_1_bss_7C584__fzgx_offset_210;
    s = *(u8 *)&lbl_1_bss_7C584__fzgx_offset_288;
    s = *(u8 *)&lbl_1_bss_7C584__fzgx_offset_29C;
    s = *(u8 *)&fzgx_pool_lbl_1_bss_7C584__fzgx_offset_2B0;
    s = *(u8 *)&lbl_1_bss_7C85C__fzgx_offset_8;
    s = *(u8 *)&fzgx_pool_lbl_1_bss_7C85C__fzgx_offset_C;
    s = *(u8 *)&lbl_1_bss_7C94C__fzgx_offset_34;
    s = *(u8 *)&lbl_1_bss_7C94C__fzgx_offset_54;
    s = *(u8 *)&lbl_1_bss_7C94C__fzgx_offset_58;
    s = *(u8 *)&fzgx_pool_lbl_1_bss_7C94C__fzgx_offset_6C;
    s = *(u8 *)&lbl_1_bss_7EA00__fzgx_offset_18;
    s = *(u8 *)&lbl_1_bss_7EA00__fzgx_offset_1C;
    s = *(u8 *)&lbl_1_bss_7EA00__fzgx_offset_20;
    s = *(u8 *)&lbl_1_bss_7EA00__fzgx_offset_24;
}
#pragma section code_type ".text"



s32 fn_1_F0E00(s32 idx, s32 *out) {
    u32 cur;
    u32 target;
    s32 i;
    f32 *tbl;
    u16 v;

    if (lbl_1_bss_7EA00__fzgx_offset_18 == 0) {
        *out = 0;
        return 0;
    }
    v = lbl_1_bss_7C94C__fzgx_offset_34[idx];
#define tbl lbl_1_bss_7C584__fzgx_offset_1FC[idx]
    if ((f32)v >= tbl[lbl_1_bss_7C94C__fzgx_offset_58[idx] - 1]) {
        cur = fn_1_3F114() * 0xFFFF;
    } else {
        f32 t0;
        u32 a;
        u32 b;
        u32 lo;
        u32 hi;
        u16 *vals;
        s8 *hiw;
        s32 k;
        f32 r;

        for (i = 0; (f32)v > tbl[i]; i++) {
        }
        a = v;
        i--;
        vals = lbl_1_bss_7C584__fzgx_offset_29C[idx];
        t0 = tbl[i];
        lo = vals[i];
        hi = vals[i + 1];
        a = (f32)a - t0;
        hiw = lbl_1_bss_7C584__fzgx_offset_288[idx];
        lo += hiw[i] * 0xFFFF;
        hi += hiw[i + 1] * 0xFFFF;
        b = tbl[i + 1] - t0;
        r = (f32)a / (f32)b;
        cur = (f32)((f32)lo * (lbl_1_rodata_6BD0 - r)) + (f32)((f32)hi * r);
    }
    target = lbl_1_rodata_6CB8 * (lbl_1_bss_7EA00__fzgx_offset_20 + (f32)lbl_1_bss_7EA00__fzgx_offset_24);
    if (target > cur) {
        GhostKey *keys = lbl_1_bss_7C85C__fzgx_offset_8;
        u32 n = lbl_1_bss_7C94C__fzgx_offset_54;
        f32 sum = lbl_1_rodata_6B60;
        f32 key;
        s32 lo;

        do {
            n--;
            key = (f32)keys[n].h6;
            key += (f32)(keys[n].b1 * 0xFFFF);
            sum += (f32)keys[n].b0;
        } while ((f32)cur < key);
        lo = keys[n].h6 + keys[n].b1 * 0xFFFF;
        sum -= (f32)(u32)(cur - lo) /
               (f32)(u32)(keys[n + 1].h6 + keys[n + 1].b1 * 0xFFFF - lo);
        *out = lbl_1_rodata_6D34 * -sum / lbl_1_rodata_6D10;
    } else {
        s8 *h;
        u16 *p;
        s8 *hiw = lbl_1_bss_7C584__fzgx_offset_288[idx];
        u16 *vals = lbl_1_bss_7C584__fzgx_offset_29C[idx];
        s32 j;
        s32 lo;
        u32 a;
        u32 b;
        f32 key;
        f32 r;
        f32 *t;

        h = hiw;
        p = vals;
        j = 0;
        do {
            key = (s32)(*p + *h * 0xFFFF);
            h++;
            p++;
            j++;
        } while ((f32)target > key);
        j -= 2;
        a = target;
        lo = vals[j] + hiw[j] * 0xFFFF;
        a -= lo;
        b = vals[j + 1] + hiw[j + 1] * 0xFFFF - lo;
        r = (f32)a / (f32)b;
        t = lbl_1_bss_7C584__fzgx_offset_1FC[idx];
        r = t[j] + (f32)(r * (t[j + 1] - t[j]));
        r = (f32)lbl_1_bss_7C94C__fzgx_offset_34[idx] - r;
        *out = lbl_1_rodata_6D34 * r / lbl_1_rodata_6D10;
    }
    return 1;
}
