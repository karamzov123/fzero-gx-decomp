#include "types.h"
#include "dolphin/types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/driver.h"
#include "rel/main_rel/prog.h"
#include "psvec.h"
#include "rel/main_rel/car.h"
#include "dolphin/hw_regs.h"








struct fn_1_A7F84_lbl_801A6D00 {
    u32 unk_0;
};

struct fn_1_A7F84_lbl_1_rodata_4A28 {
    f32 unk_0;
};

typedef struct FnA8528Config {
    u8 pad_0c[0x0c];
    f32 unk_0c;
    u8 pad_10[0x0c];
    f32 unk_1c;
    u8 pad_20[0x0c];
    f32 unk_2c;
} FnA8528Config;

struct fn_1_A9868_lbl_1_rodata_4AA0 {
    u32 unk_0;
    u32 unk_4;
    u32 unk_8;
    u32 unk_C;
    u32 unk_10;
    u32 unk_14;
    u32 unk_18;
    u32 unk_1C;
    u32 unk_20;
    f32 unk_24;
    f32 unk_28;
    f32 unk_2C;
    f32 unk_30;
};

struct FzgxCopy_88 { u32 words[22]; };

typedef struct FnA861CVehicle {
    u8 pad_0[8];
    f32 unk_8;
    u8 pad_c[0xa4 - 0xc];
    f32 unk_a4;
    u8 pad_a8[0xb0 - 0xa8];
    f32 unk_b0;
    u8 pad_b4[0xb8 - 0xb4];
    f32 unk_b8;
    u8 pad_bc[0xc0 - 0xbc];
    f32 unk_c0;
} FnA861CVehicle;

typedef struct Sig_fn_1_41488_Fn41488Data {
    u32 count;
    char *strings;
} Sig_fn_1_41488_Fn41488Data;

struct Sig_fn_800737E4_fn_800737E4_Arg0 {
    f32 unk_0;
    u8 pad_4[0x4];
    f32 unk_8;
    f32 unk_C;
    u8 pad_10[0x4];
    f32 unk_14;
    f32 unk_18;
    f32 unk_1C;
    u8 pad_20[0x8];
    f32 unk_28;
    f32 unk_2C;
};

typedef struct {
    u8 kind;
    u8 callback;
    u8 flags;
    u8 pad3;
    s16 x;
    s16 y;
    s16 z;
    s16 padA;
    void *data;
} Fn1A9250Entry;

typedef struct {
    u8 pad_0[0x8];
    u32 unk_8;
} DriverAsset;

typedef struct FnA8834Camera {
    u8 pad_0[0x90];
    u8 unk_90[0x48];
    f32 unk_d8;
    f32 unk_dc;
    u8 pad_e0[4];
    f32 unk_e4;
    u8 pad_e8[0x18c - 0xe8];
    u8 unk_18c[4];
} FnA8834Camera;

struct Sig_fn_80077B64_fn_80077B64_Arg0 {
    u8 pad_0[0x4];
    u32 unk_4;
};

typedef struct FnA8834Vehicle {
    u8 pad_0[8];
    f32 unk_8;
    u8 pad_c[0xa4 - 0xc];
    f32 unk_a4;
    u8 pad_a8[0xb0 - 0xa8];
    f32 unk_b0;
    u8 pad_b4[0xc0 - 0xb4];
    f32 unk_c0;
    u8 pad_c4[0x1fc - 0xc4];
    f32 unk_1fc;
} FnA8834Vehicle;

struct fn_1_A9868_lbl_801A6D00 {
    u32 unk_0;
};

struct Sig_fn_80077B14_fn_80077B14_Arg0 {
    u8 pad_0[0x4];
    u32 unk_4;
    u8 pad_8[0x18];
    u32 unk_20;
};

typedef struct {
    signed char gpr;
    signed char fpr;
    unsigned short reserved;
    char *input_arg_area;
    char *reg_save_area;
} Sig_parse_format_MkVaListState;

typedef struct Sig_fn_80015EE8_Fn80015EE8Out {
    f32 f0;
    f32 f1;
    f32 f2;
    f32 f3;
    f32 f4;
    f32 f5;
    f32 f6;
    f32 f7;
    f32 f8;
    f32 f9;
    f32 f10;
    f32 f11;
    f32 f12;
    f32 f13;
    f32 f14;
    f32 f15;
} Sig_fn_80015EE8_Fn80015EE8Out;

typedef struct FnA861CCamera {
    u8 pad_0[0xdc];
    f32 yaw;      /* 0xdc */
    f32 roll;     /* 0xe0 */
    f32 pitch;    /* 0xe4 */
    u8 unk_e8;
    u8 unk_e9;
    u8 pad_ea[0x15c - 0xea];
    u8 unk_15c[4];
} FnA861CCamera;

typedef union {
    u8 u8;
    f32 f32;
} PPCWGPipe;

typedef struct {
    u8 r;
    u8 g;
    u8 b;
    u8 a;
} GXColor;

typedef struct FnA7E60Object {
    u8 pad_fc[0xfc];
    s32 unk_fc;
    s32 unk_100;
    s32 unk_104;
    void *unk_108;
} FnA7E60Object;

typedef struct Resource {
    u8 pad_0[8];
    void *unk_8;
} Resource;

typedef struct {
    u8 pad_0[0x8];
    void *unk_8;
    u8 pad_C[0x4];
    u32 unk_10;
} Fn1A75dcResult;

struct fn_1_A8270_Entry {
	u32 unk_0;
	u32 unk_4;
	u32 unk_8;
	u8 pad_C[0x18];
};

struct fn_1_A8270_Arg0 {
	u8 pad_0[0xE8];
	u8 unk_E8;
	u8 unk_E9;
	s16 unk_EA;
	s16 unk_EC;
	s16 unk_EE;
	void *unk_F0;
	u8 pad_F4[8];
	struct fn_1_A8270_Entry *unk_FC;
	s32 unk_100;
	u32 unk_104;
	u8 pad_108[0x24];
	u32 *unk_12C[12];
};

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} fn_1_A7E60_Vec3;

typedef struct {
    u32 w[45];
} Unk_23800000;

typedef struct {
    u8 pad_00[0x1C];
    u16 unk_1C;
} Sig_fn_1_55628_Fn1_55628Object;

struct fn_1_A8270_Rec {
	u8 pad_0[4];
	u32 unk_4;
	u8 pad_8[0x16];
	u8 count;
};

typedef struct fn_1_8D210_car {
    f32 position[6];
    f32 scale_z;
    f32 scale_y;
    f32 scale_x;
    f32 field_24;
    u16 field_28;
    u16 field_2a;
    u16 field_2c;
    u16 field_2e;
    u16 field_30;
    u16 field_32;
    u32 field_34;
    u8 field_38;
    u8 field_39;
    u8 field_3a;
    u8 pad_3b;
    u32 field_3c;
    u8 field_40;
    u8 pad_41[3];
    f32 field_44;
    f32 field_48;
    f32 field_4c;
    f32 field_50;
    s16 field_54;
    u8 pad_56[2];
    s32 field_58;
    u8 field_5c[4];
    u32 field_60;
} fn_1_8D210_car;

typedef s32 (*fn_1_8D210_callback)(u32);

typedef struct {
    u8 pad[0x15];
    u8 code;
} State;

typedef struct {
    u8 pad[4];
    State *state;
} fn_1_8E3A4_Object;

struct Sig_fn_800713E0_fn_800713E0_Entry {
    u8 pad_0[0x18];
    u16 count;
};

struct Sig_fn_800713E0_fn_800713E0_Arg0 {
    s32 count;
    u8 pad_4[0x4];
    struct Sig_fn_800713E0_fn_800713E0_Entry **entries;
};

typedef struct Fn195158Object Fn195158Object;

struct Fn195158Object {
    u8 unk_00[0x0C];
    f32 unk_0C;
    u8 unk_10[0x1C];
    f32 unk_2C;
    u8 unk_30[0x58];
    u8 unk_88[0x04];
};

typedef struct Fn195158Data Fn195158Data;

struct Fn195158Data {
    u8 unk_00[0x08];
    Fn195158Object *unk_08;
};

typedef struct Fn195158Car Fn195158Car;

struct Fn195158Car {
    u8 unk_00[0xA0];
    s16 unk_A0;
    s16 unk_A2;
    s16 unk_A4;
    u8 unk_A6[0x02];
    f32 unk_A8;
    f32 unk_AC;
    f32 unk_B0;
    f32 unk_B4;
    f32 unk_B8;
    u8 unk_BC[0x94];
    Fn195158Data *unk_150;
};

typedef struct {
    u8 pad0[0x12];
    u16 field_12;
    u8 pad14[0x12];
    u8 field_26;
    void *field_28;
    u8 pad2c[0x8];
    void *field_34;
    u8 pad38[0x14];
    u8 field_4c;
} EventNode;

typedef struct {
    u8 pad0[0x1c];
    void *field_1c;
} CarObject;

typedef f32 fzgx_Mtx[3][4];

typedef struct Fn1967A8Resource Fn1967A8Resource;

struct Fn1967A8Resource {
    u8 unk_00;
    u8 unk_01[0x07];
    u32 unk_08;
    u8 unk_0C[0x10];
    u32 unk_1C;
};

typedef struct Fn196968Object Fn196968Object;

struct Fn196968Object {
    u8 unk_00[0x28];
    u32 unk_28;
    u8 unk_2C[0x144];
    void *unk_170;
    void *unk_174;
};

typedef struct Fn1969E8Owner Fn1969E8Owner;

struct Fn1969E8Owner {
    u8 unk_00[0x2C];
    u32 unk_2c;
    u8 unk_30[0x180];
    u32 unk_1b0;
    void *unk_1b4;
};

typedef struct Fn196BC0Object Fn196BC0Object;

struct Fn196BC0Object {
    u8 unk_00[0x30];
    void *value_30;
    u8 unk_34[0x19C];
    void *resource_1D0;
    void *resource_1D4;
};

typedef struct Fn196A68Object Fn196A68Object;

struct Fn196A68Object {
    u8 unk_00[0x34];
    u32 unk_34;
    u8 unk_38[0x1B8];
    void *unk_1F0;
    void *unk_1F4;
};

typedef struct CarR29 {
    u8 unk_00[0x14];
    f32 unk_14;
} CarR29;

typedef struct Vec3f {
    f32 x, y, z;
} Vec3f;

typedef struct {
    u32 x;
    u32 y;
    u32 z;
} Triple;

typedef struct {
    u8 **unk_00;
    void *unk_04;
    u32 pad_08;
} Fn1_87448_Slot;

typedef struct {
    u8 pad_00[0x330];
    u32 unk_330;
    Fn1_87448_Slot unk_334[1];
} Fn1_87448_Obj;

typedef struct {
    u8 pad_00[2];
    s8 unk_02;
} Fn1_87448_Arg1;

typedef struct {
    u8 pad_0[0x4];
    s32 field_4;
    s32 field_8;
    s32 field_c;
    s32 field_10;
    s32 field_14;
} Fn1_8F45C_Object;

typedef struct {
    s32 active;
    s32 entries[5];
} Fn1_8F494_Object;

typedef struct {
    u8 pad_0[0x148];
    u8 pad_148[0x20];
    u8 pad_168[0x40];
    u8 pad_1a8[0x20];
    u8 pad_1c8[0x20];
    u8 pad_1e8[0x20];
    u8 entries[0x14][0x20];
} Fn1_8F5A4_Object;

typedef struct Fn935E4Slot {
    u8 pad0[0xa];
    u16 field_a;
} Fn935E4Slot;

typedef struct Fn935E4Node {
    u8 pad0[0xa];
    u16 field_a;
    u8 pad_c[6];
    u16 field_12;
    u8 pad14[0x12];
    u8 field_26;
    u8 pad27[1];
    Fn935E4Slot *field_28;
    u8 pad2c[8];
    Fn935E4Slot *field_34;
    u8 pad38[0x14];
    u8 field_4c;
} Fn935E4Node;

typedef struct Fn935E4Car {
    u8 pad0[0x1c];
    Fn935E4Node *field_1c;
} Fn935E4Car;

typedef struct A7B5C_Mtx {
u8 pad[0x30];
} A7B5C_Mtx;

typedef struct fn_1_A7B5C_Vec3 {
f32 x;
f32 y;
f32 z;
} fn_1_A7B5C_Vec3;

typedef struct A7B5C_Obj {
A7B5C_Mtx mtx[4];
f32 unk_c0;
f32 unk_c4;
f32 unk_c8;
f32 unk_cc;
f32 unk_d0;
f32 unk_d4;
f32 unk_d8;
f32 unk_dc;
f32 unk_e0;
f32 unk_e4;
s8 unk_e8;
u8 unk_e9;
u8 pad_ea[0x10c - 0xea];
f32 unk_10c;
f32 unk_110;
fn_1_A7B5C_Vec3 unk_114;
f32 unk_120;
f32 unk_124;
f32 unk_128;
A7B5C_Mtx parts[10];
} A7B5C_Obj;

typedef struct A7B5C_Src {
u8 pad[8];
u8 *data;
} A7B5C_Src;

typedef struct { f32 x, y, z; } fzgx_Vec;

typedef struct fn_1_A89B0_Obj {
    fzgx_Mtx mtx;           /* 0x000 */
    fzgx_Vec pos[2][4];     /* 0x030, 0x060 */
    u8 pad_90[0xC0 - 0x90];
    fzgx_Vec ofs[2];        /* 0x0C0, 0x0CC */
    u8 pad_d8[0x10C - 0xD8];
    f32 len1;               /* 0x10C */
    f32 len2;               /* 0x110 */
    u8 pad_114[0x12C - 0x114];
    fzgx_Mtx joints[7];     /* 0x12C */
} fn_1_A89B0_Obj;

typedef struct fn_1_A89B0_Arg1 {
    u8 pad_0[0x1FC];
    f32 unk_1FC;
} fn_1_A89B0_Arg1;

typedef struct {
    u8 pad_0[4];
    u8 unk_4;
    u8 unk_5;
    u8 pad_6[0x32];
} fn_1_A948C_Font;

typedef struct DriverDesc {
    u8 pad_0[0x40];
    u32 unk_40;
    s32 unk_44;
    u32 unk_48;
} DriverDesc;
extern s16 fn_1_12C930(s16 arg0);
extern s16 fn_1_12CCB0(s16 arg0, s16 arg1);
extern void *fn_1_14DD68(void *arg0);
extern u32 fn_1_4630();
extern void fn_1_A7E60(s8 arg0, s8 arg1, FnA7E60Object *object, s32 arg3, void *arg4);
extern void *lbl_801A6410;
extern void *fn_1_D3884();
extern void fn_80006E10(u32 arg0);
extern void sprintf(void *buffer, char *format, ...);
extern u32 fn_80077D40();
extern u32 fn_80071470(u32, u32);
extern void fn_80008BA8(u32 arg0, u32 arg1, u32 arg2);
extern void fn_80071718(void *value);
extern void fn_1_A8270(struct fn_1_A8270_Arg0 *self, s32 arg1);
extern void fn_1_A8528(void *, void *);
extern void fn_1_A7F84(void *arg0, u32 arg1);
extern void lbl_8006DD14(void *, void *);
extern void lbl_8006DB74(void *);
extern void lbl_8006DBAC(void *arg0);
extern void lbl_8006DD7C(void);
extern void lbl_8006DAEC(void);
extern void lbl_8006DFC4(void *pos);
extern void lbl_8006DB30(void);
extern void fn_1_801F8(s16 arg0, void *arg1);
extern s32 fn_1_46C70(void);
extern s32 fn_1_465D0(s32 arg0, s32 arg1);
extern char *fn_80083DB0(char *dst, const char *src);
extern Unk_23800000 lbl_23800000[];
extern u8* fn_1_36AD0(void);
extern void fn_1_14F6F8(u8 arg0, u8 arg1, u8 arg2, void *arg3);
extern void fn_1_56858(void *, int);
extern void fn_1_46B4(u32 arg0, u32 arg1, const char *arg2, int arg3);
extern void fn_1_12A734(s32 idx);
extern void fn_1_7F658(void *arg0);
extern void fn_1_591A0(s32 id);
extern void fn_1_8E1E8(void);
extern void fn_1_FDFF4(void);
extern void fn_800711A8(void *value);
extern void _savegpr_27(void);
extern void _restgpr_27(void);
extern void OSReport(const char *msg, ...);
extern f32 lbl_1_rodata_3508[];
extern int fn_1_20A5C(f32 *, f32 *);
extern void *fn_1_21644(void *arg0, f32 *arg1, void *arg2);
extern u8 * fn_1_14F04(void);
extern void fn_1_17920(s32 index, void *arg1, f32 t);
extern void lbl_8006D7F4(f32, f32, f32);
extern void lbl_8006E0A4(void *arg0);
extern void lbl_8006E0B4(f32, f32, f32);
extern void fn_1_892FC(void *arg0, int arg1, int arg2);
extern void fn_1_23500();
extern f32 lbl_1_rodata_3518[6];
extern f32 lbl_1_rodata_3530[22];
extern u32 lbl_8006DBE4(void);
extern u8 *fn_80083970(u8 *str, const u8 *needle);
extern void fn_1_55628(Sig_fn_1_55628_Fn1_55628Object *);
extern void fn_1_556B8(void *value);
extern void fn_1_55FF0(f32 value);
extern void fn_80072558(void);
extern u32 fn_800793D4(u8 *arg0, u32 arg1, u32 arg2);
extern void fn_1_8B9B8(void *);
extern s32 fn_1_8D210(fn_1_8D210_car *car, fn_1_8D210_callback callback, u32 arg, s32 enable);
extern s32 fn_1_F7BE4(s16 arg0);
extern u8 lbl_1_rodata_3D34[164];
extern s32 fn_1_45D0();
extern void fn_1_C487C(void);
extern void fn_1_43E8(u32 arg0);
extern void fn_1_C4ABC(void);
extern s32 fn_1_3F8C(u32 arg3, u32 arg0, u32 arg1, u32 index);
extern void fn_1_43F4(void);
extern void fn_1_8E3A4(fn_1_8E3A4_Object *obj);
extern u32 fn_80074A7C(u32 arg0);
extern void fn_800713E0(struct Sig_fn_800713E0_fn_800713E0_Arg0 *, u32);
extern void fn_1_A8DD4(const char *format, ...);
extern void fn_1_A8F40(u8 arg0);
extern s32 fn_1_41418(void *resource, u16 id);
extern void fn_1_95210(void *arg0);
extern void fn_1_95158(Fn195158Car *car);
extern s32 fn_1_97174(EventNode *arg0, s32 arg1, void *arg2);
extern void fn_1_93734(CarObject *car, void *name);
extern void fn_1_4270C(void *arg0, s32 arg1, u32 arg2);
extern const f32 lbl_1_rodata_3F6C;
extern FnA8528Config *lbl_801A6D00;
extern u32 mathutil_mtxA_rotate_y(u32);
extern void mathutil_mtxA_rotate_z(s32);
extern void lbl_8006D758(void);
extern void lbl_8006E14C(f32);
extern void mathutil_mtxA_rotate_x(u32);
extern void fn_1_12AB38(void *arg0);
extern s32 fn_1_12A8A4(u32 arg0, void *arg1);
extern u32 lbl_1_bss_6E98C;
extern void fn_1_96AE8(void *base, void *arg1);
extern Fn1967A8Resource *fn_1_41518(void *arg0);
extern void fn_1_41C18(Fn1967A8Resource *arg0, void *arg1);
extern u16 fn_1_96968(Fn196968Object *object, void *arg1);
extern u16 fn_1_969E8(Fn1969E8Owner *owner, void *arg1);
extern u16 fn_1_96BC0(Fn196BC0Object *object, void *arg1);
extern u16 fn_1_96A68(Fn196A68Object *object, void *arg1);
extern const f32 lbl_1_rodata_3E48[];
extern void *camera_get_state_object(void);
extern void camera_update_state(void *);
extern CarR29 *fn_80071268(void *, void *);
extern void lbl_8006E1F0(void *, f32, f32, f32);
extern void fn_1_A714C(f32 *a, f32 *b, f32 *c, f32 *d);
extern f32 lbl_8006D21C(s32);
extern void lbl_8006E2C0(Vec3f *, f32, f32, f32);
extern void fn_8006E250(Vec3f *, Vec3f *);
extern void fn_1_B81C(Vec3f *, Vec3f *, s32);
extern void fn_1_150464(u32 arg0);
extern void fn_1_810E4(u32 arg0);
extern u8 lbl_1_rodata_3590[984];
extern void *fn_1_12AC00(void *arg0);
extern void fn_1_80294(void *arg0, void *arg1, s32 arg2);
extern u32 lbl_1_rodata_3A94[7];
extern void lbl_8006DC6C(void *, u32, u32);
extern void lbl_8006E1B0(void *, void *);
extern void lbl_8006DFE8(void *);
extern f32 fn_1_A71AC(void);
extern u8 fn_1_5910(void);
extern void fn_1_681C(u32 index, u32 *output);
extern void fn_1_6914(u32 index, u32 *output);
extern f32 lbl_8006D534(fn_1_A7E60_Vec3 *a, fn_1_A7E60_Vec3 *b);
extern u32 lbl_1_rodata_3B20[3];
extern f32 lbl_1_rodata_3B2C[47];
extern Triple lbl_1_rodata_3BE8;
extern u32 fn_80007CDC(f32 *arg0);
extern u32 fn_80007D58(f32 *arg0);
extern void lbl_8006D784(void *);
extern u32 lbl_1_rodata_3BF4[14];
extern u32 lbl_1_bss_6D8F4[31];
extern u32 lbl_801A66A0;
extern u32 fn_1_56018(s32 value);
extern void fn_1_560F0(s32 index, void *arg);
extern void fn_1_55210(void *value);
extern f32 lbl_8006D188(s16);
extern void fn_1_87448(Fn1_87448_Obj *self, Fn1_87448_Arg1 *arg1, s8 arg2, int flag, f32 f);
extern void lbl_8006D7DC(void *value);
extern f32 lbl_1_rodata_3C2C[33];
extern u8 lbl_1_bss_8CA28;
extern void fn_80008BEC(void *dest, int value, u32 size);
extern u32 GXGetTexBufferSize(u16 width, u16 height, u32 arg2, u32 arg3, u32 arg4);
extern void fn_1_550A8(void);
extern void fn_1_545B8(void);
extern void fn_1_550E0(void);
extern void fn_80038F10(f32* out);
extern void GXGetScissor(u32 *left, u32 *top, u32 *width, u32 *height);
extern void GXGetProjectionv(f32* out);
extern void C_MTXPerspective(f32 *out, f32 a1, f32 a2, f32 a3, f32 a4);
extern void fn_800737E4(struct Sig_fn_800737E4_fn_800737E4_Arg0 *, s32, f32);
extern u32 fn_80038EEC(void);
extern s32 __cvt_fp2unsigned(f32);
extern u32 fn_80074188(u32 arg0, u32 arg1, u32 arg2, u32 arg3);
extern void fn_80074918(u8 arg0, s32 arg1, u8 arg2);
extern void fn_80008204(void *);
extern void fn_80074300(u16 arg0, u16 arg1, u16 arg2, u16 arg3, u32 lab_unused0);
extern void fn_80074438(u32 arg0, u32 arg1, u32 arg2, u32 arg3);
extern void fn_8003526C(u32, u8);
extern void GXInvalidateTexAll(void);
extern void fn_80072270(void *);
extern void fn_1_4FC50(u32, u32, u16, u16, u32);
extern u32 fn_80008E84(u32 arg0);
extern void fn_1_426C(u32 arg0);
extern void fn_1_8E7D0(Fn1_8F45C_Object *obj);
extern void fn_1_12A2B8(u32 value);
extern void fn_1_12A2D0(s32 value);
extern void fn_1_9724C(void);
extern void fn_1_107C4C(void *arg);
extern void fn_1_966A0(Fn1_8F494_Object *obj);
extern void fn_1_95EF0(void *arg0, s32 arg_sp0);
extern void fn_1_8F5A4(Fn1_8F5A4_Object *obj);
extern void fn_1_968FC(Fn1_8F5A4_Object *obj);
extern s32 fn_1_41488(void *arg0, void *arg1);
extern f32 lbl_1_rodata_4010[60];
extern void fn_1_943F8(Fn935E4Car *, f32, void *);
extern void fn_1_42AD0(void *, s32, u16, s32, u16);
extern void fn_1_41328(void *arg0);
extern void fn_1_426E4(void *arg0, void *arg1);
extern u32 lbl_1_bss_6D828;
extern u8 fn_1_3F854(void);
extern s32 fn_1_8171C(s32 value);
extern u8 lbl_1_rodata_3968[232];
extern void fn_800712E4(void *arg0, u32 arg1, void *arg2);
extern u32 lbl_1_bss_6D850;
extern u32 lbl_1_bss_6D97C;
extern u32 lbl_1_bss_6D978;
extern f32 fn_1_86A2C(void *);
extern void fn_1_85688(void);
extern void fn_1_854D4(void);
extern void fn_1_85934(f32 arg);
extern void fn_1_C489C(void *arg0);
extern void fn_1_C40A0(Obj_1_bss_6D838_Target *);
extern u8 lbl_1_bss_6DA5C[30];
extern void fn_1_8A1B4(void *arg0, void *arg1, int arg2);
extern void fn_1_8B8A4(void *arg);
extern u8 lbl_1_bss_6DA5C__fzgx_offset_1E;
extern u8 lbl_1_bss_6DA5C__fzgx_offset_1F[5];
extern s32 fn_8006FDEC(void);
extern void fn_8006FEFC(void);
extern u8 lbl_1_rodata_3DD8[84];
extern u32 lbl_1_bss_6D86C[34];
extern s32 fn_1_12ADA0(void *arg0, void *arg1);
extern void fn_1_961F0(void *obj);
extern u32 lbl_1_bss_6E978[3];
extern s32 lbl_1_bss_6E984;
extern u32 lbl_1_rodata_3FA0[28];
extern void fn_80007AB4(u8 *arg0);
extern void fn_1_92554(void *arg0, s32 arg1);
extern f32 lbl_1_rodata_3F70[12];
extern void fn_1_12A2C4(u32 value);
extern void fn_1_A7B5C(A7B5C_Obj *obj, A7B5C_Src *src, s8 kind, s8 type, fn_1_A7B5C_Vec3 *pos);
extern u32 lbl_1_bss_6D970;
extern u32 lbl_1_bss_6D974;
extern u32 fn_1_435C(u32 value);
extern void fn_1_850C4(void);
extern struct fn_1_A7F84_lbl_1_rodata_4A28 lbl_1_rodata_4A28;
extern u32 lbl_8006D91C(u32);
extern u32 lbl_8006D998(u32);
extern void _savegpr_23(void);
extern void _restgpr_23(void);
extern u32 fn_80077A18(void);
extern void lbl_8006D9D8(void *);
extern void fn_80077A20(struct fn_1_A8270_Rec *, void *);
extern void fn_1_55FC4(f32 value);
extern f32 lbl_1_rodata_4A34[25];
extern Fn1A9250Entry lbl_1_bss_70658[];
extern struct fn_1_A9868_lbl_1_rodata_4AA0 lbl_1_rodata_4AA0;
extern f32 C_MTXOrtho(Sig_fn_80015EE8_Fn80015EE8Out *, f32, f32, f32, f32, f32, f32);
extern void fn_1_A861C(FnA861CCamera *cam, FnA861CVehicle *veh);
extern void fn_1_A8834(FnA8834Camera *cam, FnA8834Vehicle *veh);
extern void fn_1_A9420(u8 value);
extern s32 fn_8008077C(u32 arg0, u32 arg1, u32 arg2);
extern int fn_1_A948C(const char *str);
extern void fn_1_49410(void);
extern void fn_1_494DC(s16 index);
extern void fn_1_520A0(void);
extern void fn_1_52088(void);
extern u32 lbl_1_bss_71658[6];
extern const f64 lbl_1_rodata_4A98;
extern void fn_1_49714(f32 value1, f32 value2, f32 value3);
extern void fn_1_49680(f32 value1, f32 value2);
extern void fn_1_A93C4(u32 arg0);
extern void fn_1_4A0D8(const u8 *s);
extern void fn_1_520CC(void);
extern void fn_1_49514(u32 *value);
extern u32 GXLoadPosMtxImm(u32, u32);
extern void fn_800720B0(s32 arg0);
extern void fn_80072EDC(s32 arg0, s32 arg1);
extern void GXSetCurrentMtx(u32 value);
extern void fn_8006F1F0(void *, void *, void *);
extern void fn_8007245C(u32 value);
extern void fn_8007264C(u32 arg0, s32 arg1, s32 arg2, s32 arg3, u8 arg4);
extern void fn_800734A8(u32 arg0, s32 arg1, s32 arg2, s32 arg3);
extern void fn_80073678(u32 arg0);
extern void fn_80073898(u32 arg0);
extern void fn_80073C6C(s32 index);
extern void fn_80074660(u32 arg0);
extern void fn_800746A8();
extern void fn_80074718(u8 value, s32 arg);
extern void fn_80074788(u32 arg0);
extern void fn_800747D0(u32 arg0, u32 arg1, s32 arg2, s32 arg3, u32 arg4, s32 arg5, s32 arg6);
extern void OSPanic(const char *file, int line, const char *msg, ...);
extern void fn_8006F6A8(void *arg0);
extern void fn_1_A89B0(fn_1_A89B0_Obj *obj, fn_1_A89B0_Arg1 *arg1, s32 side);
extern void fn_1_3920(void);
extern void fn_1_A8D4C(void);
extern void fn_1_A8D64(void);
extern u32 fn_8001A78C(u32 arg0);
extern u32 fn_8001A7D0(u32 arg0);
extern void fn_1_A943C(u32 arg0, u32 arg1);
extern void fn_1_A9464(u16 arg0, u16 arg1);
extern void fn_1_A942C(u8 value);
extern void fn_1_A96BC(void);
extern void fn_1_A5C98(void *);
extern u8 lbl_1_bss_716C8[320];
extern u32 fn_1_451C(void);
extern void fn_1_A5AA0(void *buffer, void *destination);
extern u32 lbl_1_bss_71670;
extern void fn_1_A7024(f32 arg0, f32 arg1, f32 arg2, f32 arg3);
extern f32 lbl_1_rodata_4AC4[4];
extern void fn_8003462C(u32 arg0, u32 arg1, u32 arg2);
extern f32 lbl_8006D0B4(f32);
extern void lbl_8006D668(void *);
extern u32 fn_1_44884(void *);
extern size_t strlen(const char *str);
extern fn_1_A948C_Font lbl_1_data_1AEA8[];
extern char *strchr(const char *str, int c);
extern char *strrchr(const char *str, int c);
extern void fn_1_A9FFC(s16 x, s16 y, s16 w, s16 h, GXColor color);
extern const f32 lbl_1_rodata_4CA8;
extern void fn_1_C3378(void);
extern DriverDesc lbl_1_rodata_4AE0[];
extern char *fn_80083CF4(char *dest, const char *src, size_t n);
extern char *strcat(char *dest, const char *src);
extern u8 fn_1_AAEB0__fzgx_offset_0[];
extern u8 fn_1_AAF18__fzgx_offset_0[];
extern u8 fn_1_AAF1C__fzgx_offset_0[];
extern u8 fn_1_AB434__fzgx_offset_0[];
extern u8 fn_1_AB438__fzgx_offset_0[];
extern u8 fn_1_AB458__fzgx_offset_0[];
extern u8 fn_1_AB478__fzgx_offset_0[];
extern u8 fn_1_AB4F4__fzgx_offset_0[];
extern u8 fn_1_AB598__fzgx_offset_0[];
extern u8 fn_1_AB5CC__fzgx_offset_0[];
extern u8 fn_1_AB61C__fzgx_offset_0[];
extern u8 fn_1_AB64C__fzgx_offset_0[];
extern u8 fn_1_AB75C__fzgx_offset_0[];
extern u8 fn_1_AB7C4__fzgx_offset_0[];
extern u8 fn_1_AB870__fzgx_offset_0[];
extern u8 fn_1_AB880__fzgx_offset_0[];
extern u8 fn_1_AB8D8__fzgx_offset_0[];
extern u8 fn_1_AB93C__fzgx_offset_0[];
extern u8 fn_1_AB98C__fzgx_offset_0[];
extern u8 fn_1_AB99C__fzgx_offset_0[];
extern u8 fn_1_ABA14__fzgx_offset_0[];
extern u8 fn_1_ABA24__fzgx_offset_0[];
extern u8 fn_1_ABA9C__fzgx_offset_0[];
extern u8 fn_1_ABAAC__fzgx_offset_0[];
extern u8 fn_1_ABB24__fzgx_offset_0[];
extern u8 fn_1_ABB4C__fzgx_offset_0[];
extern u8 fn_1_ABC5C__fzgx_offset_0[];
extern u8 fn_1_ABC98__fzgx_offset_0[];
extern u8 fn_1_ABCE8__fzgx_offset_0[];
extern u8 fn_1_ABD58__fzgx_offset_0[];
extern u8 fn_1_ABDA8__fzgx_offset_0[];
extern u8 fn_1_ABDB8__fzgx_offset_0[];
extern u8 fn_1_ABE14__fzgx_offset_0[];
extern u8 fn_1_ABE88__fzgx_offset_0[];
extern u8 fn_1_ABF44__fzgx_offset_0[];
extern u8 fn_1_AC000__fzgx_offset_0[];
extern u8 fn_1_AC12C__fzgx_offset_0[];
extern u8 fn_1_AC188__fzgx_offset_0[];
extern u8 fn_1_AC294__fzgx_offset_0[];
extern u8 fn_1_AC2D8__fzgx_offset_0[];
extern u8 fn_1_AC328__fzgx_offset_0[];
extern u8 fn_1_AC38C__fzgx_offset_0[];
extern u8 fn_1_AC3DC__fzgx_offset_0[];
extern u8 fn_1_AC464__fzgx_offset_0[];
extern u8 fn_1_AC4B4__fzgx_offset_0[];
extern u8 fn_1_AC4C4__fzgx_offset_0[];
extern u8 fn_1_AC53C__fzgx_offset_0[];
extern u8 fn_1_AC6A4__fzgx_offset_0[];
extern u8 fn_1_AC6A8__fzgx_offset_0[];
extern u8 fn_1_AC6C8__fzgx_offset_0[];
extern u8 fn_1_AC6CC__fzgx_offset_0[];
extern u8 fn_1_AC6DC__fzgx_offset_0[];
extern u8 fn_1_AC6E0__fzgx_offset_0[];
extern u8 fn_1_AC700__fzgx_offset_0[];
extern u8 fn_1_AC704__fzgx_offset_0[];
extern u8 fn_1_AC74C__fzgx_offset_0[];
extern u8 fn_1_AC79C__fzgx_offset_0[];
extern u8 fn_1_AC904__fzgx_offset_0[];
extern u8 fn_1_AC908__fzgx_offset_0[];
extern u8 fn_1_AC928__fzgx_offset_0[];
extern u8 fn_1_AC92C__fzgx_offset_0[];
extern u8 fn_1_AC960__fzgx_offset_0[];
extern u8 fn_1_ACA00__fzgx_offset_0[];
extern u8 fn_1_ACA1C__fzgx_offset_0[];
extern u8 fn_1_ACA78__fzgx_offset_0[];
extern u8 fn_1_ACD00__fzgx_offset_0[];
extern u8 fn_1_ACD04__fzgx_offset_0[];
extern u8 fn_1_ACE7C__fzgx_offset_0[];
extern u8 fn_1_ACE80__fzgx_offset_0[];
extern u8 fn_1_ACEBC__fzgx_offset_0[];
extern u8 fn_1_ACF0C__fzgx_offset_0[];
extern u8 fn_1_ACF2C__fzgx_offset_0[];
extern u8 fn_1_ACF30__fzgx_offset_0[];
extern u8 fn_1_AD098__fzgx_offset_0[];
extern u8 fn_1_AD09C__fzgx_offset_0[];
extern u8 fn_1_AD0A0__fzgx_offset_0[];
extern u8 fn_1_AD140__fzgx_offset_0[];
extern u8 fn_1_AD164__fzgx_offset_0[];
extern u8 fn_1_AD168__fzgx_offset_0[];
extern u8 fn_1_AD1AC__fzgx_offset_0[];
extern u8 fn_1_AD1E4__fzgx_offset_0[];
extern u8 fn_1_AD264__fzgx_offset_0[];
extern u8 fn_1_AEC34__fzgx_offset_0[];
extern u8 fn_1_AECCC__fzgx_offset_0[];
extern u8 fn_1_B03A8__fzgx_offset_0[];
extern u8 fn_1_B03CC__fzgx_offset_0[];
extern u8 fn_1_B1710__fzgx_offset_0[];
extern u8 fn_1_B171C__fzgx_offset_0[];
extern u8 fn_1_B2770__fzgx_offset_0[];
extern u8 fn_1_B277C__fzgx_offset_0[];
extern u8 fn_1_B38F4__fzgx_offset_0[];
extern u8 fn_1_B3900__fzgx_offset_0[];
extern u8 fn_1_B40B4__fzgx_offset_0[];
extern u8 fn_1_B40C0__fzgx_offset_0[];
extern u8 lbl_1_data_35ACC__fzgx_offset_0[];
extern u8 lbl_1_data_35AD8__fzgx_offset_0[];
extern u8 lbl_1_data_35AE0__fzgx_offset_0[];
extern u8 lbl_1_data_35AEC__fzgx_offset_0[];
extern u8 lbl_1_data_35AF4__fzgx_offset_0[];
extern u8 lbl_1_data_35B00__fzgx_offset_0[];
extern u8 lbl_1_data_35B08__fzgx_offset_0[];
extern u8 lbl_1_data_35B10__fzgx_offset_0[];
extern u8 lbl_1_data_35B34__fzgx_offset_0[];
extern u8 lbl_1_data_35B48__fzgx_offset_0[];
extern u8 lbl_1_data_35B74__fzgx_offset_0[];
extern u8 lbl_1_data_35B88__fzgx_offset_0[];
extern u8 lbl_1_data_35BB4__fzgx_offset_0[];
extern u8 lbl_1_data_35BC8__fzgx_offset_0[];
extern u8 lbl_1_data_35BF4__fzgx_offset_0[];
extern u8 lbl_1_data_35C44__fzgx_offset_0[];
extern u8 lbl_1_data_35C50__fzgx_offset_0[];
extern u8 lbl_1_data_35C5C__fzgx_offset_0[];
extern u8 lbl_1_data_35C68__fzgx_offset_0[];
extern u8 lbl_1_data_35C74__fzgx_offset_0[];
extern u8 lbl_1_data_35CE0__fzgx_offset_0[];
extern u8 lbl_1_data_35D24__fzgx_offset_0[];
extern u8 lbl_1_data_35D34__fzgx_offset_0[];
extern u8 lbl_1_data_35D44__fzgx_offset_0[];
extern u8 lbl_1_data_35D54__fzgx_offset_0[];
extern u8 lbl_1_data_35D64__fzgx_offset_0[];
extern u8 lbl_1_data_35DC4__fzgx_offset_0[];
extern u8 lbl_1_data_35E34__fzgx_offset_0[];
extern u8 lbl_1_data_35E40__fzgx_offset_0[];
extern u8 lbl_1_data_35E4C__fzgx_offset_0[];
extern u8 lbl_1_data_35E58__fzgx_offset_0[];
extern u8 lbl_1_data_35E64__fzgx_offset_0[];
extern u8 lbl_1_data_35F4C__fzgx_offset_0[];
extern u8 lbl_1_data_35FA4__fzgx_offset_0[];
extern u8 lbl_1_data_35FB0__fzgx_offset_0[];
extern u8 lbl_1_data_35FBC__fzgx_offset_0[];
extern u8 lbl_1_data_35FC8__fzgx_offset_0[];
extern u8 lbl_1_data_35FD4__fzgx_offset_0[];
extern u8 lbl_1_data_3603C__fzgx_offset_0[];
extern u8 lbl_1_data_36070__fzgx_offset_0[];
extern u8 lbl_1_data_36088__fzgx_offset_0[];
extern u8 lbl_1_data_360A0__fzgx_offset_0[];
extern u8 lbl_1_data_360B8__fzgx_offset_0[];
extern u8 lbl_1_data_360D0__fzgx_offset_0[];
extern u8 lbl_1_data_360F8__fzgx_offset_0[];
extern u8 lbl_1_data_36128__fzgx_offset_0[];
extern u8 lbl_1_data_36140__fzgx_offset_0[];
extern u8 lbl_1_data_36158__fzgx_offset_0[];
extern u8 lbl_1_data_36170__fzgx_offset_0[];
extern u8 lbl_1_data_36188__fzgx_offset_0[];
extern u8 lbl_1_data_361B0__fzgx_offset_0[];
extern u8 lbl_1_data_361E0__fzgx_offset_0[];
extern u8 lbl_1_data_361F8__fzgx_offset_0[];
extern u8 lbl_1_data_36210__fzgx_offset_0[];
extern u8 lbl_1_data_36228__fzgx_offset_0[];
extern u8 lbl_1_data_36240__fzgx_offset_0[];
extern u8 lbl_1_data_36270__fzgx_offset_0[];
extern u8 lbl_1_data_362A0__fzgx_offset_0[];
extern u8 lbl_1_data_362BC__fzgx_offset_0[];
extern u8 lbl_1_data_362D8__fzgx_offset_0[];
extern u8 lbl_1_data_362F4__fzgx_offset_0[];
extern u8 lbl_1_data_36310__fzgx_offset_0[];
extern u8 lbl_1_data_36338__fzgx_offset_0[];
extern u8 lbl_1_data_3636C__fzgx_offset_0[];
extern u8 lbl_1_data_36388__fzgx_offset_0[];
extern u8 lbl_1_data_363A4__fzgx_offset_0[];
extern u8 lbl_1_data_363C0__fzgx_offset_0[];
extern u8 lbl_1_data_363DC__fzgx_offset_0[];
extern u8 lbl_1_data_36408__fzgx_offset_0[];
extern u8 lbl_1_data_3644C__fzgx_offset_0[];
extern u8 lbl_1_data_3646C__fzgx_offset_0[];
extern u8 lbl_1_data_3648C__fzgx_offset_0[];
extern u8 lbl_1_data_364AC__fzgx_offset_0[];
extern u8 lbl_1_data_364CC__fzgx_offset_0[];
extern u8 lbl_1_data_36510__fzgx_offset_0[];
extern u8 lbl_1_data_36554__fzgx_offset_0[];
extern u8 lbl_1_data_36574__fzgx_offset_0[];
extern u8 lbl_1_data_36594__fzgx_offset_0[];
extern u8 lbl_1_data_365B4__fzgx_offset_0[];
extern u8 lbl_1_data_365D4__fzgx_offset_0[];
extern u8 lbl_1_data_36618__fzgx_offset_0[];
extern u8 lbl_1_data_36648__fzgx_offset_0[];
extern u8 lbl_1_data_36668__fzgx_offset_0[];
extern u8 lbl_1_data_36688__fzgx_offset_0[];
extern u8 lbl_1_data_366A8__fzgx_offset_0[];
extern u8 lbl_1_data_366C8__fzgx_offset_0[];
extern u8 lbl_1_data_366F8__fzgx_offset_0[];
extern u8 lbl_1_data_3673C__fzgx_offset_0[];
extern u8 lbl_1_data_3675C__fzgx_offset_0[];
extern u8 lbl_1_data_3677C__fzgx_offset_0[];
extern u8 lbl_1_data_3679C__fzgx_offset_0[];
extern u8 lbl_1_data_367BC__fzgx_offset_0[];
extern u8 lbl_1_data_36800__fzgx_offset_0[];
extern u8 lbl_1_data_36844__fzgx_offset_0[];
extern u8 lbl_1_data_36864__fzgx_offset_0[];
extern u8 lbl_1_data_36884__fzgx_offset_0[];
extern u8 lbl_1_data_368A4__fzgx_offset_0[];
extern u8 lbl_1_data_368C4__fzgx_offset_0[];
extern u8 lbl_1_data_36908__fzgx_offset_0[];
extern u8 lbl_1_data_36928__fzgx_offset_0[];
extern u8 lbl_1_data_36938__fzgx_offset_0[];
extern u8 lbl_1_data_36948__fzgx_offset_0[];
extern u8 lbl_1_data_36958__fzgx_offset_0[];
extern u8 lbl_1_data_36968__fzgx_offset_0[];
extern u8 lbl_1_data_36984__fzgx_offset_0[];
extern u8 lbl_1_data_36998__fzgx_offset_0[];
extern u8 lbl_1_data_369A8__fzgx_offset_0[];
extern u8 lbl_1_data_369B8__fzgx_offset_0[];
extern u8 lbl_1_data_369C8__fzgx_offset_0[];
extern u8 lbl_1_data_369D8__fzgx_offset_0[];
extern u8 lbl_1_data_369E8__fzgx_offset_0[];
extern u8 lbl_1_data_36A1C__fzgx_offset_0[];
extern u8 lbl_1_data_36A34__fzgx_offset_0[];
extern u8 lbl_1_data_36A4C__fzgx_offset_0[];
extern u8 lbl_1_data_36A64__fzgx_offset_0[];
extern u8 lbl_1_data_36A7C__fzgx_offset_0[];
extern u8 lbl_1_data_36AB0__fzgx_offset_0[];
extern u8 lbl_1_data_36AE4__fzgx_offset_0[];
extern u8 lbl_1_data_36AFC__fzgx_offset_0[];
extern u8 lbl_1_data_36B14__fzgx_offset_0[];
extern u8 lbl_1_data_36B2C__fzgx_offset_0[];
extern u8 lbl_1_data_36B44__fzgx_offset_0[];
extern u8 lbl_1_data_36B78__fzgx_offset_0[];
extern u8 lbl_1_data_36B98__fzgx_offset_0[];
extern u8 lbl_1_data_36BB0__fzgx_offset_0[];
extern u8 lbl_1_data_36BC8__fzgx_offset_0[];
extern u8 lbl_1_data_36BE0__fzgx_offset_0[];
extern u8 lbl_1_data_36BF8__fzgx_offset_0[];
extern u8 lbl_1_data_36C1C__fzgx_offset_0[];
extern u8 lbl_1_data_36C50__fzgx_offset_0[];
extern u8 lbl_1_data_36C6C__fzgx_offset_0[];
extern u8 lbl_1_data_36C88__fzgx_offset_0[];
extern u8 lbl_1_data_36CA4__fzgx_offset_0[];
extern u8 lbl_1_data_36CC0__fzgx_offset_0[];
extern u8 lbl_1_data_36CF0__fzgx_offset_0[];
extern u8 lbl_1_data_36D28__fzgx_offset_0[];
extern u8 lbl_1_data_36D44__fzgx_offset_0[];
extern u8 lbl_1_data_36D60__fzgx_offset_0[];
extern u8 lbl_1_data_36D7C__fzgx_offset_0[];
extern u8 lbl_1_data_36D98__fzgx_offset_0[];
extern u8 lbl_1_data_36DD0__fzgx_offset_0[];
extern u8 lbl_1_data_36E10__fzgx_offset_0[];
extern u8 lbl_1_data_36E30__fzgx_offset_0[];
extern u8 lbl_1_data_36E50__fzgx_offset_0[];
extern u8 lbl_1_data_36E70__fzgx_offset_0[];
extern u8 lbl_1_data_36E90__fzgx_offset_0[];
extern u8 lbl_1_data_36ED0__fzgx_offset_0[];
extern u8 lbl_1_data_36F0C__fzgx_offset_0[];
extern u8 lbl_1_data_36F2C__fzgx_offset_0[];
extern u8 lbl_1_data_36F4C__fzgx_offset_0[];
extern u8 lbl_1_data_36F6C__fzgx_offset_0[];
extern u8 lbl_1_data_36F8C__fzgx_offset_0[];
extern u8 lbl_1_data_36FCC__fzgx_offset_0[];
extern u8 lbl_1_data_37008__fzgx_offset_0[];
extern u8 lbl_1_data_37028__fzgx_offset_0[];
extern u8 lbl_1_data_37048__fzgx_offset_0[];
extern u8 lbl_1_data_37068__fzgx_offset_0[];
extern u8 lbl_1_data_37088__fzgx_offset_0[];
extern u8 lbl_1_data_370CC__fzgx_offset_0[];
extern u8 lbl_1_data_3710C__fzgx_offset_0[];
extern u8 lbl_1_data_3712C__fzgx_offset_0[];
extern u8 lbl_1_data_3714C__fzgx_offset_0[];
extern u8 lbl_1_data_3716C__fzgx_offset_0[];
extern u8 lbl_1_data_3718C__fzgx_offset_0[];
extern u8 lbl_1_data_371C8__fzgx_offset_0[];
extern u8 lbl_1_data_37208__fzgx_offset_0[];
extern u8 lbl_1_data_37228__fzgx_offset_0[];
extern u8 lbl_1_data_37248__fzgx_offset_0[];
extern u8 lbl_1_data_37268__fzgx_offset_0[];
extern u8 lbl_1_data_37288__fzgx_offset_0[];
extern u8 lbl_1_data_372C8__fzgx_offset_0[];
extern u8 lbl_1_data_372F4__fzgx_offset_0[];
extern u8 lbl_1_data_3730C__fzgx_offset_0[];
extern u8 lbl_1_data_37324__fzgx_offset_0[];
extern u8 lbl_1_data_3733C__fzgx_offset_0[];
extern u8 lbl_1_data_37354__fzgx_offset_0[];
extern u8 lbl_1_data_37380__fzgx_offset_0[];
extern u8 lbl_1_data_373DC__fzgx_offset_0[];
extern u8 lbl_1_data_373F4__fzgx_offset_0[];
extern u8 lbl_1_data_3740C__fzgx_offset_0[];
extern u8 lbl_1_data_37424__fzgx_offset_0[];
extern u8 lbl_1_data_3743C__fzgx_offset_0[];
extern u8 lbl_1_data_374A8__fzgx_offset_0[];
extern u8 lbl_1_data_374D8__fzgx_offset_0[];
extern u8 lbl_1_data_374E8__fzgx_offset_0[];
extern u8 lbl_1_data_374F8__fzgx_offset_0[];
extern u8 lbl_1_data_37508__fzgx_offset_0[];
extern u8 lbl_1_data_37518__fzgx_offset_0[];
extern u8 lbl_1_data_37550__fzgx_offset_0[];
extern u8 lbl_1_data_375A4__fzgx_offset_0[];
extern u8 lbl_1_data_375B8__fzgx_offset_0[];
extern u8 lbl_1_data_375CC__fzgx_offset_0[];
extern u8 lbl_1_data_375E0__fzgx_offset_0[];
extern u8 lbl_1_data_375F4__fzgx_offset_0[];
extern u8 lbl_1_data_3763C__fzgx_offset_0[];
extern u8 lbl_1_data_37680__fzgx_offset_0[];
extern u8 lbl_1_data_37690__fzgx_offset_0[];
extern u8 lbl_1_data_376A0__fzgx_offset_0[];
extern u8 lbl_1_data_376B0__fzgx_offset_0[];
extern u8 lbl_1_data_376C0__fzgx_offset_0[];
extern u8 lbl_1_data_37704__fzgx_offset_0[];
extern u8 lbl_1_data_3773C__fzgx_offset_0[];
extern u8 lbl_1_data_37750__fzgx_offset_0[];
extern u8 lbl_1_data_37764__fzgx_offset_0[];
extern u8 lbl_1_data_37778__fzgx_offset_0[];
extern u8 lbl_1_data_3778C__fzgx_offset_0[];
extern u8 lbl_1_data_377D0__fzgx_offset_0[];
extern u8 lbl_1_data_37808__fzgx_offset_0[];
extern u8 lbl_1_data_37818__fzgx_offset_0[];
extern u8 lbl_1_data_37828__fzgx_offset_0[];
extern u8 lbl_1_data_37838__fzgx_offset_0[];
extern u8 lbl_1_data_37848__fzgx_offset_0[];
extern u8 lbl_1_data_3788C__fzgx_offset_0[];
extern u8 lbl_1_data_378EC__fzgx_offset_0[];
extern u8 lbl_1_data_378FC__fzgx_offset_0[];
extern u8 lbl_1_data_3790C__fzgx_offset_0[];
extern u8 lbl_1_data_3791C__fzgx_offset_0[];
extern u8 lbl_1_data_3792C__fzgx_offset_0[];
extern u8 lbl_1_data_37984__fzgx_offset_0[];
extern u8 lbl_1_data_379C0__fzgx_offset_0[];
extern u8 lbl_1_data_379D0__fzgx_offset_0[];
extern u8 lbl_1_data_379E0__fzgx_offset_0[];
extern u8 lbl_1_data_379F0__fzgx_offset_0[];
extern u8 lbl_1_data_37A00__fzgx_offset_0[];
extern u8 lbl_1_data_37A58__fzgx_offset_0[];
extern u8 lbl_1_data_37AB8__fzgx_offset_0[];
extern u8 lbl_1_data_37ACC__fzgx_offset_0[];
extern u8 lbl_1_data_37AE0__fzgx_offset_0[];
extern u8 lbl_1_data_37AF4__fzgx_offset_0[];
extern u8 lbl_1_data_37B08__fzgx_offset_0[];
extern u8 lbl_1_data_37B74__fzgx_offset_0[];
extern u8 lbl_1_data_37B9C__fzgx_offset_0[];
extern u8 lbl_1_data_37BB0__fzgx_offset_0[];
extern u8 lbl_1_data_37BC4__fzgx_offset_0[];
extern u8 lbl_1_data_37BD8__fzgx_offset_0[];
extern u8 lbl_1_data_37BEC__fzgx_offset_0[];
extern u8 lbl_1_data_37C28__fzgx_offset_0[];
extern u8 lbl_1_data_37C30__fzgx_offset_0[];
extern u8 lbl_1_data_37C3C__fzgx_offset_0[];
extern u8 lbl_1_data_37C48__fzgx_offset_0[];
extern u8 lbl_1_data_37C54__fzgx_offset_0[];
extern u8 lbl_1_data_37C60__fzgx_offset_0[];
extern u8 lbl_1_data_37C6C__fzgx_offset_0[];
extern u8 lbl_1_data_37C74__fzgx_offset_0[];
extern u8 lbl_1_data_37C80__fzgx_offset_0[];
extern u8 lbl_1_data_37C8C__fzgx_offset_0[];
extern u8 lbl_1_data_37C98__fzgx_offset_0[];
extern u8 lbl_1_data_37CA4__fzgx_offset_0[];
extern u8 lbl_1_data_37CB0__fzgx_offset_0[];
extern u8 lbl_1_data_37CB4__fzgx_offset_0[];
extern u8 lbl_1_data_37CBC__fzgx_offset_0[];
extern u8 lbl_1_data_37CC4__fzgx_offset_0[];
extern u8 lbl_1_data_37CCC__fzgx_offset_0[];
extern u8 lbl_1_data_37CD4__fzgx_offset_0[];
extern u8 lbl_1_data_37CDC__fzgx_offset_0[];
extern u8 lbl_1_data_37CE0__fzgx_offset_0[];
extern u8 lbl_1_data_37CE8__fzgx_offset_0[];
extern u8 lbl_1_data_37CF0__fzgx_offset_0[];
extern u8 lbl_1_data_37CF8__fzgx_offset_0[];
extern u8 lbl_1_data_37D00__fzgx_offset_0[];
extern u8 lbl_1_data_37D08__fzgx_offset_0[];
extern u8 lbl_1_data_37D44__fzgx_offset_0[];
extern u8 lbl_1_data_37D58__fzgx_offset_0[];
extern u8 lbl_1_data_37D6C__fzgx_offset_0[];
extern u8 lbl_1_data_37D80__fzgx_offset_0[];
extern u8 lbl_1_data_37D94__fzgx_offset_0[];
extern u8 lbl_1_data_37DD4__fzgx_offset_0[];
extern u8 lbl_1_data_37F64__fzgx_offset_0[];
extern u8 lbl_1_data_37F70__fzgx_offset_0[];
extern u8 lbl_1_data_37F7C__fzgx_offset_0[];
extern u8 lbl_1_data_37F88__fzgx_offset_0[];
extern u8 lbl_1_data_37F94__fzgx_offset_0[];
extern u8 lbl_1_data_381E4__fzgx_offset_0[];
extern u8 lbl_1_data_382C8__fzgx_offset_0[];
extern u8 lbl_1_data_382D4__fzgx_offset_0[];
extern u8 lbl_1_data_382E0__fzgx_offset_0[];
extern u8 lbl_1_data_382EC__fzgx_offset_0[];
extern u8 lbl_1_data_382F8__fzgx_offset_0[];
extern u8 lbl_1_data_38454__fzgx_offset_0[];
extern u8 lbl_1_data_385E4__fzgx_offset_0[];
extern u8 lbl_1_data_385F4__fzgx_offset_0[];
extern u8 lbl_1_data_38604__fzgx_offset_0[];
extern u8 lbl_1_data_38614__fzgx_offset_0[];
extern u8 lbl_1_data_38624__fzgx_offset_0[];
extern u8 lbl_1_data_38874__fzgx_offset_0[];
extern u8 lbl_1_data_38958__fzgx_offset_0[];
extern u8 lbl_1_data_3896C__fzgx_offset_0[];
extern u8 lbl_1_data_38980__fzgx_offset_0[];
extern u8 lbl_1_data_38994__fzgx_offset_0[];
extern u8 lbl_1_data_389A8__fzgx_offset_0[];
extern u8 lbl_1_data_38B04__fzgx_offset_0[];
extern u8 lbl_1_data_38B58__fzgx_offset_0[];
extern u8 lbl_1_data_38B6C__fzgx_offset_0[];
extern u8 lbl_1_data_38B80__fzgx_offset_0[];
extern u8 lbl_1_data_38B94__fzgx_offset_0[];
extern u8 lbl_1_data_38BA8__fzgx_offset_0[];
extern u8 lbl_1_data_38C08__fzgx_offset_0[];
extern u8 lbl_1_data_38C30__fzgx_offset_0[];
extern u8 lbl_1_data_38C48__fzgx_offset_0[];
extern u8 lbl_1_data_38C60__fzgx_offset_0[];
extern u8 lbl_1_data_38C78__fzgx_offset_0[];
extern u8 lbl_1_data_38C90__fzgx_offset_0[];
extern u8 lbl_1_data_38CCC__fzgx_offset_0[];
extern u8 lbl_1_data_38D00__fzgx_offset_0[];
extern u8 lbl_1_data_38D10__fzgx_offset_0[];
extern u8 lbl_1_data_38D20__fzgx_offset_0[];
extern u8 lbl_1_data_38D30__fzgx_offset_0[];
extern u8 lbl_1_data_38D40__fzgx_offset_0[];
extern u8 lbl_1_data_38D80__fzgx_offset_0[];
extern u8 lbl_1_data_38D98__fzgx_offset_0[];
extern u8 lbl_1_data_38DAC__fzgx_offset_0[];
extern u8 lbl_1_data_38DC0__fzgx_offset_0[];
extern u8 lbl_1_data_38DD4__fzgx_offset_0[];
extern u8 lbl_1_data_38DE8__fzgx_offset_0[];
extern u8 lbl_1_data_38E04__fzgx_offset_0[];
extern u8 lbl_1_data_38E0C__fzgx_offset_0[];
extern u8 lbl_1_data_38E18__fzgx_offset_0[];
extern u8 lbl_1_data_38E24__fzgx_offset_0[];
extern u8 lbl_1_data_38E30__fzgx_offset_0[];
extern u8 lbl_1_data_38E3C__fzgx_offset_0[];
extern u8 lbl_1_data_38E48__fzgx_offset_0[];
extern u8 lbl_1_data_38E80__fzgx_offset_0[];
extern u8 lbl_1_data_38E90__fzgx_offset_0[];
extern u8 lbl_1_data_38EA0__fzgx_offset_0[];
extern u8 lbl_1_data_38EB0__fzgx_offset_0[];
extern u8 lbl_1_data_38EC0__fzgx_offset_0[];
extern u8 lbl_1_data_38F04__fzgx_offset_0[];
extern u8 lbl_1_data_38F30__fzgx_offset_0[];
extern u8 lbl_1_data_38F40__fzgx_offset_0[];
extern u8 lbl_1_data_38F50__fzgx_offset_0[];
extern u8 lbl_1_data_38F60__fzgx_offset_0[];
extern u8 lbl_1_data_38F70__fzgx_offset_0[];
extern u8 lbl_1_data_38FA8__fzgx_offset_0[];
extern u8 lbl_1_data_38FE8__fzgx_offset_0[];
extern u8 lbl_1_data_38FF8__fzgx_offset_0[];
extern u8 lbl_1_data_39008__fzgx_offset_0[];
extern u8 lbl_1_data_39018__fzgx_offset_0[];
extern u8 lbl_1_data_39028__fzgx_offset_0[];
extern u8 lbl_1_data_3906C__fzgx_offset_0[];
extern u8 lbl_1_data_390C4__fzgx_offset_0[];
extern u8 lbl_1_data_390D4__fzgx_offset_0[];
extern u8 lbl_1_data_390E4__fzgx_offset_0[];
extern u8 lbl_1_data_390F4__fzgx_offset_0[];
extern u8 lbl_1_data_39104__fzgx_offset_0[];
extern u8 lbl_1_data_39148__fzgx_offset_0[];
extern u8 lbl_1_data_39190__fzgx_offset_0[];
extern u8 lbl_1_data_3919C__fzgx_offset_0[];
extern u8 lbl_1_data_391A8__fzgx_offset_0[];
extern u8 lbl_1_data_391B4__fzgx_offset_0[];
extern u8 lbl_1_data_391C0__fzgx_offset_0[];
extern u8 lbl_1_data_39214__fzgx_offset_0[];
extern u8 lbl_1_data_39248__fzgx_offset_0[];
extern u8 lbl_1_data_39254__fzgx_offset_0[];
extern u8 lbl_1_data_39260__fzgx_offset_0[];
extern u8 lbl_1_data_3926C__fzgx_offset_0[];
extern u8 lbl_1_data_39278__fzgx_offset_0[];
extern u8 lbl_1_data_392AC__fzgx_offset_0[];
extern u8 lbl_1_data_392E4__fzgx_offset_0[];
extern u8 lbl_1_data_392F0__fzgx_offset_0[];
extern u8 lbl_1_data_392FC__fzgx_offset_0[];
extern u8 lbl_1_data_39308__fzgx_offset_0[];
extern u8 lbl_1_data_39314__fzgx_offset_0[];
extern u8 lbl_1_data_39348__fzgx_offset_0[];
extern u8 lbl_1_data_3937C__fzgx_offset_0[];
extern u8 lbl_1_data_39388__fzgx_offset_0[];
extern u8 lbl_1_data_39394__fzgx_offset_0[];
extern u8 lbl_1_data_393A0__fzgx_offset_0[];
extern u8 lbl_1_data_393AC__fzgx_offset_0[];
extern u8 lbl_1_data_393E0__fzgx_offset_0[];
extern u8 lbl_1_data_39418__fzgx_offset_0[];
extern u8 lbl_1_data_39424__fzgx_offset_0[];
extern u8 lbl_1_data_39430__fzgx_offset_0[];
extern u8 lbl_1_data_3943C__fzgx_offset_0[];
extern u8 lbl_1_data_39448__fzgx_offset_0[];
extern u8 lbl_1_data_3947C__fzgx_offset_0[];
extern u8 lbl_1_data_394B8__fzgx_offset_0[];
extern u8 lbl_1_data_394C8__fzgx_offset_0[];
extern u8 lbl_1_data_394D8__fzgx_offset_0[];
extern u8 lbl_1_data_394E8__fzgx_offset_0[];
extern u8 lbl_1_data_394F8__fzgx_offset_0[];
extern u8 lbl_1_data_39520__fzgx_offset_0[];
extern u8 lbl_1_data_39550__fzgx_offset_0[];
extern u8 lbl_1_data_39564__fzgx_offset_0[];
extern u8 lbl_1_data_39578__fzgx_offset_0[];
extern u8 lbl_1_data_3958C__fzgx_offset_0[];
extern u8 lbl_1_data_395A0__fzgx_offset_0[];
extern u8 lbl_1_data_395DC__fzgx_offset_0[];
extern u8 lbl_1_data_39618__fzgx_offset_0[];
extern u8 lbl_1_data_39628__fzgx_offset_0[];
extern u8 lbl_1_data_39638__fzgx_offset_0[];
extern u8 lbl_1_data_39648__fzgx_offset_0[];
extern u8 lbl_1_data_39658__fzgx_offset_0[];
extern u8 lbl_1_data_39694__fzgx_offset_0[];
extern u8 lbl_1_data_396BC__fzgx_offset_0[];
extern u8 lbl_1_data_396CC__fzgx_offset_0[];
extern u8 lbl_1_data_396DC__fzgx_offset_0[];
extern u8 lbl_1_data_396EC__fzgx_offset_0[];
extern u8 lbl_1_data_396FC__fzgx_offset_0[];
extern u8 lbl_1_data_39740__fzgx_offset_0[];
extern u8 lbl_1_data_39780__fzgx_offset_0[];
extern u8 lbl_1_data_39790__fzgx_offset_0[];
extern u8 lbl_1_data_397A0__fzgx_offset_0[];
extern u8 lbl_1_data_397B0__fzgx_offset_0[];
extern u8 lbl_1_data_397C0__fzgx_offset_0[];
extern u8 lbl_1_data_39800__fzgx_offset_0[];
extern u8 lbl_1_data_39838__fzgx_offset_0[];
extern u8 lbl_1_data_39848__fzgx_offset_0[];
extern u8 lbl_1_data_39858__fzgx_offset_0[];
extern u8 lbl_1_data_39868__fzgx_offset_0[];
extern u8 lbl_1_data_39878__fzgx_offset_0[];
extern u8 lbl_1_data_398A0__fzgx_offset_0[];
extern u8 lbl_1_data_398B0__fzgx_offset_0[];
extern u8 lbl_1_data_398C0__fzgx_offset_0[];
extern u8 lbl_1_data_398D0__fzgx_offset_0[];
extern u8 lbl_1_data_398E0__fzgx_offset_0[];
extern u8 lbl_1_data_398F0__fzgx_offset_0[];
extern u8 lbl_1_data_39900__fzgx_offset_0[];
extern u8 lbl_1_data_3990C__fzgx_offset_0[];
extern u8 lbl_1_data_3991C__fzgx_offset_0[];
extern u8 lbl_1_data_3992C__fzgx_offset_0[];
extern u8 lbl_1_data_3993C__fzgx_offset_0[];
extern u8 lbl_1_data_3994C__fzgx_offset_0[];
extern u8 lbl_1_data_39958__fzgx_offset_0[];
extern u8 lbl_1_data_39968__fzgx_offset_0[];
extern u8 lbl_1_data_39978__fzgx_offset_0[];
extern u8 lbl_1_data_39988__fzgx_offset_0[];
extern u8 lbl_1_data_39998__fzgx_offset_0[];
extern u8 lbl_1_data_399A8__fzgx_offset_0[];
extern u8 lbl_1_data_399B8__fzgx_offset_0[];
extern u8 lbl_1_data_399C8__fzgx_offset_0[];
extern u8 lbl_1_data_399D8__fzgx_offset_0[];
extern u8 lbl_1_data_399E8__fzgx_offset_0[];
extern u8 lbl_1_data_399F8__fzgx_offset_0[];
extern u8 lbl_1_data_39A08__fzgx_offset_0[];
extern u8 lbl_1_data_39A18__fzgx_offset_0[];
extern u8 lbl_1_data_39A6C__fzgx_offset_0[];
extern u8 lbl_1_data_39A78__fzgx_offset_0[];
extern u8 lbl_1_data_39A84__fzgx_offset_0[];
extern u8 lbl_1_data_39A90__fzgx_offset_0[];
extern u8 lbl_1_data_39A9C__fzgx_offset_0[];
extern u8 lbl_1_data_39B04__fzgx_offset_0[];
extern u8 lbl_1_data_39B58__fzgx_offset_0[];
extern u8 lbl_1_data_39B64__fzgx_offset_0[];
extern u8 lbl_1_data_39B70__fzgx_offset_0[];
extern u8 lbl_1_data_39B7C__fzgx_offset_0[];
extern u8 lbl_1_data_39B88__fzgx_offset_0[];
extern u8 lbl_1_data_39BF0__fzgx_offset_0[];
extern u8 lbl_1_data_39C1C__fzgx_offset_0[];
extern u8 lbl_1_data_39C2C__fzgx_offset_0[];
extern u8 lbl_1_data_39C3C__fzgx_offset_0[];
extern u8 lbl_1_data_39C4C__fzgx_offset_0[];
extern u8 lbl_1_data_39C5C__fzgx_offset_0[];
extern u8 lbl_1_data_39C88__fzgx_offset_0[];
extern u8 lbl_1_data_39CB8__fzgx_offset_0[];
extern u8 lbl_1_data_39CC8__fzgx_offset_0[];
extern u8 lbl_1_data_39CD8__fzgx_offset_0[];
extern u8 lbl_1_data_39CE8__fzgx_offset_0[];
extern u8 lbl_1_data_39CF8__fzgx_offset_0[];
extern u8 lbl_1_data_39D2C__fzgx_offset_0[];
extern u8 lbl_1_data_39DC4__fzgx_offset_0[];
extern u8 lbl_1_data_39DDC__fzgx_offset_0[];
extern u8 lbl_1_data_39DF4__fzgx_offset_0[];
extern u8 lbl_1_data_39E0C__fzgx_offset_0[];
extern u8 lbl_1_data_39E24__fzgx_offset_0[];
extern u8 lbl_1_data_39EB0__fzgx_offset_0[];
extern u8 lbl_1_data_39EF4__fzgx_offset_0[];
extern u8 lbl_1_data_39F0C__fzgx_offset_0[];
extern u8 lbl_1_data_39F24__fzgx_offset_0[];
extern u8 lbl_1_data_39F3C__fzgx_offset_0[];
extern u8 lbl_1_data_39F54__fzgx_offset_0[];
extern u8 lbl_1_data_39FA4__fzgx_offset_0[];
extern u8 lbl_1_data_3A018__fzgx_offset_0[];
extern u8 lbl_1_data_3A01C__fzgx_offset_0[];
extern u8 lbl_1_data_3A020__fzgx_offset_0[];
extern u8 lbl_1_data_3A024__fzgx_offset_0[];
extern u8 lbl_1_data_3A028__fzgx_offset_0[];
extern u8 lbl_1_data_3A0E4__fzgx_offset_0[];
extern u8 lbl_1_data_3A15C__fzgx_offset_0[];
extern u8 lbl_1_data_3A160__fzgx_offset_0[];
extern u8 lbl_1_data_3A164__fzgx_offset_0[];
extern u8 lbl_1_data_3A168__fzgx_offset_0[];
extern u8 lbl_1_data_3A16C__fzgx_offset_0[];
extern u8 lbl_1_data_3A1C8__fzgx_offset_0[];
extern u8 lbl_1_data_3A1D0__fzgx_offset_0[];
extern u8 lbl_1_data_3A1DC__fzgx_offset_0[];
extern u8 lbl_1_data_3A1E8__fzgx_offset_0[];
extern u8 lbl_1_data_3A1F4__fzgx_offset_0[];
extern u8 lbl_1_data_3A200__fzgx_offset_0[];
extern u8 lbl_1_data_3A208__fzgx_offset_0[];
extern u8 lbl_1_data_3A210__fzgx_offset_0[];
extern u8 lbl_1_data_3A21C__fzgx_offset_0[];
extern u8 lbl_1_data_3A228__fzgx_offset_0[];
extern u8 lbl_1_data_3A234__fzgx_offset_0[];
extern u8 lbl_1_data_3A240__fzgx_offset_0[];
extern u8 lbl_1_data_3A248__fzgx_offset_0[];
extern u8 lbl_1_data_3A250__fzgx_offset_0[];
extern u8 lbl_1_data_3A25C__fzgx_offset_0[];
extern u8 lbl_1_data_3A268__fzgx_offset_0[];
extern u8 lbl_1_data_3A274__fzgx_offset_0[];
extern u8 lbl_1_data_3A280__fzgx_offset_0[];
extern u8 lbl_1_data_3A28C__fzgx_offset_0[];
extern u8 lbl_1_data_3A294__fzgx_offset_0[];
extern u8 lbl_1_data_3A2A0__fzgx_offset_0[];
extern u8 lbl_1_data_3A2AC__fzgx_offset_0[];
extern u8 lbl_1_data_3A2B8__fzgx_offset_0[];
extern u8 lbl_1_data_3A2C4__fzgx_offset_0[];
extern u8 lbl_1_data_3A2D0__fzgx_offset_0[];
extern u8 lbl_1_data_3A2D8__fzgx_offset_0[];
extern u8 lbl_1_data_3A2E4__fzgx_offset_0[];
extern u8 lbl_1_data_3A2F0__fzgx_offset_0[];
extern u8 lbl_1_data_3A2FC__fzgx_offset_0[];
extern u8 lbl_1_data_3A308__fzgx_offset_0[];
extern u8 lbl_1_data_3A314__fzgx_offset_0[];
extern u8 lbl_1_data_3A31C__fzgx_offset_0[];
extern u8 lbl_1_data_3A328__fzgx_offset_0[];
extern u8 lbl_1_data_3A334__fzgx_offset_0[];
extern u8 lbl_1_data_3A340__fzgx_offset_0[];
extern u8 lbl_1_data_3A34C__fzgx_offset_0[];
extern u8 lbl_1_data_3A358__fzgx_offset_0[];
extern u8 lbl_1_data_3A360__fzgx_offset_0[];
extern u8 lbl_1_data_3A36C__fzgx_offset_0[];
extern u8 lbl_1_data_3A378__fzgx_offset_0[];
extern u8 lbl_1_data_3A384__fzgx_offset_0[];
extern u8 lbl_1_data_3A390__fzgx_offset_0[];
extern u8 lbl_1_data_3A39C__fzgx_offset_0[];
extern u8 lbl_1_data_3A3A4__fzgx_offset_0[];
extern u8 lbl_1_data_3A3B0__fzgx_offset_0[];
extern u8 lbl_1_data_3A3BC__fzgx_offset_0[];
extern u8 lbl_1_data_3A3C8__fzgx_offset_0[];
extern u8 lbl_1_data_3A3D4__fzgx_offset_0[];
extern u8 lbl_1_data_3A3DC__fzgx_offset_0[];
extern u8 lbl_1_data_3A520__fzgx_offset_0[];
extern u8 lbl_1_data_3A524__fzgx_offset_0[];
extern u8 lbl_1_data_3A528__fzgx_offset_0[];
extern u8 lbl_1_data_3A52C__fzgx_offset_0[];
extern u8 lbl_1_data_3A530__fzgx_offset_0[];
extern u8 lbl_1_data_3A6A0__fzgx_offset_0[];
extern u8 lbl_1_data_3A6E4__fzgx_offset_0[];
extern u8 lbl_1_data_3A6E8__fzgx_offset_0[];
extern u8 lbl_1_data_3A6EC__fzgx_offset_0[];
extern u8 lbl_1_data_3A6F0__fzgx_offset_0[];
extern u8 lbl_1_data_3A6F4__fzgx_offset_0[];
extern u8 lbl_1_data_3A738__fzgx_offset_0[];
extern u8 lbl_1_data_3A77C__fzgx_offset_0[];
extern u8 lbl_1_data_3A780__fzgx_offset_0[];
extern u8 lbl_1_data_3A784__fzgx_offset_0[];
extern u8 lbl_1_data_3A788__fzgx_offset_0[];
extern u8 lbl_1_data_3A78C__fzgx_offset_0[];
extern u8 lbl_1_data_3A7D4__fzgx_offset_0[];
extern u8 lbl_1_data_3A80C__fzgx_offset_0[];
extern u8 lbl_1_data_3A810__fzgx_offset_0[];
extern u8 lbl_1_data_3A814__fzgx_offset_0[];
extern u8 lbl_1_data_3A818__fzgx_offset_0[];
extern u8 lbl_1_data_3A81C__fzgx_offset_0[];
extern u8 lbl_1_data_3A874__fzgx_offset_0[];
extern u8 lbl_1_data_3A87C__fzgx_offset_0[];
extern u8 lbl_1_data_3A880__fzgx_offset_0[];
extern u8 lbl_1_data_3A884__fzgx_offset_0[];
extern u8 lbl_1_data_3A888__fzgx_offset_0[];
extern u8 lbl_1_data_3A88C__fzgx_offset_0[];
extern u8 lbl_1_data_3A894__fzgx_offset_0[];
extern u8 lbl_1_data_3A89C__fzgx_offset_0[];
extern u8 lbl_1_data_3A8A0__fzgx_offset_0[];
extern u8 lbl_1_data_3A8A4__fzgx_offset_0[];
extern u8 lbl_1_data_3A8A8__fzgx_offset_0[];
extern u8 lbl_1_data_3A8AC__fzgx_offset_0[];
extern u8 lbl_1_data_3A8B4__fzgx_offset_0[];
extern u8 lbl_1_data_3A8BC__fzgx_offset_0[];
extern u8 lbl_1_data_3A8C0__fzgx_offset_0[];
extern u8 lbl_1_data_3A8C4__fzgx_offset_0[];
extern u8 lbl_1_data_3A8C8__fzgx_offset_0[];
extern u8 lbl_1_data_3A8CC__fzgx_offset_0[];
extern u8 lbl_1_data_3A8D4__fzgx_offset_0[];
extern u8 lbl_1_data_3A8DC__fzgx_offset_0[];
extern u8 lbl_1_data_3A8E0__fzgx_offset_0[];
extern u8 lbl_1_data_3A8E4__fzgx_offset_0[];
extern u8 lbl_1_data_3A8E8__fzgx_offset_0[];
extern u8 lbl_1_data_3A8EC__fzgx_offset_0[];
extern u8 lbl_1_data_3A8F4__fzgx_offset_0[];
extern u8 lbl_1_data_3A928__fzgx_offset_0[];
extern u8 lbl_1_data_3A92C__fzgx_offset_0[];
extern u8 lbl_1_data_3A930__fzgx_offset_0[];
extern u8 lbl_1_data_3A934__fzgx_offset_0[];
extern u8 lbl_1_data_3A938__fzgx_offset_0[];
extern u8 lbl_1_data_3A98C__fzgx_offset_0[];
extern u8 lbl_1_data_3A9E0__fzgx_offset_0[];
extern u8 lbl_1_data_3A9E4__fzgx_offset_0[];
extern u8 lbl_1_data_3A9E8__fzgx_offset_0[];
extern u8 lbl_1_data_3A9EC__fzgx_offset_0[];
extern u8 lbl_1_data_3A9F0__fzgx_offset_0[];
extern u8 lbl_1_data_3AA3C__fzgx_offset_0[];
extern u8 lbl_1_data_3AA44__fzgx_offset_0[];
extern u8 lbl_1_data_3AA48__fzgx_offset_0[];
extern u8 lbl_1_data_3AA4C__fzgx_offset_0[];
extern u8 lbl_1_data_3AA50__fzgx_offset_0[];
extern u8 lbl_1_data_3AA54__fzgx_offset_0[];
extern u8 lbl_1_data_3AA60__fzgx_offset_0[];
extern u8 lbl_1_data_3AAA0__fzgx_offset_0[];
extern u8 lbl_1_data_3AAB4__fzgx_offset_0[];
extern u8 lbl_1_data_3AAC8__fzgx_offset_0[];
extern u8 lbl_1_data_3AADC__fzgx_offset_0[];
extern u8 lbl_1_data_3AAF0__fzgx_offset_0[];
extern u8 lbl_1_data_3ABCC__fzgx_offset_0[];
extern u8 lbl_1_data_3AC48__fzgx_offset_0[];
extern u8 lbl_1_data_3AC58__fzgx_offset_0[];
extern u8 lbl_1_data_3AC68__fzgx_offset_0[];
extern u8 lbl_1_data_3AC78__fzgx_offset_0[];
extern u8 lbl_1_data_3AC88__fzgx_offset_0[];
extern u8 lbl_1_data_3AD68__fzgx_offset_0[];
extern u8 lbl_1_data_3ADD8__fzgx_offset_0[];
extern u8 lbl_1_data_3ADEC__fzgx_offset_0[];
extern u8 lbl_1_data_3AE00__fzgx_offset_0[];
extern u8 lbl_1_data_3AE14__fzgx_offset_0[];
extern u8 lbl_1_data_3AE28__fzgx_offset_0[];
extern u8 lbl_1_data_3AE2C__fzgx_offset_0[];
extern u8 lbl_1_data_3AED4__fzgx_offset_0[];
extern u8 lbl_1_data_3AEE4__fzgx_offset_0[];
extern u8 lbl_1_data_3AEF4__fzgx_offset_0[];
extern u8 lbl_1_data_3AF04__fzgx_offset_0[];
extern u8 lbl_1_data_3AF14__fzgx_offset_0[];
extern u8 lbl_1_data_3AF18__fzgx_offset_0[];
extern u8 lbl_1_data_3AFC0__fzgx_offset_0[];
extern u8 lbl_1_data_3AFD0__fzgx_offset_0[];
extern u8 lbl_1_data_3AFE0__fzgx_offset_0[];
extern u8 lbl_1_data_3AFF0__fzgx_offset_0[];
extern u8 lbl_1_data_3B000__fzgx_offset_0[];
extern u8 lbl_1_data_3B0B8__fzgx_offset_0[];
extern u8 lbl_1_data_3B0E0__fzgx_offset_0[];
extern u8 lbl_1_data_3B0F0__fzgx_offset_0[];
extern u8 lbl_1_data_3B100__fzgx_offset_0[];
extern u8 lbl_1_data_3B110__fzgx_offset_0[];
extern u8 lbl_1_data_3B120__fzgx_offset_0[];
extern u8 lbl_1_data_3B150__fzgx_offset_0[];
extern u8 lbl_1_data_3B198__fzgx_offset_0[];
extern u8 lbl_1_data_3B1A8__fzgx_offset_0[];
extern u8 lbl_1_data_3B1B8__fzgx_offset_0[];
extern u8 lbl_1_data_3B1C8__fzgx_offset_0[];
extern u8 lbl_1_data_3B1D8__fzgx_offset_0[];
extern u8 lbl_1_data_3B240__fzgx_offset_0[];
extern u8 lbl_1_data_3B278__fzgx_offset_0[];
extern u8 lbl_1_data_3B288__fzgx_offset_0[];
extern u8 lbl_1_data_3B298__fzgx_offset_0[];
extern u8 lbl_1_data_3B2A8__fzgx_offset_0[];
extern u8 lbl_1_data_3B2B8__fzgx_offset_0[];
extern u8 lbl_1_data_3B300__fzgx_offset_0[];
extern u8 lbl_1_data_3B32C__fzgx_offset_0[];
extern u8 lbl_1_data_3B340__fzgx_offset_0[];
extern u8 lbl_1_data_3B354__fzgx_offset_0[];
extern u8 lbl_1_data_3B368__fzgx_offset_0[];
extern u8 lbl_1_data_3B37C__fzgx_offset_0[];
extern u8 lbl_1_data_3B3AC__fzgx_offset_0[];
extern u8 lbl_1_data_3B3C0__fzgx_offset_0[];
extern u8 lbl_1_data_3B3D0__fzgx_offset_0[];
extern u8 lbl_1_data_3B3E0__fzgx_offset_0[];
extern u8 lbl_1_data_3B3F0__fzgx_offset_0[];
extern u8 lbl_1_data_3B400__fzgx_offset_0[];
extern u8 lbl_1_data_3B40C__fzgx_offset_0[];
extern u8 lbl_1_data_3B420__fzgx_offset_0[];
extern u8 lbl_1_data_3B434__fzgx_offset_0[];
extern u8 lbl_1_data_3B448__fzgx_offset_0[];
extern u8 lbl_1_data_3B45C__fzgx_offset_0[];
extern u8 lbl_1_data_3B470__fzgx_offset_0[];
extern u8 lbl_1_data_3B490__fzgx_offset_0[];
extern u8 lbl_1_data_3B4AC__fzgx_offset_0[];
extern u8 lbl_1_data_3B4C0__fzgx_offset_0[];
extern u8 lbl_1_data_3B4D4__fzgx_offset_0[];
extern u8 lbl_1_data_3B4E8__fzgx_offset_0[];
extern u8 lbl_1_data_3B4FC__fzgx_offset_0[];
extern u8 lbl_1_data_3B520__fzgx_offset_0[];
extern u8 lbl_1_data_3B540__fzgx_offset_0[];
extern u8 lbl_1_data_3B550__fzgx_offset_0[];
extern u8 lbl_1_data_3B560__fzgx_offset_0[];
extern u8 lbl_1_data_3B570__fzgx_offset_0[];
extern u8 lbl_1_data_3B580__fzgx_offset_0[];
extern u8 lbl_1_data_3B594__fzgx_offset_0[];
extern u8 lbl_1_data_3B5C8__fzgx_offset_0[];
extern u8 lbl_1_data_3B5DC__fzgx_offset_0[];
extern u8 lbl_1_data_3B5F0__fzgx_offset_0[];
extern u8 lbl_1_data_3B604__fzgx_offset_0[];
extern u8 lbl_1_data_3B618__fzgx_offset_0[];
extern u8 lbl_1_data_3B63C__fzgx_offset_0[];
extern u8 lbl_1_data_3B64C__fzgx_offset_0[];
extern u8 lbl_1_data_3B65C__fzgx_offset_0[];
extern u8 lbl_1_data_3B66C__fzgx_offset_0[];
extern u8 lbl_1_data_3B67C__fzgx_offset_0[];
extern u8 lbl_1_data_3B68C__fzgx_offset_0[];
extern u8 lbl_1_data_3B69C__fzgx_offset_0[];
extern u8 lbl_1_data_3B6C8__fzgx_offset_0[];
extern u8 lbl_1_data_3B6DC__fzgx_offset_0[];
extern u8 lbl_1_data_3B6F0__fzgx_offset_0[];
extern u8 lbl_1_data_3B704__fzgx_offset_0[];
extern u8 lbl_1_data_3B718__fzgx_offset_0[];
extern u8 lbl_1_data_3C1E8__fzgx_offset_0[];
extern u8 lbl_1_data_3C1F8__fzgx_offset_0[];
extern u8 lbl_1_data_3C20C__fzgx_offset_0[];
extern u8 lbl_1_data_3C21C__fzgx_offset_0[];
extern u8 lbl_1_data_3C22C__fzgx_offset_0[];
extern u8 lbl_1_data_3C244__fzgx_offset_0[];
extern u8 lbl_1_data_3C254__fzgx_offset_0[];
extern u8 lbl_1_data_3C284__fzgx_offset_0[];
extern u8 lbl_1_data_3C290__fzgx_offset_0[];
extern u8 lbl_1_data_3C2A0__fzgx_offset_0[];
extern u8 lbl_1_data_3C2B4__fzgx_offset_0[];
extern u8 lbl_1_data_3C2C4__fzgx_offset_0[];
extern u8 lbl_1_data_3C2D4__fzgx_offset_0[];
extern u8 lbl_1_data_3C2E8__fzgx_offset_0[];
extern u8 lbl_1_data_3C2F8__fzgx_offset_0[];
extern u8 lbl_1_data_3C30C__fzgx_offset_0[];
extern u8 lbl_1_data_3C320__fzgx_offset_0[];
extern u8 lbl_1_data_3C334__fzgx_offset_0[];
extern u8 lbl_1_data_3C348__fzgx_offset_0[];
extern u8 lbl_1_data_3C360__fzgx_offset_0[];
extern u8 lbl_1_data_3C374__fzgx_offset_0[];
extern u8 lbl_1_data_3C388__fzgx_offset_0[];
extern u8 lbl_1_data_3C398__fzgx_offset_0[];
extern u8 lbl_1_data_3C3A8__fzgx_offset_0[];
extern u8 lbl_1_data_3C3B8__fzgx_offset_0[];
extern u8 lbl_1_data_3C3CC__fzgx_offset_0[];
extern u8 lbl_1_data_3C3DC__fzgx_offset_0[];
extern u8 lbl_1_data_3C3F4__fzgx_offset_0[];
extern u8 lbl_1_data_3C404__fzgx_offset_0[];
extern u8 lbl_1_data_3C418__fzgx_offset_0[];
extern u8 lbl_1_data_3C42C__fzgx_offset_0[];
extern u8 lbl_1_data_3C440__fzgx_offset_0[];
extern u8 lbl_1_data_3C450__fzgx_offset_0[];
extern u8 lbl_1_data_3C460__fzgx_offset_0[];
extern u8 lbl_1_data_3C470__fzgx_offset_0[];
extern u8 lbl_1_data_3C484__fzgx_offset_0[];
extern u8 lbl_1_data_3C498__fzgx_offset_0[];
extern u8 lbl_1_data_3C4AC__fzgx_offset_0[];
extern u8 lbl_1_data_3C4C0__fzgx_offset_0[];
extern u8 lbl_1_data_3C4D8__fzgx_offset_0[];
extern u8 lbl_1_data_3C4F4__fzgx_offset_0[];
extern u8 lbl_1_data_3C50C__fzgx_offset_0[];
extern u8 lbl_1_data_3C520__fzgx_offset_0[];
extern u8 lbl_1_data_3C538__fzgx_offset_0[];
extern u8 lbl_1_data_3C550__fzgx_offset_0[];
extern u8 lbl_1_data_3C568__fzgx_offset_0[];
extern u8 lbl_1_data_3C578__fzgx_offset_0[];
extern void fn_1_A2DC4(u32);

static inline s8 tab_index(s8 c) {
	const s8 *p = (const s8 *)&lbl_1_data_34348;
	s32 k;
	for (k = 0; k < 10; k++) {
		if (c == *p) {
			return k;
		}
		p++;
	}
	return 0;
}

#pragma opt_loop_invariants off
void fn_1_A8270(struct fn_1_A8270_Arg0 *self, s32 arg1) {
	s32 i;
	u32 *out;
	u32 unk_104;
	struct fn_1_A8270_Entry *ent;
	struct fn_1_A8270_Rec *rec;
	s32 ok;
    s32 lab_t0;

	unk_104 = self->unk_104;
	out = (u32 *)fn_80077A18();
	lbl_8006DAEC();
	for (i = 0; i < self->unk_100; i++) {
		ent = &self->unk_FC[i];
		rec = (struct fn_1_A8270_Rec *)fn_80071268( (void *)(u32)(unk_104), (void *)(u32)(ent->unk_4));
		if (rec != 0) {
			lbl_8006D9D8(&self->unk_F0);
			mathutil_mtxA_rotate_z(self->unk_EE);
			lab_t0 = self->unk_EA;
			mathutil_mtxA_rotate_y(lab_t0);
			mathutil_mtxA_rotate_x(self->unk_EC);
			if (self->unk_E9 != 0) {
				lbl_8006E0A4( (void *)((u32)&lbl_1_data_35654[self->unk_E8 * 12]));
			}
			if (self->unk_E9 != 0) {
				lbl_8006E14C(((const f32 *)lbl_1_data_355A4)[self->unk_E8]);
			}
			ok = 1;
			if ((rec->unk_4 & 0xC) != 0 && ent->unk_8 != 0) {
				s32 j;
				for (j = 0; j < (s32)rec->count; j++) {
					const s8 *str = (const s8 *)ent->unk_8;
					u8 c = str[j];
					s8 idx = tab_index(c);
					out[j] = (u32)(void *)&self->unk_12C[idx * 12];
				}
			} else if ((rec->unk_4 & 0xC) != 0) {
				fn_80077A20(rec, 0);
			} else {
				ok = 0;
			}
			if (ok != 0) {
				if (arg1 != 0) {
					lbl_8006E14C(((f32 *)(lbl_1_rodata_4A34))[0]);
					fn_1_55FC4(((f32 *)(lbl_1_rodata_4A34))[0]);
				}
				fn_80072558();
				fn_1_556B8( (void *)(struct fn_1_A8270_Rec *)(rec));
			}
		}
	}
	lbl_8006DB30();
}
#pragma opt_loop_invariants reset
