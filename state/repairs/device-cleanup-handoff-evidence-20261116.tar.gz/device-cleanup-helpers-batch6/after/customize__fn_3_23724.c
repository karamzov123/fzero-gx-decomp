#include "types.h"
#include "rel/customize/globals.h"
#include "rel/customize/toolkit.h"


extern u32 lbl_801A6410;
extern void fn_1_46B4(u32, u32, u8 *, int);
extern const f32 lbl_3_rodata_740;
extern void fn_3_1ABD8(void *arg0, s16 x1, s16 y1, s16 x2, s16 y2, u32 *value);
extern void fn_3_1B130(void *, s16, s16, u32 *);
extern void fn_3_149AC(void);
extern void fn_3_1BA20(void *target, s16 x, s16 y, s16 z, s16 w, s32 *value);
extern void fn_3_1BF08(void *, s16, s16, s16, s16, u32 *);
extern u8 lbl_3_bss_A2458[8];
extern void fn_3_BD98(void);
extern void fn_3_BEF0(void);
extern void fn_3_BE88(void);
extern void fn_3_156A8(void);
extern void fn_80074188(s16, s16, s16, s16);
extern void fn_1_5233C(void *, void *);
extern struct fn_3_1A1D8_lbl_1_bss_9F8 lbl_1_bss_9F8;
extern u8 lbl_1_bss_38460[0x54];
extern u8 lbl_1_bss_7F0C0[];
extern u8 lbl_1_data_1E5C0[0x34];
extern u32 lbl_1_rodata_26F8;
extern u8 lbl_1_rodata_28B0[0x4];
extern u32 lbl_3_rodata_744[9];
extern f32 lbl_3_rodata_768[38];
extern const f32 lbl_3_rodata_8F0;
extern u32 lbl_801A66A0;
extern u32 lbl_801A66A8;
extern u8 lbl_801A66B4[0x4];
extern u32 lbl_801A6D00;
extern void fn_3_15240(void *, s32, s16, u16, s32, s16);
extern s32 lbl_1_data_416B8[][3];
extern char *fn_1_7F49C(s16, s16, char *);
extern void fn_3_240A4(void);
extern s32 fn_1_F8158(s32);
extern s32 fn_1_F809C(s32);
extern u8 lbl_3_data_3D50__fzgx_offset_0[];
extern u8 lbl_3_data_3D5C__fzgx_offset_0[];
extern u8 lbl_3_data_3D60__fzgx_offset_0[];
extern u8 lbl_3_data_3D6C__fzgx_offset_0[];
extern u8 lbl_3_data_3D74__fzgx_offset_0[];
extern u8 lbl_3_data_3D7C__fzgx_offset_0[];
extern u8 lbl_3_data_3D80__fzgx_offset_0[];
extern u8 lbl_3_data_3D88__fzgx_offset_0[];
extern u8 lbl_3_data_3D98__fzgx_offset_0[];
extern u8 lbl_3_data_3DA0__fzgx_offset_0[];
extern u8 lbl_3_data_3DB0__fzgx_offset_0[];
extern u8 lbl_3_data_3DBC__fzgx_offset_0[];
extern u8 lbl_3_data_3EBC__fzgx_offset_0[];
extern u8 lbl_3_data_3ED4__fzgx_offset_0[];
extern u8 lbl_3_data_3EF0__fzgx_offset_0[];
extern u8 lbl_3_data_3F08__fzgx_offset_0[];
extern u8 lbl_3_data_3F24__fzgx_offset_0[];
extern u8 lbl_3_data_3F58__fzgx_offset_0[];
extern u8 lbl_3_data_3F84__fzgx_offset_0[];
extern u8 lbl_3_data_3FAC__fzgx_offset_0[];
extern u8 lbl_3_data_3FBC__fzgx_offset_0[];
extern u8 lbl_3_data_3FCC__fzgx_offset_0[];
extern u8 lbl_3_data_3FDC__fzgx_offset_0[];
extern u8 lbl_3_data_3FEC__fzgx_offset_0[];
extern u8 lbl_3_data_3FFC__fzgx_offset_0[];
extern u8 lbl_3_data_4010__fzgx_offset_0[];
extern u8 lbl_3_data_4024__fzgx_offset_0[];
extern u8 lbl_3_data_4030__fzgx_offset_0[];
extern u8 lbl_3_data_403C__fzgx_offset_0[];
extern u8 lbl_3_data_4050__fzgx_offset_0[];
extern u8 lbl_3_data_407C__fzgx_offset_0[];
extern u8 lbl_3_data_409C__fzgx_offset_0[];
extern u8 lbl_3_data_40C0__fzgx_offset_0[];
extern u8 lbl_3_data_40DC__fzgx_offset_0[];
extern u8 lbl_3_data_4100__fzgx_offset_0[];
extern u8 lbl_3_data_4130__fzgx_offset_0[];
extern u8 lbl_3_data_4154__fzgx_offset_0[];
extern u8 lbl_3_data_418C__fzgx_offset_0[];
extern u8 lbl_3_data_41A8__fzgx_offset_0[];
extern u8 lbl_3_data_41D8__fzgx_offset_0[];
extern u8 lbl_3_data_41E0__fzgx_offset_0[];
extern u8 lbl_3_data_41EC__fzgx_offset_0[];
extern u8 lbl_3_data_41F4__fzgx_offset_0[];
extern u8 lbl_3_data_41FC__fzgx_offset_0[];
extern u8 lbl_3_data_4208__fzgx_offset_0[];
extern u8 lbl_3_data_4218__fzgx_offset_0[];
extern u8 lbl_3_data_4228__fzgx_offset_0[];
extern u8 lbl_3_data_423C__fzgx_offset_0[];
extern u8 lbl_3_data_424C__fzgx_offset_0[];
extern u8 lbl_3_data_4260__fzgx_offset_0[];
extern u8 lbl_3_data_4268__fzgx_offset_0[];
extern u8 lbl_3_data_4270__fzgx_offset_0[];
extern u8 lbl_3_data_4278__fzgx_offset_0[];
extern u8 lbl_3_data_4284__fzgx_offset_0[];
extern u8 lbl_3_data_428C__fzgx_offset_0[];
extern u8 lbl_3_data_429C__fzgx_offset_0[];
extern u8 lbl_3_data_42A4__fzgx_offset_0[];
extern u8 lbl_3_data_42B0__fzgx_offset_0[];
extern u8 lbl_3_data_42B8__fzgx_offset_0[];
extern u8 lbl_3_data_42C0__fzgx_offset_0[];
extern u8 lbl_3_data_42CC__fzgx_offset_0[];
extern u8 lbl_3_data_42D4__fzgx_offset_0[];
extern u8 lbl_3_data_42DC__fzgx_offset_0[];
extern u8 lbl_3_data_42E8__fzgx_offset_0[];
extern u8 lbl_3_data_42F0__fzgx_offset_0[];
extern u8 lbl_3_data_42F8__fzgx_offset_0[];
extern u8 lbl_3_data_4304__fzgx_offset_0[];
extern u8 lbl_3_data_4308__fzgx_offset_0[];
extern u8 lbl_3_data_430C__fzgx_offset_0[];
extern u8 lbl_3_data_4310__fzgx_offset_0[];
extern u8 lbl_3_data_4320__fzgx_offset_0[];
extern u8 lbl_3_data_4340__fzgx_offset_0[];
extern u8 lbl_3_data_4350__fzgx_offset_0[];
extern u8 lbl_3_data_436C__fzgx_offset_0[];
extern u8 lbl_3_data_4378__fzgx_offset_0[];
extern u8 lbl_3_data_4394__fzgx_offset_0[];
extern u8 lbl_3_data_43A0__fzgx_offset_0[];
extern u8 lbl_3_data_43BC__fzgx_offset_0[];
extern u8 lbl_3_data_43E4__fzgx_offset_0[];
extern u8 lbl_3_data_4408__fzgx_offset_0[];
extern u8 lbl_3_data_4440__fzgx_offset_0[];
extern u8 lbl_3_data_4470__fzgx_offset_0[];
extern u8 lbl_3_data_4488__fzgx_offset_0[];
extern u8 lbl_3_data_44A8__fzgx_offset_0[];
extern u8 lbl_3_data_44C8__fzgx_offset_0[];
extern u8 lbl_3_data_44EC__fzgx_offset_0[];
extern u8 lbl_3_data_44F4__fzgx_offset_0[];
extern u8 lbl_3_data_4500__fzgx_offset_0[];
extern u8 lbl_3_data_4510__fzgx_offset_0[];
extern u8 lbl_3_data_4524__fzgx_offset_0[];
extern u8 lbl_3_data_4530__fzgx_offset_0[];
extern u8 lbl_3_data_4540__fzgx_offset_0[];
extern u8 lbl_3_data_4564__fzgx_offset_0[];
extern u8 lbl_3_data_4590__fzgx_offset_0[];
extern u8 lbl_3_data_45A4__fzgx_offset_0[];
extern u8 lbl_3_data_45C0__fzgx_offset_0[];
extern u8 lbl_3_data_45D0__fzgx_offset_0[];
extern u8 lbl_3_data_45DC__fzgx_offset_0[];
extern u8 lbl_3_data_45F0__fzgx_offset_0[];
extern u8 lbl_3_data_460C__fzgx_offset_0[];
extern u8 lbl_3_data_4630__fzgx_offset_0[];
extern u8 lbl_3_data_463C__fzgx_offset_0[];
extern s32 fn_1_F965C(s16);
extern s32 fn_1_F9028(s16);
extern u32 fn_1_F8DC4(s16, s16, void *);
extern char *fn_1_F8E30(s16, s16, char *);
extern s16 lbl_1_bss_962;
extern u32 strlen(const char *);
extern f32 fn_1_4B040(const char *);
extern s16 lbl_3_bss_20844;

extern u32 lbl_801A6410;
extern void fn_1_46B4(u32, u32, u8 *, int);
extern const f32 lbl_3_rodata_740;
extern void fn_3_1ABD8(void *arg0, s16 x1, s16 y1, s16 x2, s16 y2, u32 *value);
extern void fn_3_1B130(void *, s16, s16, u32 *);
extern void fn_3_149AC(void);
extern void fn_3_1BA20(void *target, s16 x, s16 y, s16 z, s16 w, s32 *value);
extern void fn_3_1BF08(void *, s16, s16, s16, s16, u32 *);
extern u8 lbl_3_bss_A2458[8];
extern void fn_3_BD98(void);
extern void fn_3_BEF0(void);
extern void fn_3_BE88(void);
extern void fn_3_156A8(void);
extern void fn_80074188(s16, s16, s16, s16);
extern void fn_1_5233C(void *, void *);
extern struct fn_3_1A1D8_lbl_1_bss_9F8 lbl_1_bss_9F8;
extern u8 lbl_1_bss_38460[0x54];
extern u8 lbl_1_bss_7F0C0[];
extern u8 lbl_1_data_1E5C0[0x34];
extern u32 lbl_1_rodata_26F8;
extern u8 lbl_1_rodata_28B0[0x4];
extern u32 lbl_3_rodata_744[9];
extern f32 lbl_3_rodata_768[38];
extern const f32 lbl_3_rodata_8F0;
extern u32 lbl_801A66A0;
extern u32 lbl_801A66A8;
extern u8 lbl_801A66B4[0x4];
extern u32 lbl_801A6D00;
extern void fn_3_15240(void *, s32, s16, u16, s32, s16);
extern s32 lbl_1_data_416B8[][3];
extern char *fn_1_7F49C(s16, s16, char *);
extern void fn_3_240A4(void);
extern s32 fn_1_F8158(s32);
extern s32 fn_1_F809C(s32);
extern u8 lbl_3_data_3D50__fzgx_offset_0[];
extern u8 lbl_3_data_3D5C__fzgx_offset_0[];
extern u8 lbl_3_data_3D60__fzgx_offset_0[];
extern u8 lbl_3_data_3D6C__fzgx_offset_0[];
extern u8 lbl_3_data_3D74__fzgx_offset_0[];
extern u8 lbl_3_data_3D7C__fzgx_offset_0[];
extern u8 lbl_3_data_3D80__fzgx_offset_0[];
extern u8 lbl_3_data_3D88__fzgx_offset_0[];
extern u8 lbl_3_data_3D98__fzgx_offset_0[];
extern u8 lbl_3_data_3DA0__fzgx_offset_0[];
extern u8 lbl_3_data_3DB0__fzgx_offset_0[];
extern u8 lbl_3_data_3DBC__fzgx_offset_0[];
extern u8 lbl_3_data_3EBC__fzgx_offset_0[];
extern u8 lbl_3_data_3ED4__fzgx_offset_0[];
extern u8 lbl_3_data_3EF0__fzgx_offset_0[];
extern u8 lbl_3_data_3F08__fzgx_offset_0[];
extern u8 lbl_3_data_3F24__fzgx_offset_0[];
extern u8 lbl_3_data_3F58__fzgx_offset_0[];
extern u8 lbl_3_data_3F84__fzgx_offset_0[];
extern u8 lbl_3_data_3FAC__fzgx_offset_0[];
extern u8 lbl_3_data_3FBC__fzgx_offset_0[];
extern u8 lbl_3_data_3FCC__fzgx_offset_0[];
extern u8 lbl_3_data_3FDC__fzgx_offset_0[];
extern u8 lbl_3_data_3FEC__fzgx_offset_0[];
extern u8 lbl_3_data_3FFC__fzgx_offset_0[];
extern u8 lbl_3_data_4010__fzgx_offset_0[];
extern u8 lbl_3_data_4024__fzgx_offset_0[];
extern u8 lbl_3_data_4030__fzgx_offset_0[];
extern u8 lbl_3_data_403C__fzgx_offset_0[];
extern u8 lbl_3_data_4050__fzgx_offset_0[];
extern u8 lbl_3_data_407C__fzgx_offset_0[];
extern u8 lbl_3_data_409C__fzgx_offset_0[];
extern u8 lbl_3_data_40C0__fzgx_offset_0[];
extern u8 lbl_3_data_40DC__fzgx_offset_0[];
extern u8 lbl_3_data_4100__fzgx_offset_0[];
extern u8 lbl_3_data_4130__fzgx_offset_0[];
extern u8 lbl_3_data_4154__fzgx_offset_0[];
extern u8 lbl_3_data_418C__fzgx_offset_0[];
extern u8 lbl_3_data_41A8__fzgx_offset_0[];
extern u8 lbl_3_data_41D8__fzgx_offset_0[];
extern u8 lbl_3_data_41E0__fzgx_offset_0[];
extern u8 lbl_3_data_41EC__fzgx_offset_0[];
extern u8 lbl_3_data_41F4__fzgx_offset_0[];
extern u8 lbl_3_data_41FC__fzgx_offset_0[];
extern u8 lbl_3_data_4208__fzgx_offset_0[];
extern u8 lbl_3_data_4218__fzgx_offset_0[];
extern u8 lbl_3_data_4228__fzgx_offset_0[];
extern u8 lbl_3_data_423C__fzgx_offset_0[];
extern u8 lbl_3_data_424C__fzgx_offset_0[];
extern u8 lbl_3_data_4260__fzgx_offset_0[];
extern u8 lbl_3_data_4268__fzgx_offset_0[];
extern u8 lbl_3_data_4270__fzgx_offset_0[];
extern u8 lbl_3_data_4278__fzgx_offset_0[];
extern u8 lbl_3_data_4284__fzgx_offset_0[];
extern u8 lbl_3_data_428C__fzgx_offset_0[];
extern u8 lbl_3_data_429C__fzgx_offset_0[];
extern u8 lbl_3_data_42A4__fzgx_offset_0[];
extern u8 lbl_3_data_42B0__fzgx_offset_0[];
extern u8 lbl_3_data_42B8__fzgx_offset_0[];
extern u8 lbl_3_data_42C0__fzgx_offset_0[];
extern u8 lbl_3_data_42CC__fzgx_offset_0[];
extern u8 lbl_3_data_42D4__fzgx_offset_0[];
extern u8 lbl_3_data_42DC__fzgx_offset_0[];
extern u8 lbl_3_data_42E8__fzgx_offset_0[];
extern u8 lbl_3_data_42F0__fzgx_offset_0[];
extern u8 lbl_3_data_42F8__fzgx_offset_0[];
extern u8 lbl_3_data_4304__fzgx_offset_0[];
extern u8 lbl_3_data_4308__fzgx_offset_0[];
extern u8 lbl_3_data_430C__fzgx_offset_0[];
extern u8 lbl_3_data_4310__fzgx_offset_0[];
extern u8 lbl_3_data_4320__fzgx_offset_0[];
extern u8 lbl_3_data_4340__fzgx_offset_0[];
extern u8 lbl_3_data_4350__fzgx_offset_0[];
extern u8 lbl_3_data_436C__fzgx_offset_0[];
extern u8 lbl_3_data_4378__fzgx_offset_0[];
extern u8 lbl_3_data_4394__fzgx_offset_0[];
extern u8 lbl_3_data_43A0__fzgx_offset_0[];
extern u8 lbl_3_data_43BC__fzgx_offset_0[];
extern u8 lbl_3_data_43E4__fzgx_offset_0[];
extern u8 lbl_3_data_4408__fzgx_offset_0[];
extern u8 lbl_3_data_4440__fzgx_offset_0[];
extern u8 lbl_3_data_4470__fzgx_offset_0[];
extern u8 lbl_3_data_4488__fzgx_offset_0[];
extern u8 lbl_3_data_44A8__fzgx_offset_0[];
extern u8 lbl_3_data_44C8__fzgx_offset_0[];
extern u8 lbl_3_data_44EC__fzgx_offset_0[];
extern u8 lbl_3_data_44F4__fzgx_offset_0[];
extern u8 lbl_3_data_4500__fzgx_offset_0[];
extern u8 lbl_3_data_4510__fzgx_offset_0[];
extern u8 lbl_3_data_4524__fzgx_offset_0[];
extern u8 lbl_3_data_4530__fzgx_offset_0[];
extern u8 lbl_3_data_4540__fzgx_offset_0[];
extern u8 lbl_3_data_4564__fzgx_offset_0[];
extern u8 lbl_3_data_4590__fzgx_offset_0[];
extern u8 lbl_3_data_45A4__fzgx_offset_0[];
extern u8 lbl_3_data_45C0__fzgx_offset_0[];
extern u8 lbl_3_data_45D0__fzgx_offset_0[];
extern u8 lbl_3_data_45DC__fzgx_offset_0[];
extern u8 lbl_3_data_45F0__fzgx_offset_0[];
extern u8 lbl_3_data_460C__fzgx_offset_0[];
extern u8 lbl_3_data_4630__fzgx_offset_0[];
extern u8 lbl_3_data_463C__fzgx_offset_0[];
extern s32 fn_1_F965C(s16);
extern s32 fn_1_F9028(s16);
extern u32 fn_1_F8DC4(s16, s16, void *);
extern char *fn_1_F8E30(s16, s16, char *);
extern s16 lbl_1_bss_962;
extern u32 strlen(const char *);
extern f32 fn_1_4B040(const char *);
extern s16 lbl_3_bss_20844;

extern u32 lbl_801A6410;
extern void fn_1_46B4(u32, u32, u8 *, int);
extern const f32 lbl_3_rodata_740;
extern void fn_3_1ABD8(void *arg0, s16 x1, s16 y1, s16 x2, s16 y2, u32 *value);
extern void fn_3_1B130(void *, s16, s16, u32 *);
extern void fn_3_149AC(void);
extern void fn_3_1BA20(void *target, s16 x, s16 y, s16 z, s16 w, s32 *value);
extern void fn_3_1BF08(void *, s16, s16, s16, s16, u32 *);


extern void fn_3_BD98(void);
extern void fn_3_BEF0(void);
extern void fn_3_BE88(void);
extern void fn_3_156A8(void);
extern void fn_80074188(s16, s16, s16, s16);
extern void fn_1_5233C(void *, void *);



#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.699999988079071f;
}
static const u32 fzgx_pool_table2[6] = {0xFFFFFF00, 0xFFFF0000, 0xFF000000, 0x0000FF00, 0xFFF200FF, 0xFFFF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.4583333432674408f;
    s = 284.0f;
    s = 329.0f;
    s = 100.0f;
    s = 0.9166666865348816f;
    s = 360.0f;
    s = 0.5416666865348816f;
    s = 441.0f;
    s = 332.0f;
    s = 345.0f;
    s = 358.0f;
    s = 0.48749998211860657f;
    s = 395.0f;
    s = 331.0f;
    s = 359.0f;
    s = 320.0f;
    s = 362.0f;
    s = 200.0f;
    s = 323.0f;
    s = 381.0f;
    s = 13.0f;
    s = 0.007843137718737125f;
    s = 6.0f;
    s = 7.0f;
    s = 0.14901961386203766f;
    s = 0.12941177189350128f;
    s = 132.0f;
    s = 150.0f;
    s = 0.800000011920929f;
    s = 0.30000001192092896f;
}
static const u32 fzgx_pool_table4[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table6[43] = {0x00004A00, 0x00005400, 0x00003800, 0x00003E00, 0x00003700, 0x00005500, 0x00003000, 0x00003500, 0x00003A00, 0x00004000, 0x00004400, 0x00005000, 0x00003300, 0x00002E00, 0x00003100, 0x00004F00, 0x00003900, 0x00003D00, 0x00004C00, 0x00003F00, 0x00004800, 0x00005200, 0x00004500, 0x00005300, 0x00003C00, 0x00005600, 0x00004300, 0x00004200, 0x00003200, 0x00002F00, 0x00003400, 0x00003600, 0x00004D00, 0x00004600, 0x00004100, 0x00005100, 0x00004E00, 0x00004700, 0x00003B00, 0x00004B00, 0x00004900, 0xFFF200FF, 0xFFFF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 380.0f;
    s = 334.0f;
    s = 0.40625f;
}
static const u32 fzgx_pool_table8[6] = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 480.0f;
    s = 640.0f;
    s = 62.0f;
    s = 1.3411765098571777f;
    s = 8.0f;
    s = 0.125f;
    s = 1.0f;
    s = 0.5f;
    s = 215.0f;
    s = 3.0f;
    s = 180.0f;
    s = 90.0f;
    s = 240.0f;
    s = 44.0f;
    s = 89.9000015258789f;
    s = 40.0f;
    s = 16384.0f;
    s = 65536.0f;
    s = 60.0f;
    s = 80.0f;
    s = 460.0f;
    s = 0.6666666865348816f;
    s = 0.6078431606292725f;
    s = -3.0f;
    s = 0.0f;
    s = 0.6196078658103943f;
    s = 0.5058823823928833f;
    s = 216.0f;
    s = 0.20000000298023224f;
    s = 140.0f;
    s = 250.0f;
    s = 400.0f;
    s = 550.0f;
    s = 0.46666666865348816f;
    d = 4503599627370496.0;
}
static const u32 fzgx_pool_table10[9] = {0x00000000, 0x41200000, 0xC0A00000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep10(void) { const u32 *volatile cp; cp = fzgx_pool_table10; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime11(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -0.5f;
    s = 182.04444885253906f;
    s = 10.0f;
}
static const u32 fzgx_pool_table12[6] = {0x00000000, 0x41200000, 0xC0A00000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep12(void) { const u32 *volatile cp; cp = fzgx_pool_table12; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime13(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 3.75f;
    s = 3.5f;
    s = 0.05000000074505806f;
}
static const u32 fzgx_pool_table14[6] = {0x00000000, 0x41200000, 0xC0A00000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep14(void) { const u32 *volatile cp; cp = fzgx_pool_table14; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime15(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.25f;
}
static const u32 fzgx_pool_table16[6] = {0x00000000, 0x41200000, 0xC0A00000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep16(void) { const u32 *volatile cp; cp = fzgx_pool_table16; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime17(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 3.5176470279693604f;
    s = 8.79411792755127f;
    s = 10.55294132232666f;
    s = 315.0f;
    s = 2.0f;
    s = 1.2999999523162842f;
    s = 0.6000000238418579f;
    s = 0.6274510025978088f;
    s = 0.7529411911964417f;
    s = 3.5999999046325684f;
    s = 9.0f;
}
static const u32 fzgx_pool_table18[2] = {0x00000000, 0x41200000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep18(void) { const u32 *volatile cp; cp = fzgx_pool_table18; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime19(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -5.0f;
}
static const u32 fzgx_pool_table20[16] = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000003, 0x00020001, 0x00000001, 0x00020003, 0x00000000, 0x40A00000, 0xC1700000, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep20(void) { const u32 *volatile cp; cp = fzgx_pool_table20; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime21(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 5.211764812469482f;
}
static const u32 fzgx_pool_table22[2] = {0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep22(void) { const u32 *volatile cp; cp = fzgx_pool_table22; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime23(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -0.21176470816135406f;
}
static const u32 fzgx_pool_table24[13] = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00FFFF00, 0x00FFFF00, 0x00FF0000, 0x00FF0000, 0x00FF0000, 0x00FF0000, 0xFFFF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep24(void) { const u32 *volatile cp; cp = fzgx_pool_table24; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime25(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 266.0f;
    s = 120.0f;
    s = 547.0f;
    s = 173.0f;
    s = 23.0f;
    s = 223.0f;
    s = 257.0f;
    s = 20.0f;
    s = 12.0f;
    s = 67.75f;
    s = 2.5f;
    s = 0.3499999940395355f;
    s = 0.15000000596046448f;
    s = 11.0f;
    s = 16.0f;
}
static const u32 fzgx_pool_table26[4] = {0x00FFFF00, 0x00FFFF00, 0x00FF0000, 0x00FF0000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep26(void) { const u32 *volatile cp; cp = fzgx_pool_table26; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime27(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 286.0f;
    s = 153.0f;
    s = 277.0f;
    s = -71.0f;
    s = 172.0f;
    s = 63.0f;
    s = 4.0f;
    s = 24.0f;
    s = 5.0f;
}
static const u32 fzgx_pool_table28[1] = {0x00170018};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep28(void) { const u32 *volatile cp; cp = fzgx_pool_table28; }  /* fzgx-allow: S2 pool primer sink */
#pragma section code_type ".text"

struct fn_3_23724_Unk88 {
    u32 field00;
    f32 field04;
    f32 field08;
    f32 field0C;
    u32 field10[18];
};


extern void fn_1_50190(void *, f32, f32, f32, f32, f32, f32);
extern void fn_1_50164(f32, f32, f32, f32, void *);

void fn_3_23724(s16 arg0, s16 arg1, s16 arg2, f32 arg3, f32 arg4, f32 arg5, f32 arg6) {
    struct fn_3_23724_Unk88 u;
    f32 t0;
    f32 t1;
    f32 t2;
    f32 t3;
    f32 t4;
    f32 t5;
    f32 t6;
    f32 lab_t3;
    t0 = arg4 - 4.0f;
    t1 = t0 - 24.0f;
    u = *(struct fn_3_23724_Unk88 *)(void *)(*(u8 (*)[])&lbl_1_rodata_26F8);
    u.field00 = 0x8921;
    u.field04 = (f32)arg0;
    u.field08 = (f32)arg1;
    u.field0C = (f32)arg2;
    u.field10[8] = 6;
    lab_t3 = 7.0f;
    fn_1_50190(&u, arg3, arg4, lab_t3, 7.0f, 23.0f, 7.0f);
    t2 = t1 * (((arg6) < 0.0f) ? 0.0f : (((arg6) > 1.0f) ? 1.0f : (arg6)));
    u = *(struct fn_3_23724_Unk88 *)(void *)(*(u8 (*)[])&lbl_1_rodata_26F8);
    u.field00 = 0x8902;
    u.field04 = (f32)arg0;
    t4 = (24.0f + (f32)(t1 * (((arg5) < 0.0f) ? 0.0f : (((arg5) > 1.0f) ? 1.0f : (arg5)))) < (((f32)(((t2) / 2.0f))) + (24.0f)))
        ? (((f32)(t2 / 2.0f) + 24.0f))
        : ((t3 = 24.0f) + (f32)(t1 * (((arg5) < 0.0f) ? 0.0f : (((arg5) > 1.0f) ? 1.0f : (arg5)))) > t0 - (f32)(((t2) / 2.0f)))
        ? t0 - (f32)(((t2) / 2.0f))
        : t3 + (f32)(t1 * (((arg5) < 0.0f) ? 0.0f : (((arg5) > 1.0f) ? 1.0f : (arg5))));
    t5 = (((((f32)arg1)) + ((t4))));
    u.field08 = t5;
    u.field0C = (f32)(arg2 - 1);
    u.field10[8] = 10;
    fn_1_50164(12.0f, t2, 5.0f, 5.0f, &u);
}
