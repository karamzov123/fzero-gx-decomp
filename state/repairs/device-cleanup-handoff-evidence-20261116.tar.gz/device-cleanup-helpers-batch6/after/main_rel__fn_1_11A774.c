#include "types.h"
#include "psvec.h"
#include "types.h"
#include "types.h"
#include "types.h"
#include "types.h"
#include "types.h"

#ifndef GAME_MAIN_REL_CAR_TEST_TYPES_H
#define GAME_MAIN_REL_CAR_TEST_TYPES_H
#ifndef REL_MAIN_REL_GLOBALS_H
#define REL_MAIN_REL_GLOBALS_H

// lbl_1_data_3FFBC: .data size 0x574, referenced by 31 functions, shape {}
extern u8 lbl_1_data_3FFBC[0x574];

#endif  // REL_MAIN_REL_GLOBALS_H
#ifndef REL_MAIN_REL_CAR_TEST_H
#define REL_MAIN_REL_CAR_TEST_H

#endif  // REL_MAIN_REL_CAR_TEST_H

/* end rel/main_rel/car_test.h */

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} Fn183D28Vec3;

extern void lbl_8006E1B0(Fn183D28Vec3 *, Fn183D28Vec3 *);

#endif  // GAME_MAIN_REL_CAR_TEST_TYPES_H

/* end game/main_rel/car_test_types.h */
/* begin game/vec3.h (deltawave784/windows-and-types@cf9407c75) */
#ifndef GAME_VEC3_H
#define GAME_VEC3_H

// Three-float vector shared by the main_rel type headers (camera, car, font, ghost,
// live_camera each carried an identical private copy); Vec3f likewise (car, screen_effect,
// stcoli). Hand-owned (librarian).


typedef struct Vec3 {
    f32 x;
    f32 y;
    f32 z;
} Vec3;

typedef struct Vec3f {
    f32 x, y, z;
} Vec3f;
#endif  // GAME_VEC3_H
#ifndef REL_MAIN_REL_ACCESSORY_H
#define REL_MAIN_REL_ACCESSORY_H

#endif  // REL_MAIN_REL_ACCESSORY_H

/* end rel/main_rel/accessory.h */

struct Sig_fn_80077B14_fn_80077B14_Arg0 {
 u8 pad_0[4]; u32 unk_4; u8 pad_8[0x18]; u32 unk_20;
};
typedef struct { f32 x,y,z; } Sig_fn_1_1286F4_Vec3f;
extern s32 fn_80077B14(struct Sig_fn_80077B14_fn_80077B14_Arg0 *);
extern void fn_1_1286F4(Sig_fn_1_1286F4_Vec3f *);
extern void lbl_8006DBAC(Vec3 *);
extern void lbl_8006DAEC(void);
extern void lbl_8006DBE4(void);
extern void lbl_8006DC20(void);
extern f32 lbl_8006D118(f32, f32 *);
extern f32 lbl_8006D0B4(f32);
extern f32 lbl_8006D0E8(f32);
extern void fn_8006E250(Vec3f *, Vec3f *);
extern const u8 lbl_1_rodata_7AB8[];
typedef struct Node {
 u8 flags, pad1, count, pad3;
 u16 links[6];
 Fn183D28Vec3 pos,prev,local,vel;
 f32 weight;
} Node;
typedef struct { Node *a,*b; f32 length; } Link;
typedef struct { u8 pad[8]; u8 *base; } Model;
typedef struct { u8 pad[0x88]; s32 kind; u8 pad8c[0x150 - 0x8c]; Model *model; } Owner;
typedef struct { u8 flags; u8 pad[7]; u32 index; Owner *owner;
 struct Sig_fn_80077B14_fn_80077B14_Arg0 *obj;
 u32 pad14,count,linkCount,pad20; Node *nodes; Link *links; } Work;
#define F(o) (*(const f32 *)(pool+(o)))
#define D(o) (*(const f64 *)(pool+(o)))
#define INDEX(i) (((u32 *)lbl_1_data_3FFBC)[i])
#define SPHERE(BASE, CX, CY, CZ, RADIUS, STRENGTH) { \
 Fn183D28Vec3 diff; \
 Fn183D28Vec3 center; \
 f32 scale; \
 f32 cx,cy,cz; \
 cz=CZ; cy=CY; cx=CX; \
 center.x=cx; center.y=cy; center.z=cz; \
 lbl_8006DBAC((Vec3 *)(arg0->owner->model->base+BASE)); \
 lbl_8006E1B0(&center,&center); \
 for(ki=0,kn=arg0->nodes;ki<arg0->count;ki++,kn++) { \
 if(!(kn->flags&1)) { \
 f32 x,z,y,r; \
 x=kn->pos.x; y=kn->pos.y; z=kn->pos.z; \
 x-=center.x; y-=center.y; z-=center.z; \
 r=(f32)(x*x)+y*y+z*z; \
 if(r<RADIUS) { \
 scale=STRENGTH*lbl_8006D0E8(r); \
 psvec_sub_scale_add(&kn->pos,&center,scale,&diff,&kn->pos); \
 } \
 } \
 } \
}


#define delta (*dp)
static inline void fn_1_11A774_constrain(const u8 *pool, Node *a, Node *b, Link *l, f32 *len, Fn183D28Vec3 *dp) {
 f32 wb;
 f32 inv;
 f32 s;
 f32 wa;
 f32 fb;
 f32 r;
 f32 fa;
 f32 cx;
 f32 cy;
 f32 cz;
 f32 x;
 inv=lbl_8006D118(*len,len);
 r=lbl_8006D0B4((l->length));
 s=inv*(*len-r);
 *len=s;
 cx=delta.x*s; cy=delta.y*s; cz=delta.z*s;
 wa=a->weight; wb=b->weight;
 x=a->pos.x;
 delta.x=cx; delta.y=cy; delta.z=cz;
 r=F(0xa0)/(wa+wb);
 fa=wa*r; fb=wb*r;
 a->pos.x=x-(f32)(cx*fa);
 a->pos.y-=(f32)(cy*fa);
 a->pos.z-=(f32)(cz*fa);
 b->pos.x+=(f32)(cx*fb);
 b->pos.y+=(f32)(cy*fb);
 b->pos.z+=(f32)(cz*fb);
}
#undef delta
#define LINKFIX { fn_1_11A774_constrain(pool,a,b,l,&len,dp); }
#pragma opt_common_subs off
static inline void fn_1_11A774_loop0(Work *arg0) {
 u32 i1;
 Node *n1;
 for(i1=0,n1=arg0->nodes;i1<arg0->count;i1++,n1++) {
 lbl_8006DBE4();
 lbl_8006E1B0(&n1->local,&n1->pos);
 }
}

void fn_1_11A774(Work *arg0) {
 const u8 *pool=lbl_1_rodata_7AB8;
 u8 *fmodel;
 u32 i3;
 u32 k;
 Link *l;
 Node *kn;
 Node *fn;
 Node *n3;
 Node *a;
 u32 fj;
 u8 *model3;
 u32 ki;
 Node *vn;
 u32 fi;
 u32 li;
 u32 vi;
 u16 *lp;
 Node *b;
 Node *n2;
 u32 i2;
 f32 c68;
 f32 c404;
 f32 c410;
 f32 c424;
 f32 c2b4;
 f32 c418;
 f32 c41c;
 f32 c3b4;
 f32 c414;
 Fn183D28Vec3 deltav;
 Fn183D28Vec3 random;
 Fn183D28Vec3 *dp = &deltav;
#define delta (*dp)
 f32 len;
 if(arg0 && arg0->obj) {
 fn_80077B14(arg0->obj);
 if(arg0->flags & 2) {
 arg0->flags &= ~2;
 lbl_8006DBAC((Vec3 *)(arg0->owner->model->base+INDEX(arg0->index)*396+136));
 lbl_8006DAEC();
 fn_1_11A774_loop0(arg0);
 lbl_8006DC20();
 }
 for(i2=0,n2=arg0->nodes;i2<arg0->count;i2++,n2++) {
 if(!(n2->flags&1)) {
 n2->prev=n2->pos;
 n2->pos.x+=n2->vel.x;
 n2->pos.y+=n2->vel.y;
 n2->pos.z+=n2->vel.z;
 n2->pos.y-=D(0x58);
 n2->vel.y-=F(0x60);
 }
 }
 model3=arg0->owner->model->base+INDEX(arg0->index)*396;
 for(i3=0,n3=arg0->nodes;i3<arg0->count;i3++,n3++) {
 lbl_8006DBAC((Vec3 *)(model3+136));
 lbl_8006DAEC();
 if(n3->flags&1) {
 lbl_8006DBE4();
 lbl_8006E1B0(&n3->local,&n3->pos);
 }
 lbl_8006DC20();
 }
 for(k=0;k<8;k++) {
 c68=F(0x68); c404=F(0x404); c410=F(0x410); c414=F(0x414); c2b4=F(0x2b4); c418=F(0x418); c41c=F(0x41c); c3b4=F(0x3b4); c424=F(0x424);
 for(li=0,l=arg0->links;li<arg0->linkCount;li++,l++) {
 a=l->a; b=l->b;
 if(a && b) {
 f32 y;
 f32 wa;
 f32 x;
 f32 inv;
 f32 s;
 f32 cz;
 f32 cy;
 f32 r;
 f32 cx;
 f32 fa;
 f32 wb;
 f32 z;
 f32 fb;
 x=a->pos.x-b->pos.x;
 y=a->pos.y-b->pos.y;
 z=a->pos.z-b->pos.z;
 delta.x=x; delta.y=y; delta.z=z;
 len=(f32)(x*x)+y*y+z*z;
 if(len-F(0x9c)>(l->length)) LINKFIX
 if(F(0x1a4)+len<(l->length)) LINKFIX
 }
 }
 SPHERE(532,c404,c68,c68,F(0x408),F(0x40c))
 SPHERE(532,c2b4,c414,c410,F(0x398),F(0x2a8))
 SPHERE(532,c2b4,c414,c68,F(0x398),F(0x2a8))
 SPHERE(532,c2b4,c414,c418,F(0x398),F(0x2a8))
 SPHERE(532,c41c,c414,c410,F(0x420),F(0xc4))
 SPHERE(532,c41c,c414,c68,F(0x420),F(0xc4))
 SPHERE(532,c41c,c414,c418,F(0x420),F(0xc4))
 SPHERE(0x1948,c424,c3b4,c68,F(0x3f8),F(0x3fc))
 }
 for(vi=0,vn=arg0->nodes;vi<arg0->count;vi++,vn++) {
 fn_1_1286F4((Sig_fn_1_1286F4_Vec3f *)&random);
 vn->vel.x*=D(0x190); vn->vel.y*=D(0x190); vn->vel.z*=D(0x190);
 vn->vel.x+=(f64)(D(0x188)*(vn->pos.x-vn->prev.x));
 vn->vel.y+=(f64)(D(0x188)*(vn->pos.y-vn->prev.y));
 vn->vel.z+=(f64)(D(0x188)*(vn->pos.z-vn->prev.z));
 vn->vel.x+=(f64)(D(0x198)*random.x); vn->vel.y+=(f64)(D(0x198)*random.y); vn->vel.z+=(f64)(D(0x198)*random.z);
 }
 fmodel=(u8 *)fn_80077B14(arg0->obj);
 lbl_8006DBAC((Vec3 *)(arg0->owner->model->base+INDEX(arg0->index)*396+136));
 for(fi=0,fn=arg0->nodes;fi<arg0->count;fi++,fn++) {
 for(fj=0,lp=(u16 *)fn;(s32)fj<fn->count;lp++,fj++) {
 fn_8006E250((Vec3f *)&fn->pos,(Vec3f *)(fmodel+(lp[2]<<6)));
 }
 }
 }
}
#pragma opt_common_subs reset
