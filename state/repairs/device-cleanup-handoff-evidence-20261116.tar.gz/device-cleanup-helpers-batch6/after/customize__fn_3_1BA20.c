#include "types.h"
#include "rel/customize/globals.h"
#include "rel/customize/toolkit.h"
#include "font.h"
#include "types.h"

/* begin game/vec3.h (deltawave784/fzgx, CC0) */
#ifndef GAME_VEC3_H
#define GAME_VEC3_H

// Three-float vector shared by the main_rel type headers (camera, car, font, ghost,
// live_camera each carried an identical private copy); Vec3f likewise (car, screen_effect,
// stcoli). Hand-owned (librarian).


typedef struct Vec3 {
    f32 x;
    f32 y;
    f32 z;
} Vec3;

typedef struct Vec3f {
    f32 x, y, z;
} Vec3f;

#endif  // GAME_VEC3_H

/* end game/vec3.h */





struct QView {
    u8 unk_0;
    u8 pad_1[0x3];
    u32 unk_4;
    u32 unk_8;
    u8 pad_C[0x2];
    u8 unk_E;
    u8 pad_F[0x1];
    u8 unk_10;
};

typedef struct CustomizeData {
    u32 unk_00[2];
    u32 unk_08;
    u8 pad_0c[0x14];
    void *unk_20;
} CustomizeData;

struct fn_3_1A1D8_lbl_1_bss_9F8_0_E20 {
    u8 pad_0[0x10];
    u16 unk_10;
    u8 pad_12[0x2];
};

struct fn_3_1A1D8_lbl_1_bss_9F8 {
    struct fn_3_1A1D8_lbl_1_bss_9F8_0_E20 unk_0[1];
};

struct fn_3_1A264_lbl_1_bss_9F8_10_E20 {
    u16 unk_0;
    u8 pad_2[0x12];
};

struct fn_3_1A264_lbl_1_bss_9F8 {
    u8 pad_0[0x10];
    struct fn_3_1A264_lbl_1_bss_9F8_10_E20 unk_10[1];
};

typedef struct {
    u8 r, g, b, a;
} QColor;

typedef struct { u32 id; f32 x,y,z; u32 rest[18]; } Packet23524;

struct fn_3_1D338_sprite {
    u32 unk0;
    f32 x;
    f32 y;
    f32 z;
    u8 pad10[0x1C];
    f32 unk2C;
    u32 unk30;
    u8 pad34[4];
    u8 color[4];
    u8 pad3C[0x14];
    void (*draw)(void *, void *);
    u8 pad54[4];
};

struct fn_3_23724_Copy88 {
    u32 flags;
    f32 x, y, z;
    u32 pad[8];
    u32 mode;
    u32 tail[9];
};

typedef struct {
    u32 flags;
    u8 pad[0x1c];
} fn_3_1F81C_CustomizeEntry;

typedef struct CustomizeObject CustomizeObject;

struct CustomizeObject {
    u8 pad0[0x18];
    u16 count;
    u8 pad1[0x26];
    fn_3_1F81C_CustomizeEntry entries[1];
    u8 pad2[0xc];
    f32 value;
};

typedef struct {
    CustomizeObject *object;
} CustomizeSlot;

typedef struct {
    u8 pad0[8];
    CustomizeSlot *slot;
} CustomizeManager;

typedef struct {
    u8 pad0[0xc];
    CustomizeManager *manager;
} CustomizeRoot;

struct fn_3_20374_lbl_1_data_1E5C0 {
u32 unk_0,unk_4,unk_8; f32 unk_C,unk_10,unk_14; u32 unk_18,unk_1C,unk_20,unk_24,unk_28,unk_2C,unk_30;
};

struct fn_3_23724_lbl_3_rodata_768 {
    u8 pad_0[0x78];
    f32 seven;
    u8 pad_7C[0x10C];
    f32 one;
    f32 half;
    u8 pad_190[0x40];
    f32 zero;
    u8 pad_1D4[0x180];
    f32 twentythree;
    u8 pad_358[0xC];
    f32 twelve;
    u8 pad_368[0x40];
    f32 unk_3A8;
    f32 unk_3AC;
    f32 five;
};

struct fn_3_2BFB4_lbl_3_rodata_768 {
    u8 pad_0[0x22C];
    f32 unk_22C;
    u8 pad_230[0x1E8];
    f32 unk_418;
    u8 pad_41C[0x25C];
    f32 unk_678;
};

struct fn_3_2C164_lbl_3_rodata_768 {
    u8 pad_0[0x22C];
    f32 unk_22C;
    u8 pad_230[0x1E8];
    f32 unk_418;
    u8 pad_41C[0x25C];
    f32 unk_678;
};

struct fn_3_20374_lbl_3_rodata_768 {
f32 unk_0; u8 pad_4[0x94]; f64 unk_98; u8 pad_A0[0xE8]; f32 unk_188;
u8 pad_18C[0x6C]; f64 unk_1F8; u8 pad_200[0x28]; f32 unk_228;
u8 pad_22C[0x5C]; f32 unk_288,unk_28C,unk_290,unk_294,unk_298,unk_29C,unk_2A0,unk_2A4,unk_2A8;
};

typedef struct Sig_fn_1_87610_Fn187610Data {
u8 pad_000[2]; s8 field_002; u8 pad_003[0x205]; u8 field_208[0x120];
} Sig_fn_1_87610_Fn187610Data;

typedef struct Sig_fn_8006F038_Vec3 { f32 x,y,z; } Sig_fn_8006F038_Vec3;

struct fn_3_2B268_lbl_1_bss_7F0C0 {
    u8 pad_0[0x48F8];
    u32 unk_48F8;
};

typedef struct Sig_fn_1_8D210_fn_1_8D210_car {
    f32 position[6];
    f32 scale_z;
    f32 scale_y;
    f32 scale_x;
    f32 field_24;
    u16 field_28;
    u16 field_2a;
    u16 field_2c;
    u16 field_2e;
    u16 field_30;
    u16 field_32;
    u32 field_34;
    u8 field_38;
    u8 field_39;
    u8 field_3a;
    u8 pad_3b;
    u32 field_3c;
    u8 field_40;
    u8 pad_41[3];
    f32 field_44;
    f32 field_48;
    f32 field_4c;
    f32 field_50;
    s16 field_54;
    u8 pad_56[2];
    s32 field_58;
    u8 field_5c[4];
    u32 field_60;
} Sig_fn_1_8D210_fn_1_8D210_car;

typedef s32 (*Sig_fn_1_8D210_fn_1_8D210_callback)(u32);

struct fn_3_2BFB4_lbl_801A66B4 {
    u32 unk_0;
};

typedef struct Rgba {
    u8 r, g, b, a;
} Rgba;

typedef struct {
    u32 unk_0;
    u32 unk_4;
    u32 unk_8;
    Vec3 pos;
    u32 unk_18[7];
} Fn3_1FF7C_Camera;

typedef struct {
    u8 pad_0[0x60];
    Vec3 pos;
    f32 unk_6C;
} Fn3_1FF7C_Mtx;

typedef struct {
    u32 flags;
    u8 pad_4[0x1C];
} Fn3_1FF7C_Entry;

typedef struct {
    u8 pad_0[0x18];
    u16 count;
    u8 pad_1A[0x26];
    Fn3_1FF7C_Entry entries[1];
} Fn3_1FF7C_Model;


typedef struct {
    u8 pad_0[0x8];
    u16 unk_8;
    u8 pad_A[0x6];
    u16 unk_10;
    u16 unk_12;
} fn_3_1A648_Pad;

typedef struct fn_3_273F4_Pool {
    u8 pad_0[0x1c];
    f32 unk_1C;
    u8 pad_20[0x40];
    f32 unk_60;
    u8 pad_64[0x11c];
    f32 unk_180;
    u8 pad_184[0x4];
    f32 unk_188;
    u8 pad_18C[0x44];
    f32 unk_1D0;
    u8 pad_1D4[0x58];
    f32 unk_22C;
    u8 pad_230[0x14c];
    f32 unk_37C;
    u8 pad_380[0x74];
    f32 unk_3F4;
    u8 pad_3F8[0xc];
    f32 unk_404;
    u8 pad_408[0x10];
    f32 unk_418;
    u8 pad_41C[0xf8];
    f32 unk_514;
    u8 pad_518[0x4];
    f32 unk_51C;
    u8 pad_520[0x24];
    f32 unk_544;
    u8 pad_548[0x1c];
    f32 unk_564;
    u8 pad_568[0x34];
    u32 unk_59C;
    u32 unk_5A0;
    u32 unk_5A4;
    u32 unk_5A8;
    f32 unk_5AC;
    f32 unk_5B0;
    f32 unk_5B4;
    f32 unk_5B8;
    f32 unk_5BC;
    f32 unk_5C0;
    f32 unk_5C4;
    f32 unk_5C8;
    f32 unk_5CC;
} fn_3_273F4_Pool;
extern const f32 lbl_3_rodata_740;
extern void fn_3_1B130(void *data, s16 x, s16 y, Rgba color);
extern void fn_3_BE10(void);
extern void fn_3_BEF0(void);
extern void fn_3_1445C(void);
extern void fn_3_BE88(void);
extern void fn_80008BA8(u32 *, void *, s32);
extern s32 fn_8008023C(u32 arg0, u32 arg1, u32 arg2);
extern struct fn_3_1A1D8_lbl_1_bss_9F8 lbl_1_bss_9F8;
extern u32 fn_3_141A8(u32);
extern u8 fn_3_1443C(void);
extern u32 fn_3_14064(void);
extern u32 fn_3_1401C(void);
extern u32 fn_3_1402C(u8 index);
extern void fn_1_A2D84(u32 arg0);
extern void fn_80008BEC(void *dest, int value, u32 size);
extern void fn_3_1B4BC(void *, s16, s16, s16, s16, u32 *);
extern void fn_3_149AC();
extern void fn_3_14794(void *, u32, u32, u32 *);
extern void fn_3_146C0(void *arg0, s16 x, s16 y, s16 delta, u32 *arg4);
extern u32 lbl_1_rodata_26F8;
extern u32 lbl_801A66A8;
extern u16 fn_1_A5DB0(void);
extern s32 fn_1_A5DC4(void);
extern f32 lbl_8006D188(s32);
extern void fn_1_50164();
extern void fn_1_49410(void);
extern void fn_1_4954C(f32 value);
extern void fn_1_4955C(f32 value1, f32 value2);
extern void fn_1_49590(f32 value);
extern void fn_1_495A0(f32 value);
extern void fn_1_495C8(u8 value);
extern void fn_1_4966C(f32 value1, f32 value2);
extern void fn_1_496FC(f32 value1, f32 value2);
extern void fn_1_49738(u32 value);
extern u32 fn_3_2B750(s16, s16);
extern void fn_3_2406C(void);
extern void fn_3_240DC(void *, void *);
extern void fn_1_5233C(void *arg0, void *arg1);
extern struct fn_3_20374_lbl_1_data_1E5C0 lbl_1_data_1E5C0;
extern u32 lbl_801A66A0;
extern CustomizeObject *lbl_801A6D00;
extern void fn_8006F038(Vec3 *arg0, Vec3 *arg1, s16 arg2);
extern void lbl_8006DCDC(void);
extern void fn_1_F7870(u32 value);
extern void lbl_8006DCA4(void);
extern void lbl_8006E0B4(f32, f32, f32);
extern void mathutil_mtxA_rotate_x(s32);
extern void mathutil_mtxA_rotate_y(s32);
extern u32 fn_1_56018(s32 value);
extern void lbl_8006D784(void *);
extern void fn_1_560F0(s32 index, void *arg);
extern void fn_80072558(void);
extern void fn_1_55210(CustomizeObject *);
extern void lbl_8006DB74(void*);
extern void fn_1_151BDC(u32 value);
extern void fn_1_14E2DC(void *, s16, f32);
extern void lbl_8006DBAC(Vec3 *);
extern void fn_1_FCFA4(void *);
extern void fn_1_50190(void *arg0, f32 farg0, f32 farg1, f32 farg2, f32 farg3, f32 farg4, f32 farg5);
extern f32 lbl_3_rodata_768[];
extern s32 fn_3_1FF7C(void);
extern s32 fn_3_837C(s16 arg0);
extern u32 fn_3_23A1C(u32, u32, u32, u32, u32);
extern u32 fn_3_26A34(u32, u32, u32);
extern u32 fn_3_1C278(s16, u8, u8, u8, u32, f32);
extern void fn_1_133DBC(void* arg0);
extern void fn_1_8D1EC(void *, s32 (*)(u32), void *);
extern void fn_1_134AD4(void);
extern u32 fn_1_13ABA8(u32);
extern void fn_1_138120(void *);
extern void fn_1_495B0(u32 value);
extern void fn_1_4965C(u8 value);
extern void fn_1_49748(f32 value);
extern void fn_1_49514(u32 *value);
extern void *fn_1_14EEC4(s16 index, void *obj, s16 subindex);
extern char *fn_1_14EA74(s32, char *, s16);
extern int fn_1_14EE00(s16 arg0, void *arg1, s16 arg2);
extern f32 fn_1_A6FE8(void);
extern u8 lbl_1_bss_7F0C0[];
extern u32 fn_3_1EFE4(void);
extern u32 lbl_801A66C0[1];
extern void fn_3_2A2F8(s16, s16, s16, s16, s32);
extern void fn_3_7A08(s16 *arg0, s16 *arg1, int arg2);
extern u32 fn_3_225F8(u32, u32, u32);
extern void fn_1_54278(u32 arg0, u32 arg1);
extern void fn_1_5428C(f32 value);
extern void fn_1_53BD8(void *, f32, f32, f32, f32, f32);
extern void fn_1_495FC(void);
extern u32 fn_3_2B778(s16, u32, u32, u32, u32);
extern f32 lbl_8006D118(f32 *, f32);
extern void fzgx_usef(f32);
extern void fzgx_used(f64);
extern void fzgx_usep(void *);
extern s32 fzgx_sink_s;
extern u32 fzgx_sink_u;
extern void fn_3_1AB34(void *obj, s16 start, s16 base, u32 *items);
extern u32 fn_3_17820();
extern void fn_3_1ADA4(void *, int, int, int, int);
extern void fn_3_1AE40(void *data, u32 x1, u32 y1, s16 x2, s16 y2);
extern void fn_3_1AEE4(void *data, u32 x1, u32 y1, u32 x2, u32 y2);
extern void fn_3_1B008(void *data, u32 x1, u32 y1, u32 x2, u32 y2);
extern u8 lbl_3_bss_A2458[8];
extern void fn_3_BD98(void);
extern u8 fn_3_1441C(void);
extern void fn_3_14008(void);
extern const QColor lbl_3_rodata_744[9];
extern void fn_3_152BC(u32, s32, s32, s32, s32, QColor);
extern void fn_3_14E18(void *arg0, u32 arg1, u32 arg2, s16 arg3, u32 arg4);
extern const f32 lbl_3_rodata_8F0;
extern const f32 lbl_3_rodata_990[297];
extern CustomizeRoot lbl_1_bss_38460;
extern u32 fn_1_870BC(u32,u32,Sig_fn_1_87610_Fn187610Data*,u32,u32,f32);
extern void fn_1_5621C(f32 value0, f32 value1, f32 value2, f32 value3);
extern void lbl_8006D7DC(void*);
extern void lbl_8006DFE8(void*);
extern void lbl_8006E14C(f32);
extern s32 fn_3_1EC2C(u32);
extern void fn_3_23724(u32 arg0, u32 arg1, u32 arg2, f32 arg3, f32 arg4, f32 arg5, f32 arg6);
extern u32 fn_3_21300(u32,u32,u32);
extern u32 fn_80074188(u32 arg0, u32 arg1, u32 arg2, u32 arg3);
extern u32 fn_1_151E20(u32 value, s16 index);
extern void fn_1_A9868();
extern void fn_1_AA188(s32, s32, s32, s32, void *, void *, void *, void *);
extern void fn_1_AA538(void);
extern void fn_1_4E0F4(void);
extern s32 lbl_3_bss_24370;
extern f64 lbl_3_rodata_800;
extern void fn_1_51564(u16 first, u16 second, u16 third, u16 fourth, u16 fifth, u16 sixth);
extern void fn_1_5158C(FontDrawPacket *, u32, s16, s16);
extern int sprintf(char *s, const char *format, ...);
extern struct fn_3_2BFB4_lbl_801A66B4 lbl_801A66B4;
extern u8 fn_1_B7C00(void);
extern u32 lbl_801A6410;
extern void fn_1_46B4(u32 arg0, u32 arg1, const char *arg2, int arg3);
extern void fn_3_1ABD8(void *arg0, s16 x1, s16 y1, s16 x2, s16 y2, u32 *value);
extern void fn_3_1BA20(void *arg0, s16 arg1, s16 arg2, s16 arg3, s16 arg4, s32 *arg5);
extern void fn_3_1BF08(void *data, s16 x1, s16 y1, s16 x2, s16 y2, u32 *color);
extern void fn_3_156A8(void);
extern void fn_3_1ACE4(void *data, s32 first_a, s32 second_a, s32 first_b, s32 second_b, u32 *values);

#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = 24.0f;
    s = 86.0f;
    s = 100.0f;
    s = 385.0f;
    s = 170.0f;
    s = 104.0f;
    s = 40.0f;
    s = 96.0f;
    s = 90.0f;
    s = 0.5f;
    s = 20.0f;
    s = 60.0f;
    s = 80.0f;
    s = 15.0f;
    s = 30.0f;
    s = 320.0f;
    s = 372.0f;
    s = 0.10000000149011612f;
    s = 0.6000000238418579f;
    s = 375.0f;
    s = 0.75f;
    s = 248.0f;
    s = 1.0f;
    s = 0.800000011920929f;
    s = 240.0f;
    s = 25.0f;
    s = 1.0199999809265137f;
    s = 1.0099999904632568f;
    s = 0.4000000059604645f;
    s = 32768.0f;
    s = 10.0f;
    s = 81.0f;
    s = 399.0f;
    s = 18.0f;
    s = 12.0f;
    s = 0.0f;
    d = 4503601774854144.0;
    d = 4503599627370496.0;
}
static const unsigned long fzgx_pool_table2[3] = {0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const unsigned long *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile float s; volatile double d;  /* fzgx-allow: S2 pool primer sinks */
    s = -1.0f;
    d = 0.5;
    s = 2.0f;
    s = -2.0f;
    s = -4.0f;
    s = 4.0f;
}
#pragma section code_type ".text"


typedef struct { u32 value; } DrawColor;
static inline void draw(void *obj, s16 start, s16 base, DrawColor *items) {
    s32 half;
    s32 y;
    s16 width;
    s32 x;
    s16 i;
    u16 size;
    u32 item;

    size = lbl_3_bss_A2438.unk_C * 2 + 1;
    half = size >> 1;
    i = -half;
    x = base + i;
    y = start - half;
    width = size;
    while (i <= half) {
        item = items->value;
        fn_3_146C0(obj, y, x, width, &item);
        x++;
        i++;
    }
}

#pragma opt_propagation off
void fn_3_1BA20(void *arg0, s16 arg1, s16 arg2, s16 arg3, s16 arg4, s32 *arg5) {
    s32 v7, v1, v4, v3, v5;
    s16 v10;
    f32 loc_28;
    f32 t0;
    s16 v24, v22;
    s32 v21, v20, v19, v18;
    s16 v27, v28, v36, v44;
    s32 v26, v35, v43, v51;
    u16 v25, v34, v42, v50;
    s16 v32, v39, v47, v55;
    s32 v31, v40, v48, v54;
    u32 v23, v33, v41, v49;
    DrawColor loc_14, loc_10, loc_C, loc_8;
    f32 v59, v62, v68;

    v1 = arg3 - arg1;
    v4 = arg4 - arg2;
    v10 = __abs(v1) > __abs(v4) ? __abs(v1) : __abs(v4);
    t0 = lbl_8006D118(&loc_28, 1.0f);
    v21 = (s32)((f32)v10 * t0);
    v19 = (s32)(2.0f + (1.0f + (f32)((f32)(-2.0f * loc_28) * (f32)v10)));
    v18 = (s32)(1.0f + (2.0f + (f32)((f32)(-4.0f * loc_28) * (f32)v10)));
    v20 = 0;
    while ((s16)v21 >= 0) {
        v22 = (s16)v20;
        v24 = (s16)v21;
        loc_14 = *(DrawColor *)arg5;
        draw(arg0, arg1 + v24, arg2 + v22, &loc_14);
        loc_10 = *(DrawColor *)arg5;
        draw(arg0, arg1 - v24, arg2 + v22, &loc_10);
        loc_C = *(DrawColor *)arg5;
        draw(arg0, arg1 + v24, arg2 - v22, &loc_C);
        loc_8 = *(DrawColor *)arg5;
        draw(arg0, arg1 - v24, arg2 - v22, &loc_8);
        if ((s16)v19 < 0) {
            v20++;
            v19 = (s32)((f32)(s16)v19 + (2.0f + (f32)(4.0f * (f32)(s16)v20)));
            v18 = (s32)((f32)(s16)v18 + (f32)(4.0f * (f32)(s16)v20));
        } else if ((s16)v18 >= 0) {
            v21--;
            v19 = (s32)((f32)(s16)v19 - (f32)(4.0f * (f32)(s16)v21));
            v18 = (s32)((f32)(s16)v18 - ((f32)(4.0f * (f32)(s16)v21) - 2.0f));
        } else {
            v20++;
            v21--;
            v19 = (s32)((f32)(s16)v19 + (2.0f + ((f32)(4.0f * (f32)(s16)v20) - (f32)(4.0f * (f32)(s16)v21))));
            v18 = (s32)((f32)(s16)v18 + (2.0f + ((f32)(4.0f * (f32)(s16)v20) - (f32)(4.0f * (f32)(s16)v21))));
        }
    }
}
