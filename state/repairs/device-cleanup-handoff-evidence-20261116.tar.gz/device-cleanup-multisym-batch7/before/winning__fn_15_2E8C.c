#include "types.h"
#include "font.h"
extern f32 lbl_15_rodata_0[25];
extern u8 lbl_1_data_2A7E0[0xf8];
extern u32 lbl_1_rodata_26F8;
extern void *lbl_801A6410;
extern s32 lbl_801A66B4;
extern void fn_1_8F494(void *);
extern void lbl_8006D7DC(void *);
extern u32 fn_1_7ACDC(u32);
extern void fn_1_789E8(void);
extern void fn_1_78EBC(void);
extern void fn_1_7E9C4(void);
extern void fn_1_9A5CC(void);
extern void fn_1_9A7BC(void);
extern u8 lbl_1_data_2B0D4[];
extern char *lbl_1_data_2BD54[][6];
extern void fn_1_3EF14(void *);
extern void fn_1_520A0(void);
extern void fn_1_52070(u32);
extern void fn_1_141360(u8, s32, s32, s32, f32, f32);
extern void fn_1_520CC(void);
extern void fn_1_494DC(s16);
extern void fn_1_495B0(u32);
extern void fn_1_495C8(u8);
extern void fn_1_49590(f32);
extern void fn_1_495A0(f32);
extern void fn_1_50A90(void *, s32, s32, s32, s32);
extern void *memcpy(void *, const void *, u32);
extern int sprintf(char *, const char *, ...);
extern s16 fn_1_12EF24(s16, s16);
extern u16 fn_1_48690(u32);
extern void fn_1_CFCA4(const char *, f32, f32, f32);
extern void fn_1_4962C(void);
extern char *fn_1_5415C(s32, s32);
extern f64 __fabs(f64);
extern s32 fn_1_12CCB0(s16, s16);
extern s32 fn_1_12CB04(s16);
extern void fn_1_3F8C(void *, void *, void *, s32);
extern void *fn_1_435C(void *);
extern void *fn_1_4630(void *, u32, void *, s32);
extern void fn_1_46B4(void *, u32, void *, s32);
extern void fn_1_7EAE8();
extern u32 fn_1_C6F80(u32);
extern void *camera_get_state_object(void);
extern u8 lbl_15_bss_0__fzgx_offset_0[0x3F8];
extern const u8 lbl_15_rodata_0__fzgx_offset_0[0x1EC];

char lbl_15_data_0[8] = "WIN_1ST";
char lbl_15_data_8[8] = "WIN_2ND";
char lbl_15_data_10[8] = "WIN_3RD";
char lbl_15_data_18[8] = "WIN_4TH";
char *lbl_15_data_20[4] = {lbl_15_data_0, lbl_15_data_8, lbl_15_data_10, lbl_15_data_18};
char lbl_15_data_30[6] = "BLACK";
char lbl_15_data_38[5] = "GRAY";
char lbl_15_data_40[5] = "BLUE";
char lbl_15_data_48[7] = "WHITE?";
char *lbl_15_data_50[4] = {lbl_15_data_30, lbl_15_data_38, lbl_15_data_40, lbl_15_data_48};
char lbl_15_data_60[5] = "menu";
char lbl_15_data_68[8] = "winning";
extern void fn_15_3AC(void);
extern void fn_15_644(void);
extern void fn_15_B8C(void);
extern void fn_15_1D7C(void);
extern void fn_15_1DF4(void);
extern void fn_15_1EE0(void);
struct WinningScene {
    char *name;
    void (*init)(void);
    void (*main)(void);
    void (*exit)(void);
};
struct WinningScene lbl_15_data_70[2] = {
    {lbl_15_data_60, fn_15_3AC, fn_15_644, fn_15_B8C},
    {lbl_15_data_68, fn_15_1D7C, fn_15_1DF4, fn_15_1EE0},
};

#include "types.h"

struct fn_15_2E8C_bss0 {
    u8 pad_0[0x2C];
    u8 *unk_2C;
    u8 pad_30[0x8];
    s16 unk_38;
    u8 pad_3A[0x92];
    u16 unk_CC;
    u16 unk_CE;
    u8 unk_D0;
    u8 pad_D1[0x7B];
    s16 unk_14C;
};


extern s32 fn_1_12CB04(s16);
extern u32 fn_1_8E4A4(u32, u32, u32);

struct ResultAnimation {
    f32 ease, acceleration, velocity, x, y;
    s16 unknown_14;
    char label[20];
    char value[50];
};
struct ResultRow { u32 unknown_0; struct ResultAnimation anim; };
/* file-scope objects of the retail TU, in retail order: MWCC addresses them off one section base */
u16 lbl_15_bss_0;
u16 fzgx_pool_lbl_15_bss_0_fill_2;
u32 lbl_15_bss_4[2];
u32 lbl_15_bss_C;
u32 lbl_15_bss_10;
u32 lbl_15_bss_14;
s32 lbl_15_bss_14__fzgx_offset_4;
u32 lbl_15_bss_1C;
u8 fzgx_pool_lbl_15_bss_1C_fill_20;
u8 lbl_15_bss_1C__fzgx_offset_5;
u16 fzgx_pool_lbl_15_bss_21_fill_22;
u32 fzgx_pool_lbl_15_bss_21_fill_24[2];
u8 *lbl_15_bss_2C;
u32 fzgx_pool_lbl_15_bss_2C_fill_30;
u8 fzgx_pool_lbl_15_bss_2C_fill_34;
u8 fzgx_pool_lbl_15_bss_35_fill_35;
u16 fzgx_pool_lbl_15_bss_35_fill_36;
s16 lbl_15_bss_35__fzgx_offset_3;
u16 fzgx_pool_lbl_15_bss_35_fill_3A;
s16 lbl_15_bss_35__fzgx_offset_7;
u16 fzgx_pool_lbl_15_bss_35_fill_3E;
u32 fzgx_pool_lbl_15_bss_35_fill_40[13];
void *lbl_15_bss_74;
void *lbl_15_bss_78[4];
u32 lbl_15_bss_88[5];
u32 fzgx_pool_lbl_15_bss_9C_fill_9C[12];
u16 lbl_15_bss_9C__fzgx_offset_30;
u16 lbl_15_bss_9C__fzgx_offset_32;
u8 lbl_15_bss_D0;
u8 fzgx_pool_lbl_15_bss_0_fill_D1;
u16 fzgx_pool_lbl_15_bss_0_fill_D2;
u8 lbl_15_bss_D4;
u8 fzgx_pool_lbl_15_bss_D4_fill_D5;
u16 fzgx_pool_lbl_15_bss_D4_fill_D6;
u32 fzgx_pool_lbl_15_bss_D4_fill_D8[29];
s16 lbl_15_bss_D4__fzgx_offset_78;
u16 fzgx_pool_lbl_15_bss_D4_fill_14E;
u32 fzgx_pool_lbl_15_bss_D4_fill_150;
s16 lbl_15_bss_154;
u16 fzgx_pool_lbl_15_bss_154_fill_156;
struct ResultRow lbl_15_bss_154__fzgx_offset_4[7];

#pragma section code_type ".fzgxpool"
static void fzgx_bss_layout(void) {
    volatile u8 s;  /* fzgx-allow: S2 layout primer sink: MWCC emits .bss objects in first-access order */
    s = *(u8 *)&lbl_15_bss_0;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_0_fill_2;
    s = *(u8 *)&lbl_15_bss_4;
    s = *(u8 *)&lbl_15_bss_C;
    s = *(u8 *)&lbl_15_bss_10;
    s = *(u8 *)&lbl_15_bss_14;
    s = *(u8 *)&lbl_15_bss_14__fzgx_offset_4;
    s = *(u8 *)&lbl_15_bss_1C;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_1C_fill_20;
    s = *(u8 *)&lbl_15_bss_1C__fzgx_offset_5;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_21_fill_22;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_21_fill_24;
    s = *(u8 *)&lbl_15_bss_2C;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_2C_fill_30;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_2C_fill_34;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_35_fill_35;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_35_fill_36;
    s = *(u8 *)&lbl_15_bss_35__fzgx_offset_3;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_35_fill_3A;
    s = *(u8 *)&lbl_15_bss_35__fzgx_offset_7;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_35_fill_3E;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_35_fill_40;
    s = *(u8 *)&lbl_15_bss_74;
    s = *(u8 *)&lbl_15_bss_78;
    s = *(u8 *)&lbl_15_bss_88;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_9C_fill_9C;
    s = *(u8 *)&lbl_15_bss_9C__fzgx_offset_30;
    s = *(u8 *)&lbl_15_bss_9C__fzgx_offset_32;
    s = *(u8 *)&lbl_15_bss_D0;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_0_fill_D1;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_0_fill_D2;
    s = *(u8 *)&lbl_15_bss_D4;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_D4_fill_D5;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_D4_fill_D6;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_D4_fill_D8;
    s = *(u8 *)&lbl_15_bss_D4__fzgx_offset_78;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_D4_fill_14E;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_D4_fill_150;
    s = *(u8 *)&lbl_15_bss_154;
    s = *(u8 *)&fzgx_pool_lbl_15_bss_154_fill_156;
    s = *(u8 *)&lbl_15_bss_154__fzgx_offset_4;
}
#pragma section code_type ".text"
#pragma section code_type ".fzgxpool"
static void fzgx_data_base(void) {
    const void *volatile sink; /* fzgx-allow: S2 preserve retail section-base first-use order */
    sink = lbl_15_data_0;
    sink = lbl_15_data_8;
    sink = lbl_15_data_10;
}
#pragma section code_type ".text"
#pragma section code_type ".fzgxpool"
__declspec(section ".fzgxpool") static void fzgx_pool_prime1(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.0f;
}
static const u32 fzgx_pool_table2[21] = {0x00FF00FF, 0x808080FF, 0xFFFFFFFF, 0xC3ACEF3B, 0x43FC728F, 0x44241408, 0xC3AD35A2, 0x43FE58B4, 0x44243FBE, 0x00000000, 0x3F800000, 0x00000000, 0xC3ACEF3B, 0x43FC728F, 0x44241408, 0xC3AD35A2, 0x43FE58B4, 0x44243FBE, 0x00000000, 0x3F800000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep2(void) { const u32 *volatile cp; cp = fzgx_pool_table2; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime3(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 200.0f;
    s = 1.0f;
}
static const u32 fzgx_pool_table4[1] = {0xFFC800FF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep4(void) { const u32 *volatile cp; cp = fzgx_pool_table4; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime5(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 30.0f;
    d = 0.01;
    s = 2.0f;
    s = 320.0f;
    s = 240.0f;
    s = 20.0f;
    s = 10.0f;
    s = 0.5f;
    s = 3.0f;
    s = 0.03999999910593033f;
    d = 4503601774854144.0;
}
static const u32 fzgx_pool_table6[3] = {0x00000000, 0x00000000, 0x43480000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep6(void) { const u32 *volatile cp; cp = fzgx_pool_table6; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime7(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 0.6000000238418579f;
}
static const u32 fzgx_pool_table8[8] = {0x000000FF, 0x404040FF, 0x404088FF, 0xAAAAAAFF, 0xFF0000FF, 0x00000000, 0x00000000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep8(void) { const u32 *volatile cp; cp = fzgx_pool_table8; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime9(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 1.5f;
    s = -0.8999999761581421f;
}
static const u32 fzgx_pool_table10[5] = {0x00000003, 0x00040006, 0x00000000, 0x3F800000, 0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep10(void) { const u32 *volatile cp; cp = fzgx_pool_table10; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime11(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = -1.5f;
    s = -2.25f;
    s = -2.0f;
    s = 0.20000000298023224f;
    s = -0.20000000298023224f;
    s = -2.200000047683716f;
    s = 9.0f;
    s = 1.0399999618530273f;
    s = 1000.0f;
    s = 4.0f;
    s = 5.0f;
    s = -4.0f;
    s = 55.0f;
}
static const u32 fzgx_pool_table12[3] = {0x00FF00FF, 0x808080FF, 0xFFFFFFFF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep12(void) { const u32 *volatile cp; cp = fzgx_pool_table12; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime13(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 40.0f;
}
static const u32 fzgx_pool_table14[1] = {0x00FFFFFF};
static const u32 value_color_pool[1] = {0xFFFFFFFF};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep14(void) { const u32 *volatile cp; cp = fzgx_pool_table14; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime15(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    s = 540.0f;
    s = 60.0f;
    s = 234.0f;
    s = 11.0f;
    s = 142.0f;
    s = 296.0f;
    s = 324.0f;
    s = 0.800000011920929f;
}
static const f32 result_width[1] = {940.0f};
__declspec(section ".fzgxpool") static void keep_result_width(void) { const f32 *volatile cp; cp = result_width; } /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void prime_remaining(void) {
    volatile f32 s; /* fzgx-allow: S2 pool primer sink */
    s = 103.0f;
    s = 1.440000057220459f;
    s = 160.0f;
    s = 211.0f;
    s = 0.8399999737739563f;
    s = 141.0f;
    s = 180.0f;
    s = 27.0f;
    s = 224.0f;
    s = 117.0f;
    s = 23.0f;
    s = 1.2999999523162842f;
}
static const u32 fzgx_pool_table16[1] = {0x00000000};  /* fzgx-allow: A1 retail pool bytes */
__declspec(section ".fzgxpool") static void fzgx_pool_keep16(void) { const u32 *volatile cp; cp = fzgx_pool_table16; }  /* fzgx-allow: S2 pool primer sink */
__declspec(section ".fzgxpool") static void fzgx_pool_prime17(void) {
    volatile f32 s; volatile f64 d;  /* fzgx-allow: S2 pool primer sinks */
    d = 320.0;
    s = 250.0f;
    s = 1.559999942779541f;
    s = 0.4000000059604645f;
}
#pragma section code_type ".text"

struct fn_15_2E8C_data_90 {
    u8 pad_0[0x4];
    u32 unk_4;
    u32 unk_8;
    u32 unk_C;
    u32 unk_10;
};
struct fn_15_2E8C_data_90 lbl_15_data_90 = {
    {0x00U, 0x00U, 0x00U, 0x00U},
    0x00001248U,
    0x000012FCU,
    0x0000137EU,
    0x000019C8U
};
u8 lbl_15_data_A4[0xB0] = {
    0x77U, 0x69U, 0x6EU, 0x6EU, 0x69U, 0x6EU, 0x67U, 0x2EU, 0x63U, 0x00U, 0x00U, 0x00U, 0x50U, 0x75U, 0x73U, 0x68U, 0x20U, 0x3CU, 0x41U, 0x3EU, 0x20U, 0x74U, 0x6FU, 0x20U, 0x77U, 0x69U, 0x6EU, 0x6EU, 0x69U, 0x6EU, 0x67U, 0x20U, 0x72U, 0x75U, 0x6EU, 0x20U, 0x6DU, 0x6FU, 0x64U, 0x65U, 0x21U, 0x0AU, 0x00U, 0x00U, 0x43U, 0x41U, 0x52U, 0x3AU, 0x25U, 0x32U, 0x64U, 0x2CU, 0x20U, 0x54U, 0x59U, 0x50U, 0x45U, 0x3AU, 0x25U, 0x32U, 0x64U, 0x20U, 0x00U, 0x00U, 0x20U, 0x25U, 0x73U, 0x28U, 0x25U, 0x73U, 0x29U, 0x20U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x4CU, 0x3AU, 0x20U, 0x4FU, 0x4EU, 0x0AU, 0x00U, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x4CU, 0x3AU, 0x20U, 0x4FU, 0x46U, 0x46U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x51U, 0x3AU, 0x20U, 0x47U, 0x43U, 0x20U, 0x57U, 0x49U, 0x4EU, 0x4EU, 0x49U, 0x4EU, 0x47U, 0x20U, 0x52U, 0x55U, 0x4EU, 0x0AU, 0x00U, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x51U, 0x3AU, 0x20U, 0x47U, 0x43U, 0x20U, 0x56U, 0x53U, 0x20U, 0x3AU, 0x20U, 0x25U, 0x31U, 0x64U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x51U, 0x3AU, 0x20U, 0x41U, 0x43U, 0x20U, 0x31U, 0x73U, 0x74U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x00U, 0x53U, 0x45U, 0x51U, 0x3AU, 0x20U, 0x41U, 0x43U, 0x20U, 0x45U, 0x4EU, 0x44U, 0x0AU, 0x00U, 0x00U, 0x00U, 0x00U
};
u8 lbl_15_data_154[0xE] = "StaffRollMain";
u8 lbl_15_data_164[0x78] = {
    0x53U, 0x74U, 0x61U, 0x66U, 0x66U, 0x52U, 0x6FU, 0x6CU, 0x6CU, 0x44U, 0x69U, 0x73U, 0x70U, 0x00U, 0x00U, 0x00U, 0x57U, 0x69U, 0x6EU, 0x6EU, 0x69U, 0x6EU, 0x67U, 0x43U, 0x61U, 0x6CU, 0x63U, 0x00U, 0x4CU, 0x69U, 0x67U, 0x68U, 0x74U, 0x4DU, 0x61U, 0x69U, 0x6EU, 0x00U, 0x00U, 0x00U, 0x6DU, 0x6FU, 0x74U, 0x5FU, 0x6CU, 0x69U, 0x67U, 0x68U, 0x74U, 0x5FU, 0x63U, 0x61U, 0x6CU, 0x63U, 0x00U, 0x00U, 0x57U, 0x69U, 0x6EU, 0x6EU, 0x69U, 0x6EU, 0x67U, 0x44U, 0x69U, 0x73U, 0x70U, 0x00U, 0x6DU, 0x6FU, 0x74U, 0x5FU, 0x6CU, 0x69U, 0x67U, 0x68U, 0x74U, 0x5FU, 0x64U, 0x69U, 0x73U, 0x70U, 0x00U, 0x00U, 0x52U, 0x6FU, 0x62U, 0x45U, 0x78U, 0x65U, 0x63U, 0x00U, 0x73U, 0x65U, 0x74U, 0x5FU, 0x77U, 0x69U, 0x6EU, 0x6EU, 0x65U, 0x72U, 0x5FU, 0x72U, 0x61U, 0x6EU, 0x6BU, 0x00U, 0x52U, 0x6FU, 0x62U, 0x44U, 0x69U, 0x73U, 0x70U, 0x43U, 0x6CU, 0x69U, 0x70U, 0x00U
};

void fn_15_2E8C(void) {
    u8 *rec;
    s16 k;
    s16 c;
    s16 i;
    u32 *q;
    u8 *e;
    u8 f;
    s16 cnt;
    s16 n;
    s16 r;
    u32 acc;

    
    i = 0;
    q = (u32 *)((u8 *)&lbl_15_bss_D4);
    lbl_15_bss_9C__fzgx_offset_32 = 0;
    rec = lbl_15_bss_2C;
    lbl_15_bss_9C__fzgx_offset_30 = 0;
    lbl_15_bss_D0 = 0;

    for (; i < 0x16; i += 7) {
        q[0] = 0;
        q[1] = 0;
        q[2] = 0;
        q[3] = 0;
        q[4] = 0;
        q[5] = 0;
        q[6] = 0;
        q += 7;
    }
    q = (u32 *)((u8 *)&lbl_15_bss_D4) + i;
    for (; i < 0x1D; i++) {
        *q++ = 0;
    }

    cnt = lbl_15_bss_35__fzgx_offset_3;
    e = rec;
    acc = 0;
    for (n = 0; n < cnt; n++) {
        f = e[5];
        switch (f) {
        case 19:
            acc += 3;
            break;
        case 30:
            acc += 1;
            break;
        case 34:
            if (n == 0) {
                acc += 6;
            } else {
                acc += 3;
            }
            break;
        case 40:
            acc += 1;
            break;
        case 16:
            acc += 2;
            break;
        }
        e += 8;
    }
    lbl_15_bss_D4__fzgx_offset_78 = 26 - (u8)acc;

    for (k = 0; k < lbl_15_bss_D4__fzgx_offset_78; k++) {
        e = rec + ((k + lbl_15_bss_35__fzgx_offset_3) << 3);
        c = e[5];
        if (c >= 41) {
            c = *((u8 *)(*(u8 **)e) + 0x81A0);
        }
        r = fn_1_12CB04(c);
        switch (r) {
        case 2:
            lbl_15_bss_D0 = 1;
            fn_1_8E4A4(c, 0x10000000, 0x80000000);
            fn_1_8E4A4((s16)fn_1_12CCB0(c, 0), 0x10000000, 0x80000000);
            fn_1_8E4A4((s16)fn_1_12CCB0(c, 1), 0x10000000, 0x80000000);
            break;
        case 1:
            fn_1_8E4A4(c, 0x10000000, 0x80000000);
            fn_1_8E4A4((s16)fn_1_12CCB0(c, 0), 0x10000000, 0x80000000);
            break;
        case 0:
            fn_1_8E4A4(c, 0x10000000, 0x80000000);
            break;
        }
    }
}

/* winning .data 0x240-0x1EE4 */
char lbl_15_data_240[9] = "WIN_WAIT";
char lbl_15_data_24C[18] = "set_other_rob_pos";
char lbl_15_data_260[10] = "StageCalc";
char lbl_15_data_26C[15] = "BackGroundCalc";
char lbl_15_data_27C[8] = "FogMain";
char lbl_15_data_284[7] = "FogOff";
char lbl_15_data_28C[10] = "StageDisp";
char lbl_15_data_298[15] = "BackGroundDisp";
char lbl_15_data_2A8[7] = "Burner";
char lbl_15_data_2B0[11] = "BurnerDisp";
char lbl_15_data_2BC[22] = "EnemyTotalControlMain";
char lbl_15_data_2D4[17] = "%1d\x88\xCA : %s(%s) \n";
char lbl_15_data_2E8[13] = "\x94w\x8Ci \x81" "F %s \n";
char lbl_15_data_2F8[15] = "\x83p\x81[\x83X: %5.2f\n";
char lbl_15_data_308[14] = "BGM: \x81\xF4\x95\\\x8F\xB2" "AC";
char lbl_15_data_318[29] = "BGM: \x81\xF4\x95\\\x8F\xB2GC \x83" "E\x83" "C\x83j\x83\x93\x83O\x83\x89\x83\x93";
char lbl_15_data_338[44] = "BGM: \x81\xF4\x83t\x83@\x83\x8B\x83R\x83\x93\x82\xCC\x83" "e\x81[\x83}\x81iAC\x83G\x83\x93\x83" "f\x83" "B\x83\x93\x83O\x81j";
char lbl_15_data_364[7] = "DUMMY\n";

struct ResultRow lbl_15_data_36C[6][7] = {
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "MUTECITY", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TIME", "01'59\"980"}},
        {0xFFFFFFFF, {0.075f, 0.1f, 0.0f, 700.0f, 120.0f, -1, "BEST LAP", "00'12\"882"}},
        {0xFFFFFFFF, {0.07f, 0.11f, 0.0f, 700.0f, 150.0f, -1, "MAX SPEED", "1024"}},
        {0xFFFFFFFF, {0.065f, 0.13f, 0.0f, 700.0f, 180.0f, -1, "POINTS", "98"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 210.0f, -1, "ATTACK", "NONE"}},
    },
};
struct ResultRow lbl_15_data_132C[6][4] = {
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
    {
        {0x006400C8, {0.1f, 0.07f, 0.0f, 700.0f, 0.0f, -1, "RUBY CUP", ""}},
        {0xFFFFFFFF, {0.09f, 0.08f, 0.0f, 700.0f, 60.0f, -1, "TOTAL RANK", "1"}},
        {0xFFFFFFFF, {0.08f, 0.09f, 0.0f, 700.0f, 90.0f, -1, "TOTAL POINTS", "230"}},
        {0xFFFFFFFF, {0.06f, 0.16f, 0.0f, 700.0f, 120.0f, -1, "TOTAL ATTACK", "NONE"}},
    },
};

char *lbl_15_data_1C80[6][6] = {
    {"ALL CUP", "RUBY CUP", "SAPPHIRE CUP", "EMERALD CUP", "DIAMOND CUP", "AX CUP"},
    {"GER", "GER", "GER", "GER", "GER", NULL},
    {"FRA", "FRA", "FRA", "FRA", "FRA", NULL},
    {"SPA", "SPA", "SPA", "SPA", "SPA", NULL},
    {"ITA", "ITA", "ITA", "ITA", "ITA", NULL},
    {"ALL CUP", "RUBY CUP", "SAPPHIRE CUP", "EMERALD CUP", "DIAMOND CUP", "AX CUP"},
};
char *lbl_15_data_1D50[6][4] = {
    {"NOVICE CLASS", "STANDARD CLASS", "EXPERT CLASS", "MASTER CLASS"},
    {"GER", "GER", "GER", "GER"},
    {"FRA", "FRA", "FRA", "FRA"},
    {"SPA", "SPA", "SPA", "SPA"},
    {"ITA", "ITA", "ITA", "ITA"},
    {"NOVICE CLASS", "STANDARD CLASS", "EXPERT CLASS", "MASTER CLASS"},
};
char *lbl_15_data_1DB4[6] = {"PTS", "PTS", "PTS", "PTS", "PTS", "PTS"};
char *lbl_15_data_1DD4[6] = {"KM/H", "KM/H", "KM/H", "KM/H", "KM/H", "KM/H"};
s16 lbl_15_data_1DEC[6] = {700, 1100, 1500, 1900, 2300, 2700};
char *lbl_15_data_1E6C[6] = {"CONGRATULATIONS!!", "CONGRATULATIONS!!(GER)", "CONGRATULATIONS!!(FRA)", "CONGRATULATIONS!!(SPA)", "CONGRATULATIONS!!(ITA)", "CONGRATULATIONS!!"};
char *lbl_15_data_1ECC[6] = {"YOU GOT", "YOU GOT(GER)", "YOU GOT(FRA)", "YOU GOT(SPA)", "YOU GOT(ITA)", "YOU GOT"};

extern void fn_15_3368(s16);

struct fn_15_30E8_entry {
    u32 unk_0;
    u8 unk_4;
    u8 value;
    u8 unk_6[2];
};

struct fn_15_30E8_object {
    u8 unk_0[0x81a0];
    u8 value;
};

struct fn_15_30E8_lbl_15_bss_0 {
    u8 unk_0[0x2c];
    struct fn_15_30E8_entry *entries;
    u8 unk_30[8];
    s16 entry_offset;
    u8 unk_3a[0x112];
    s16 entry_count;
};

void fn_15_30E8(void) {
    struct fn_15_30E8_lbl_15_bss_0 *state;
    struct fn_15_30E8_entry *entry;
    s32 i;
    s16 value;

    state = &(*(struct fn_15_30E8_lbl_15_bss_0 *)&lbl_15_bss_0);
    entry = state->entries;
    i = 0;
    while (i < state->entry_count) {
        value = entry[i + state->entry_offset].value;
        if ((s16)value >= 0x29) {
            value = ((struct fn_15_30E8_object *)entry[i + state->entry_offset].unk_0)->value;
        }
        fn_15_3368((s16)value);
        i++;
    }
}

struct fn_15_3174_lbl_15_rodata_0 {
    f32 unk_0;
    u8 pad_4[0x58];
    f32 unk_5C;
    u8 pad_60[0x24];
    f32 unk_84;
    u8 pad_88[0x8];
    f64 unk_90;
    u8 pad_98[0x30];
    f32 unk_C8;
    u8 pad_CC[0x18];
    f32 unk_E4;
    f32 unk_E8;
    f32 unk_EC;
    f32 unk_F0;
    f32 unk_F4;
    f32 unk_F8;
};
struct fn_15_3174_lbl_1_data_2A7E0 {
    u8 pad_0[0x3C];
    u32 unk_3C;
};

extern u8 lbl_15_bss_D0;
extern void lbl_8006E1B0(void *, void *);

#pragma opt_propagation off
#pragma opt_lifetimes off
void fn_15_3174(void * arg0) {
    struct fn_15_3174_lbl_15_rodata_0 *p_lbl_15_rodata_0;
    u8 v0;
    u32 v1;
    s16 v2;
    f32 v3;
    f32 v4;
    f32 v5;
    f32 v6;
    f32 v7;
    f32 v8;
    f32 v9;
    f32 v11;
    f32 v10;
    u32 v12;
    f32 v13;
    f32 v14;
    f32 v15;
    void * v16;
    p_lbl_15_rodata_0 = (struct fn_15_3174_lbl_15_rodata_0 *)&(*(struct fn_15_3174_lbl_15_rodata_0 *)&lbl_15_rodata_0);
    v0 = *(u8 *)((u8 *)arg0 + 1220);
    v1 = (*(struct fn_15_3174_lbl_1_data_2A7E0 *)&lbl_1_data_2A7E0).unk_3C;
    v2 = (s16)v0;
    if (v2 < 8) {
    v3 = (0.0f);
    *(f32 *)((u8 *)arg0 + 168) = (f32)((-1.5f) + (f32)((0.5f) * (f32)(s32)v2));
    *(f32 *)((u8 *)arg0 + 172) = v3;
    *(f32 *)((u8 *)arg0 + 176) = v3;
    } else {
    if (v2 < 17) {
    v4 = (0.5f);
    v5 = (0.0f);
    *(f32 *)((u8 *)arg0 + 168) = (f32)((-2.25f) + (f32)(v4 * (f32)(s32)(v2 - 8)));
    *(f32 *)((u8 *)arg0 + 172) = v5;
    *(f32 *)((u8 *)arg0 + 176) = v4;
    } else {
    if (v2 < 26) {
    v6 = (0.0f);
    v7 = (1.0f);
    *(f32 *)((u8 *)arg0 + 168) = (f32)((-2.0f) + (f32)((0.5f) * (f32)(s32)(v2 - 17)));
    *(f32 *)((u8 *)arg0 + 172) = v6;
    *(f32 *)((u8 *)arg0 + 176) = v7;
    } else {
    v8 = (0.5f);
    v9 = (-2.25f);
    v10 = (1.5f);
    v11 = (0.200000003f);
    *(f32 *)((u8 *)arg0 + 168) = (f32)(v9 + (f32)(v8 * (f32)(s32)(v2 - 26)));
    *(f32 *)((u8 *)arg0 + 172) = v11;
    *(f32 *)((u8 *)arg0 + 176) = v10;
    }
    }
    }
    v12 = *(u32 *)((u8 *)arg0 + 136);
    if ((s32)v12 == 33 || (s32)v12 == 42 || (s32)v12 == 43) {
    v13 = (0.0f);
    *(f32 *)((u8 *)arg0 + 168) = (-2.20000005f);
    v14 = (-0.200000003f);
    *(f32 *)((u8 *)arg0 + 172) = v13;
    *(f32 *)((u8 *)arg0 + 176) = v14;
    }
    if ((s16)v0 == 26 && lbl_15_bss_D0 == 0) {
    v15 = (0.0f);
    *(f32 *)((u8 *)arg0 + 168) = (-2.0f);
    *(f32 *)((u8 *)arg0 + 172) = v15;
    *(f32 *)((u8 *)arg0 + 176) = v15;
    }
    lbl_8006D7DC((void *)(v1 + 16));
    v16 = (void *)(((u8 *)arg0 + 168));
    lbl_8006E1B0((void *)v16, (void *)v16);
    *(f32 *)((u8 *)arg0 + 184) = (1.0f);
}
#pragma opt_lifetimes reset

#pragma opt_propagation reset

#include "types.h"

struct fn_15_3368_data {
    u8 pad_0[0xa4];
    u8 unk_a4[0x114];
    u8 unk_1b8[0x18];
    u8 unk_1d0[0x70];
    u8 unk_240[0xc];
    u8 unk_24c[4];
};

struct fn_15_3368_bss {
    u8 pad_0[0x74];
    void *unk_74;
    void *unk_78;
    u8 pad_7c[0x50];
    s16 unk_cc;
    s16 unk_ce;
    u8 pad_d0[4];
    void *unk_d4[16];
};

struct fn_15_3368_obj {
    u8 pad_0[0x18];
    u32 unk_18;
    u8 pad_1c[0x4a8];
    u8 unk_4c4;
};

extern void fn_1_8F45C(void *, s16, u32, u32);
extern void fn_1_934CC(void *, void *, u8 *);
extern void fn_15_3174(void *);
extern void fn_1_8F62C(void *);
extern void fn_1_92530(void *);

#define FN_15_3368_SETUP(ID)                                                    \
    do {                                                                       \
        obj = fn_1_4630(lbl_801A6410, 0x4e0, data->unk_a4, 0x993);           \
        slot = bss->unk_cc;                                                    \
        tbl = bss->unk_d4;                                                     \
        tbl[slot] = obj;                                                       \
        obj = tbl[slot];                                                       \
        fn_1_8F45C(obj, ID, 0x10000000, 0x80000000);                           \
        fn_1_934CC(obj, (u8 *)obj + 0x148, data->unk_240);                     \
        obj->unk_18 |= 0xc0000000; /* fzgx-allow: A1 flag pair, not an address */ \
        obj->unk_4c4 = (u8)bss->unk_ce;                                        \
        fn_1_435C(bss->unk_74);                                                \
        fn_1_3F8C(data->unk_1b8, fn_1_8F62C, obj, 0xa);                        \
        fn_1_3F8C(data->unk_24c, fn_15_3174, obj, 0xb);                        \
        fn_1_435C(bss->unk_78);                                                \
        fn_1_3F8C(data->unk_1d0, fn_1_92530, obj, 0xa);                        \
    } while (0)

#pragma opt_common_subs off
void fn_15_3368(s16 arg0) {
    s32 tmp_call3;
    struct fn_15_3368_data *data;
    struct fn_15_3368_bss *bss;
    struct fn_15_3368_obj *obj;
    s32 id;
    s32 slot;
    s32 cid;
    s16 lab_t0;
    s32 cid_2;
    void **tbl;

    data = (struct fn_15_3368_data *)lbl_15_data_0;
    (void) data;  /* fzgx: keeps the web at its definition */
    bss = (struct fn_15_3368_bss *)lbl_15_bss_0__fzgx_offset_0;
    id = arg0;
    switch ((s16)fn_1_12CB04(id)) {
    case 2:
        FN_15_3368_SETUP(id);
        bss->unk_cc++;
        lab_t0 = id;
        tmp_call3 = fn_1_12CCB0(lab_t0, 0);
        cid = tmp_call3;
        FN_15_3368_SETUP(cid);
        bss->unk_cc++;
        lab_t0 = id;
        cid_2 = fn_1_12CCB0(lab_t0, 1);
        FN_15_3368_SETUP(cid_2);
        bss->unk_cc++;
        break;
    case 1:
        FN_15_3368_SETUP(id);
        bss->unk_cc++;
        lab_t0 = id;
        cid_2 = fn_1_12CCB0(lab_t0, 0);
        FN_15_3368_SETUP(cid_2);
        bss->unk_cc++;
        bss->unk_ce++;
        break;
    case 0:
        FN_15_3368_SETUP(id);
        bss->unk_cc++;
        bss->unk_ce++;
        break;
    }
}
#pragma opt_common_subs reset


#undef FN_15_3368_SETUP

extern void fn_1_469BC(void);

void fn_15_38FC(void) {
    u32 *p;
    s16 i;

    fn_1_469BC();
    p = (u32 *)&lbl_15_bss_D4;
    for (i = 0; i < 0x1D; i++) {
        if (p[i] != 0) {
            fn_1_8F494((void *)p[i]);
            fn_1_46B4(lbl_801A6410, p[i], (*(u8 (*)[176])&lbl_15_data_A4), 0x9DA);
            p[i] = 0;
        }
    }
}

struct fn_15_398C_entry {
    u8 pad_0[0x18];
    u32 flags;
};

struct fn_15_398C_state {
    u8 pad_0[0x14];
    u32 flags;
    u8 pad_18[0x84];
    struct fn_15_398C_entry *entries_9c[0xd4 / 4 - 0x9c / 4];
    struct fn_15_398C_entry *entries_d4[0x1d];
};



void fn_15_398C(void) {
    struct fn_15_398C_state *s;
    struct fn_15_398C_entry **p;
    struct fn_15_398C_entry *entry;
    s16 i;

    s = &(*(struct fn_15_398C_state *)&lbl_15_bss_0);
    s->flags |= 0x04000000;
    p = &s->entries_9c[0];
    for (i = 0; i < 0xc; i++) {
        entry = *p;
        if (entry != 0) {
            entry->flags &= 0x3FFFFFFF;
        }
        p++;
    }
    p = &s->entries_d4[0];
    for (i = 0; i < 0x1d; i++) {
        entry = *p;
        if (entry != 0) {
            entry->flags &= 0x3FFFFFFF;
        }
        p++;
    }
}

void fn_15_3A14(void) {
    u8 *p_lbl_15_data_0;
    p_lbl_15_data_0 = (u8 *)lbl_15_data_0;
    fn_1_435C(lbl_15_bss_74);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 608, fn_1_789E8, 0, 21);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 620, fn_1_9A5CC, 0, 23);
    fn_1_435C(lbl_15_bss_78[0]);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 636, fn_1_7E9C4, 0, 4);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 644, fn_1_7EAE8, 0, 29);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 652, fn_1_78EBC, 0, 7);
    fn_1_3F8C((u8 *)p_lbl_15_data_0 + 664, fn_1_9A7BC, 0, 10);
    fn_1_7EAE8();
    fn_1_7ACDC(50);
}

// fn_15_3AFC: empty in retail (single blr).
void fn_15_3AFC(void) {
}

extern u32 fn_1_79100(void);

void fn_15_3B00(void) {
    u32 t0;
    t0 = fn_1_79100();
    fn_1_7EAE8(t0);
}

#include "types.h"

typedef struct fn_15_3B24_Machine {
    u32 flags;
    u8 pad_4[0x81A0 - 0x4];
    u8 unk_81A0;
    u8 pad_81A1[3];
    u8 unk_81A4;
    u8 pad_81A5[7];
    u8 unk_81AC;
    u8 pad_81AD[7];
    u8 unk_81B4;
} fn_15_3B24_Machine;

typedef struct fn_15_3B24_Racer {
    fn_15_3B24_Machine *machine;
    u8 pad_4;
    u8 id;
    u8 color;
    u8 pad_7;
} fn_15_3B24_Racer;

typedef struct fn_15_3B24_Entry {
    s16 index;
    s16 id;
    s32 type;
    u8 color;
    u8 pad_9[3];
    u32 flags;
    u16 parts[4];
    s32 type_copy;
    u8 pad_1C[4];
} fn_15_3B24_Entry;

typedef struct fn_15_3B24_Work {
    u8 pad_0[0x14];
    u32 flags;
    u8 pad_18[0x9];
    u8 unk_21;
    u8 pad_22[0x2];
    void *heap_a;
    void *heap_b;
    fn_15_3B24_Racer *racers;
    u8 pad_30[0x4];
    u8 unk_34;
    u8 unk_35;
    u8 unk_36;
    u8 pad_37[0x3];
    s16 count;
    u8 pad_3C[0x2];
    u8 unk_3E;
    u8 pad_3F[0xD];
    u8 *objects;
    u8 pad_50[0x100];
    u32 *scene;
} fn_15_3B24_Work;

typedef struct fn_15_3B24_Rodata {
    f32 zero;
    u8 pad_4[0x54];
    f32 unk_58;
    f32 unk_5C;
    u8 pad_60[0xA4];
    f32 unk_104;
    f32 unk_108;
    f32 unk_10C;
    f32 unk_110;
} fn_15_3B24_Rodata;

typedef struct fn_15_3B24_Car {
    u8 pad_0[0x390];
    u32 unk_390;
    u8 pad_394[0x3BA - 0x394];
    s16 unk_3BA;
} fn_15_3B24_Car;

typedef struct fn_15_3B24_Model {
    u32 flags;
    u8 pad_4[0x8];
    f32 unk_C;
    u8 pad_10[0x22];
    u8 unk_32;
} fn_15_3B24_Model;

extern u8 lbl_1_data_28060[];

extern void *fn_1_45D0(void *, u32, void *, u32);
extern void fn_1_3CF0(void *, u32);
extern void fn_1_4310(u32);
extern void fn_1_981C4(void);
extern void fn_1_98230(void);
extern void fn_1_9835C(void);
extern void fn_1_584D4(void);
extern void fn_1_80058(s8, fn_15_3B24_Entry *);
extern void fn_80008BEC(void *, int, u32);
extern void fn_80008BA8(void *, void *, u32);
extern s32 fn_1_FA088(void);
extern void fn_1_FA0A0(void);
extern s32 fn_1_FA004(void);
extern void fn_1_FA01C(void);
extern void fn_1_81834(u8, s8, s8);
extern u8 *fn_1_83070(void *, void *, fn_15_3B24_Entry *, s16);
extern void fn_1_82724(void *, void *, fn_15_3B24_Entry *, s16, u32);
extern void fn_1_835E0(void *, void *, void *);
extern void fn_1_86194(f32);
extern void fn_1_817C0(void);
extern void *fn_1_86254(u32);
extern void fn_1_C3A0C(void *);
extern void fn_1_C42F4(void);
extern void fn_1_861B4(void);
extern fn_15_3B24_Car *fn_1_868C0(s8);
extern void fn_1_22E8C(void *, void *);

#pragma opt_propagation off
void fn_15_3B24(void) {
    fn_15_3B24_Racer *list;
    fn_15_3B24_Entry *entry;
    fn_15_3B24_Racer *racer;
    u8 *preset;
    fn_15_3B24_Work *work;
    u8 *str;
    const fn_15_3B24_Rodata *rodata;
    fn_15_3B24_Racer *racers;
    s16 i;
    fn_15_3B24_Racer *src;
    fn_15_3B24_Model *model;
    fn_15_3B24_Car *car;
    u8 *obj;
    s16 j;
    s16 slot;
    fn_15_3B24_Machine *machine;
    f32 scale;
    f32 x;
    fn_15_3B24_Entry entries[3];
    u8 buf[0xB4];

    rodata = (const fn_15_3B24_Rodata *)lbl_15_rodata_0__fzgx_offset_0;
    str = (u8 *)lbl_15_data_0;
    work = (fn_15_3B24_Work *)lbl_15_bss_0__fzgx_offset_0;
    list = work->racers;
    racers = list;
    work->unk_21 = 1;
    work->heap_a = fn_1_45D0(lbl_801A6410, 0x173C, str + 0xA4, 0xA4E);
    work->heap_b = fn_1_45D0(lbl_801A6410, 0x173C, str + 0xA4, 0xA4F);
    fn_1_3CF0(work->heap_a, 128);
    fn_1_3CF0(work->heap_b, 128);
    fn_1_981C4();
    fn_1_435C(work->heap_a);
    fn_1_3F8C(str + 0x2A8, fn_1_98230, NULL, 10);
    fn_1_435C(work->heap_b);
    fn_1_3F8C(str + 0x2B0, fn_1_9835C, NULL, 21);
    fn_1_584D4();
    work->scene = fn_1_4630(lbl_801A6410, 0x14B8, str + 0xA4, 0xA66);
    *work->scene |= 0x20C040;

    racer = racers;
    entry = entries;
    for (i = 0; i < work->count; i++) {
        fn_1_80058((s8)racer->id, entry);
        if (work->flags & 0x40) {
            slot = ((u8 *)racers)[0xF8];
        } else {
            slot = i;
        }
        entry->index = i;
        src = &racers[slot];
        entry->id = src->id;
        entry->color = src->color;
        switch ((31 - __cntlzw(entry->color)) & 3) {
        case 0:
            entry->color = 0x10;
            break;
        case 1:
            entry->color = 0x20;
            break;
        case 2:
            entry->color = 0x40;
            break;
        case 3:
            entry->color = 0x80;
            break;
        default:
            entry->color = 0x10;
            break;
        }
        entry->type = 2;
        if (entry->id >= 41) {
            machine = src->machine;
            if (machine != NULL && (machine->flags & 0x80000000)) {
                fn_80008BEC(entry->parts, 0, 16);
                if (machine->flags & 0x40000000) {
                    work->unk_3E = 1;
                    if (slot == 0) {
                        if (fn_1_FA088()) {
                            work->unk_34 = 1;
                            work->unk_36 = 1;
                            fn_1_FA0A0();
                        }
                        if (fn_1_FA004()) {
                            work->unk_35 = 1;
                            work->unk_36 = 1;
                            fn_1_FA01C();
                        }
                    }
                    entry->flags |= 0x4000000;
                    entry->parts[0] = machine->unk_81A4;
                    entry->parts[1] = machine->unk_81AC;
                    entry->parts[2] = machine->unk_81B4;
                } else {
                    entry->id = machine->unk_81A0;
                }
                entry->type_copy = entry->type;
            }
        }
        entry++;
        racer++;
    }

    fn_1_81834(0, -1, 0);
    work->objects = fn_1_83070(work->heap_a, work->heap_b, entries, work->count);
    fn_1_82724(work->heap_a, work->heap_b, entries, work->count, 1);
    fn_1_835E0(work->scene, work->heap_a, NULL);
    if (!(work->flags & 1)) {
        fn_1_86194(rodata->unk_104);
    } else if (work->flags & 0x78) {
        fn_1_86194(rodata->zero);
    } else {
        fn_1_86194(rodata->zero);
        fn_1_817C0();
    }
    fn_1_C3A0C(fn_1_86254(0));
    fn_1_435C(work->heap_a);
    fn_1_3F8C(str + 0x2BC, fn_1_C42F4, fn_1_86254(0), 2);
    fn_1_4310(0);
    fn_1_861B4();
    if (work->flags & 0x40000000) {
        fn_1_C6F80(1);
    }

    obj = work->objects;
    preset = lbl_1_data_28060 + 0x438;
    scale = rodata->unk_58;
    for (j = 0; j < work->count; j++, obj += 0x620) {
        model = *(fn_15_3B24_Model **)(obj + 0x484);
        car = fn_1_868C0((s8)j);
        car->unk_3BA = 1;
        if (!(work->flags & 0x78)) {
            model->unk_C = rodata->zero;
        }
        car->unk_390 |= 0x40000;
        model->flags |= 2;
        switch (j) {
        case 0:
            model->unk_32 = 0x22;
            x = rodata->zero;
            *(f32 *)(obj + 0x7C) = x;
            *(f32 *)(obj + 0x84) = rodata->unk_5C;
            x = rodata->zero;
            *(f32 *)(obj + 0x94) = x;
            *(f32 *)(obj + 0x98) = x;
            *(f32 *)(obj + 0x9C) = x;
            break;
        case 1:
            model->unk_32 = 0x23;
            x = rodata->unk_108;
            *(f32 *)(obj + 0x7C) = x;
            *(f32 *)(obj + 0x84) = rodata->unk_10C;
            x = rodata->zero;
            *(f32 *)(obj + 0x94) = x;
            *(f32 *)(obj + 0x98) = x;
            *(f32 *)(obj + 0x9C) = x;
            break;
        case 2:
            model->unk_32 = 0x24;
            x = rodata->unk_110;
            *(f32 *)(obj + 0x7C) = x;
            *(f32 *)(obj + 0x84) = rodata->unk_10C;
            x = rodata->zero;
            *(f32 *)(obj + 0x94) = x;
            *(f32 *)(obj + 0x98) = x;
            *(f32 *)(obj + 0x9C) = x;
            break;
        }
        fn_80008BA8(buf, preset, 0xB4);
        fn_1_22E8C(obj, buf);
        *(f32 *)(obj + 0xC) = scale;
    }
}
#pragma opt_propagation reset

u32 fn_15_401C(u32 arg0) {
    u32 v0;
    u32 t0, t1;
    v0 = arg0;
    if ((lbl_15_bss_14 & 0x40000000) != 0) {
    v0 = 1;
    t0 = fn_1_C6F80(v0);
    v0 = t0;
    } else {
    v0 = 0;
    t1 = fn_1_C6F80(v0);
    v0 = t1;
    }
    return v0;
}

// fn_15_405C: empty in retail (single blr).
void fn_15_405C(void) {
}

extern u32 fn_1_41A8(void *);
extern u32 fn_1_58854(u32);
extern u32 fn_1_85878(void);
extern u32 fn_1_982C4(u32);
extern u32 fn_1_C47B4(u32);



struct fn_15_4060_lbl_15_bss_0 {
    u8 pad_0[0x21];
    u8 unk_21;
    u8 pad_22[0x2];
    void *unk_24;
    void *unk_28;
    u8 pad_2C[0x124];
    u32 unk_150;
};

void fn_15_4060(void) {
    struct fn_15_4060_lbl_15_bss_0 *p_lbl_15_bss_0;
    u32 t0, t1, t2;
    void *t6, *t8;
    p_lbl_15_bss_0 = (struct fn_15_4060_lbl_15_bss_0 *)&(*(struct fn_15_4060_lbl_15_bss_0 *)&lbl_15_bss_0);
    t0 = fn_1_85878();
    t1 = fn_1_982C4(t0);
    t2 = fn_1_58854(t1);
    fn_1_C47B4(t2);
    fn_1_C6F80(0);
    fn_1_46B4(lbl_801A6410, p_lbl_15_bss_0->unk_150, &(*(u32 *)&lbl_15_data_A4), 2849);
    t6 = fn_1_435C(p_lbl_15_bss_0->unk_24);
    fn_1_41A8(t6);
    t8 = fn_1_435C(p_lbl_15_bss_0->unk_28);
    fn_1_41A8(t8);
    fn_1_46B4(lbl_801A6410, (u32)p_lbl_15_bss_0->unk_24, &(*(u32 *)&lbl_15_data_A4), 2854);
    fn_1_46B4(lbl_801A6410, (u32)p_lbl_15_bss_0->unk_28, &(*(u32 *)&lbl_15_data_A4), 2855);
    p_lbl_15_bss_0->unk_21 = 0;
}

#include "types.h"

typedef struct {
    u8 pad_0[0x38];
    s16 unk_38;
    u8 pad_3A[0x2E];
    s32 unk_68;
    s32 unk_6C;
    s32 unk_70;
    u8 pad_74[0x24];
    s16 unk_98;
} fn_15_4124_St;

typedef struct {
    u8 pad_0[0x1C];
    f32 unk_1C;
} fn_15_4124_Sub;

typedef struct {
    u16 unk_0;
    u8 pad_2[0xE];
    u16 unk_10;
} fn_15_4124_Ctrl;

typedef struct {
    void **unk_0;
} fn_15_4124_Holder;

extern fn_15_4124_Ctrl lbl_1_bss_D58;
extern fn_15_4124_Holder lbl_1_bss_6EAD0;
extern void fn_1_A1588(void *, u32);

void fn_15_4124(void) {
    fn_15_4124_St *st = (fn_15_4124_St *)lbl_15_bss_0__fzgx_offset_0;
    fn_15_4124_Sub *cam;
    s32 dir;
    s32 sel;
    s32 m;
    s32 n;
    s32 last;

    cam = camera_get_state_object();

    if ((lbl_1_bss_D58.unk_10 >> 3) & 1) {
        dir = -1;
    } else if ((lbl_1_bss_D58.unk_10 >> 2) & 1) {
        dir = 1;
    } else {
        dir = 0;
    }

    n = st->unk_38;
    m = n + 3;
    sel = (st->unk_6C + dir + m) % m;
    st->unk_6C = sel;
    if (sel < 0) {
        sel = 0;
    } else {
        last = n - 1;
        if (sel > last) {
            sel = last;
        }
    }
    st->unk_68 = sel;

    if (((lbl_1_bss_D58.unk_0 >> 11) & 1) == 0) {
        if (lbl_1_bss_D58.unk_10 & 1) {
            dir = -1;
        } else if ((lbl_1_bss_D58.unk_10 >> 1) & 1) {
            dir = 1;
        } else {
            dir = 0;
        }
    } else {
        dir = 0;
    }

    if (dir != 0) {
        switch (st->unk_6C - st->unk_38) {
        case 0:
            st->unk_70 = (st->unk_70 + dir + 4) % 4;
            break;
        case 1:
            cam->unk_1C += dir;
            if (cam->unk_1C > 55.0f) {
                cam->unk_1C = 55.0f;
            }
            if (cam->unk_1C < 30.0f) {
                cam->unk_1C = 30.0f;
            }
            break;
        case 2:
            st->unk_98 += dir;
            switch (st->unk_98 % 3) {
            case 0:
                fn_1_A1588(lbl_1_bss_6EAD0.unk_0[0], 0x11);
                break;
            case 1:
                fn_1_A1588(lbl_1_bss_6EAD0.unk_0[0], 0x35);
                break;
            default:
                fn_1_A1588(lbl_1_bss_6EAD0.unk_0[0], 0x42);
                break;
            }
            break;
        }
    }
}

#include "types.h"


struct fn_15_435C_lbl_15_rodata_0 {
    u8 pad_0[0x70];
    f32 unk_70;
    u8 pad_74[0xC];
    f32 unk_80;
    f32 unk_84;
    u8 pad_88[0x90];
    u32 unk_118;
    u32 unk_11C;
    u32 unk_120;
    f32 unk_124;
};

struct fn_15_435C_lbl_15_bss_0 {
    u8 pad_0[0x38];
    s16 unk_38;
    u8 pad_3A[0x32];
    u32 unk_6C;
    u32 unk_70;
    u8 pad_74[0x24];
    s16 unk_98;
    u8 pad_9A[2];
    u32 unk_9C[1];
};

struct fn_15_435C_lbl_15_data_0 {
    u8 pad_0[0x50];
    u32 unk_50[0x2D];
    u8 pad_104[0x1D0];
    char unk_2D4[0x14];
    char unk_2E8[0x10];
    char unk_2F8[0x10];
    char unk_308[0x10];
    char unk_318[0x20];
    char unk_338[0x2C];
    char unk_364[0x40];
};

struct fn_15_435C_cam {
    u8 pad_0[0x1C];
    f32 unk_1C;
};

struct fn_15_435C_elem {
    u8 pad_0[0x88];
    u32 unk_88;
};

extern u32 lbl_1_data_20B14[];

extern void fn_1_49410(void);
extern void fn_1_4954C(f32);
extern void fn_1_4955C(f32, f32);
extern void fn_1_495FC(void);
extern void fn_1_496FC(f32, f32);
extern void fn_1_49514(u32 *);
extern s16 fn_1_12C930(s16);
extern s16 fn_1_12C710(int);
extern s16 fn_1_7F49C(s16, s16, void *);
extern void fn_1_4AE0C(const char *, ...);
extern void fn_1_4A0D8(const char *);

#pragma opt_loop_invariants off
#pragma opt_common_subs off
#pragma opt_propagation off
#pragma opt_lifetimes off
void fn_15_435C(void) {
    u32 buf[8];
    u32 v[6];
    struct fn_15_435C_lbl_15_rodata_0 *p_ro = (struct fn_15_435C_lbl_15_rodata_0 *)lbl_15_rodata_0__fzgx_offset_0;
    struct fn_15_435C_lbl_15_data_0 *p_data = (struct fn_15_435C_lbl_15_data_0 *)lbl_15_data_0;
    struct fn_15_435C_lbl_15_bss_0 *p_bss = (struct fn_15_435C_lbl_15_bss_0 *)lbl_15_bss_0__fzgx_offset_0;
    struct fn_15_435C_cam *p_cam;
    struct fn_15_435C_elem **p_ent;
    u32 *p_tbl;
    s32 i;

    v[3] = p_ro->unk_118;
    v[4] = p_ro->unk_11C;
    v[5] = p_ro->unk_120;
    p_cam = (struct fn_15_435C_cam *)camera_get_state_object();
    fn_1_49410();
    fn_1_4954C(p_ro->unk_70);
    fn_1_4955C(p_ro->unk_84, p_ro->unk_84);
    fn_1_495FC();
    fn_1_496FC(p_ro->unk_80, p_ro->unk_124);
    v[0] = v[5];
    p_ent = (struct fn_15_435C_elem **)((u8 *)p_bss + 0x9C);
    i = 0;

    while (i < (s32)p_bss->unk_38 + 3) {
        if (i == (s32)p_bss->unk_6C) {
            v[2] = v[3];
            fn_1_49514(&v[2]);
        }
        else {
            v[1] = v[0];
            fn_1_49514(&v[1]);
        }

        if (i < (s32)p_bss->unk_38) {
            struct fn_15_435C_elem *p_e = *p_ent;
            u32 v_tbl = lbl_1_data_20B14[(s16)fn_1_12C930((s16)p_e->unk_88)];

            fn_1_7F49C(fn_1_12C710(p_e->unk_88), 5, buf);
            fn_1_4AE0C(p_data->unk_2D4, i + 1, v_tbl, buf);
        }
        else {
            switch (i - (s32)p_bss->unk_38) {
            case 0:
                p_tbl = p_data->unk_50;
                fn_1_4AE0C(p_data->unk_2E8, p_tbl[p_bss->unk_70]);
                break;
            case 1: {
                f32 f_live = p_cam->unk_1C;
                fn_1_4AE0C(p_data->unk_2F8, f_live);
                break;
            }
            case 2:
                switch (p_bss->unk_98 % 3) {
                case 0:
                    fn_1_4A0D8(p_data->unk_308);
                    break;
                case 1:
                    fn_1_4A0D8(p_data->unk_318);
                    break;
                default:
                    fn_1_4A0D8(p_data->unk_338);
                    break;
                }
                break;
            default:
                fn_1_4AE0C(p_data->unk_364);
                break;
            }
        }
        p_ent++;
        i++;
    }
}
#pragma opt_lifetimes reset
#pragma opt_propagation reset
#pragma opt_common_subs reset
#pragma opt_loop_invariants reset

void fn_15_4568(void) {
    lbl_15_bss_154 = 0;
}

/* Non-owning section views reproduce the retail base-relative accesses. */
struct ResultState {
    u8 pad_0[0x14];
    u32 flags;
    s32 frame;
    u8 pad_1c[0x10];
    u8 *source;
    u8 pad_30[0xC];
    s16 cup;
    u8 pad_3e[0x116];
    s16 page;
    u8 pad_156[2];
    struct ResultRow rows[7];
};



extern void fn_1_49410(void);
extern void fn_1_4955C(f32, f32);
extern void fn_1_496FC(f32, f32);
extern void fn_1_49514(u32 *);

static inline f32 clamp_result(f32 value, f32 low, f32 high) {
    if (value < low) return low;
    else if (value > high) return high;
    else return value;
}

/* Keep phase-local coordinate homes; the scan, easing and clamp inputs are separate locals. */
#pragma opt_lifetimes off
void fn_15_4578(void) {
    s32 count;
    u8 snapshot[0x14B8];
    FontDrawPacket packet;
    FontDrawPacket course_packet;
    u32 text_color;
    u32 value_color;
    s32 i;
    s32 timeline_i;
    s32 fade_start;
    u8 *course; /* Declaration order sets allocation priority: after count/fade_start, before result/image/anim. */
    u8 *result;
    s32 image;
    s32 icon; /* Valid course IDs map to switch cases; retail has no default store. */
    s16 racer;
    struct { s32 value; } frame;
    char *suffix;
    s32 rank;
    struct { s16 value; } start;
    s16 end;
    f32 fzgx_live;
    struct ResultRow *row;
    struct ResultAnimation *anim;
    f32 *first_x;
    s32 width;
    f32 t;
    f32 ease;
    f32 banner_t;
    f32 backdrop_t;
    f32 dx;
    f32 x;
    struct { f32 value; } y;
    f32 height;
    f32 alpha;
    f32 height_2;
    u32 time;
    f32 offset_2;

    if (!(lbl_15_bss_14 & 0x78)) return;
    if (lbl_15_bss_14 & 0x20000000) {
        racer = 1;
    } else {
        fn_1_3EF14(snapshot);
        racer = snapshot[0xA6];
    }
    if (lbl_15_bss_14__fzgx_offset_4 >= 300 && lbl_15_bss_14__fzgx_offset_4 < 600) {
        if ((f32)lbl_15_bss_14__fzgx_offset_4 > 540.0f) {
            banner_t = 1.0f - ((f32)lbl_15_bss_14__fzgx_offset_4 - 540.0f) / 60.0f;
            alpha = clamp_result(banner_t, 0.0f, 1.0f);
        } else {
            banner_t = (f32)(lbl_15_bss_14__fzgx_offset_4 - 300) / 60.0f;
            alpha = clamp_result(banner_t, 0.0f, 1.0f);
        }
        switch (racer) {
        case 1: image = 0xA102; break;
        case 2: image = 0xA103; break;
        case 3: image = 0xA104; break;
        case 4: image = 0xA105; break;
        default: image = 0xA106; break;
        }
        fn_1_520A0();
        fn_1_52070(320);
        packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
        packet.image = image;
        packet.x = 320.0f;
        packet.y = 234.0f;
        packet.z = 11.0f;
        packet.flags = 10;
        packet.alpha = alpha;
        fn_1_4F734(&packet);
        fn_1_141360(racer, (s32)packet.x, (s32)packet.y, 10, 1.0f, alpha);
        fn_1_520CC();
        fn_1_49410();
        fn_1_494DC(6);
        fn_1_495B0(0xC0000000U); /* fzgx-allow: A1 packed rendering flags, not an address */
        fn_1_495C8(1);
        fn_1_49590(0.5f);
        fn_1_4955C(1.5f, 1.5f);
        fn_1_496FC(320.0f, 142.0f);
        fn_1_495A0(alpha);
        fn_1_4A0D8("F-ZERO GRAND PRIX\n");
        fn_1_496FC(320.0f, 296.0f);
        fn_1_4955C(1.5f, 1.5f);
        fn_1_4AE0C("%s\n", lbl_15_data_1C80[lbl_801A66B4][(s16)racer]);
        fn_1_496FC(320.0f, 324.0f);
        fn_1_4955C(0.8f, 0.8f);
        fn_1_4AE0C("%s", lbl_15_data_1D50[lbl_801A66B4][lbl_15_bss_35__fzgx_offset_7]);
        packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
        packet.x = 320.0f;
        packet.y = 240.0f;
        packet.z = 20.0f;
        packet.flags = 10;
        packet.image = 2;
        packet.alpha = alpha;
        fn_1_50A90(&packet, 18, 45, 940, 234);
    }
    fn_1_49410();
    fn_1_49590(0.5f);
    frame.value = lbl_15_bss_14__fzgx_offset_4;
    for (timeline_i = 0; (s16)timeline_i < 6; timeline_i++) {
        if (frame.value == lbl_15_data_1DEC[timeline_i]) lbl_15_bss_154 = timeline_i;
    }
    start.value = lbl_15_data_1DEC[lbl_15_bss_154];
    if (start.value > frame.value) return;
    if (lbl_15_bss_14__fzgx_offset_4 >= start.value + 400) return;
    end = start.value;
    end += 400;
    count = 7;
    fade_start = (s32)((f32)end - 60.0f);
    if (lbl_15_bss_154 == 5) count = 4;
    if (frame.value == start.value) {
        if (lbl_15_bss_154 == 5) {
            memcpy(lbl_15_bss_154__fzgx_offset_4, lbl_15_data_132C[lbl_801A66B4], (s16)count * 0x60);
            sprintf(lbl_15_bss_154__fzgx_offset_4[0].anim.label, "%s", lbl_15_data_1C80[lbl_801A66B4][(s16)racer]);
            if (!(lbl_15_bss_14 & 0x20000000)) {
                result = lbl_15_bss_2C;
                sprintf(lbl_15_bss_154__fzgx_offset_4[1].anim.value, "%d", result[0xF8]+1);
                sprintf(lbl_15_bss_154__fzgx_offset_4[2].anim.value, "%d", *(u16 *)(result+0xF4));
                sprintf(lbl_15_bss_154__fzgx_offset_4[3].anim.value, "%d", *(u16 *)(result+0xF6));
            }
        } else {
            memcpy(lbl_15_bss_154__fzgx_offset_4, lbl_15_data_36C[lbl_801A66B4], (s16)count * 0x60);
            sprintf(lbl_15_bss_154__fzgx_offset_4[0].anim.label, "%s", lbl_1_data_2BD54[fn_1_12EF24(racer,lbl_15_bss_154)][lbl_801A66B4]);
            if (!(lbl_15_bss_14 & 0x20000000)) {
                course = lbl_15_bss_2C + 0xF0;
                sprintf(lbl_15_bss_154__fzgx_offset_4[1].anim.value, "%d", course[0xE+lbl_15_bss_154]+1);
                time = ((u32 *)(course+0x24))[lbl_15_bss_154];
                sprintf(lbl_15_bss_154__fzgx_offset_4[2].anim.value, "%02d'%02d\"%03d", (time>>20)&255, (time>>12)&255, time&0xFFF);
                time = ((u32 *)(course+0x38))[lbl_15_bss_154];
                sprintf(lbl_15_bss_154__fzgx_offset_4[3].anim.value, "%02d'%02d\"%03d", (time>>20)&255, (time>>12)&255, time&0xFFF);
                sprintf(lbl_15_bss_154__fzgx_offset_4[4].anim.value, "%d", ((u16 *)(course+0x18))[lbl_15_bss_154]);
                sprintf(lbl_15_bss_154__fzgx_offset_4[5].anim.value, "%d", course[9+lbl_15_bss_154]);
                sprintf(lbl_15_bss_154__fzgx_offset_4[6].anim.value, "%d", course[0x13+lbl_15_bss_154]);
            }
        }
    }
    row = lbl_15_bss_154__fzgx_offset_4;
    first_x = &row->anim.x;
    width = (s32)result_width[0];
    for (i = 0; (s16)i < (s16)count; row++, i++) {
        anim = &row->anim;
        if (lbl_15_bss_14__fzgx_offset_4 < (s16)fade_start) {
            ease = anim->ease;
            if ((s16)i == 0 || lbl_15_bss_154 == 5) {
                fzgx_live = anim->x;
                dx = (320.0f - fzgx_live) * ease;
                fzgx_live = anim->x;
                anim->x = fzgx_live + dx;
            } else {
                fzgx_live = anim->x;
                dx = (296.0f - fzgx_live) * ease;
                fzgx_live = anim->x;
                anim->x = fzgx_live + dx;
            }
        } else {
            dx = 10.0f * anim->acceleration;
            anim->velocity = anim->velocity + dx;
            fzgx_live = anim->x;
            anim->x = fzgx_live - anim->velocity;
        }
        if ((s16)i == 0) {
            x = 103.0f + anim->y;
            y.value = anim->y;
            height = anim->x;
            if (lbl_15_bss_154 == 5) {
                fn_1_49410();
                fn_1_494DC(6);
                fn_1_495B0(0xC0000000U); /* fzgx-allow: A1 packed rendering flags */
                fn_1_495C8(9);
                fn_1_49590(0.5f);
                fn_1_4955C(1.44f, 1.44f);
                fn_1_496FC(height, 160.0f + y.value);
                fn_1_495A0(1.0f);
                fn_1_4A0D8("F-ZERO GRAND PRIX\n");
                fn_1_4AE0C("%s", lbl_15_data_1C80[lbl_801A66B4][(s16)racer]);
                offset_2 = anim->x;
                x = 211.0f + anim->y;
                fn_1_4955C(0.84f, 0.84f);
                fn_1_496FC(offset_2,x);
                fn_1_4AE0C("%s", lbl_15_data_1D50[lbl_801A66B4][lbl_15_bss_35__fzgx_offset_7]);
            } else {
                switch (lbl_1_data_2B0D4[fn_1_12EF24(racer,lbl_15_bss_154)]) {
                case 1: case 17: case 18: icon = 0; break;
                case 2: case 3: icon = 1; break;
                case 4: case 5: icon = 2; break;
                case 6: case 7: icon = 3; break;
                case 8: case 9: icon = 4; break;
                case 10: icon = 5; break;
                case 11: case 12: icon = 6; break;
                case 13: icon = 7; break;
                case 14: icon = 8; break;
                case 15: icon = 9; break;
                case 16: icon = 10; break;
                case 19: icon = 11; break;
                }
                course_packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
                course_packet.image = 0xBB00;
                fn_1_51678(&course_packet, course_packet.image, 0, icon * 36, fn_1_48690(0xBB00), 36);
                course_packet.x = height;
                course_packet.y = x;
                course_packet.flags = 6;
                fn_1_4F734(&course_packet);
                fn_1_CFCA4(anim->label, anim->x, 141.0f + anim->y, 1.0f);
            }
        } else {
            x = anim->x;
            if (lbl_15_bss_154 == 5) {
                y.value = 180.0f + anim->y;
                offset_2 = 0.0f;
                x = 27.0f + x;
                height_2 = 224.0f;
            } else {
                y.value = 117.0f + anim->y;
                height_2 = 200.0f;
                offset_2 = 23.0f;
            }
            fn_1_49410();
            fn_1_495B0(0xC0000000U); /* fzgx-allow: A1 packed rendering flags */
            fn_1_494DC(6);
            fn_1_4955C(1.3f,1.3f);
            y.value = 23.0f + y.value;
            fn_1_496FC(x,y.value);
            fn_1_495C8(18);
            text_color = fzgx_pool_table14[0];
            fn_1_49514(&text_color);
            fn_1_4AE0C("%s", anim->label);
            fn_1_49590(0.5f);
            fn_1_496FC(x,y.value);
            fn_1_495C8(16);
            value_color = value_color_pool[0];
            fn_1_49514(&value_color);
            fn_1_4AE0C(" : %s", anim->value);
            if ((s16)i == 1) {
                result = lbl_15_bss_2C + 0xF0;
                fn_1_4962C();
                fn_1_4955C(1.04f,1.04f);
                if (lbl_15_bss_154 == 5) {
                    rank = result[8]+1;
                    if (lbl_801A66B4 == 5) suffix = fn_1_5415C(rank, 0);
                    else suffix = fn_1_5415C(rank, lbl_801A66B4);
                    fn_1_4AE0C(" %s", suffix);
                } else {
                    rank = result[lbl_15_bss_154+14]+1;
                    if (lbl_801A66B4 == 5) suffix = fn_1_5415C(rank, 0);
                    else suffix = fn_1_5415C(rank, lbl_801A66B4);
                    fn_1_4AE0C(" %s", suffix);
                }
            }
            if ((s16)i == 2 && lbl_15_bss_154 == 5) {
                fn_1_4955C(1.04f,1.04f);
                fn_1_4AE0C(" %s", lbl_15_data_1DB4[lbl_801A66B4]);
            }
            if ((s16)i == 4) {
                fn_1_4955C(1.04f,1.04f);
                fn_1_4AE0C(" %s", lbl_15_data_1DD4[lbl_801A66B4]);
            }
            if ((s16)i == 5) {
                fn_1_4955C(1.04f,1.04f);
                fn_1_4AE0C(" %s", lbl_15_data_1DB4[lbl_801A66B4]);
            }
            if ((s16)i == 1) {
                packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
                packet.x = 320.0f;
                packet.y = 240.0f + offset_2;
                packet.z = 20.0f;
                packet.flags = 10;
                packet.image = 2;
                alpha = __fabs(*first_x - 320.0f) / 320.0;
                backdrop_t = 1.0f - alpha;
                alpha = clamp_result(backdrop_t,0.0f,1.0f);
                packet.alpha = alpha;
                fn_1_50A90(&packet,18,45,width,(s32)(height_2*alpha));
            }
            if (lbl_15_bss_154 == 5 && (s16)i == 1) {
                switch (racer) {
                case 1: image = 0xA102; break;
                case 2: image = 0xA103; break;
                case 3: image = 0xA104; break;
                case 4: image = 0xA105; break;
                default: image = 0xA106; break;
                }
                fn_1_520A0();
                fn_1_52070(320);
                packet = (*(FontDrawPacket *)&lbl_1_rodata_26F8);
                t = 1.56f * alpha;
                alpha = 0.4f * alpha;
                packet.image = image;
                packet.x = 320.0f;
                packet.y = 250.0f;
                packet.z = 11.0f;
                packet.scale_x = t;
                packet.scale_y = t;
                packet.alpha = alpha;
                packet.flags = 10;
                fn_1_4F734(&packet);
                fn_1_141360(racer, (s32)packet.x, (s32)packet.y, 10, 1.56f, alpha);
                fn_1_520CC();
            }
        }
    }
}
#pragma opt_lifetimes reset
