#include "types.h"
#include "rel/main_rel/memcard.h"
#include "rel/main_rel/data/lbl_1_rodata_4AE0.h"

extern void OSReport(const char *, ...);
extern void OSPanic(const char *, int, const char *, ...);
extern s32 CARDUnmount(s32);
extern void fn_1_46B4(u32, u32, const char *, int);
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;
extern const f32 lbl_1_rodata_4CA8;
extern const char *fn_80019C48(void);
extern size_t strlen(const char *);
extern char *fn_80083970(char *, const char *);
extern s32 strncmp(const char *, const char *, size_t);
extern char *strncpy(char *, const char *, size_t);
typedef struct FileEntry {
 u8 unk_0, unk_1; char name[0x22]; u32 unk_24, unk_28; u8 pad[4];
} FileEntry;
typedef struct CardState {
 u8 unk_0, unk_1; u8 pad_2[2]; s32 unk_4; u32 unk_8;
 u8 pad_C[0xC]; u32 unk_18, unk_1C;
 char unk_20[0x20]; u32 unk_40, unk_44; char unk_48[4], unk_4C[2];
 u8 pad_4E[0x46]; FileEntry *unk_94; u8 pad_98[0x50]; u32 unk_E8;
} CardState;
typedef struct CardContext {
 u8 unk_0; s8 unk_1; u8 unk_2, unk_3, unk_4, unk_5, unk_6, unk_7;
 s16 unk_8, unk_A; void *unk_C; u8 pad_10[0x14]; CardState *unk_24;
 s8 unk_28; u8 unk_29, unk_2A, unk_2B, unk_2C, unk_2D; u8 pad_2E[2];
 u32 unk_30; f32 unk_34, unk_38;
} CardContext;
static inline void reset_context(CardContext *p, u8 *b) {
 p->unk_24 = 0;
 p->unk_2 = 255; p->unk_3 = 255; p->unk_4 = 255; p->unk_5 = 255; p->unk_6 = 255;
 p->unk_7 = 0; p->unk_8 = -1; p->unk_A = -1;
 p->unk_30 = 0; p->unk_34 = lbl_1_rodata_4CA8; p->unk_38 = lbl_1_rodata_4CA8;
 p->unk_2A &= ~4;
 b[0x5C08] = 0; b[0x1F8] = 1;
}
void fn_1_B171C(void *arg0) {
 u8 *p_lbl_1_data_35AC8;
 u8 *p_lbl_1_bss_716C0;
 CardContext *p = arg0;
 u32 v0;
 p_lbl_1_data_35AC8 = (u8 *)&lbl_1_data_35AC8;
 p_lbl_1_bss_716C0 = (u8 *)&lbl_1_bss_716C0;
 OSReport((char *)p_lbl_1_data_35AC8 + 0x708C, p->unk_4);
 v0 = p->unk_4;
 if (v0 == 255) return;
 switch (v0) {
 default:
 OSReport((char *)p_lbl_1_data_35AC8 + 0x6DDC, v0);
 OSReport((char *)p_lbl_1_data_35AC8 + 0x6DF0, p->unk_3);
 OSPanic((char *)p_lbl_1_data_35AC8 + 0x6CF0, 0x151C, (char *)p_lbl_1_data_35AC8 + 0x6E04);
 break;
 case 1: {
 u32 flags;
 Obj_1_bss_9F8 *input;
 p->unk_24->unk_8 &= ~0x200;
 flags = p->unk_24->unk_8;
 if (flags & 0x8000) p->unk_3 = 27;
 else {
 input = &lbl_1_bss_9F8;
 if ((input->unk_8 >> 8) & 1) p->unk_3 = 27;
 else if (((input->unk_8 >> 11) & 1) && !(flags & 2)) {
 if (p->unk_5 == 3 && p->unk_C != 0) {
 do {} while (CARDUnmount(p->unk_0) == -1);
 fn_1_46B4(lbl_801A6410, (u32)p->unk_C, (char *)p_lbl_1_data_35AC8 + 0x6CF0, 0x152E);
 p->unk_7 = 0; p->unk_C = 0;
 { CardState *s = p->unk_24; s->unk_1C = 0; s->unk_18 = 0; }
 }
 if (p->unk_6 != 255) { p->unk_3 = p->unk_6; p->unk_6 = 255; }
 else p->unk_3 = p->unk_5;
 p->unk_8 = -1; p->unk_A = -1; p->unk_2A &= ~4;
 /* The alternate action resamples the live input rather than using the earlier snapshot. */
 } else if ((((volatile Obj_1_bss_9F8 *)input)->unk_8 >> 10) & 1) {
 /* Fetch the current card-state pointer when processing the newly sampled action. */
 if (((volatile CardContext *)p)->unk_24->unk_8 & 0x400) {
 p->unk_3 = 5; p->unk_24->unk_8 &= ~0x400; p->unk_24->unk_8 |= 0x200;
 p->unk_2A &= ~4; p->unk_2A |= 0x10;
 }
 }
 }
 p_lbl_1_bss_716C0[0x5C49] = 0;
 break;
 }
 case 27:
 if (p->unk_24->unk_8 & 0x8000) p->unk_2 = 254;
 else if ((lbl_1_bss_9F8.unk_8 >> 8) & 1) p->unk_2 = 254;
 break;
 case 3:
 if (p->unk_1 == -127) {
 p->unk_24->unk_4 = p->unk_1; p->unk_3 = 1; break;
 }
 switch (p->unk_24->unk_4) {
 case -5: p->unk_24->unk_8 |= 2;
 case -128: case -3: case -2: p->unk_3 = 1; break;
 case -13:
 if (p->unk_24->unk_8 & 0x8000) { p->unk_2A |= 4; p->unk_2 = 254; }
 else if (lbl_801A66B4 == 5) p->unk_3 = 5;
 else { p->unk_24->unk_8 |= 0x400; p->unk_3 = 1; }
 break;
 case -1: break;
 case -6: case 0: p->unk_3 = 4; break;
 default: p->unk_3 = 0; break;
 }
 break;
 case 38: p->unk_3 = 3; break;
 case 4:
 switch (p->unk_24->unk_4) {
 case -5: p->unk_24->unk_8 |= 2;
 case -128: case -3: p->unk_3 = 1; break;
 case -6:
 if (p->unk_24->unk_8 & 0x8000) { p->unk_2A |= 4; p->unk_2 = 254; }
 else p->unk_3 = 5;
 break;
 case -13:
 if (p->unk_24->unk_8 & 0x8000) { p->unk_2A |= 4; p->unk_2 = 254; }
 else if (lbl_801A66B4 == 5) p->unk_3 = 5;
 else { p->unk_24->unk_8 |= 0x400; p->unk_3 = 1; }
 break;
 case -1: break;
 case 0: p->unk_3 = 7; break;
 default: p->unk_3 = 0; break;
 }
 break;
 case 5:
 if (p->unk_24->unk_4 != 0) {
 int done;
 if (!(p->unk_2A & 1)) { p->unk_28 = 12; p->unk_2A |= 1; done = 0; }
 else if (p->unk_28 > 0) { p->unk_28--; done = 0; }
 else done = 1;
 if (done) {
 if (p->unk_24->unk_4 == 2 || p->unk_24->unk_1 == 1) { p->unk_24->unk_4 = -126; p->unk_3 = 1; }
 else { p->unk_3 = 6; p->unk_24->unk_8 |= 0x200; }
 }
 }
 break;
 case 6:
 switch (p->unk_24->unk_4) {
 case -5: p->unk_24->unk_8 |= 2;
 case -128: case -3: p->unk_3 = 1; break;
 case -1: break;
 case 0: p->unk_3 = 22; p->unk_24->unk_8 &= ~0x200; break;
 default: p->unk_3 = 0; break;
 }
 break;
 case 22:
 if ((lbl_1_bss_9F8.unk_8 >> 8) & 1) { p->unk_3 = 27; p->unk_24->unk_4 = -121; }
 break;
 case 7:
 switch (p->unk_24->unk_4) {
 case -128: case -3: p->unk_3 = 1; break;
 case -1: break;
 case 0: p->unk_3 = 25; break;
 default: p->unk_3 = 0; break;
 }
 break;
 case 25:
 switch (p->unk_24->unk_4) {
 case -128: case -3: p->unk_3 = 1; break;
 case -4: case -10: p->unk_2C++; break;
 case -1: break;
 case 0:
 if (p->unk_24->unk_E8 & 4) {
 const char *prefix;
 u32 size;
 u32 len;
 const char *game;
 char *end;
 game = fn_80019C48();
 prefix = (char *)lbl_1_rodata_4AE0[2].name;
 len = strlen(prefix);
 end = fn_80083970(p->unk_24->unk_20, (char *)p_lbl_1_data_35AC8 + 0x6CFC);
 if (!strncmp(p->unk_24->unk_48, game, 4) &&
 !strncmp(p->unk_24->unk_4C, (char *)p_lbl_1_data_35AC8 + 0x7088, 2) &&
 !strncmp(p->unk_24->unk_20, prefix, len) && end != 0) {
 FileEntry *entry;
 char *start;
 entry = &p->unk_24->unk_94[p->unk_2D];
 start = p->unk_24->unk_20 + len;
 size = end - start;
 strncpy(entry->name, start, size); entry->name[size] = 0;
 entry->unk_1 = 2; entry->unk_24 = p->unk_24->unk_40; entry->unk_28 = p->unk_24->unk_44;
 p->unk_2D++;
 }
 }
 if (p->unk_24->unk_E8 & 0x10) {
 const char *prefix;
 u32 len;
 const char *game;
 char *end;
 game = fn_80019C48();
 prefix = (char *)lbl_1_rodata_4AE0[4].name;
 len = strlen(prefix);
 end = fn_80083970(p->unk_24->unk_20, (char *)p_lbl_1_data_35AC8 + 0x6CFC);
 if (!strncmp(p->unk_24->unk_48, game, 4) &&
 !strncmp(p->unk_24->unk_4C, (char *)p_lbl_1_data_35AC8 + 0x7088, 2) &&
 !strncmp(p->unk_24->unk_20, prefix, len) && end != 0) {
 u32 size;
 FileEntry *entry;
 char *start;
 entry = &p->unk_24->unk_94[p->unk_2D];
 start = p->unk_24->unk_20 + len;
 size = end - start;
 strncpy(entry->name, start, size); entry->name[size] = 0;
 entry->unk_1 = 4; entry->unk_24 = p->unk_24->unk_40; entry->unk_28 = p->unk_24->unk_44;
 p->unk_2D++;
 }
 }
 if (p->unk_24->unk_E8 & 0x20) {
 const char *prefix;
 u32 len;
 const char *game;
 char *end;
 game = fn_80019C48();
 prefix = (char *)lbl_1_rodata_4AE0[5].name;
 len = strlen(prefix);
 end = fn_80083970(p->unk_24->unk_20, (char *)p_lbl_1_data_35AC8 + 0x6CFC);
 if (!strncmp(p->unk_24->unk_48, game, 4) &&
 !strncmp(p->unk_24->unk_4C, (char *)p_lbl_1_data_35AC8 + 0x7088, 2) &&
 !strncmp(p->unk_24->unk_20, prefix, len) && end != 0) {
 u32 size;
 FileEntry *entry;
 char *start;
 entry = &p->unk_24->unk_94[p->unk_2D];
 start = p->unk_24->unk_20 + len;
 size = end - start;
 strncpy(entry->name, start, size); entry->name[size] = 0;
 entry->unk_1 = 5; entry->unk_24 = p->unk_24->unk_40; entry->unk_28 = p->unk_24->unk_44;
 p->unk_2D++;
 }
 }
 p->unk_2C++;
 break;
 default: p->unk_3 = 0; break;
 }
 if (p->unk_2C == 127 || p->unk_3 != 255) {
 *(u32 *)((u8 *)p->unk_24->unk_94 + p->unk_2D * 0x30 + 0x24) = 0;
 if (p->unk_3 == 255) p->unk_3 = 26;
 }
 break;
 case 26:
 if (p->unk_24->unk_8 & 4) {
 int done;
 if (!(p->unk_24->unk_8 & 8)) { p->unk_28 = 45; p->unk_24->unk_8 |= 8; done = 0; }
 else if (p->unk_28 > 0) { p->unk_28--; done = 0; }
 else done = 1;
 if (done) {
 *(s32 *)(p_lbl_1_bss_716C0 + 0x1F4) = p->unk_24->unk_4;
 fn_1_46B4(lbl_801A6410, (u32)p->unk_24, (char *)p_lbl_1_data_35AC8 + 0x6CF0, 0x3EC);
 reset_context(p, p_lbl_1_bss_716C0);
 }
 } else if ((lbl_1_bss_9F8.unk_8 >> 8) & 1) {
 *(s32 *)(p_lbl_1_bss_716C0 + 0x1F4) = p->unk_24->unk_4;
 fn_1_46B4(lbl_801A6410, (u32)p->unk_24, (char *)p_lbl_1_data_35AC8 + 0x6CF0, 0x3EC);
 reset_context(p, p_lbl_1_bss_716C0);
 }
 break;
 }
 if (p->unk_24 != 0) *(s32 *)(p_lbl_1_bss_716C0 + 0x1F4) = p->unk_24->unk_4;
}

#include "rel/main_rel/memcard.h"
#include "rel/main_rel/data/lbl_1_rodata_4AE0.h"

typedef struct {
    u8 unk_0;
    u8 unk_1;
    char name[0x22];
    u32 unk_24;
    u32 unk_28;
    u32 unk_2C;
} MemcardEntry;

typedef struct {
    u8 pad_00[0x08];
    u32 unk_08;
    u32 unk_0C;
    u8 pad_10[0x10];
    char unk_20[0x20];
    u32 unk_40;
    u32 unk_44;
    char unk_48[4];
    char unk_4C[0x48];
    MemcardEntry *unk_94;
    char unk_98[0x20];
    u32 unk_B8;
    u8 pad_BC[0x20];
    u32 unk_DC;
} MemcardWork;

typedef struct {
    u8 pad_00[0x24];
    MemcardWork *unk_24;
    u8 pad_28[0x05];
    u8 unk_2D;
} MemcardCtx;

extern u32 lbl_801A6410;
extern void fn_1_46B4(u32, u32, const char *, int);
extern u32 fn_1_4630(u32, u32, const char *, int);
extern const char *fn_80019C48(void);
extern size_t strlen(const char *);
extern char *fn_80083970(char *, const char *);
extern s32 strncmp(const char *, const char *, size_t);
extern char *strncpy(char *, const char *, size_t);
extern int sprintf(char *, const char *, ...);

static inline u32 parseHex(u8 *s, int n) {
    int i;
    u32 c;
    u32 sum = 0;

    for (i = 0; i < n; i++, s++) {
        c = *s;
        if (c >= 'A' && c <= 'F') {
            c -= 'A' - 10;
        } else {
            c -= '0';
        }
        sum += c << ((n - 1 - i) * 4);
    }
    return sum;
}

void fn_1_B22AC(MemcardCtx *ctx, s32 kind) {
    char * fzgx_live;
    char *base;
    MemcardEntry *entry;
    const char *code;
    const MemcardKind *info;
    size_t len;
    char *p1;
    size_t n_2;
    char *p2;
    u32 value;
    size_t n;

    base = (char *)&lbl_1_data_35AC8;
    code = fn_80019C48();
    info = &lbl_1_rodata_4AE0[kind];
    len = strlen(info->name);
    p1 = fn_80083970(ctx->unk_24->unk_20, base + 0x6cfc);
    p2 = fn_80083970(ctx->unk_24->unk_20, base + 0x6dd4);
    if (strncmp(ctx->unk_24->unk_48, code, 4) != 0) {
        return;
    }
    if (strncmp(ctx->unk_24->unk_4C, base + 0x7088, 2) != 0) {
        return;
    }
    if (strncmp(ctx->unk_24->unk_20, info->name, len) != 0) {
        return;
    }
    if (p1 == NULL && p2 == NULL) {
        return;
    }

    entry = &ctx->unk_24->unk_94[ctx->unk_2D];
    if (p1 != NULL) {
        n = p1 - (ctx->unk_24->unk_20 + len);
        fzgx_live = entry->name;
        strncpy(fzgx_live, ctx->unk_24->unk_20 + len, n);
        fzgx_live = entry->name;
        fzgx_live[n] = 0;
    } else {
        n_2 = p2 - (ctx->unk_24->unk_20 + len);
        fzgx_live = entry->name;
        strncpy(fzgx_live, ctx->unk_24->unk_20 + len, n_2);
        fzgx_live = entry->name;
        fzgx_live[n_2] = 0;
    }
    entry->unk_1 = kind;
    value = *(volatile u32 *)&info->unk_40;  /* fzgx-allow: S2 volatile view keeps the verified load order */
    entry->unk_24 = (*(MemcardWork *volatile *)&ctx->unk_24)->unk_40;
    entry->unk_28 = ctx->unk_24->unk_44;
    ctx->unk_2D++;
    ctx->unk_24->unk_08 |= 0x20;
    ctx->unk_24->unk_08 |= 0x4;

    if (value == 0 && kind == 4) {
        fzgx_live = entry->name;
        ctx->unk_24->unk_B8 = parseHex((u8 *)fzgx_live, 5);
    } else if (value == 0 && kind == 5) {
        fzgx_live = entry->name;
        ctx->unk_24->unk_B8 = parseHex((u8 *)fzgx_live, 8);
    } else if (value == 0 && kind == 2) {
        ctx->unk_24->unk_B8 = 16040;
    } else {
        ctx->unk_24->unk_B8 = value;
    }

    ctx->unk_24->unk_0C = entry->unk_24;
    fzgx_live = entry->name;
    sprintf(ctx->unk_24->unk_98, base + 0x713c, info->name, fzgx_live);
    if (entry->unk_2C != 0) {
        fn_1_46B4(lbl_801A6410, entry->unk_2C, base + 0x6cf0, 0x16f4);
        entry->unk_2C = 0;
    }
    entry->unk_2C = fn_1_4630(lbl_801A6410, ctx->unk_24->unk_B8, base + 0x6cf0, 0x16f7);
    if (ctx->unk_24->unk_DC != 0) {
        fn_1_46B4(lbl_801A6410, ctx->unk_24->unk_DC, base + 0x6cf0, 0x16f9);
        ctx->unk_24->unk_DC = 0;
    }
    ctx->unk_24->unk_DC = fn_1_4630(lbl_801A6410, ctx->unk_24->unk_0C, base + 0x6cf0, 0x16fc);
}

/* the sprintf format above (base + 0x713C) */
char lbl_1_data_3CC04[] = "%s%s";

// fn_1_B2770: main_rel .text:0x000B2770 size 0xC
// Store byte 0x3 at offset 3 of the pointer argument

#include "types.h"

void fn_1_B2770(int unused, void *ptr) {
    *(u8 *)((u8 *)ptr + 3) = 0x3;
}

#include "types.h"
#include "rel/main_rel/memcard.h"
#include "rel/main_rel/data/lbl_1_rodata_4AE0.h"

typedef struct UnkWork_1_B277C {
    u8 pad_00[0x04];
    s32 unk_04;
    u32 unk_08;
    u32 unk_0C;
    u8 pad_10[0x08];
    u32 unk_18;
    u32 unk_1C;
    u8 pad_20[0x74];
    u8 *unk_94;
    u8 pad_98[0x20];
    u32 unk_B8;
    u8 pad_BC[0x20];
    u8 *unk_DC;
    u8 pad_E0[0x08];
    u32 unk_E8;
} UnkWork_1_B277C;

typedef struct UnkCtx_1_B277C {
    u8 unk_00;
    s8 unk_01;
    u8 unk_02;
    u8 unk_03;
    u8 unk_04;
    u8 unk_05;
    u8 unk_06;
    u8 unk_07;
    s16 unk_08;
    s16 unk_0A;
    u32 unk_0C;
    u8 pad_10[0x14];
    UnkWork_1_B277C *unk_24;
    s8 unk_28;
    u8 pad_29;
    u8 unk_2A;
    u8 pad_2B;
    u8 unk_2C;
    u8 unk_2D;
    u8 pad_2E[0x02];
    u32 unk_30;
    f32 unk_34;
    f32 unk_38;
} UnkCtx_1_B277C;

typedef struct Unk716C0_1_B277C {
    u8 unk_00;
    u8 pad_01[0x1F0];
    u8 unk_1F1;
    u8 pad_1F2[0x02];
    u32 unk_1F4;
    u8 unk_1F8;
    u8 unk_1F9;
    u8 pad_1FA[0x5A0E];
    u8 unk_5C08;
    u8 pad_5C09[0x40];
    u8 unk_5C49;
} Unk716C0_1_B277C;

typedef struct UnkBuf8_1_B277C {
    u8 m0;
    u8 m1;
    u8 m2;
    u8 m3;
    u8 m4;
    u8 m5;
    u8 m6;
    u8 m7;
} UnkBuf8_1_B277C;

typedef struct UnkHdr10_1_B277C {
    u8 m0;
    u8 m1;
    u8 m2;
    u8 m3;
    u16 m4;
    u8 m5;
    u8 m6;
    u8 m7;
    u8 m8;
    u8 pad[2];
} UnkHdr10_1_B277C;

typedef struct UnkOut16_1_B277C {
    u8 m0;
    u8 m1;
    u8 m2;
    u8 m3;
    u8 m4;
    u8 m5;
    u8 pad6[3];
    u8 m9;
    u8 pad10[3];
    u8 m13;
    u8 m14;
    u8 m15;
} UnkOut16_1_B277C;

extern const f32 lbl_1_rodata_4CA8;
extern u32 lbl_801A6410;
extern s32 lbl_801A66B4;

extern void OSReport(const char *, ...);
extern void OSPanic(const char *, int, const char *, ...);
extern s32 CARDUnmount(s32);
extern void fn_1_46B4(u32, u32, const char *, int);
extern u32 fn_1_4630(u32, u32, const char *, int);
extern u32 fn_1_1563E8(u32 a, u32 b);
extern u32 fn_1_F4810(void *a0, void *a1, void *a2, void *a3, void *a4, void *a5, void *a6, void *a7, void *a8);
extern void fn_80008BA8(u32 dst, u32 src, u32 size);
extern void fn_80008BEC(void *dst, int val, u32 size);

#pragma opt_common_subs on
#pragma opt_dead_assignments off
#pragma opt_propagation on
static inline u8 * fn_1_B277C_address_18218(u8 * base, s32 offset) { struct { u8 * value; } result;
    result.value = (u8 *)offset;
    result.value = base + (s32)result.value;
    return result.value; }
#pragma opt_lifetimes off
static inline u8 *record_address(u8 *base, s32 offset) { u8 *result; result = (u8 *)(offset - 0x30); result = base + (s32)result; return result; }
void fn_1_B277C(UnkCtx_1_B277C *ctx) {
    UnkWork_1_B277C * fzgx_live;
    const char *data = (const char *)&lbl_1_data_35AC8;
    Unk716C0_1_B277C *p = (Unk716C0_1_B277C *)&lbl_1_bss_716C0;
    u8 *rec;
    u32 state = ctx->unk_04;

    if (state != 0xff) {
        switch (state) {
        default:
            OSReport(data + 0x6ddc, state);
            OSReport(data + 0x6df0, ctx->unk_03);
            OSPanic(data + 0x6cf0, 0x1724, data + 0x6e04);
            break;
        case 1: {
            u8 *self;
            UnkWork_1_B277C *w;
            ctx->unk_24->unk_08 &= 0xfffffdff;
            w = (*(UnkWork_1_B277C * volatile *)&(ctx->unk_24)) /* Retail reloads this field. */;
            if ((w->unk_08 & 0x8000) != 0) {
                ctx->unk_03 = 0x1b;
            } else {
                Obj_1_bss_9F8 *s9 = &lbl_1_bss_9F8;
                u32 t9 = (u16)((s9->unk_8));
                if (((t9 >> 8) & 1) != 0) {
                ctx->unk_03 = 0x1b;
            } else if (((t9 >> 11) & 1) != 0 && (w->unk_08 & 2) == 0) {
                if (ctx->unk_05 == 3 && ctx->unk_0C != 0) {
                    s32 r;
                    do {
                        r = CARDUnmount(ctx->unk_00);
                    } while (r == -1);
                    fn_1_46B4(lbl_801A6410, ctx->unk_0C, data + 0x6cf0, 0x1736);
                    ctx->unk_07 = 0;
                    ctx->unk_0C = 0;
                    {
                        UnkWork_1_B277C *wp = ctx->unk_24;
                        wp->unk_1C = 0;
                        wp->unk_18 = 0;
                    }
                }
                if (ctx->unk_06 != 0xff) {
                    ctx->unk_03 = ctx->unk_06;
                    ctx->unk_06 = 0xff;
                } else {
                    ctx->unk_03 = ctx->unk_05;
                }
                ctx->unk_08 = -1;
                ctx->unk_0A = -1;
                ctx->unk_2A &= ~4;
                self = (u8 *)p + 8;
                if ((u8 *)ctx == self) {
                    p->unk_1F1 = 0;
                } else if ((u8 *)ctx == self + 0xa0) {
                    p->unk_1F1 = 1;
                }
            } else if (((s9->unk_8 >> 10) & 1) != 0) {
                UnkWork_1_B277C *w3 = ctx->unk_24;
                if ((w3->unk_08 & 0x400) != 0) {
                    ctx->unk_03 = 5;
                    ctx->unk_24->unk_08 &= 0xfffffbff;
                    ctx->unk_24->unk_08 |= 0x200;
                    ctx->unk_2A &= ~4;
                    ctx->unk_2A |= 0x10;
                }
            }
            }
            p->unk_5C49 = 0;
            break;
        }
        case 27:
            ctx->unk_02 = 0xfe;
            break;
        case 3: {
            s8 v1 = ctx->unk_01;
            if (v1 == -0x7f) {
                ctx->unk_24->unk_04 = v1;
                ctx->unk_03 = 1;
            } else {
                UnkWork_1_B277C *w = ctx->unk_24;
                switch (w->unk_04) {
                case -5:
                    w->unk_08 |= 2;
                case -128:
                case -3:
                case -2:
                    ctx->unk_03 = 1;
                    break;
                case -13:
                    if ((w->unk_08 & 0x8000) != 0) {
                        ctx->unk_2A |= 4;
                        ctx->unk_02 = 0xfe;
                    } else if (lbl_801A66B4 == 5) {
                        ctx->unk_03 = 5;
                    } else {
                        w->unk_08 |= 0x400;
                        ctx->unk_03 = 1;
                    }
                    break;
                case -6:
                case 0:
                    ctx->unk_03 = 4;
                    break;
                case -1:
                    break;
                default:
                    ctx->unk_03 = 0;
                    break;
                }
            }
            break;
        }
        case 38:
            ctx->unk_03 = 3;
            break;
        case 4: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -5:
                w->unk_08 |= 2;
            case -128:
            case -3:
                ctx->unk_03 = 1;
                break;
            case -6:
                if ((w->unk_08 & 0x8000) != 0) {
                    ctx->unk_2A |= 4;
                    ctx->unk_02 = 0xfe;
                } else {
                    ctx->unk_03 = 5;
                }
                break;
            case -13:
                if ((w->unk_08 & 0x8000) != 0) {
                    ctx->unk_2A |= 4;
                    ctx->unk_02 = 0xfe;
                } else if (lbl_801A66B4 == 5) {
                    ctx->unk_03 = 5;
                } else {
                    w->unk_08 |= 0x400;
                    ctx->unk_03 = 1;
                }
                break;
            case 0:
                ctx->unk_03 = 7;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 5: {
            UnkWork_1_B277C *w = ctx->unk_24;
            if (w->unk_04 != 0) {
                s32 flag;
                if ((ctx->unk_2A & 1) == 0) {
                    ctx->unk_28 = 0x0c;
                    flag = 0;
                    ctx->unk_2A |= 1;
                } else {
                    s8 c = ctx->unk_28;
                    if (c > 0) {
                        ctx->unk_28 = c - 1;
                        flag = 0;
                    } else {
                        flag = 1;
                    }
                }
                if (flag != 0) {
                    w = ctx->unk_24;
                    if (w->unk_04 == 2 || *(u8 *)((u8 *)w + 1) == 1) {
                        w->unk_04 = -0x7e;
                        ctx->unk_03 = 1;
                    } else {
                        ctx->unk_03 = 6;
                        ctx->unk_24->unk_08 |= 0x200;
                    }
                }
            }
            break;
        }
        case 6: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -5:
                w->unk_08 |= 2;
            case -128:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0:
                ctx->unk_03 = 0x16;
                ctx->unk_24->unk_08 &= 0xfffffdff;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 22: {
            UnkWork_1_B277C *w = ctx->unk_24;
            u32 v = w->unk_08;
            if ((v & 4) != 0) {
                s32 flag;
                if ((v & 8) == 0) {
                    ctx->unk_28 = 0x2d;
                    flag = 0;
                    ctx->unk_24->unk_08 |= 8;
                } else {
                    s8 c = ctx->unk_28;
                    if (c > 0) {
                        ctx->unk_28 = c - 1;
                        flag = 0;
                    } else {
                        flag = 1;
                    }
                }
                if (flag != 0) {
                    ctx->unk_03 = 0x1b;
                }
            } else if (((lbl_1_bss_9F8.unk_8 >> 8) & 1) != 0) {
                ctx->unk_03 = 0x1b;
            }
            ctx->unk_24->unk_04 = -0x79;
            break;
        }
        case 7: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0:
                ctx->unk_03 = 0x19;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 25:
        case 33: {
            UnkWork_1_B277C *w = ctx->unk_24;
            w->unk_B8 = 0xffffffff;
            w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -3:
                ctx->unk_03 = 1;
                break;
            case -10:
            case -4:
                ctx->unk_2C++;
                break;
            case 0:
                if (ctx->unk_2C < 0x7f) {
                    if ((ctx->unk_24->unk_E8 & 4) != 0) {
                        fn_1_B22AC((MemcardCtx *)ctx, 2);
                    }
                    if ((ctx->unk_24->unk_E8 & 0x10) != 0) {
                        fn_1_B22AC((MemcardCtx *)ctx, 4);
                    }
                    if ((ctx->unk_24->unk_E8 & 0x20) != 0) {
                        fn_1_B22AC((MemcardCtx *)ctx, 5);
                    }
                    ctx->unk_2C++;
                }
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            if (ctx->unk_2C >= 0x7f || ctx->unk_03 != 0xff) {
                w = ctx->unk_24;
                *(u32 *)(((((((((ctx->unk_2D * 0x30)))) + (((((0x24)))) + (((((u8 *)w->unk_94)))))))))) = 0;
                if (ctx->unk_03 == 0xff) {
                    ctx->unk_03 = 0x13;
                }
            }
            w = ctx->unk_24;
            if (w->unk_B8 != 0xffffffff) {
                ctx->unk_03 = 0xa;
            }
            break;
        }
        case 10: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -10:
            case -6:
            case -3:
                ctx->unk_03 = 1;
                if (ctx->unk_24->unk_04 == -6) {
                    p->unk_1F9 = 1;
                }
                break;
            case -4:
                ctx->unk_03 = 0x12;
                break;
            case 0:
                ctx->unk_03 = 0x0e;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 18: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -5:
                w->unk_08 |= 2;
            case -128:
            case -12:
            case -10:
            case -7:
            case -3:
                ctx->unk_03 = 1;
                break;
            case -4:
                if ((w->unk_08 & 0x100) != 0) {
                    ctx->unk_03 = 0x1f;
                } else {
                    ctx->unk_03 = 1;
                }
                break;
            case 0:
                ctx->unk_03 = 0x0a;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 31: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -6:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0:
                w->unk_04 = -4;
                ctx->unk_03 = 1;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 14: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -10:
            case -4:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0: {
                u8 *a;
                UnkWork_1_B277C *p2;
                ctx->unk_03 = 0x17;
                p2 = ctx->unk_24;
                a = p2->unk_94;
                p2->unk_94 = p2->unk_DC;
                p2->unk_DC = a;
                p->unk_00 = 1;
                break;
            }
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 23: {
            s32 off;
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -14:
            case -11:
            case -10:
            case -4:
            case -3: {
                u8 *a;
                UnkWork_1_B277C *p2;
                ctx->unk_03 = 1;
                p2 = ctx->unk_24;
                a = p2->unk_94;
                p2->unk_94 = p2->unk_DC;
                p2->unk_DC = a;
                p->unk_00 = 0;
                break;
            }
            case 0: {
                u16 r;
                w = ctx->unk_24;
                r = (u16)fn_1_1563E8((u32)w->unk_94 + 2, w->unk_0C - 2);
                if (*(u16 *)ctx->unk_24->unk_94 != r ||
                    (((u8 *)ctx->unk_24->unk_94)[2] == 5 &&
                     ((u8 *)ctx->unk_24->unk_94)[3] != ((const u8 *)lbl_1_rodata_4AE0)[0x1ba])) {
                    ctx->unk_03 = 0x21;
off = ctx->unk_2D;
off *= 0x30;
fzgx_live = ctx->unk_24;
rec = record_address((u8 *)fzgx_live->unk_DC, off);
                    if (*(s16 *)&lbl_1_bss_960 != 1) {
                        rec[0] = 1;
                    } else {
                        fn_1_46B4(lbl_801A6410, *(u32 *)(rec + 0x2c), data + 0x6cf0, 0x1933);
                        *(u32 *)(rec + 0x2c) = 0;
                        if (ctx->unk_24->unk_94 != 0) {
                            fn_1_46B4(lbl_801A6410, (u32)ctx->unk_24->unk_94, data + 0x6cf0, 0x1936);
                            ctx->unk_24->unk_94 = 0;
                        }
                        fn_80008BEC(rec, 0, 0x30);
                        ctx->unk_2D--;
                    }
                    p->unk_1F9 = 1;
                } else {
((u8 *)ctx->unk_24->unk_DC)[ctx->unk_2D * 0x30 - 0x30] = 0;
                    ctx->unk_03 = 8;
                }
                {
                    u8 *a;
                    UnkWork_1_B277C *p2;
                    p2 = ctx->unk_24;
                    a = p2->unk_94;
                    p2->unk_94 = p2->unk_DC;
                    p2->unk_DC = a;
                    p->unk_00 = 0;
                }
                break;
            }
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 8: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -5:
                w->unk_08 |= 2;
            case -128:
            case -10:
            case -3:
                ctx->unk_03 = 1;
                break;
            case -4:
            case 0:
                ctx->unk_03 = 9;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 9: {
            UnkBuf8_1_B277C buf8;
            UnkOut16_1_B277C out;
            UnkHdr10_1_B277C hdr10;
            s32 off;
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -6:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0: {
                u8 *dc;
                off = ctx->unk_2D;
                rec = fn_1_B277C_address_18218((u8 *)w->unk_94, (off * 0x30 - 0x30));
                ctx->unk_03 = 0x21;
                dc = ctx->unk_24->unk_DC;
                if (*(s16 *)&lbl_1_bss_960 == 2) {
                    if (rec[1] == 2) {
                        hdr10.m0 = dc[0x2060];
                        hdr10.m1 = dc[0x2061];
                        hdr10.m2 = dc[0x2084];
                        hdr10.m3 = dc[0x2085];
                        hdr10.m4 = *(u16 *)(dc + 0x2086);
                        hdr10.m5 = dc[0x2064];
                        hdr10.m6 = dc[0x2065];
                        hdr10.m7 = dc[0x2066];
                        hdr10.m8 = dc[0x2067];
                        if (dc != 0) {
                            fn_1_46B4(lbl_801A6410, (u32)dc, data + 0x6cf0, 0x19aa);
                            ctx->unk_24->unk_DC = 0;
                        }
                        if (*(u32 *)(rec + 0x2c) != 0) {
                            fn_1_46B4(lbl_801A6410, *(u32 *)(rec + 0x2c), data + 0x6cf0, 0x19ae);
                            *(u32 *)(rec + 0x2c) = 0;
                        }
                        *(u32 *)(rec + 0x2c) = fn_1_4630(lbl_801A6410, 0x0a, data + 0x6cf0, 0x19b1);
                        fn_80008BA8(*(u32 *)(rec + 0x2c), (u32)&hdr10, 0x0a);
                    } else if (rec[1] == 5) {
                        if (*(u32 *)(rec + 0x2c) != 0) {
                            fn_1_F4810(dc + 0x2060, &out.m0, &out.m5, &out.m2, &out.m3,
                                       &out.m4, &out.m1, &out.m9, &out.m13);
                            buf8.m0 = out.m0;
                            buf8.m1 = out.m3;
                            buf8.m2 = out.m4;
                            buf8.m3 = out.m5;
                            buf8.m4 = out.m9;
                            buf8.m5 = out.m13;
                            buf8.m6 = out.m14;
                            buf8.m7 = out.m15;
                            if (ctx->unk_24->unk_DC != 0) {
                                fn_1_46B4(lbl_801A6410, (u32)ctx->unk_24->unk_DC, data + 0x6cf0, 0x19cb);
                                ctx->unk_24->unk_DC = 0;
                            }
                            fn_1_46B4(lbl_801A6410, *(u32 *)(rec + 0x2c), data + 0x6cf0, 0x19ce);
                            *(u32 *)(rec + 0x2c) = 0;
                        }
                        *(u32 *)(rec + 0x2c) = fn_1_4630(lbl_801A6410, 8, data + 0x6cf0, 0x19d1);
                        fn_80008BA8(*(u32 *)(rec + 0x2c), (u32)&buf8, 8);
                    }
                } else {
                    fn_80008BA8(*(u32 *)(rec + 0x2c), (u32)(dc + 0x2060), ctx->unk_24->unk_B8);
                    if (ctx->unk_24->unk_DC != 0) {
                        fn_1_46B4(lbl_801A6410, (u32)ctx->unk_24->unk_DC, data + 0x6cf0, 0x19d9);
                        ctx->unk_24->unk_DC = 0;
                    }
                }
                break;
            }
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 19: {
            UnkWork_1_B277C *w = ctx->unk_24;
            switch (w->unk_04) {
            case -128:
            case -6:
            case -3:
                ctx->unk_03 = 1;
                break;
            case 0:
                ctx->unk_03 = 0x1a;
                break;
            case -1:
                break;
            default:
                ctx->unk_03 = 0;
                break;
            }
            break;
        }
        case 26: {
            UnkWork_1_B277C *w = ctx->unk_24;
            u32 v = w->unk_08;
            if ((v & 4) != 0) {
                s32 flag;
                if ((v & 8) == 0) {
                    ctx->unk_28 = 0x2d;
                    flag = 0;
                    ctx->unk_24->unk_08 |= 8;
                } else {
                    s8 c = ctx->unk_28;
                    if (c > 0) {
                        ctx->unk_28 = c - 1;
                        flag = 0;
                    } else {
                        flag = 1;
                    }
                }
                if (flag != 0) {
                    u32 t4 = ctx->unk_24->unk_04;
                    (*(u32 volatile *)&(p->unk_1F4)) /* Retail stores before the call reload. */ = t4;
                    fn_1_46B4(lbl_801A6410, (u32)(*(UnkWork_1_B277C * volatile *)&(ctx->unk_24)) /* Retail reloads after the store. */, data + 0x6cf0, 0x3ec);
                    ctx->unk_24 = 0;
                    ctx->unk_02 = 0xff;
                    ctx->unk_03 = 0xff;
                    ctx->unk_04 = 0xff;
                    ctx->unk_05 = 0xff;
                    ctx->unk_06 = 0xff;
                    ctx->unk_07 = 0;
                    ctx->unk_08 = -1;
                    ctx->unk_0A = -1;
                    ctx->unk_30 = 0;
                    ctx->unk_34 = lbl_1_rodata_4CA8;
                    ctx->unk_38 = lbl_1_rodata_4CA8;
                    ctx->unk_2A &= ~4;
                    p->unk_5C08 = 0;
                    p->unk_1F8 = 1;
                }
            } else if (((lbl_1_bss_9F8.unk_8 >> 8) & 1) != 0) {
                (*(u32 volatile *)&(p->unk_1F4)) /* Retail stores before the call reload. */ = ctx->unk_24->unk_04;
                fn_1_46B4(lbl_801A6410, (u32)(*(UnkWork_1_B277C * volatile *)&(ctx->unk_24)) /* Retail reloads after the store. */, data + 0x6cf0, 0x3ec);
                ctx->unk_24 = 0;
                ctx->unk_02 = 0xff;
                ctx->unk_03 = 0xff;
                ctx->unk_04 = 0xff;
                ctx->unk_05 = 0xff;
                ctx->unk_06 = 0xff;
                ctx->unk_07 = 0;
                ctx->unk_08 = -1;
                ctx->unk_0A = -1;
                ctx->unk_30 = 0;
                ctx->unk_34 = lbl_1_rodata_4CA8;
                ctx->unk_38 = lbl_1_rodata_4CA8;
                ctx->unk_2A &= ~4;
                p->unk_5C08 = 0;
                p->unk_1F8 = 1;
            }
            break;
        }
        }
        if (ctx->unk_24 != 0) {
            p->unk_1F4 = ctx->unk_24->unk_04;
        }
    }
}
#pragma opt_lifetimes reset

#pragma opt_propagation reset

#pragma opt_dead_assignments reset

#pragma opt_common_subs reset
