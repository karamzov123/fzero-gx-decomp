#include "types.h"
#include "rel/main_rel/globals.h"
#include "rel/main_rel/accessory.h"
extern void *fn_80077B14(void *);
extern void lbl_8006DBAC(void *);
extern void fn_8006E250(void *, void *);
extern void fn_1_10846C(void);
extern f32 lbl_1_rodata_7B1C;
extern f32 lbl_1_rodata_7B20;
extern s32 fn_1_14D670(void);
extern u32 lbl_801A66A0;
extern s32 fn_1_86678(s32 arg);
extern u32 lbl_1_bss_897AC[1741];
extern u32 lbl_1_bss_897A4;
extern u32 lbl_1_bss_897A8;
extern void * lbl_801A6410;
extern void lbl_8006DAEC(void);
extern void lbl_8006DBE4(void);
extern void lbl_8006E1B0(void *, void *);
extern void lbl_8006DC20(void);
extern const f64 lbl_1_rodata_7BF8;
extern void fn_80008BA8(void *dst, void *src, int size);
extern void *fn_1_45D0(void *manager, int type, void *data, int code);
extern void fn_1_105744(void);
extern void fn_1_106DB4(void);
extern void fn_1_9D0EC(u32, u32, void*, void*);
extern void fn_1_103AA8(void);
extern u32 lbl_1_bss_85288[2];
extern void fn_1_103AD4(void);
extern void fn_1_105768(void);
extern void fn_1_9E5B8(void *);
extern f32 lbl_1_rodata_7B58[40];
extern u8 lbl_1_rodata_8058[16];
extern int mathutil_mtxA_rotate_z__fzgx_offset_C();
extern struct fn_1_129D9C_system *lbl_801A6D00;
extern void lbl_8006DCA4(void);
extern void lbl_8006E1C0(void *, void *);
extern void lbl_8006DFC4(void *);
extern void lbl_8006D7B0(void);
extern void lbl_8006D668(void *);
extern void lbl_8006E0B4(f32, f32, f32);
extern void lbl_8006E14C(f32);
extern void lbl_8006DB74(void *);
extern void fn_80072558(void);
extern void fn_80083DB0(void *, void *);
extern void *fn_1_55210(void *);
extern void *fn_1_548AC(u32);
extern void *fn_1_5448C(void *);
extern void fn_1_5489C(void *, void *);
extern void fn_1_12A0E0();

#include "psvec.h"
#include "font.h"

extern f64 __fabs(f64);

typedef struct {
    u8 r, g, b, a;
} Color_12907C;

#pragma section code_type ".fzgxpool"
static void fzgx_pool_layout(void) {
    volatile f32 s; /* fzgx-allow: S2 pool primer sink: fixes the TU literal order */
    s = 0.0f;
    s = -4.8f;
}
#pragma section code_type ".text"

typedef struct {
    u8 pad_0[0x104];
    u16 angle;   /* 0x104 */
    u8 pad_106[2];
    f32 height;  /* 0x108 */
} Car_12907C;

typedef struct {
    f32 x, y, z;
} Vec_12907C;

extern FontDrawPacket lbl_1_rodata_26F8;
extern u32 fn_1_5910(void);
extern s32 fn_1_6B48(u32 index);
extern s32 fn_1_6EC0(u8);
extern void fn_1_12999C(void);
extern u32 fn_1_864E8(s32);
extern u32 fn_1_3F7E0(void);
extern u32 fn_1_86810(s32);
extern Car_12907C *fn_1_8627C(s32);
extern void fn_1_A714C(f32 *, f32 *, f32 *, f32 *);
extern f32 fn_1_A71BC(void);
extern void fn_1_862D4(s32, Vec_12907C *);
extern void lbl_8006D9D8(void *);
extern void lbl_8006D7B0(void);
extern s32 camera_get_state(void);
extern s32 lbl_8006D24C(f32, f32);
extern s32 fn_1_485A8(s32);

/* Translate the locked-cache matrix along its y column: m[i][3] += m[i][1] * y. */
static inline void mtxA_translate_y(f32 y) {
    f32 *mtx = (f32 *)0xE0000000;  /* fzgx-allow: A2 locked matrix */
    f32 s = y;
    f32 x0, x1, y0, y1, z0, z1;
    x0 = mtx[1];
    x1 = mtx[3];
    y0 = mtx[5];
    y1 = mtx[7];
    z0 = mtx[9];
    z1 = mtx[11];
    x0 = x0 * s + x1;
    y0 = y0 * s + y1;
    z0 = z0 * s + z1;
    mtx[3] = x0;
    mtx[7] = y0;
    mtx[11] = z0;
}


#pragma opt_propagation off
#pragma opt_lifetimes off
#define CLAMP(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))
/* base + x * rate, kept unfused. */
static inline f32 remap(f32 x, f32 base, f32 rate) {
    return base + (f32)(x * rate);
}

void fn_1_12907C(void) {
    s32 player;
    f32 dist;
    u32 target;
    s16 id;
    s16 angle;
    s32 count;
    f32 dh;
    f32 height;
    s16 tilt;
    f32 scale;
    f32 h;
    f32 dummy;
    f32 aspect;
    Vec_12907C pos;
    Vec_12907C v;
    f32 inv;
    f32 y;
    f32 x;
    f32 sx;
    f32 sy;
    f32 m;
    f32 size;
    f32 fov;
    FontDrawPacket packet;
    s8 mode;

    player = fn_1_5910();
    dist = ((f32 *)&lbl_1_bss_89770)[player];
    target = ((u32 *)&lbl_1_bss_89760)[player];
    id = fn_1_6B48(player);
    if (fn_1_6EC0(player) == 0) {
        return;
    }
    fn_1_12999C();
    if (dist < -100.0f) {
        return;
    }
    if (0.0f == dist) {
        return;
    }
    if (fn_1_864E8(id) & 0x10880) {
        return;
    }
    if (fn_1_864E8(target) & 0x8000880) {
        return;
    }
    count = fn_1_3F7E0();
    if ((u8)fn_1_86810(id) + 1 >= count) {
        return;
    }
    height = fn_1_8627C(target)->height;
    {
        Car_12907C *car = fn_1_8627C(id);
        dh = height - car->height;
        tilt = (s16)car->angle;
    }
    scale = 1.0f;
    if (dh > 40.0f) {
        return;
    }
    if (dh < -40.0f) {
        return;
    }
    if (tilt > 0x3000) {
        return;
    }
    if (tilt < -0x3000) {
        return;
    }
    fn_1_A714C(&dummy, &h, &dummy, &dummy);
    fov = fn_1_A71BC();
    aspect = 1.0f / h;
    fn_1_862D4(target, &pos);
    lbl_8006D9D8(&pos);
    lbl_8006D7B0();
    mtxA_translate_y(0.2f);
    psvec_set(&v, ((f32 *)0xE0000000)[11], ((f32 *)0xE0000000)[7], ((f32 *)0xE0000000)[3]);  /* fzgx-allow: A2 locked matrix */
    if (v.z > -1.0f) {
        v.z = -1.0f;
    }
    inv = -1.0f / v.z;
    sx = aspect * (inv * (v.x * fov));
    sy = inv * (v.y * fov);
    mode = camera_get_state();
    y = 445.0f;
    switch (mode) {
    case 0:
        x = 320.0f + (f32)(20.0f * sx);
        if (x < 15.0f) {
            x = 15.0f;
        } else if (x > 625.0f) {
            x = 625.0f;
        }
        break;
    case 1:
        switch (player) {
        case 0:
            {
                f32 t = 320.0f + (f32)(90.0f * sx);
                x = (t < 15.0f) ? 15.0f : ((t > 625.0f) ? 625.0f : t);
            }
            y = 225.0f;
            break;
        case 1:
            {
                f32 t = 320.0f + (f32)(90.0f * sx);
                x = (t < 15.0f) ? 15.0f : ((t > 625.0f) ? 625.0f : t);
            }
            break;
        }
        break;
    case 2:
        x = 10.0f * sx;
        switch (player) {
        case 0:
            x += 160.0f;
            if (x < 18.0f) {
                x = 18.0f;
            } else if (x > 302.0f) {
                x = 302.0f;
            }
            break;
        case 1:
            x += 480.0f;
            if (x < 338.0f) {
                x = 338.0f;
            } else if (x > 622.0f) {
                x = 622.0f;
            }
            break;
        }
        break;
    case 3:
        switch (player) {
        case 0:
            {
                f32 t = 320.0f + (f32)(20.0f * sx);
                x = (t < 15.0f) ? 15.0f : ((t > 625.0f) ? 625.0f : t);
            }
            y = 225.0f;
            break;
        case 1:
            {
                f32 t = 160.0f + (f32)(10.0f * sx);
                x = (t < 10.0f) ? 10.0f : ((t > 310.0f) ? 310.0f : t);
            }
            scale = 0.5f;
            break;
        case 2:
            {
                f32 t = 480.0f + (f32)(10.0f * sx);
                x = (t < 330.0f) ? 330.0f : ((t > 630.0f) ? 630.0f : t);
            }
            scale = 0.5f;
            break;
        }
        break;
    case 4:
        switch (player) {
        case 1:
            {
                f32 t = 320.0f + (f32)(20.0f * sx);
                x = (t < 15.0f) ? 15.0f : ((t > 625.0f) ? 625.0f : t);
            }
            y = 225.0f;
            break;
        case 0:
            {
                f32 t = 160.0f + (f32)(10.0f * sx);
                x = (t < 10.0f) ? 10.0f : ((t > 310.0f) ? 310.0f : t);
            }
            scale = 0.5f;
            break;
        case 2:
            {
                f32 t = 480.0f + (f32)(10.0f * sx);
                x = (t < 330.0f) ? 330.0f : ((t > 630.0f) ? 630.0f : t);
            }
            scale = 0.5f;
            break;
        }
        break;
    case 5:
        switch (player) {
        case 2:
            {
                f32 t = 320.0f + (f32)(20.0f * sx);
                x = (t < 15.0f) ? 15.0f : ((t > 625.0f) ? 625.0f : t);
            }
            y = 225.0f;
            break;
        case 0:
            {
                f32 t = 160.0f + (f32)(10.0f * sx);
                x = (t < 10.0f) ? 10.0f : ((t > 310.0f) ? 310.0f : t);
            }
            scale = 0.5f;
            break;
        case 1:
            {
                f32 t = 480.0f + (f32)(10.0f * sx);
                x = (t < 330.0f) ? 330.0f : ((t > 630.0f) ? 630.0f : t);
            }
            scale = 0.5f;
            break;
        }
        break;
    case 6:
    case 8:
        x = 20.0f * sx;
        scale = 0.5f;
        switch (player) {
        case 0:
            x += 160.0f;
            if (x < 10.0f) {
                x = 10.0f;
            } else if (x > 310.0f) {
                x = 310.0f;
            }
            y = 225.0f;
            break;
        case 1:
            x += 480.0f;
            if (x < 330.0f) {
                x = 330.0f;
            } else if (x > 630.0f) {
                x = 630.0f;
            }
            y = 225.0f;
            break;
        case 2:
            x += 160.0f;
            if (x < 10.0f) {
                x = 10.0f;
            } else if (x > 310.0f) {
                x = 310.0f;
            }
            break;
        case 3:
            x += 480.0f;
            if (x < 330.0f) {
                x = 330.0f;
            } else if (x > 630.0f) {
                x = 630.0f;
            }
            break;
        }
        break;
    }
    m = (__fabs(sx) > __fabs(sy)) ? __fabs(sx) : __fabs(sy);
    if (m > 0.8f) {
        f32 k = 0.8f / m;
        v.x *= k;
        v.y *= k;
        angle = lbl_8006D24C(v.y - (f32)(0.2f * k), v.x) + 0x4000;
    } else {
        angle = lbl_8006D24C(v.y - (f32)(0.2f * m), v.x) + 0x4000;
    }
    packet = lbl_1_rodata_26F8;
    if (fn_1_485A8(0x94)) {
        packet.image = 0x944F;
    } else if (fn_1_485A8(0x97)) {
        packet.image = 0x9732;
    }
    if ((s32)packet.image != 0) {
        static const Color_12907C color = {0xFF, 0x88, 0x33, 0x88};
        size = CLAMP(remap(-dist, 1.0504202f, -0.010504202f), 0.5f, 1.0f);
        size *= scale;
        packet.x = x;
        packet.y = y;
        packet.z = 1.0f;
        packet.rotation_z = angle / 2;
        packet.scale_x *= size;
        packet.scale_y *= size;
        *(Color_12907C *)packet.color = color;
        packet.flags = 10;
        fn_1_4F734(&packet);
    }
}
#pragma opt_lifetimes reset
#pragma opt_propagation reset

#include "types.h"

struct Vec3 { f32 x; f32 y; f32 z; };
struct Obj_t {
 u32 unk_0; u8 pad_4[0x148]; u8 unk_14C[4]; u8 pad_150[0x325];
 s8 unk_475; u8 pad_476[0x26]; u32 unk_49C;
};
struct Ref { u8 pad_0[0x10]; u8 unk_10; u8 pad_11[7]; };
struct E30 { u8 pad[0x30]; };
struct Pool {
 f32 unk_0; u8 pad_4[0xC]; f32 unk_10; u8 pad_14[0x3C]; f32 unk_50; u8 pad_54[0x24];
 u32 unk_78; u32 unk_7C; u32 unk_80; u32 unk_84; u32 unk_88; u32 unk_8C; s32 unk_90; u32 unk_94;
 u8 pad_98[0x8]; u32 unk_A0; u32 unk_A4; s32 unk_A8; f32 unk_AC; f32 unk_B0; u8 pad_B4[0x4];
 f64 unk_B8; f32 unk_C0; f32 unk_C4; f32 unk_C8; f32 unk_CC; f32 unk_D0; f32 unk_D4;
 f32 unk_D8; f32 unk_DC; f32 unk_E0;
};
extern const struct Pool lbl_1_rodata_8068;
extern struct E30 lbl_1_bss_7CA58[168];
extern s8 lbl_1_bss_9C[8];
extern u8 lbl_1_bss_89780[32];
extern s32 lbl_801A66B4;
extern s16 fn_1_3F0C8(void);
extern s32 fn_1_F2F34(void);
extern void fn_1_3EF14(void *);
extern f32 fn_1_A71AC(void);
extern s32 fn_1_40B20(void);
extern void *fn_1_86254(s32);
extern u32 fn_1_5910(void);
extern s32 fn_1_12A24C(s8);
extern void fn_1_862A8(s32, struct Vec3 *);
extern u8 fn_1_D66BC(void *, void *);
extern void fn_1_129D9C(void *, struct Vec3 *, u8 *, void *, u8, u8, u8, f32);
extern s32 fn_1_F1D60(void);
extern s32 fn_1_4C10(void);
extern u8 *fn_1_F1C54(u32);
extern u32 fn_1_EB0B0(void);
extern u8 *fn_80083970(u8 *, const u8 *);
void fn_1_12999C(void) {
 s32 i;
 u32 t3C[3];
 u32 t2C[4];
 struct Vec3 v20;
 struct Vec3 v14;
 struct Vec3 v8;
 u8 o48[0x18];
 u8 buf[5296];
 struct Pool *p = (struct Pool *)&lbl_1_rodata_8068;
 u8 *sub;
 s32 n;
 s32 mode = 1;
 struct Obj_t *o;
 f32 val;
 s8 idx;
 u8 self;
 u32 j;
 u8 *q;
 f32 lab_t7;
 t3C[0]=p->unk_78; t3C[1]=p->unk_7C; t3C[2]=p->unk_80;
 t2C[0]=p->unk_84; t2C[1]=p->unk_88; t2C[2]=p->unk_8C; t2C[3]=p->unk_90;
 if (*(s16 *)&lbl_1_bss_960 != 2 && *(s16 *)&lbl_1_bss_960 != 9) return;
 if (fn_1_3F0C8() != 41) {
 switch (fn_1_3F0C8()) {
 case 40: break;
 /* Unsupported machine: branch to the shared function exit. */
 default: goto end;
 }
 }
 {
 if (fn_1_F2F34() != 0) return;
 fn_1_3EF14(buf);
 val=fn_1_A71AC();
 n=fn_1_40B20();
 if (*(s16 *)&lbl_1_bss_960 == 9) mode=lbl_1_bss_9C[7];
 for(i=0;i<(s32)buf[9];i++) {
 o=(struct Obj_t *)fn_1_86254(i);
 if(o->unk_0 & 0x8000880) continue;
 sub=(u8 *)o->unk_49C;
 if(o->unk_475 != -1 && fn_1_5910() == (u32)o->unk_475) continue;
 idx=fn_1_12A24C((s8)i);
 self=(i==n);
 if(mode==0 || sub[0x115]>=3) {
 if(idx==-1 && !self) continue;
 }
 if(o->unk_0 & 0x10000) continue;
 fn_1_862A8(i,&v20);
 if(idx!=-1) {
 if(((0)[lbl_1_bss_89780]) != 0) {
 if(fn_1_D66BC((void *)(u32)(u8)idx,o48)!=0) {
 fn_1_129D9C(o->unk_14C,&v20,o48,0,0,self,0,val);
 continue;
 }
 }
 fn_1_129D9C(o->unk_14C,&v20,0,*(void **)(lbl_1_bss_38458->unk_8+t2C[idx]*8),0,self,0,val);
 continue;
 }
 if(mode!=0) {
 u8 lvl=sub[0x115];
 if(lvl<3) {
 fn_1_129D9C(o->unk_14C,&v20,0,*(void **)(lbl_1_bss_38458->unk_8+t3C[lvl]*8),0,self,0,val);
 continue;
 }
 }
 if(!self) continue;
 fn_1_129D9C(o->unk_14C,&v20,0,0,0,self,0,val);
 }
 if(fn_1_F1D60()!=0) {
 if(*(s16 *)&lbl_1_bss_960==9 && lbl_1_bss_9C[6]==-2) {
 v14.x=p->unk_0; v14.y=p->unk_10; v14.z=p->unk_0;
 fn_1_129D9C(lbl_1_bss_7CA58,&v14,0,0,1,1,0,val);
 return;
 }
 }
 if(fn_1_F1D60()!=0) {
 v8.x=p->unk_0; v8.y=p->unk_10; v8.z=p->unk_0;
 if(fn_1_4C10()==0) {
 for(j=0;j<fn_1_EB0B0();j++) {
 q=fn_1_F1C54(j);
 if(lbl_801A66B4!=5 && fn_80083970(q,(const u8 *)"\x8A\x4A\x94\xAD\x8E\xD2")!=0) q=(u8 *)&p->unk_94;
 fn_1_129D9C(&lbl_1_bss_7CA58[j],&v8,q,0,1,0,0,val);
 }
 }
 }
 }
end:
 return;
}

#include "types.h"
#include "rel/main_rel/accessory.h"

struct fn_1_129D9C_system {
    u8 pad_0[0x2C];
    f32 unk_2C;
};
struct fn_1_129D9C_chain {
    u8 pad_0[0x38];
    u32 unk_38;
    u8 pad_3C[0xC];
    u32 unk_48;
};

extern void lbl_8006DBAC(void *);

#pragma opt_common_subs off
void fn_1_129D9C(void *arg0, struct Vec3 *arg1, u8 *arg2, void *arg4,
                 u8 arg5, u8 arg6, u8 arg7, f32 arg3) {
    struct Pool *p;
    f32 v1;
    f32 v2;
    f32 d;

    p = (struct Pool *)&lbl_1_rodata_8068;
    if (arg2 != 0) {
        v1 = p->unk_AC;
    } else {
        v1 = p->unk_B0;
    }
    if (arg7) {
        v1 = p->unk_AC;
    }
    v2 = p->unk_B0 * v1;
    if (!arg5) {
        lbl_8006DCA4();
        lbl_8006E1C0(arg1, arg1);
        lbl_8006DFC4(arg0);
    } else {
        lbl_8006DBAC(arg0);
    }
    lbl_8006D7B0();
    if (__fabsf(arg1->x) > p->unk_B8 ||
        __fabsf(arg1->y) > p->unk_B8) {
        arg1->z = p->unk_0;
        lbl_8006D668(arg1);
        mathutil_mtxA_rotate_z__fzgx_offset_C(-arg1->x, arg1->y);
    }
    lbl_8006E0B4(p->unk_0, p->unk_C0, p->unk_0);
    lbl_8006E14C(v1);
    d = -lbl_801A6D00->unk_2C;
    d *= arg3;
    {
        f32 q = p->unk_C4 / d;
        if ((q * v2) < p->unk_C8) {
            v2 = d * (p->unk_C8 / v2 / p->unk_C4);
        } else if ((q * v2) > p->unk_CC) {
            v2 = d * (p->unk_CC / v2 / p->unk_C4);
        } else {
            v2 = p->unk_10;
        }
    }
    lbl_8006E14C(v2);
    if (arg7) {
        lbl_8006E0B4(p->unk_0, p->unk_D0, p->unk_0);
    }
    lbl_8006E0B4(p->unk_0, p->unk_10, p->unk_0);
    fn_80072558();
    fn_1_55210((void *)((struct fn_1_129D9C_chain *)lbl_1_bss_38458->unk_8)->unk_38);
    if (arg6) {
        lbl_8006E0B4(p->unk_0, p->unk_10, p->unk_0);
        lbl_8006D7B0();
        lbl_8006E14C(v1);
        lbl_8006E14C(v2);
        fn_80072558();
        fn_1_55210((void *)((struct fn_1_129D9C_chain *)lbl_1_bss_38458->unk_8)->unk_48);
        lbl_8006E0B4(p->unk_0, p->unk_D4, p->unk_0);
        if (arg4 == 0) {
            return;
        }
    }
    lbl_8006E0B4(p->unk_0, p->unk_10, p->unk_0);
    lbl_8006D7B0();
    lbl_8006E14C(v1);
    lbl_8006E14C(v2);
    if (arg2 != 0) {
        arg2[0x10] = 0;
        arg4 = fn_1_548AC(0x50);
        if (arg4 != 0) {
{
    u32 loc_8[3];
            loc_8[0] = p->unk_A0;
            loc_8[1] = p->unk_A4;
            loc_8[2] = p->unk_A8;
            lbl_8006DB74((u8 *)arg4 + 8);
            *(f32 *)((u8 *)arg4 + 56) = p->unk_10 / v2;
            *(void **)((u8 *)arg4 + 4) = (void *)fn_1_12A0E0;
            fn_80083DB0((u8 *)arg4 + 60, arg2);
            fn_1_5489C(fn_1_5448C(loc_8), arg4);
}
        }
    } else {
        fn_80072558();
        fn_1_55210(arg4);
    }
}
#pragma opt_common_subs reset

typedef struct Sig_fn_80015EE8_Fn80015EE8Out {
    f32 f0;
    f32 f1;
    f32 f2;
    f32 f3;
    f32 f4;
    f32 f5;
    f32 f6;
    f32 f7;
    f32 f8;
    f32 f9;
    f32 f10;
    f32 f11;
    f32 f12;
    f32 f13;
    f32 f14;
    f32 f15;
} Sig_fn_80015EE8_Fn80015EE8Out;

extern void C_MTXOrtho(Sig_fn_80015EE8_Fn80015EE8Out *, f32, f32, f32, f32, f32, f32);
extern void fn_800737E4(void *, s32);
extern void fn_80074918(u8, s32, u8);

#pragma opt_propagation off
#pragma opt_common_subs off
void fn_1_12A080(void) {
    f32 fzgx_live;
    struct Pool *pool_lbl_1_rodata_8068 = (struct Pool *)&lbl_1_rodata_8068;
    Sig_fn_80015EE8_Fn80015EE8Out out;

    fzgx_live = pool_lbl_1_rodata_8068->unk_50;
    C_MTXOrtho(&out, pool_lbl_1_rodata_8068->unk_0, fzgx_live, pool_lbl_1_rodata_8068->unk_0, pool_lbl_1_rodata_8068->unk_D8, pool_lbl_1_rodata_8068->unk_DC, pool_lbl_1_rodata_8068->unk_E0);
    fn_800737E4(&out, 1);
    fn_80074918(1, 3, 1);
}
#pragma opt_common_subs reset

#pragma opt_propagation reset

#include "dolphin/hw_regs.h"
#include "dolphin/types.h"
#include "rel/main_rel/accessory.h"
#include "psvec.h"

extern void fn_1_520A0(void);
extern void fn_1_52070(u32);
extern f32 fn_1_A71AC(void);
extern void fn_1_49410(void);
extern void fn_1_494DC(s16);
extern void fn_1_49514(u32 *);
extern void fn_1_4954C(f32);
extern void fn_1_496FC(f32, f32);
extern void fn_1_12A080(void);
extern void fn_1_49738(void (*)(void));
extern void fn_1_495FC(void);
extern void fn_1_495C8(u8);
extern void fn_1_495A0(f32);
extern void fn_1_4955C(f32, f32);
extern void fn_1_4966C(f32, f32);
extern void fn_1_4A0D8(const char *);
extern void fn_1_520CC(void);
extern void lbl_8006DBAC(void *);
extern int fn_80083BCC(const char *, const char *);
typedef struct { f32 value0, value1, value2; } Sig_fn_8006F78C_Fn8006F78CData;
extern void fn_8006F78C(void *, Sig_fn_8006F78C_Fn8006F78CData *, f32);
typedef struct {
    u8 unk_00[8];
    u8 unk_08[0x30];
    f32 unk_38;
    char unk_3C[1];
} DisplayData;

static inline f32 fn_1_12A0E0_read_pointer(Sig_fn_8006F78C_Fn8006F78CData * owner) { return owner->value1; }
#pragma opt_propagation off
#pragma opt_common_subs off
void fn_1_12A0E0(DisplayData *arg0)
{
    f32 fzgx_live;
    f32 z;
    f32 scale;
    f32 x;
    f32 y;
    u8 *pool = (u8 *)&lbl_1_rodata_8068;
    f32 depth;
    f32 size;
    Sig_fn_8006F78C_Fn8006F78CData vec;
    u32 color;
    fn_1_520A0();
    fn_1_52070(0x140);
    scale = fn_1_A71AC();
    lbl_8006DBAC(arg0->unk_08);
    fn_1_49410();
    fn_1_494DC(5);
    if (fn_80083BCC(arg0->unk_3C, "STAFF") == 0) {
        color = *(u32 *)(pool + 0xE4);
        fn_1_49514(&color);
    }
    z = *(f32 *)(LC_BASE + 0x2C);
    x = *(f32 *)(LC_BASE + 0xC);
    y = *(f32 *)(LC_BASE + 0x1C);
    depth = (f32)(*(f64 *)(pool + 0xE8) - *(f64 *)(pool + 0xF0) / z);
    psvec_set(&vec, z, y, x);
    fn_1_4954C(-depth);
    fn_8006F78C(&vec, &vec, scale);
    fzgx_live = vec.value0;
    fn_1_496FC(fzgx_live, fn_1_12A0E0_read_pointer(&vec));
    fn_1_49738(fn_1_12A080);
    fn_1_495FC();
    fn_1_495C8(0x11);
    if (arg0->unk_38 < *(f32 *)(pool + 0x60)) {
        arg0->unk_38 = *(f32 *)(pool + 0x60);
    }
    fn_1_495A0(*(f32 *)(pool + 0x6C));
    size = *(f32 *)(pool + 0xB0) * arg0->unk_38;
    fn_1_4955C(size, size);
    fn_1_4966C(*(f32 *)pool, *(f32 *)pool);
    fn_1_4A0D8(arg0->unk_3C);
    fn_1_520CC();
}
#pragma opt_common_subs reset

#pragma opt_propagation reset
