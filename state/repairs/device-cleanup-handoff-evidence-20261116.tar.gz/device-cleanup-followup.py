"""Bounded follow-up on exact cleanups through the shared repair Engine."""
import json
import re
import shlex
import sys
from pathlib import Path
root=Path('/home/armandofm/projects/fzgx-device-cleanup')
sys.path.insert(0,str(root/'tools'))
from fzgx import api, fixup, fixup_source, oracle
from fzgx.project import Project
p=Project('GFZE01')
folder=Path('/home/armandofm/.hermes/cache/scratch/device-cleanup-followup')
engine=fixup.Engine(p,folder)

def cost(body):
    helpers=len(re.findall(r'\bstatic\s+inline\s+f32\s+\w*operand\w*\s*\(',body))
    carriers=len(re.findall(r'\bstruct\s*\{\s*(?:s32|u32|f32)\s+\w+\s*;\s*\}\s*\w+\s*;',body))
    dead=int('data_base = (u32)&lbl_3_data_1A40;' in body)
    controls=len(re.findall(r'(?m)^\s*#\s*pragma\s+opt_',body))
    return helpers+carriers+dead,controls

seeds=[]
for selector in ['customize:fn_3_1D338','customize:fn_3_CE94','main_rel:fn_1_7D6B8']:
    sym=p.resolve(selector)
    unit=p.unit_of(sym)
    rec=p.unit_record(unit)
    seeds.append(engine.record(p.key(sym),api._canonical_text(p,unit),rec.get('mw_version') or oracle.module_flags(p,sym.module)[1],shlex.join(rec.get('extra_cflags') or []),label='installed accepted partial'))
rows=list(seeds)
with oracle.build_lock():
    engine.evaluate(seeds)
    for row in seeds:
        if row.get('object'):engine.check(row)
    assert all(r.get('matched') for r in seeds)
    best={r['symbol']:r for r in seeds}
    for round_index in range(3):
        candidates=[]
        seen={r['id'] for r in rows}
        for symbol,base in list(best.items()):
            body=Path(base['source']).read_text()
            name=p.resolve(symbol).name
            proposals=list(fixup_source.native_operand_helpers(body,name))+list(fixup_source.unwrap_scalar_carriers(body,name))+list(fixup_source.optimizer_directive_removals(body,name))
            # These exact admitted sources expose two known pure, unused
            # definitions and one dead address initializer. Prove no other use.
            if name=='fn_3_1D338':
                changed=body
                for helper in ['fn_3_1D338_operand__','fn_3_1D338_operand___']:
                    pattern=r'(?m)^static inline f32 '+re.escape(helper)+r'\([^\n]*\) \{ return left \* right; \}\n'
                    if len(re.findall(r'\b'+re.escape(helper)+r'\b',changed))==1:
                        changed,n=re.subn(pattern,'',changed)
                        assert n==1
                if changed!=body:proposals.append(('remove unused pure operand definitions',changed))
            if name=='fn_3_CE94' and len(re.findall(r'\bdata_base\b',body))==2:
                declaration='    u32 data_base;\n'
                assignment='    data_base = (u32)&lbl_3_data_1A40;\n'
                assert body.count(declaration)==body.count(assignment)==1
                proposals.append(('remove unused data-base local and pure initializer',body.replace(declaration,'',1).replace(assignment,'',1)))
            for label,text in proposals:
                if cost(text)>=cost(body):continue
                row=engine.record(symbol,text,base['mw'],base['flags'],parent=base['id'],label=label)
                if row['id'] not in seen:
                    seen.add(row['id']);candidates.append(row)
        if not candidates:break
        engine.evaluate(candidates)
        for row in candidates:
            if row.get('object'):engine.check(row)
        rows.extend(candidates)
        improved=False
        for row in candidates:
            if row.get('matched') and cost(Path(row['source']).read_text())<cost(Path(best[row['symbol']]['source']).read_text()):
                best[row['symbol']]=row;improved=True
        print('ROUND',round_index+1,'candidates',len(candidates),'improved',improved,flush=True)
        if not improved:break
frontier={symbol:sorted([r for r in rows if r['symbol']==symbol and not r.get('matched') and r.get('object')],key=lambda r:(r.get('word_errors',10**9),len(Path(r['source']).read_text())))[:3] for symbol in best}
report=dict(generator_sha256=engine.generator_sha256,environment=engine.environment,records=rows,best=best,frontier=frontier)
(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n')
fixup.archive_sources(report,folder/'sources.json.gz')
for name,row in best.items():print(name,row['label'],cost(Path(row['source']).read_text()))
(folder/'accepted.json').write_text(json.dumps([r for r in best.values() if r.get('parent')],indent=2)+'\n')
