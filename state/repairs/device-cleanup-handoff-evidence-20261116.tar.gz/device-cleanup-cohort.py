"""Frozen pragma-removal cohort using the existing fzgx repair Engine."""
import hashlib
import json
import re
import shlex
import sys
from pathlib import Path
root = Path('/home/armandofm/projects/fzgx-device-cleanup')
sys.path.insert(0, str(root / 'tools'))
from fzgx import api, fixup, fixup_source, oracle
from fzgx.original_assembly import source_form
from fzgx.project import Project
p = Project('GFZE01')
mode = sys.argv[1] if len(sys.argv) > 1 else '1'
semantic = mode == 'semantic'
index = 1 if semantic else int(mode)
output = Path('/home/armandofm/.hermes/cache/scratch') / ('device-cleanup-' + ('semantic' if semantic else 'cohort-' + str(index)))
engine = fixup.Engine(p, output)
census = json.loads(Path('/home/armandofm/.hermes/cache/scratch/device_census_0efb2ebad.json').read_text())
eligible = []
for name, entry in census['functions'].items():
    if entry['class'] != 'DEVICE' or name in ['_prolog', '_epilog']:
        continue
    parts = Path(entry['file']).parts
    mod = 'main' if parts[1] == 'dol' else parts[2]
    sym = p.resolve(mod + ':' + name)
    if sym is None or sym.size != entry['size']:
        continue
    unit = p.unit_of(sym)
    record = p.unit_record(unit)
    if not record or record.get('status') != 'matching' or source_form(record['source'], name, bool(record.get('asm'))) != 'c':
        continue
    body = api._canonical_text(p, unit)
    proposals = (list(fixup_source.native_operand_helpers(body, name))
                 + list(fixup_source.unwrap_scalar_carriers(body, name))) if semantic else list(fixup_source.optimizer_directive_removals(body, name))
    if proposals:
        eligible.append((sym, record, body, proposals))
previous = set()
for earlier in range(1, index):
    frozen_path = output.parent / ('device-cleanup-cohort-' + str(earlier)) / 'cohort.json'
    previous.update(row['symbol'] for row in json.loads(frozen_path.read_text())['functions'])
limit = 8 if semantic else 16
selected = sorted((item for item in eligible if p.key(item[0]) not in previous),
                  key=lambda item: (-item[0].size, p.key(item[0])))[:limit]
assert len(selected) == limit
frozen = [dict(symbol=p.key(s), size=s.size, source=r['source'], tu=r.get('tu'),
               source_sha256=hashlib.sha256(body.encode()).hexdigest(),
               compiler=r.get('mw_version') or oracle.module_flags(p, s.module)[1],
               extra_cflags=r.get('extra_cflags', []), proposals=len(proposals))
          for s, r, body, proposals in selected]
(output / 'cohort.json').write_text(json.dumps(dict(
    hypothesis='Pure float operand wrappers and anonymous scalar carriers can sometimes be replaced by ordinary arithmetic/locals.' if semantic else 'Some per-function optimizer controls are redundant after accepted source/type changes.',
    stopping_condition='Exactly eight frozen largest eligible sources; only fully exact source simplifications count.' if semantic else 'Exactly sixteen frozen largest eligible pragma candidates; extend this family only if at least two distinct functions admit an exact removal. Near-match gains do not count.',
    functions=frozen), indent=2) + '\n')
rows = []
for sym, record, body, proposals in selected:
    mw = record.get('mw_version') or oracle.module_flags(p, sym.module)[1]
    flags = shlex.join(record.get('extra_cflags') or [])
    base = engine.record(p.key(sym), body, mw, flags, label='installed baseline')
    rows.append(base)
    for label, text in proposals:
        rows.append(engine.record(p.key(sym), text, mw, flags, parent=base['id'], label=label))
with oracle.build_lock():
    engine.evaluate(rows)
    for row in rows:
        if row.get('object'):
            engine.check(row)
    # Individually redundant settings can interact. Check their combined removal
    # explicitly, and only prefer it when the complete object still matches.
    combinations = []
    for baseline in [r for r in rows if r['label'] == 'installed baseline']:
        exact = [r for r in rows if r.get('parent') == baseline['id'] and r.get('matched')
                 and r['label'].startswith('test optimizer directive removal ')]
        if len(exact) > 1:
            text = Path(baseline['source']).read_text()
            options = [r['label'].split()[-1] for r in exact]
            proposals = list(fixup_source.optimizer_directive_removals(text, p.resolve(baseline['symbol']).name))
            for option in options:
                current = dict(fixup_source.optimizer_directive_removals(text, p.resolve(baseline['symbol']).name))
                text = current['test optimizer directive removal ' + option]
            combinations.append(engine.record(baseline['symbol'], text, baseline['mw'], baseline['flags'],
                                              parent=baseline['id'], label='combined exact removals ' + ','.join(options)))
    if combinations:
        engine.evaluate(combinations)
        for row in combinations:
            if row.get('object'):
                engine.check(row)
        rows.extend(combinations)

best = {}
for row in rows:
    if row.get('matched'):
        # Prefer fewer optimizer directives, never a better score with more devices.
        text = Path(row['source']).read_text()
        controls = len(re.findall(r'(?m)^\s*#\s*pragma\s+opt_', text))
        wrappers = len(re.findall(r'\bstatic\s+inline\s+(?:f32|float)\s+\w*operand\w*\s*\(', text))
        carriers = len(re.findall(r'\bstruct\s*\{\s*(?:f32|float|s32|u32|int)\s+\w+\s*;\s*\}\s*\w+\s*;', text))
        count = (wrappers + carriers, controls) if semantic else (controls,)
        old = best.get(row['symbol'])
        if old is None or count < old[0]:
            best[row['symbol']] = (count, row)
report = dict(generator_sha256=engine.generator_sha256, environment=engine.environment,
              records=rows, best={s:r for s, (_, r) in best.items()}, frontier={})
(output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
fixup.archive_sources(report, output / 'sources.json.gz')
accepted = [r for r in report['best'].values() if r.get('parent')]
print('COHORT', len(selected), 'RECORDS', len(rows), 'EXACT CLEANUPS', len(accepted))
for base in [r for r in rows if r['label'] == 'installed baseline']:
    chosen = report['best'].get(base['symbol'])
    print(base['symbol'], 'baseline', base.get('matched'), base.get('word_errors'),
          'selected', chosen['label'] if chosen else None)
(output / 'accepted.json').write_text(json.dumps(accepted, indent=2) + '\n')
