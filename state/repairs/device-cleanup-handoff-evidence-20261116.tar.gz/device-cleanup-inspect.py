import difflib
import json
import re
import sys
from pathlib import Path
root=Path('/home/armandofm/projects/fzgx-device-cleanup')
sys.path.insert(0,str(root/'tools'))
from fzgx.project import Project
from fzgx import api
p=Project('GFZE01')
mode=sys.argv[1] if len(sys.argv)>1 else '1'
folder=Path('/home/armandofm/.hermes/cache/scratch')/('device-cleanup-'+mode if mode in ['semantic','followup'] else 'device-cleanup-cohort-'+mode)
accepted=json.loads((folder/'accepted.json').read_text())
total=0
for row in accepted:
    sym=p.resolve(row['symbol'])
    unit=p.unit_of(sym)
    old=api._canonical_text(p,unit)
    new=Path(row['source']).read_text()
    count=lambda t:len(re.findall(r'(?m)^\s*#\s*pragma\s+opt_',t))
    n=count(old)-count(new)
    total+=n
    print('\n',row['symbol'],p.unit_record(unit).get('tu'),row['label'],'directive lines removed',n)
    print(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),n=3)))
print('TOTAL',len(accepted),'functions',total,'directive lines')
report=json.loads((folder/'report.json').read_text())
for row in report['records']:
    if row['label']=='installed baseline' and not row.get('matched'):
        print('BASELINE NONEXACT',{k:v for k,v in row.items() if k not in ['regions','source_lint']})
